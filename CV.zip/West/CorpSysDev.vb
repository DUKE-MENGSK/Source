﻿Imports System.Runtime.Serialization

Namespace West
    Friend Class CorpSysDev
        Friend Class ADE
            Friend Class Framework
                Friend Class WICService
                    <Serializable>
                    Friend Class NoAgentSkillsException
                        Inherits Exception

                        Public Sub New()
                        End Sub

                        Public Sub New(message As String)
                            MyBase.New(message)
                        End Sub

                        Public Sub New(message As String, innerException As Exception)
                            MyBase.New(message, innerException)
                        End Sub

                        Protected Sub New(info As SerializationInfo, context As StreamingContext)
                            MyBase.New(info, context)
                        End Sub
                    End Class
                End Class

                Friend Class SocketService
                    Friend Class SocketUserProxy
                        Friend Sub SendMessage(userIdentifier As String, message As String)
                            Throw New NotImplementedException()
                        End Sub
                    End Class
                End Class
            End Class
        End Class

        Friend Class ADE50Logs
            Friend Class MVAdeLogger
                Public Property ProjectId As Object
                Public Property AgentId As Object
                Public Property TwoByteSiteId As Object
                Public Property CallEndTime As Date
                Public Property CallLogTime As Date
                Public Property TalkSeconds As Integer
                Public Property HoldSeconds As Integer
                Public Property WrapSeconds As Integer
                Public Property OtherSeconds As Integer
                Public Property Disposition As String

                Friend Sub AddVariableData(v As String, myLogKey As Object)
                    Throw New NotImplementedException()
                End Sub

                Friend Function GetLogXML() As String
                    Throw New NotImplementedException()
                End Function
            End Class
        End Class
    End Class
End Namespace
