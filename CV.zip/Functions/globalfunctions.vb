﻿Imports System.Web.Script.Serialization
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports System.ComponentModel
Imports System.Threading
Imports System.ComponentModel.EventHandlerList
Imports System.ComponentModel.Component

Public Class GlobalFunctions
    Inherits SLSharedLib.SLSharedFunctions

    'systxb new
    ' Session not available in globalfunctions.vb, must pass it or set it.
    Private m_SessionDataStores As DataStoreVariables
    Private m_SessionLocalStores As LocalStoreVariables
    Private m_SessionLists As BWLists
    Protected WithEvents ScriptPaths As New ScriptPath

    ' XP82260 BOA Webservice
    Private boaRoute As BOARouteCall.BOARouteCallDetail 'boa route call webservice
    Private WithEvents bgw As New BackgroundWorker 'bg worker for boa route
    Private mraServiceHelp As MRAService.MRAServiceClient 'boa mra webservice

    Private retryCtr = 0 ' iterator for current retries
    Private retryCount = 8 ' count of retry

    Dim var5var1lbl As String = ""
    Dim wsMessage As String = ""
    Dim wsSuccess As Boolean = False

    Dim callID As String = ""
    Dim appID As String = ""
    Dim BOA_VDNslist As New Dictionary(Of String, String) 'list of VDNs for Boa Route Call Default Calls
    Private GDLR As GenericDataLookup.Request
    '

    ''' <summary>
    '''
    '''
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shadows Property NGS() As DataStoreVariables
        '************************************************************************
        'Method Name: Get and Set session DataStores
        'Argument List: N/A
        'Return Type: String - returns the value of sessionDataset.
        'Scope: Public
        'Pre-Condition:  N/A.
        'Stored Procedures: N/A.
        'Description: Returns the sessionDataset.
        'Formula:
        '************************************************************************
        Get
            Return m_SessionDataStores
        End Get
        Set(ByVal Value As DataStoreVariables)
            m_SessionDataStores = Value

            'set the base session datastores to session
            MyBase.NGS = CType(Value, WestSharedFunctions.BaseDataStoreVariables)

        End Set
    End Property
    ''' <summary>
    '''
    '''
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Property LS() As LocalStoreVariables
        '************************************************************************
        'Method Name: Get and Set session LocalStores
        'Argument List: N/A
        'Return Type: String - returns the value of sessionDataset.
        'Scope: Public
        'Pre-Condition:  N/A.
        'Stored Procedures: N/A.
        'Description: Returns the sessionDataset.
        'Formula:
        '************************************************************************
        Get
            Return m_SessionLocalStores
        End Get
        Set(ByVal Value As LocalStoreVariables)
            m_SessionLocalStores = Value
        End Set
    End Property

    ''' <summary>
    '''
    '''
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Property Lists() As BWLists
        '************************************************************************
        'Method Name: Get and Set session LocalStores
        'Argument List: N/A
        'Return Type: String - returns the value of sessionDataset.
        'Scope: Public
        'Pre-Condition:  N/A.
        'Stored Procedures: N/A.
        'Description: Returns the sessionDataset.
        'Formula:
        '************************************************************************
        Get
            Return m_SessionLists
        End Get
        Set(ByVal Value As BWLists)
            m_SessionLists = Value
        End Set
    End Property

    Public Property UPC As Object
    Public Property SL As Object
    'systxb end new



    '-------------------------Script Specific Code-------------------
    Public Sub IncrementCounterRules()
        'Created:BW Conversion:5/5/2010 11:01:33 AM
        Try
            '20100823 cgossman - unplugging Tandem logging
            'Call DCC()
            'Call MaualApp()
            'Call OtherStuff()
            'Call CreditCardAutoDecline()
            'Call AutoApproval()
            'Call DISPOSITIONS()
            'Call InwardCall()
            'Call Activation()
            'Call HOMEEQUITY()
            'Call ConsumerFinance()
            'Call MailDeletion()
            'Call DataPassSolicitation()
            'Call MBNACounters()
            'Call Calltime()
            'Call SetFixedCounters()
            Me.gfIncrementNGSCounters()




        Catch ex As Exception
            Throw
        End Try
    End Sub


    Public Sub gfSignOn()
        'Created:MN2170H1:systxb:05/09/2003 10:36:38 AM
        Try
            Dim value = MyBase.SignOn()
            ' special VACD rules handling. We've hit the first and second VACD rules, and our shift has ended. Catch the exception and respond to the special condition.
        Catch Nex As West.CorpSysDev.ADE.Framework.WICService.NoAgentSkillsException
            Me.UPC.Script.FATALERROR = True
            MyBase.ResetPhoneControlState("SignOff")
            ' end, special VACD rule handling
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfSignOff()
        'Created:MN2170H1:systxb:05/09/2003 10:45:57 AM
        Try
            MyBase.SignOff()
            Me.LogSystemMessage("gfSignOff", "Clearing Numbers")
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Public Sub LogSystemMessage(v1 As String, v2 As String)
        Throw New NotImplementedException()
    End Sub

    Public Sub gfMakeReady()
        'Created:MN2170H1:systxb:05/09/2003 10:49:02 AM
        Try

            MyBase.MakeReady()
        Catch NoAgentSkillsException As West.CorpSysDev.ADE.Framework.WICService.NoAgentSkillsException
            'go to the fatal path, set script variable to keep from going to msgboard.
            'force agents to sign out on the fatalskills panel.
            Me.UPC.Script.FATALERROR = True
            'branch to the fatalerror script path in gfhandlemakeready or gfhandlemakenotready
            'make not ready
            Me.gfMakeNotReady()
            'sign off
            Me.gfSignOff()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfMakeNotReady()
        'Created:MN2170H1:systxb:05/09/2003 10:49:44 AM
        Try
            MyBase.MakeNotReady()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHold()
        'Created:MN2170H1:systxb:05/09/2003 10:50:33 AM
        Try
            MyBase.Hold()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfOffHold()
        'Created:MN2170H1:systxb:05/09/2003 10:55:08 AM
        Try
            MyBase.OffHold()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfDisconnect()
        'Created:MN2170H1:systxb:05/09/2003 10:56:02 AM
        Try
            LS.l3rdPartyOrCallerDisconConference = "N"
            LS.IsMBKNullRecorded = "N"
            Call LogSystemMessage("gfDisconnect", "Disconnect")

            If Me.UPC.Script.DEBUGON = True Then
                Me.LogSystemMessage("Script", "In  ME.gfDisconnect; " _
                     & " Disconnected flag = " & Me.UPC.Script.DISCONNECTED _
                     & ", OutboundDialBusy flag = " & Me.UPC.Script.OUTBOUNDDIALBUSY)
            End If
            'only disconnect if we're actually connected...
            If (Me.UPC.Script.DISCONNECTED.ToUpper() <> "Y") Or (Me.UPC.Script.OUTBOUNDDIALBUSY.ToUpper() = "Y") Then
                If Me.UPC.Script.DEBUGON = True Then
                    Me.LogSystemMessage("Script", " ME.gfDisconnect about to call shared DISCONNECT; " _
                         & " Disconnected flag = " & Me.UPC.Script.DISCONNECTED _
                         & ", Outdialbusy flag = " & Me.UPC.Script.OUTBOUNDDIALBUSY)
                End If
                MyBase.Disconnect()
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleRemoteDisconnect()
        'Created:MN2170H1:systxb:05/09/2003 10:57:29 AM
        Try
            MyBase.HandleRemoteDisconnect()
            'call setData  ("LocalStore", "lStatusFlag", "3" ) 
            'call setData  ("LocalStore", "lDisconnectFlag", "1" ) 
            'call Set_CurrPath ( "LOG" ) 
            'call PageDown (  ) 
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfDialThirdParty(ByVal pPhoneNumber As String, ByVal pDialType As String)
        'Created:MN2170H1:systxb:05/09/2003 11:46:51 AM
        Try
            'kp added flags 3/05, outbound conditionalizing added 9/08
            If pDialType <> "OUTBOUND" Then
                Me.LS.lthirdpartydialed = "Y"
            End If
            Me.LS.lthirdpartyanswered = "N"
            Me.LS.lConferenced = "N"
            'end kp added 3/05
            MyBase.DialThirdParty(pPhoneNumber, pDialType)
        Catch ex As Exception
        End Try
    End Sub
    Public Sub gfConference()
        'Created:MN2170H1:systxb:05/09/2003 11:43:11 AM
        Try
            LS.l3rdPartyOrCallerDisconConference = "Y"
            Call LogSystemMessage("gfConference", "Conference")
            Me.LS.lStatusFlag = "2"
            MyBase.Conference()
            'pageDown()
        Catch ex As Exception
            Me.LS.lStatusFlag = "5"
            Me.LS.lTransferNumTwo = 0
        End Try
    End Sub
    Public Sub gfTransfer()
        'Created:MN2170H1:systxb:05/09/2003 12:35:56 PM
        Try
            MyBase.Transfer()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfDisconnectThirdParty()
        'Created:MN2170H1:systxb:05/09/2003 12:36:47 PM
        Try
            Me.UPC.Script.ThirdPartyDialed = False
            LS.l3rdPartyOrCallerDisconConference = "Y" '1242019
            'kp added 3/05
            'TS 01/30 - Add if check for conference on Hold
            If Me.LS.lConferenced = "N" Then
                ' conditionalize for anything but Avaya -- ejh 5/15/2006
                If Me.UPC.System.PHONETYPE <> "CTC-AVAYA" And Me.UPC.System.PHONETYPE <> "CTC-AVAYA-PLUS" Then
                    Me.gfOffHold()
                End If
            End If
            'end kp added 3/05
            MyBase.DisconnectThirdParty()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfForceSignOff()
        'Created:MN2170H1:systxb:05/09/2003 12:37:31 PM
        Try
            MyBase.SignOff()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfLogOn()
        'Created:MN2170H1:systxb:05/09/2003 12:38:44 PM
        Try
            MyBase.LogOn()

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleNewCall()
        'Created:MN2170H1:systxb:05/09/2003 12:39:35 PM


        Try
            'log a debug message when debug on
            Me.LogSystemMessageDB("Script", "In ME.gfHandleNewCall; ScriptCallmode: " & Me.UPC.Script.SCRIPTCALLMODE, CBool(Me.UPC.Script.DEBUGON))


            MyBase.HandleNewCall()

            gfPreloads()

            LS.l3rdPartyOrCallerDisconConference = "Y"



        Catch ex As Exception
            Throw
        End Try


    End Sub
    Public Sub gfHandleSignOn()
        Try
            MyBase.HandleSignOn()

            Me.NGS.CommonLanguageScript = CType(Me.SL.ScriptSLWebserviceValues.CommonGenericDataLookup, String)

            Dim adeExp As Regex = New Regex("[a-z|A-Z]{3}[0-9]{2}[a-z|A-Z]{5,6}[0-9]{2,3}")
            Dim match As Match = adeExp.Match(Me.UPC.Configuration.PHONE_WEB_SERVICE_URL)
            If Not match.Success Then
                LogSystemMessage("MBK SIGN-ON", "Unable to get SERVER name")
                Exit Sub
            End If

            Me.NGS.SERVER = match.Value

            'Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg = String.Empty

            ''Setting Standard Web Svc URLS
            'If Not RetrieveStandardWebServiceURLS() Then
            '    ' raise exception.....
            '    Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg =
            '        "There was an error setting web service URL values.  This is not recoverable and you have been signed off.  Please notify your supervisor"
            '    gfSignOff()
            '    Exit Sub
            'End If

            'Setting Script Specific URLs
            'If Not gfSetWebServiceURLs() Then
            '    ' raise exception.....
            '    Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg =
            '        "There was an error setting web service URL values.  This is not recoverable and you have been signed off.  Please notify your supervisor"
            '    gfSignOff()
            '    Exit Sub
            'End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Public Function gfSetWebServiceURLs() As Boolean
        ' New function 09/2015 - to dynamically set Webservice URL values
        Try
            ' Set all script-specific Webservice URLs below....
            '    Use Me.UPC.ScriptSLWebServiceValues.ScriptURL01 through .ScriptURL25
            '    to hold values...DOCUMENT which of the generically named fields are
            '    being used for which web service
            'Setting ScriptSpecificWebserviceURL01 = "BOAWebIVLProd"
            If String.IsNullOrEmpty(Me.SL.ScriptSLWebserviceValues.ScriptSpecificWebserviceURL01) Then
                Me.SL.ScriptSLWebserviceValues.ScriptSpecificWebserviceURL01 = GetWebserviceValueByName("")
                If String.IsNullOrEmpty(Me.SL.ScriptSLWebserviceValues.ScriptSpecificWebserviceURL01) Then
                    LogSystemMessage("gfSetWebServiceURLs function", "Exception: <service name here> value not set")
                    Return False
                End If
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function GetWebserviceValueByName(v As String) As Object
        Throw New NotImplementedException()
    End Function

    Public Sub gfHandleSignOff()
        'Created:MN2170H1:systxb:05/09/2003 12:41:15 PM
        Try
            MyBase.HandleSignOff()
            If Me.UPC.Script.FATALERROR = True Then
                Set_CurrPath(ScriptPaths.FATAL)
                ResetPhoneControlState("loggedon")
            Else
                Set_CurrPath(ScriptPaths.MSG)
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleMakeReady()
        'Created:MN2170H1:systxb:05/09/2003 12:42:23 PM


        Try
            'log a debug message when debug on
            Me.LogSystemMessageDB("Script", "In GFHANDLEMAKEREADY, scriptcallmode: " & Me.UPC.Script.CALLMODE.ToString(), CBool(Me.UPC.Script.DEBUGON))


            MyBase.HandleMakeReady()


            'This will change the refresh frame to a page with a 4 minute check to see if the schedule has ended and in a ready state
            '05/03 Stach - Changed to allow for VACD in B&M
            'if getData("system","PHONETYPE") = "WIC" then
            If Me.UPC.Configuration.emailAddress <> "" Then
                Dim sb As New System.Text.StringBuilder(500)
                'sb.Append("parent.frames['frameRefresh'].frameElement.src = 'RefreshAfterReady.aspx';" & vbCrLf)
                'sb.Append("parent.frames['frameRefresh'].window.navigate(parent.frames['frameRefresh'].frameElement.src);" & vbCrLf)
                ' load RefreshAfterReady.aspx in same location as current window (i.e. Panels folder)
                sb.AppendLine("parent.parent.parent.frames['frameRefresh'].window.location.href = '../RefreshAfterReady.aspx';")
                sb.Append(vbCrLf)




                'Save to a script variable - to be retrieved in stdPanel - updateClientSide()
                Me.UPC.Script.clientcode = sb.ToString()


                '****make sure a set_currpath always follows
            End If


            'If there is a failed Aliaslookup, don't require the agent to log the call.
            If Me.UPC.Script.isCallLogged.ToString.Trim.Equals("N") And
             Me.UPC.Script.isDisconnected.ToString.Trim.Equals("Y") Then


                'If there is a failed Aliaslookup, don't require the agent to log the call.
                If Me.LS.lPerformedLookup.ToString.Trim.Equals("True") Then
                    ' --- Overlapping call  ---
                    Set_CurrPath(ScriptPaths.OVC)
                    Exit Sub
                End If
            End If


            InitVars()


            Me.UPC.Script.isCallLogged = "N"
            Me.UPC.Script.isDisconnected = "N"


            ' the next lines manage VACD rules hits
            Me.UPC.Script.ForceNotReadyReceived = "N"
            Me.UPC.Script.ForceSignoffReceived = "N"







            Set_CurrPath(ScriptPaths.MSG)


        Catch ex As Exception
            Throw
        End Try


    End Sub

    Private Sub InitVars()
        Throw New NotImplementedException()
    End Sub

    Public Sub gfHandleNotReady()
        'Created:MN2170H1:systxb:05/09/2003 12:43:14 PM
        Try
            'log a debug message when debug on
            If Me.UPC.Script.DEBUGON = True Then
                Me.LogSystemMessage("Script", "In ME.gfHandleNotReady, scriptcallmode: " & Me.UPC.Script.SCRIPTCALLMODE)
            End If
            MyBase.HandleNotReady()
            Set_CurrPath(ScriptPaths.MSG)
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleHold()
        'Created:MN2170H1:systxb:05/09/2003 12:44:07 PM
        Try
            MyBase.HandleHold()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleOffHold()
        'Created:MN2170H1:systxb:05/09/2003 12:45:01 PM
        Try
            MyBase.HandleOffHold()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleDisconnect()
        'Created:MN2170H1:systxb:05/09/2003 12:45:52 PM
        Try
            'cover the bases here for Avaya at Home, due to the very close scrutiny of phone states in reporting
            If Me.UPC.Script.DISCONNECTED <> "Y" Then
                'Not disconnected 
                If Me.UPC.System.PHONETYPE = "CTC-AVAYA-PLUS" Then
                    Me.SendAuxCodeToADE("ACW")
                    Me.UPC.Script.DISCONNECTED = "Y"
                End If
            End If
            If Me.UPC.Script.DEBUGON = True Then
                Me.LogSystemMessage("Script", "In GfHandleDisconnect")
            End If
            '02/20 TS - Added overlapping call code
            Me.UPC.Script.OVCcallStartTime = Me.UPC.Script.callStartTime
            Me.UPC.Script.OVCcallWrapStartTime = Now().ToString()
            Me.UPC.Script.isDisconnected = "Y"
            'End 02/20

            'add to handle duplicate disconnects, when running with avaya we send two.
            'added badoutdial check to go to logging - 
            'UA --- we set badoutdial to Y when dialing... if we get a disconnect before badoutdial goes to "N" then we still
            ' want to go to logging...
            If Me.UPC.Script.DISCONNECTED = "Y" And Me.UPC.Script.OutDialingFlag <> "Y" Then
                If Me.UPC.Script.DEBUGON = True Then
                    Me.LogSystemMessage("Script", "Disconnect Flag is Y, Outdialing flag <> Y - Exiting ME.gfHandleDisconnect...")
                End If
                Exit Sub
            End If
            If Me.LS.lReturnToCaller = "Y" Then
            Else
                Me.LS.lStatusFlag = "3"
                Me.LS.lDisconnectFlag = "1"
                'UA addition
                Me.UPC.Script.OutDialingFlag = "N"
                If Me.UPC.Script.DEBUGON = True Then
                    Me.LogSystemMessage("Script", "lReturnToCaller is N, ScriptCallmode is " & Me.UPC.Script.SCRIPTCALLMODE & ", set path to LOG and pageDown...")
                End If
                Set_CurrPath(ScriptPaths.LOG)
            End If
            If Me.LS.lDisconnectFlag = "1" Then
                If Me.UPC.Script.DEBUGON = True Then
                    Me.LogSystemMessage("Script", "lDisconnectFlag is 1, pageDown...")
                End If
                PageDown()
            End If
            'systxb - changed - gone through disconnect logic completely first time - set disconnected flag to 'y'
            If Me.UPC.Script.DEBUGON = True Then
                Me.LogSystemMessage("Script", "About to call shared HandleDisconnect...")
            End If
            MyBase.HandleDisconnect()
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub PageDown()
        Throw New NotImplementedException()
    End Sub

    Public Sub gfHandleDialThirdParty()
        'Created:MN2170H1:systxb:05/09/2003 12:46:54 PM


        Try
            'Log
            LS.l3rdPartyOrCallerDisconConference = "Y"
            Me.LogSystemMessageDB("Script", "gfHandleDialThirdParty has been raised", CBool(Me.UPC.Script.DEBUGON))

            Me.LS.lStatusFlag = "1"
            MyBase.HandleDialThirdParty()


            'PageDown()
        Catch ex As Exception
            Me.LS.lStatusFlag = "4"
            Me.LS.lTransferNumTwo = 0
            'PageDown()
        End Try


    End Sub
    Public Sub gfHandleConference()
        'Created:MN2170H1:systxb:05/09/2003 12:49:24 PM
        Try
            'call setData  ("LocalStore", "lStatusFlag", "5" ) 
            Me.LS.lStatusFlag = "2"
            MyBase.HandleOffHold()
            MyBase.HandleConference()
            'PageDown()
        Catch ex As Exception
            Me.LS.lStatusFlag = "5"
            Me.LS.lTransferNumTwo = 0
        End Try
    End Sub
    Public Sub gfHandleTransfer()
        'Created:MN2170H1:systxb:05/09/2003 12:50:40 PM
        Try
            MyBase.HandleTransfer()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleLoggedOn()
        'Created:MN2170H1:systxb:05/09/2003 12:51:40 PM
        Try
            MyBase.HandleLoggedOn()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleDisconnectThirdParty()
        'Created:MN2170H1:systxb:05/09/2003 12:52:29 PM
        Try

            LS.l3rdPartyOrCallerDisconConference = "Y" 'JUN042020 RITM0400374
            LS.IsMBKNullRecorded = "N"
            Call LogSystemMessage("gfHandleDisconnectThirdParty", "Third Party Has Been Disconnected")

            '#TEMPLATE Generated Code
            '#Changing this code is not recommended
            MyBase.HandleDisconnectThirdParty()
            '#End of Template Generated Code
            'if getData  ("LocalStore", "lStatusFlag") = "3" then
            'pageDown()
            'end if
        Catch ex As Exception
            'call gfOffHold (  )
            Throw
        End Try
    End Sub
    Public Sub gfScriptLoad()
        'Created:MN2170H1:systxb:05/09/2003 01:22:36 PM


        Try
            MyBase.ScriptLoad()

            Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg = String.Empty
            'Setting Standard Web Svc URLS 
            If Not RetrieveStandardWebServiceURLS() Then
                ' raise exception..... 
                Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg = "There was an error setting web service URL values. This is not recoverable and you have been signed off.  Please notify your supervisor"
                SendPhoneErrorToUPC(Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg)
                Exit Sub
            End If
            'Setting Script Specific URLs 
            'If Not gfSetWebServiceURLs() Then
            '    ' raise exception..... 
            '    Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg = "There was an error setting web service URL values. This is not recoverable and you have been signed off.  Please notify your supervisor"
            '    SendPhoneErrorToUPC(Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg)
            '    Exit Sub
            'End If


            '201005 lapeters  Preparing for UPC launch.  UPC handles this make ready.
            'set this flag to Y to automatically go to ready when signing on.  N otherwise.
            Me.UPC.Script.AutoMakeReady = "N"


            Dim strBuilder As New System.Text.StringBuilder(500)


            strBuilder.Append("In ME.gfScriptLoad; ScriptCallmode: ").Append(Me.UPC.Script.SCRIPTCALLMODE)
            strBuilder.Append("; IsNewCall: ").Append(Me.UPC.Script.IsNewCall)
            strBuilder.Append("; MessageIdentifier: ").Append(Me.UPC.Script.MessageIdentifier)
            strBuilder.Append("; GUID: ").Append(Me.UPC.System.GUID)
            strBuilder.Append("; ScriptSwitch: ").Append(Me.UPC.System.ScriptSwitch)


            Me.LogSystemMessage("Script", strBuilder.ToString)


            If Me.UPC.Script.IsNewCall.Equals(True) Then
                Me.UPC.Script.NewCallFlag = Now().ToString


                Me.gfHandleMakeReady()


                Try
                    HandleNewCallEvent(Me.UPC.Script.MessageIdentifier)
                Catch ex As Exception
                    Me.UPC.Script.NewCallException = ex.StackTrace & ex.Message
                End Try


                Me.gfHandleNewCall()
                'Stach 05/10 - Handle missing screen pop on slow loading scripts
                If CBool(Me.UPC.Script.AliasLookupSuccess) <> (True) Then
                    'We have not done screenpop stuff, assuming becuase script loaded to slowly branch there
                    Me.LogSystemMessage("Script", "In ME.gfscriptload after new call/script load.  Detected Aliaslookup not complete, assume no screenpop took place so triggering one.")
                    Set_CurrPath(ScriptPaths.START)
                Else
                    Me.LogSystemMessage("Script", "In ME.gfscriptload after new call/script load.  Detected Aliaslookup did complete so not branching.")
                End If
                'Stach 05/10 - Handle missing screen pop on slow loading scripts
                Exit Sub
            End If


            If (Len(Trim(Me.UPC.System.GUID)) > 0) AndAlso (Me.UPC.System.ScriptSwitch <> "True") Then
                SendEnableSignon(Me.UPC.System.GUID)
            End If


            If Me.UPC.System.ScriptSwitch = "True" Then
                'set the script variables from the saved system variables (updatescripturl)
                Me.UPC.Script.SCRIPTCALLMODE = Me.UPC.System.ScriptCallmode
                Me.UPC.Script.DEBUGON = Me.UPC.System.DebugOn
                Me.UPC.Script.SignedOn = Me.UPC.System.SignedOn
                Me.UPC.Script.STARTCALLTIME = Me.UPC.System.StartCallTime


                If CBool(Me.UPC.System.MakeBusyAfterSwitch) Then
                    'new code for universal agent...
                    Me.LogSystemMessageDB("Script", "gfScriptLoad; setting Scriptcallmode to: " & Me.UPC.System.ScriptCallmode & " then making NOT READY...", CBool(Me.UPC.Script.DEBUGON))


                    'send switchcallmode performs the make ready or make not ready functions UNCOMMENT FOR UA...
                    'according to mode and sets the scriptcallmode flag.
                    'call setData  ("Script", "ScriptCallmode", getData ("System", "ScriptCallmode") ) 


                    gfMakeNotReady()
                Else
                    Me.LogSystemMessageDB("Script", "gfScriptLoad; calling switching callmode to: " & Me.UPC.System.ScriptCallmode & "...", CBool(Me.UPC.Script.DEBUGON))


                    'send switchcallmode performs the make ready or make not ready functions UNCOMMENT FOR UA
                    'according to mode and sets the scriptcallmode flag.
                    'call SendSwitchCallMode ( getData ("System", "ScriptCallmode"), "False" ) 


                    'comment out for UA...
                    gfMakeReady()
                End If
            Else
                'not switching scripts -set the startcalltime here.... (instead of in startup.aspx)...
                Me.UPC.Script.STARTCALLTIME = Now().ToString
            End If




        Catch ex As Exception
            Throw
        End Try


    End Sub

    Private Sub SendEnableSignon(gUID As Object)
        Throw New NotImplementedException()
    End Sub

    Private Sub HandleNewCallEvent(messageIdentifier As Object)
        Throw New NotImplementedException()
    End Sub

    Private Sub SendPhoneErrorToUPC(commonSettingURLErrorMsg As Object)
        Throw New NotImplementedException()
    End Sub

    Private Function RetrieveStandardWebServiceURLS() As Boolean
        Throw New NotImplementedException()
    End Function

    Public Sub LogSystemMessageDB(v1 As String, v2 As Object, v3 As Boolean)
        Throw New NotImplementedException()
    End Sub

    Public Sub gfHandleForceSignOff()
        'Created:MN2170H1:systxb:05/09/2003 01:27:08 PM
        Try
            MyBase.HandleForceSignOff()
            ' this is in response to a VACD rules hit
            Me.UPC.Script.ForceSignoffReceived = "Y"
            If Me.UPC.Script.ForceNotReadyReceived = "Y" Then
                Me.UPC.Script.ForceNotReadyReceived = "N"
                If Me.UPC.System.PHONETYPE = "CTC-AVAYA-PLUS" Then
                    gfSignOff()
                    Threading.Thread.Sleep(1001)
                    DisplayError("Wrap time has reached a maximum , phone session timing out.  Please press 'Sign On' to resume work.")
                Else
                    DisplayError("Wrap time has reached a maximum , phone session timing out.  Please log current call.")
                End If
            Else
                DisplayError("Phone session is timing out due to inactivity.")
            End If
            ' end VACD rules
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfForceNotReady()
        'Created:MN2170H1:sysejh:06/12/2006 02:23:14 PM
        Try
            MyBase.HandleForceNotReady()
            ' these lines handle VACD rules
            Me.UPC.Script.ForceNotReadyReceived = "Y"
            DisplayError("Wrap time is long, please log current call.")
            ' end VACD rules
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfPreloads()
        'Created:MN2170H1:systxb:05/09/2003 01:40:22 PM


        Try
            '21010517 cgossman 
            Me.NGS.M_ScriptName = Me.UPC.System.ScriptName.ToString.Trim
            Me.NGS.M_Version = Me.UPC.System.ScriptVersion.ToString.Trim
            Me.NGS.M_ReleaseID = Me.UPC.System.ScriptRelease.ToString.Trim
            Me.LS.lversion = Me.UPC.System.ScriptName.ToString.Trim & " Ver: " & Me.UPC.System.ScriptVersion.ToString.Trim & " Release: " & Me.UPC.System.ScriptRelease.ToString.Trim
            '20100507 lapeters Reset the primary Alias lookup Flag for the panel
            Me.UPC.Script.AliasLookupSuccess = False


            '20100505 lapeters Script now uses dynamic debug see sharepoint document at http://go.west.com/sites/WCMG/ProductionSupport/Product%20Support%20Development/Clients/__ALL__/DynamicDebugFlag.docx for details
            'log a debug message when debug on
            Me.LogSystemMessageDB("Script", "In GfPreloads", CBool(Me.UPC.Script.DEBUGON))


            MyBase.Preloads()


            'overwrite and add to any values set in base preloads now...
            'set Soap timeout to blank for default 10 seconds 
            Me.UPC.Script.SoapTimeout = 0  'String.Empty


            'initialize localstore fields
            Me.LS.lNumTransfer = 0
            Me.LS.lNumOfDisconnect = 0
            Me.LS.lAlreadyDisconnect = "N"
            Me.LS.lStatusFlag = "0"
            Me.LS.lUserFlag = "N"
            Me.LS.lVoice99started = String.Empty
            Me.LS.lStartRecord = String.Empty
            Me.LS.lVRUTransId = 0
            Me.LS.lTransferFlag = "N"
            Me.LS.lDial = String.Empty
            Me.LS.lTransferConnect = "Y"
            Me.UPC.Script.DEBUGON = True



            'initialize script fields
            Me.UPC.Script.FATALERROR = False
            Me.UPC.Script.AliasRetryInd = False
            Me.UPC.Script.isInLogging = "N"
            Me.UPC.Script.PerformedLookup = False
            Me.UPC.Script.AliasLookupSuccess = False


            'we have to reset the outbounddial busy flag for the next outbound call....
            Me.UPC.Script.OUTBOUNDDIALBUSY = "N"


            'initialize datastore fields
            If Me.NGS.M_ANI_AREA_C = String.Empty And Me.UPC.CallData.ani.Length >= 10 Then ' prevent borkage on outdial calls
                Me.NGS.M_ANI_AREA_C = Me.UPC.CallData.ani.Substring(0, 3)
                Me.NGS.M_ANI_PHONE = Me.UPC.CallData.ani.Substring(3, 7)
            End If
            'kvyas commented 10/25/2011 we are initialize m_prob_call_i two times in this function. we need initialize m_prob_call_i = "I" not "O". 
            'call setData  ("DataStore", "M_PROB_CALL_I", "O" )


            Select Case Me.UPC.System.SITE.ToString.Trim
                Case "NM"
                    Me.LS.lSiteName = "Makati"
                Case "SA"
                    Me.LS.lSiteName = "San Antonio"
                    '10132016 cosaih Added Utica, NY
                Case "UA"
                    Me.LS.lSiteName = "Utica"
                Case Else
                    Me.LS.lSiteName = "Omaha"
            End Select


            Me.LS.lSiteID = Me.UPC.System.SITE.ToString.Trim


            '20100924 cgossman - moving to SCREENPOP
            'Sets Referral Transfer Number
            'select case getDatatrim ("LocalStore", "l800NumberDialed") 
            'case "8002268893", "8003489688", "8004687632", "8668676326", "8777219398", "8778260930", "8887587946"
            'call setData  ("LocalStore", "lRefNumber", "8008547338" ) 
            'case "8005214443", "8662298023", "8664082769"
            'call setData  ("LocalStore", "lRefNumber", "8774652733" ) 
            'case "8002059989"
            'call setData  ("LocalStore", "lRefNumber", "8667249224" ) 
            'case "8667456882", "8882297111", "8883523227", "8883937489", "8888402742"
            'call setData  ("LocalStore", "lRefNumber", "8884560687" ) 
            'case "8005988748", "8008639693", "8665066268", "8665066272", "8668046586"
            'call setData  ("LocalStore", "lRefNumber", "8002972326" ) 
            'case else
            'select case getDataTrim ("DataStore", "M_PRODUCT_ID")
            'case "MBNACNFM", "MBNACNFS", "MBNACFSS" 'Consumer Finance
            'call setData  ("LocalStore", "lRefNumber", "8008928349" ) 
            'case "MBNASANS"
            'call setData  ("LocalStore", "lRefNumber", "8005987684" ) 
            'case else
            'call setData  ("LocalStore", "lRefNumber", "8888844950" ) 
            'end select
            'end select






            'set this flag to determine what mode to go to after logging.  UNIVERSAL AGENT...
            'values are: 
            '		 "INBOUND",
            '		 "MANUALS", 
            '		 "OUTBOUND"
            '        "OTHER" (makes the script go to the same mode it was in at the time of logging for the next call).  
            'call setData  ("Script", "GoToModeAfterLogging", "OTHER" ) 


            'From Original Preloads
            '
            'adding flag to determine which script the agent logs into durring conversion process
            Me.NGS.SELECT122 = "4"


            Me.NGS.M_PROB_CALL_I = "I"
            Me.NGS.AGENTFNAME = Me.UPC.AgentInfo.firstname
            Me.NGS.AGENTLNAME = Me.UPC.AgentInfo.lastname
            Me.LS.lErrorCust = "Y"


            If Me.LS.lCODE32.ToString.Trim.Equals(String.Empty) Then
                Me.LS.lCODE32 = "0"
            End If


            Me.LS.lXLFFlag = String.Empty
            Me.LS.lXLFdnc = String.Empty
            Me.LS.lXLFmain = String.Empty
            Me.LS.lNumberOfSearches = 0
            Me.LS.lNoMatchesFound = "N"
            Me.LS.lNumRecordsFound = 0


            Me.LS.lTotalDoNotContact = 0
            Me.LS.lTotalMail = 0
            Me.LS.lTotalCall = 0
            Me.LS.lTotalBoth = 0


            Me.LS.lIVLweb1 = String.Empty
            Me.LS.lsTimeSleep = 3000

            If String.IsNullOrEmpty(Me.NGS.SERVER) Then
                Dim adeExp As Regex = New Regex("[a-z|A-Z]{3}[0-9]{2}[a-z|A-Z]{5,6}[0-9]{2,3}")
                Dim match As Match = adeExp.Match(Me.UPC.Configuration.PHONE_WEB_SERVICE_URL)
                If Not match.Success Then
                    LogSystemMessage("MBK gfPreloads", "Unable to get SERVER name")
                    Exit Sub
                End If
                LogSystemMessage("MBK gfPreloads", "SERVER = " & match.Value)
                Me.NGS.SERVER = match.Value
            End If

        Catch ex As Exception
            Throw
        End Try


    End Sub
    Public Sub gfScriptStartBrowse()
        'Created:OM7704L1:Systxb:06/16/2003 09:34:52 AM
        Try
            MyBase.HandleStartBrowseEvent()
            Set_CurrPath(ScriptPaths.MSG)
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfSignonEnabled()
        'Created:OM7704L1:Systxb:06/26/2003 11:59:57 AM
        Try
            MyBase.SignonEnabled()
            Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg = String.Empty
            'Setting Standard Web Svc URLS 
            If Not RetrieveStandardWebServiceURLS() Then
                ' raise exception..... 
                Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg = "There was an error setting web service URL values. This is not recoverable and you have been signed off.  Please notify your supervisor"
                SendPhoneErrorToUPC(Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg)
                Exit Sub
            End If
            'Setting Script Specific URLs 
            'If Not gfSetWebServiceURLs() Then
            '    ' raise exception..... 
            '    Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg = "There was an error setting web service URL values. This is not recoverable and you have been signed off.  Please notify your supervisor"
            '    SendPhoneErrorToUPC(Me.SL.ScriptSLWebserviceValues.CommonSettingURLErrorMsg)
            '    Exit Sub
            'End If


            '	call Set_CurrPath ( "MSG" ) 
            '0907 - Stach Auto Signon for WAHE
            If Me.UPC.Configuration.userType = "WAHE" Then
                gfSignOn()
            End If
            If Me.UPC.System.PHONETYPE = "CTC-AVAYA-PLUS" Then
                'new for Avaya strikes
                Me.UPC.Script.StrikeCount = 0
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleMuteSSCRecorder()
        Try
            'stub method
        Catch ex As Exception

        End Try
    End Sub
    Public Sub gfSendLoggedOffEvent()
        Try
            'send the logged off event to the socket proxy
            If Len(Trim(Me.UPC.System.GUID)) > 0 Then
                Me.SendLoggedOffEvent(Me.UPC.System.GUID)
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub SendLoggedOffEvent(gUID As Object)
        Throw New NotImplementedException()
    End Sub

    Public Sub gfSendDataPass()
        'Created:OM7704L1:Systxb:07/14/2003 04:37:38 PM
        Try
            SetDataPassItem("MSG_setup_time", Me.UPC.CallData.CALLSETUP)
            SetDataPassItem("MSG_vru_number", Me.UPC.CallData.CALLUNIT)
            SetDataPassItem("MSG_channel_number", Me.UPC.CallData.CALLLINE)
            SetDataPassItem("MSG_generated_rtn", Me.UPC.CallData.rtn)
            SetDataPassItem("MSG_actual_rtn", Me.UPC.CallData.rtn)
            SetDataPassItem("MSG_ani_ac", Mid(Me.UPC.CallData.ani, 1, 3))
            SetDataPassItem("MSG_ani_phone", Mid(Me.UPC.CallData.ani, 4, 7))
            SetDataPassItem("MSG_depending_field_2", "50")
            'call SetDataPassItem ( "MSG_disposition", getData ( "DataStore", "SECOND_DISP") ) 
            'call SetDataPassItem ( "MSG_fixed_fields", getData ( "DataStore", "M_OPER_C") ) 
            SetDataPassItem("MSG_phone_num", Me.LS.lTransferNumber)
            StoreDataPass()
            RunDataPass()
            'pageDown()
        Catch ex As Exception
            'Throw ex
            'Don't stop things because of this
            HandleExceptions(ex)
        End Try
    End Sub

    Private Sub HandleExceptions(ex As Exception)
        Throw New NotImplementedException()
    End Sub

    Private Sub RunDataPass()
        Throw New NotImplementedException()
    End Sub

    Private Sub StoreDataPass()
        Throw New NotImplementedException()
    End Sub

    Private Sub SetDataPassItem(v As String, cALLSETUP As Object)
        Throw New NotImplementedException()
    End Sub

    Public Sub gfSignonFailed(ByVal pReplyCode As String, ByVal pErrorText As String)
        'Created:OM0610L1:Sysgsc:07/19/2003 12:48:46 PM
        Try
            MyBase.HandleSignonFailed(pReplyCode, pErrorText)
            '05/03 Stach - Changed to allow for VACD in B&M
            'if getData("system","PHONETYPE") = "WIC" then
            If Me.UPC.Configuration.emailAddress <> "" Then
                Me.gfDisconnect()
                Me.gfMakeNotReady()
                Me.gfSignOff()
                '04/07 - Added delay, reporting was having issues tracking events in real time
                Threading.Thread.Sleep(1601)
                Me.gfSignOn()
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfMakeReadyFailed(ByVal pErrorCode As String, ByVal pErrorText As String)
        'Created:OM0610L1:Sysgsc:08/05/2003 11:47:24 AM
        Try
            MyBase.HandleMakeReadyFailed()
            DisplayError(pErrorText)
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfCallComplete()
        'Created:OM0610L1:Sysgsc:09/08/2003 09:37:32 AM


        Try
            Me.LogSystemMessage("gfCallComplete", "Clearing Numbers")
            Dim mraService = New MRAService.MRAServiceClient()
            mraService.AllowConsent(Me.LS.MBK, "") 'Clear cache using temp MBK

            MyBase.HandleCallCompleteEvent()


            ''added 7/25/2005 Jimmy Nichols
            'if  getDatatrim ("LocalStore", "lRecordOK") = "Y" then
            'call gfVoice99 ( "ARCHIVE" ) 
            'end if
            ''end add 7/25/2005 Jimmy Nichols


            Me.NGS.TALK_TIME = Me.UPC.CallData.timetalk
            Me.NGS.HOLD_TIME = Me.UPC.CallData.timehold
            Me.NGS.WRAP_TIME = Me.UPC.CallData.timewrap
            Me.NGS.OTHER_TIME = Me.UPC.CallData.timeother
            Me.NGS.TOTAL_TIME = Me.UPC.CallData.timetotal


            Me.gfPostloads()
            'GSC Uncomment this to debug. These values will not get reset on the MakeReay, like the 
            '    DataStore will, you can check the values in the debug window after you log.
            Me.UPC.Script.Talk_Time = Me.UPC.CallData.timetalk
            Me.UPC.Script.Hold_Time = Me.UPC.CallData.timehold
            Me.UPC.Script.Wrap_Time = Me.UPC.CallData.timewrap
            Me.UPC.Script.Other_Time = Me.UPC.CallData.timeother
            Me.UPC.Script.Total_Time = Me.UPC.CallData.timetotal


            'Used for NGS Logging
            Me.NGS.CallInfoCallEndTime = Now.ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss")
            Me.NGS.CallInfoLengthOfCall = Me.UPC.Script.Total_Time
            Me.NGS.TOTAL_TIME = Me.UPC.CallData.timetotal


            '<log to mv>
            Try
                Dim objLog As New West.CorpSysDev.ADE50Logs.MVAdeLogger
                objLog.ProjectId = Me.UPC.System.ProjectId
                objLog.AgentId = Me.UPC.System.USER_ID
                objLog.TwoByteSiteId = Me.UPC.System.SITE
                objLog.CallEndTime = CDate(Me.UPC.Script.callEndTime)
                objLog.CallLogTime = DateTime.Now
                objLog.TalkSeconds = CInt(Me.UPC.Script.Talk_Time)
                objLog.HoldSeconds = CInt(Me.UPC.Script.Hold_Time)
                objLog.WrapSeconds = CInt(Me.UPC.Script.Wrap_Time)
                objLog.OtherSeconds = CInt(Me.UPC.Script.Other_Time)
                objLog.Disposition = String.Empty
                objLog.AddVariableData("LogKey", Me.UPC.Script.MyLogKey)
                'objLog.AddVariableData("Disp1", getData("DataStore", "INIT_DISP"))
                'objLog.AddVariableData("Disp2", getData("DataStore", "SECOND_DISP"))


                Me.LogSystemMessage("Script", objLog.GetLogXML())

            Catch mvex As Exception
                ' eat error....don't stop
            End Try
            '</log to mv>




        Catch ex As Exception
            'don't throw the exception to the user if mv logging fails
            'throw ex
        End Try


    End Sub
    Public Sub gfExternalProcedureComplete()
        'Created:OM0610L1:Sysgsc:09/08/2003 10:35:59 AM
        Try
            '#Script Template Generated Code DO NOT MOFIY
            MyBase.HandleExternalProcedureComplete()
            '#End of Template Generated Code
            'SYSTXB - commented this out, causing double disconnects on logging...
            ''cosmjb
            If Me.LS.lTransferFlag = "Y" Then
                'If getData("Script","DISCONNECTED") = "N" then
                '	gfdisconnect()
                'end if
                'GSC This is specific to this script, not all scripts might want to 
                '	Page Down to the next panel
                'PageDown (  ) 
                'SYSTXB - end change for double disconnects
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfExternalProcedureFailed()
        'Created:OM0610L1:Sysgsc:09/08/2003 10:38:37 AM
        Try
            '#Script Template Generated Code DO NOT MOFIY
            MyBase.HandleExternalProcedureFailed()
            '#End of Template Generated Code
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleDialThirdPartyFailed()
        'Created:OM0610L1:Sysgsc:09/19/2003 07:45:54 AM
        Try
            '#Template Generated Code
            'Changing this code is not recommended
            MyBase.HandleDialThirdPartyFailed()
            '#End Template Generated Code
            If Me.UPC.System.PHONETYPE = "CTC-AVAYA" Then
                Me.LS.lthirdpartydialed = "N"
                Me.LS.lthirdpartyanswered = "N"
                Me.LS.lConferenced = "N"
                DisplayError("3rd party dial failed. WAIT! 30 sec for tone to end, then take caller offhold.")
            Else
                'kp added 3/05
                Me.gfOffHold()
                DisplayStatus("Dial of third party has failed.")
                Me.LS.lthirdpartydialed = "N"
                Me.LS.lthirdpartyanswered = "N"
                Me.LS.lConferenced = "N"
                'end kp added 3/05
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub DisplayStatus(v As String)
        Throw New NotImplementedException()
    End Sub

    Public Sub gfPostloads()
        'Created:OM6391D01:cosmjb:10/08/2003 08:21:31 AM
        Try
            'call setData  ("LocalStore", "lDate3", getDatatrim ("LocalStore", "DateOfBirth") )
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'JFrum - Added for NGS Logging
            'You must set one of the following Status Codes to CallInfo.CallType:
            ' "Order"
            ' "Info Only"
            ' "Inquiry"
            ' "Doc C/S"
            ' "Referral"
            ' "Support"
            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            'kvyas 10252011 Added M_PROB_CALL_I so it does not mess up when we call gfIncermentalNGSCounter function. 
            Select Case Me.NGS.Init_Disp.ToString.Trim
                Case "A000", "G000" 'Application
                    Select Case Me.NGS.Second_Disp.ToString.Trim
                        Case "A200", "G200" 'No Sale
                            Me.NGS.CallInfoCallType = "Info Only"
                            Me.NGS.M_PROB_CALL_I = "I"
                        Case Else 'Sale
                            Me.NGS.CallInfoCallType = "Order"
                            Me.NGS.M_PROB_CALL_I = "O"
                    End Select
                Case "B000", "H000" 'TelCom
                    Me.NGS.CallInfoCallType = "Info Only"
                    Me.NGS.M_PROB_CALL_I = "I"
                Case "C000", "I000" 'Customer Assistance
                    Me.NGS.CallInfoCallType = "Doc C/S"
                    Me.NGS.M_PROB_CALL_I = "P"
                Case "D000", "J000" 'Referrals
                    Me.NGS.CallInfoCallType = "Referral"
                    Me.NGS.M_PROB_CALL_I = "R"
                Case "S000"
                    Me.NGS.CallInfoCallType = "Order"
                    Me.NGS.M_PROB_CALL_I = "O"
                Case "T000" 'Status of Application
                    Me.NGS.CallInfoCallType = "Inquiry"
                    Me.NGS.M_PROB_CALL_I = "I"
                Case Else
                    'When all else fails do something else...
                    Me.NGS.CallInfoCallType = "Inquiry"
                    Me.NGS.M_PROB_CALL_I = "I"
            End Select


            'From Original Postloads
            If Me.NGS.M_CANADA_FLAG.ToString.Trim.Equals("N") Then
                Me.NGS.M_CANADA_FLAG = String.Empty
            End If




            'System Down Manual Applications
            'must pass numerics for manual app auto file
            'changing alphas to numerics
            If Me.NGS.SELECT82 = "B" Then
                If Me.LS.lAssocBank.ToString.Trim.Equals(String.Empty) Then
                    Me.LS.lAssocBank = "000"
                End If
                If Me.LS.lmailZip.ToString.Trim.Equals(String.Empty) Then
                    Me.LS.lmailZip = "00000"
                End If
                If Me.LS.lHomePhone.ToString.Trim.Equals(String.Empty) Then
                    Me.LS.lHomePhone = "0000000000"
                End If
                If Me.LS.lDateOfBirth.ToString.Trim.Equals(String.Empty) Then
                    Me.LS.lDateOfBirth = "00000000"
                End If
                If Me.LS.lEmpPhone.ToString.Trim.Equals(String.Empty) Then
                    Me.LS.lEmpPhone = "0000000000"
                End If
                If Me.LS.lPhone4.ToString.Trim.Equals(String.Empty) Then
                    Me.LS.lPhone4 = "0000000000"
                End If
                If Me.LS.lCRZip2.ToString.Trim.Equals(String.Empty) Then
                    Me.LS.lCRZip2 = "00000"
                End If
                If Me.LS.lCCExpd1.ToString.Trim.Equals(String.Empty) Then
                    Me.LS.lCCExpd1 = "00000"
                End If
                If Me.LS.lReference.ToString.Trim.Equals(String.Empty) Then
                    Me.LS.lReference = "000000000000000"
                End If
            End If


            If Me.NGS.QTY_CARD99.ToString.Trim.Equals(String.Empty) Then
                Me.NGS.QTY_CARD99 = 0
            End If
        Catch ex As Exception
            Throw
        End Try


    End Sub
    Public Sub gfAgentFailedToAnswer(ByVal preplyCode As String)
        'Created:OM0610L1:Sysgsc:01/12/2004 03:39:56 PM
        Try
            MyBase.HandleAgentFailedToAnswer(preplyCode)
            Me.UPC.Script.StrikeCount = (CInt(Me.UPC.Script.StrikeCount) + 1)
            If Me.UPC.Script.StrikeCount = "3" Then
                Me.UPC.Script.StrikeCount = "0"
                Me.LogSystemMessage("Script", "Third strike, ADE signing off session.")
                gfSignOff()
                Threading.Thread.Sleep(101)
                gfSendStrikeoutAlert()
                DisplayError("Three calls have gone unanswered, please press 'Sign On' in ADE to resume work.")
            Else
                ' force logging if we're at 1 or 2.
                Me.LogSystemMessage("Script", "Call offered, but went unanswered. Strike number: " & Me.UPC.Script.StrikeCount)
                Me.UPC.Script.CALLMODE = "0"
                Set_CurrPath(ScriptPaths.STRIKE)
                'call gfHandleDisconnect (  ) 
            End If


            If Me.UPC.System.PHONETYPE.ToString.Trim.Equals("CTC-AVAYA-PLUS") Then
                Set_CurrPath(ScriptPaths.ANSWER)
            Else
                Set_CurrPath(ScriptPaths.START)
            End If


            'Select Case cInt(pReplyCode)
            'Case -15
            '' This is a shared west function
            ''		resetAbandonedPhoneState(getData("System","GUID"))
            'Case -13
            '' Agent did not answer the phone
            '' Trying to perform phone functions results in a timing error with the VACD.
            '' Try putting any phone code into the gfHandleAgentStrike function, which will be called
            '' right after this one, when the VACD tells us the agent has been locked.
            '' If you need to remember whether the agent did not answer or their phone was busy
            '' Save the state info in this function
            'DisplayError("You did not Answer in coming call. You must Sign In to the system again")
            'Case -12
            '' Trying to perform phone functions results in a timing error with the VACD.
            '' Try putting any phone code into the gfHandleAgentStrike function, which will be called
            '' right after this one, when the VACD tells us the agent has been locked.
            '' If you need to remember whether the agent did not answer or their phone was busy
            '' Save the state info in this function
            'DisplayError("You missed an in coming call Because your phone was busy. You must Sign In to the system again")
            'End Select
        Catch ex As Exception
            Throw
        End Try


    End Sub

    Private Sub Set_CurrPath(sTRIKE As String)
        Throw New NotImplementedException()
    End Sub

    Private Sub DisplayError(v As String)
        Throw New NotImplementedException()
    End Sub

    Public Sub gfAgentAnswered()
        'Created:OM0610L1:Sysgsc:01/12/2004 03:40:16 PM


        Try

            'log a debug message when debug on
            Me.LogSystemMessageDB("Script", "In ME.gfAgentAnswered; ScriptCallmode: " & Me.UPC.Script.SCRIPTCALLMODE, CBool(Me.UPC.Script.DEBUGON))


            MyBase.HandleAgentAnswered()
            'If Nortel set switch to Not Ready after a call comes in so it won't auto set the agent to Ready at disconnect.
            If (Me.UPC.System.PHONETYPE).ToUpper = "CTC" Then
                'MyBase.MakeBusyAFterCall()   Nortel is no longer used, function no longer present
            End If


            If Me.UPC.System.PHONETYPE.ToString.Trim.Equals("CTC-AVAYA-PLUS") Then
                Set_CurrPath(ScriptPaths.ANSWER)
            Else
                'call Set_CurrPath ( "START" ) 
                'Stach 05/10 - Handle missing screen pop on slow loading scripts
                If CBool(Me.UPC.Script.AliasLookupSuccess) <> (True) Then
                    'We have not done screenpop stuff, assuming becuase script loaded to slowly branch there
                    'call LogSystemMessageDB ( "Script", "In gfAgentAnswered.  Detected Aliaslookup not complete so branching.",getDataBoolean ("Script", "DEBUGON") ) 
                    Me.LogSystemMessage("Script", "In ME.gfAgentAnswered.  Detected Aliaslookup not complete so branching.")
                    Set_CurrPath(ScriptPaths.START)
                Else
                    'We have done screenpop stuff so don't branch, just note it in the log for torubleshooting purposes
                    Me.LogSystemMessage("Script", "In ME.gfAgentAnswered.  Detected Aliaslookup complete so not branching.")
                End If


            End If



        Catch ex As Exception

        End Try


    End Sub
    Public Sub gfHandleAgentStrike()
        'Created:OM0610L1:Sysgsc:01/13/2004 04:23:37 PM
        Try
            'myBase.HandleAgentStrike()
            'gfMakeNotReady()
            'gfSignoff()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfLogCall()
        'Created:OM0597L3:sysixs:12/07/2005 02:30:54 PM
        Try
            '20100720 cgossman - best practice change
            Dim sb As New System.Text.StringBuilder(2000)
            ' * THESE EMAIL ADDRESSES NEED TO BE SET SPECIFICALLY PER SITE *
            Me.LS.ltoAddr = "TEST@GMAIL.COM"


            sb.Append("Overlapping Call Notification Message^ ^")
            sb.Append("Agent Name: ").Append(Me.UPC.AgentInfo.fullname).Append("^")
            sb.Append("Agent Term_id: ").Append(Me.UPC.AgentInfo.term_id).Append("^")
            sb.Append("Phone ANI :").Append(Me.UPC.CallData.ani).Append("^")
            sb.Append("Phone EXT :").Append(Me.UPC.CallData.Ext).Append("^")
            sb.Append("Phone RTN :").Append(Me.UPC.CallData.rtn).Append("^")
            sb.Append("Time :").Append(Now)
            Dim AgentInfoMessage As String = sb.ToString()
            SendEmailFourOh(Me.LS.ltoAddr, "", "OVERLAPPINGCALL@GMAIL.COM", "Overlapping Call Notification", AgentInfoMessage)
            '--------------------------------------------
            Me.UPC.Script.Logging = "Y"
            Me.UPC.Script.isInLogging = "Y"
            Me.UPC.Script.isCallLogged = "Y"
            Me.UPC.Script.isDisconnected = "N"
            Me.UPC.Script.callStartTime = Me.UPC.Script.OVCcallStartTime
            Me.UPC.Script.CallWrapStartTime = Me.UPC.Script.OVCcallWrapStartTime
            gfCallComplete()
            Me.UPC.Script.CallType = "O"
            '20100823 cgossman - unplugging Tandem logging
            '-------- start - sendLogordsMessage() -------------
            'select case getData("Script","CALLTYPE")
            'case "O"
            'call setData("DataStore","M_LAYOUT_NAME",getDataTrim("Script","orderLayoutName"))
            'case "P"
            'call setData("DataStore","M_LAYOUT_NAME",getDataTrim("Script","problemLayoutName"))
            'end select
            '
            'call SetFixedCounters (  ) 
            Me.IncrementCounterRules()
            ' call FormatVariableArea (  ) 
            'Call FormatVariableAreaFORBW6()
            '
            '
            'call SendLogordsSoap ( "" ) 
            '-------- end - sendLogordsMessage() -------------
            Me.UPC.Script.Logging = "N"
            InitVars()
            Me.UPC.Script.isCallLogged = "N"
            Me.UPC.Script.isDisconnected = "N"
        Catch ex As Exception
            Throw (ex)
        End Try


    End Sub

    Private Sub SendEmailFourOh(ltoAddr As String, v1 As String, v2 As String, v3 As String, agentInfoMessage As String)
        Throw New NotImplementedException()
    End Sub

    Public Sub gfCheckWahaSchedule()
        'Created:OM6341D4:coskpp:03/09/2006 11:32:28 AM
        Try
            If Me.UPC.Script.CALLMODE = "2" Then 'Waiting
                If Me.UPC.Configuration.userType = "" Then
                    ' this is the pre-5.6 version
                    If Not MyBase.CheckSchedule() Then
                        'No longer has a schedule
                        'go to the fatal path, set script variable to keep from going to msgboard.
                        'force agents to sign out on the fatalskills panel.
                        Me.UPC.Script.FATALERROR = True
                        'branch to the fatalerror script path in gfhandlemakeready or gfhandlemakenotready
                        'make not ready
                        gfMakeNotReady()
                        'sign off
                        gfSignOff()
                    End If
                Else
                    If Not MyBase.CheckSchedule2() Then
                        'No longer has a schedule
                        'go to the fatal path, set script variable to keep from going to msgboard.
                        'force agents to sign out on the fatalskills panel.
                        Me.UPC.Script.FATALERROR = True
                        'branch to the fatalerror script path in gfhandlemakeready or gfhandlemakenotready
                        'make not ready
                        gfMakeNotReady()
                        'sign off
                        gfSignOff()
                    End If
                End If
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleAvayaNoScheduleWarning()
        'Created:OM0597D1:sysejh:07/10/2008 02:44:03 PM
        Try
            DisplayError("Your schedule has expired. Please log out until next scheduled shift.")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleCallerDisconnectInConsult()
        'Created:OM0597D1:sysejh:07/10/2008 02:45:33 PM
        Try
            DisplayError("Original Caller hung up while on hold.  Please log remaining call.")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleCreateAvayaExtensionFailed()
        'Created:OM0597D1:sysejh:07/10/2008 02:47:00 PM
        Try
            DisplayError("Trouble creating virtual phone extension: Please log out and re-launch application. If failures persist contact service support.")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleMistakenTransferAttempt()
        'Created:OM0597D1:sysejh:07/10/2008 02:48:22 PM
        Try
            DisplayError("Transfer not possible in 2-way call. Request cancelled.")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleOutboundDialComplete()
        'Created:OM0597D1:sysejh:07/10/2008 02:49:27 PM
        Try
            Dim socketProxy As New West.CorpSysDev.ADE.Framework.SocketService.SocketUserProxy
            Dim userIdentifier As String = Me.UPC.System.GUID
            Dim message As String
            message = "UserIdentifier=" & userIdentifier & "&Class=PHONE&Action=AgentDialComplete"
            socketProxy.SendMessage(userIdentifier, message)
            Me.UPC.Script.CALLMODE = "1"
            Me.UPC.Script.callStartTime = Now().ToString
            Me.UPC.Script.DISCONNECTED = "N"
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleThirdPartyDialInHold()
        'Created:OM0597D1:sysejh:07/10/2008 02:51:47 PM


        Try
            'log a debug message when debug on (for testing)
            Me.LogSystemMessageDB("Script - For Testing", "gfHandleThirdPartyDialInHold has been raised.", CBool(Me.UPC.Script.DEBUGON))


            DisplayError("Please take caller off ME.HOLD before re-trying third party dial.")


        Catch ex As Exception
            Throw
        End Try


    End Sub
    Public Sub gfHandleDataEntryCallAnswered()
        'Created:OM7704L2:Systxb:01/06/2009 12:10:00 PM
        Try
            'log a debug message when debug on
            If Me.UPC.Script.DEBUGON = True Then
                Me.LogSystemMessage("Script", "In ME.gfHandleDataEntryCallAnswered")
            End If
            'base call - starts call time, sets callmode to 1 and disconnected to Y
            MyBase.HandleDataEntryCallAnswered()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleDataEntryCallFailed(ByVal pErrorCode As String)
        'Created:OM7704L2:Systxb:01/06/2009 12:11:33 PM
        Try
            'log a debug message when debug on
            If Me.UPC.Script.DEBUGON = True Then
                Me.LogSystemMessage("Script", "In ME.gfHandleDataEntryCallFailed")
            End If
            MyBase.HandleDataEntryCallFailed(pErrorCode)
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleOutboundDialBusy()
        'Created:OM7704L2:Systxb:01/06/2009 12:12:34 PM
        Try
            'log a debug message when debug on
            If Me.UPC.Script.DEBUGON = True Then
                'call LogSystemMessage ( "Script", "In gfHandleOutboundDialBusy, setting OutboundDialBusy to Y...") 
                Me.LogSystemMessage("Script", "In ME.gfHandleOutboundDialBusy, setting OUTBOUNDDIALBUSY to Y...")
            End If
            'we have to disconnect a busied call....
            Me.UPC.Script.OUTBOUNDDIALBUSY = "Y"
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Function gfAbleToChangePaths(ByVal pPathToChangeTo As String) As Boolean
        'Created:OM7704L2:Systxb:01/06/2009 12:15:12 PM
        Try
            'log a debug message when debug on
            If Me.UPC.Script.DEBUGON = True Then
                Me.LogSystemMessage("Script", "In ME.gfAbleToChangePaths; ScriptCallmode: " & Me.UPC.Script.SCRIPTCALLMODE _
                       & "; PATHTOCHANGETO: " & pPathToChangeTo _
                       & "; SIGNEDON: " & Me.UPC.Script.SignedOn _
                       & "; DISCONNECTED: " & Me.UPC.Script.DISCONNECTED _
                       & "; PATHID: " & Me.UPC.Script.PathID _
                       & "; CURRPATH: " & Me.UPC.Script.CURRPATH _
                       & "; CURRPATHNAME: " & Me.UPC.Script.CurrPathName _
                       & "; CURRPOS: " & Me.UPC.Script.CURRPOS.ToString())
            End If
            If Me.UPC.Script.DEBUGON = True Then
                Me.LogSystemMessage("Script", "In ME.gfAbleToChangePaths; Returning TRUE")
            End If
            Return True
        Catch ex As Exception
            Throw
        End Try
    End Function
    Public Sub gfSendAuxCodeToADE(ByVal pAuxCodeValue As String)
        'Created:OM7704L2:Systxb:01/06/2009 01:28:39 PM
        Try
            'log a debug message when debug on
            If Me.UPC.Script.DEBUGON = True Then
                Me.LogSystemMessage("Script", "In ME.gfSendAuxCodeToADE...")
            End If
            'call the base shared aux code function
            MyBase.SendAuxCodeToADE(pAuxCodeValue)
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfAnswerCall()
        'Created:OM4246D1:mjhansen:04/02/2009 04:02:29 PM


        Try
            Me.LogSystemMessage("Script", "Agent clicked AnswerCall")
            MyBase.AnswerCall(Me.UPC.System.GUID)


        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfAnswerCall: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub

    Public Sub LogException(ex As Exception)
        Throw New NotImplementedException()
    End Sub

    Public Sub gfSendStrikeoutAlert()
        'Created:OM4246D1:mjhansen:04/02/2009 04:08:26 PM


        'TODO: 20100521 lapeters/cshepler - Is ADE goig away?  If it is Should we change ADE or remove reference to it?
        Try
            SendAlert("Three calls have gone unanswered, you have been logged out. Please sign back into ADE to continue working.")

        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfSendStrikeoutAlert: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub

    Private Sub SendAlert(v As String)
        Throw New NotImplementedException()
    End Sub

    Public Sub gfHandleDialThirdPartyAnswered()
        'Created:OM0736L1:AMStach:12/22/2009 03:37:13 PM


        Try
            'Log
            Me.LogSystemMessageDB("Script", "gfHandleDialThirdPartyAnswered has been raised", CBool(Me.UPC.Script.DEBUGON))
            '[INC1822775]
            gfConference()
            Me.LS.lStatusFlag = "2"

            If mraServiceHelp Is Nothing Then
                mraServiceHelp = New MRAService.MRAServiceClient()
            End If

            If mraServiceHelp IsNot Nothing Then
                mraServiceHelp.AllowConsent(Me.LS.MBK, "") 'Update the Data per MBK after Initiating Conference Call
            Else
                LogSystemMessage("MRA Conference", "mraServiceHelp not initialized!")
            End If
            If Not String.IsNullOrWhiteSpace(Me.LS.MBK) Then
                LogSystemMessage("MRA Conference", String.Format("MBK = {0}, 800Number = {1}", Me.LS.MBK, Me.NGS.BusinessData32))
            End If
        Catch ex As Exception
            Throw
        End Try


    End Sub
    Public Sub gfHandleDestinationBusy()
        'Created:OM6112D1:kvyas:01/21/2010 03:08:45 PM
        Try
            DisplayError("Destination is busy!  Go ahead and drop the third party.")

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfCallerDisconnectInConsult()
        'Created:OM6112D1:kvyas:01/21/2010 03:16:56 PM
        Try
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandle3rdPartyOrCallerDisconConference()
        'Created:OM6112D1:kvyas:01/21/2010 03:26:22 PM
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub


    Public Sub gfCalcIncome3()
        'Created: ScriptConvert:5/5/2010 11:51:29 AM


        'TODO 20100520 lapeters/caryn - find and replace the Local Stores similar to lCheckAmt5 with there new names.
        Try
            Dim annualincome As Integer = CInt(Me.LS.lAnnualSalary)
            Dim addincome As Integer = CInt(Me.LS.lCheckAmt5)
            Dim addtotal As Integer = 0
            Dim totalincome As Integer = 0


            'lManualTotalIncome is the Total Annual Income
            'lTotalHouseInc is the Total Annual Income
            'lCheckAmt5 is the additional Income
            'lAddFreq is additional Income frequency
            'lAddHours is the number of hours




            'There are 52 weeks in a year
            '2080 is the number of hours when you work full time for a year (40*52)


            Me.LogSystemMessageDB("Script", "gfCalcIncome3, lAddFreq = " & Me.LS.lAddFreq, CBool(Me.UPC.Script.DEBUGON))
            Me.LogSystemMessageDB("Script", "gfCalcIncome3, lAnnualSalary = " & Me.LS.lAnnualSalary, CBool(Me.UPC.Script.DEBUGON))
            Me.LogSystemMessageDB("Script", "gfCalcIncome3, lCheckAmt5 = " & Me.LS.lCheckAmt5, CBool(Me.UPC.Script.DEBUGON))


            Select Case Me.LS.lAddFreq.ToString.Trim
                Case "A"    'Hourly
                    If CInt(Me.LS.lAddHours) > 0 Then
                        addtotal = addincome * CInt(Me.LS.lAddHours) * 52
                    Else
                        addtotal = addincome * 2080
                    End If
                Case "B"    'Weekly
                    addtotal = addincome * 52
                Case "C"    'Bi-Weekly
                    addtotal = addincome * 26
                Case "D"    'Monthly
                    addtotal = addincome * 12
                Case "E"    'Annualy
                    addtotal = addincome
                Case Else
            End Select


            totalincome = annualincome + addtotal


            'field for total Household income
            Me.LS.lTotalHouseInc = totalincome
            Me.LS.lAnnualAddIncome = addtotal




        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfCalcIncome3: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub


    Public Sub gfCalcIncome5()
        'Created: ScriptConvert:5/5/2010 11:51:29 AM


        Try
            Dim annualincome As Integer = 0
            Dim addincome As Integer = 0
            Dim addtotal As Integer = 0
            Dim totalincome As Integer = 0
            Dim addpension As Integer = 0


            'lAnnualSalary is the Total Annual Income
            'lAdditionalIncome is the additional Income
            'lAddFreq is additional Income frequency
            'lAddHours is the number of hours
            'lAnnualPensionAmt is the annual pension amount


            annualincome = CInt(Me.LS.lAnnualSalary)
            addincome = CInt(Me.LS.lAdditionalIncome)
            addpension = CInt(Me.LS.lAnnualPensionAmt)
            'There are 52 weeks in a year
            '2080 is the number of hours when you work full time for a year (40*52)
            'calc Additional Income
            Select Case Me.LS.lAddFreq.ToString.Trim
                Case "A"    'Hourly
                    If CInt(Me.LS.lAddHours) > 0 Then
                        addtotal = addincome * CInt(Me.LS.lAddHours) * 52
                    Else
                        addtotal = addincome * 2080
                    End If
                Case "B"    'Weekly
                    addtotal = addincome * 52
                Case "C"    'Bi-Weekly
                    addtotal = addincome * 26
                Case "D"    'Monthly
                    addtotal = addincome * 12
                Case "E"    'Annualy
                    addtotal = addincome
                Case Else
                    addtotal = 0
            End Select


            'adds pension to additional income
            addtotal += addpension


            'Total Annual Income plus additional income including pension
            totalincome = annualincome + addtotal


            'field for total annual income
            Me.LS.lTotalHouseInc = totalincome


            'field for total additional income includes Pension total
            Me.LS.lAnnualAddIncome = addtotal


        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfCalcIncome5: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub


    Public Sub gfDoNotContact()
        'Created: ScriptConvert:5/5/2010 11:51:29 AM


        Try
            'confirm letter
            If Me.LS.lConfirmLetter.ToString.Trim.Equals("Y") Then
                Me.NGS.SELECT23 = "Y"
            End If
            'policy letter
            If Me.LS.lPolicyLetter.ToString.Trim.Equals("Y") Then
                Me.NGS.SELECT24 = "Y"
            End If
            '20100607 lapeters Changed to getDataInt from getDataTrim so case will work.
            '20100619 cgossman  PH_# is used to determine whether the DNC entries go on the Do Not Contact Report
            ' or the Phone Only Report
            ' PH_# = A, C, or D will send DNC entries to the Do Not Contact Report
            ' PH_# = B will send DNC entries to the Phone Only Report
            Select Case CInt(Me.LS.lTotalDoNotContact)
                Case 1
                    Me.LS.lDNC1AREAC = Me.LS.lmailAreaC.ToString.Trim
                    Me.LS.lDNC1PHONE3 = Me.LS.lmailPhone3.ToString.Trim
                    Me.LS.lDNC1PHONE4 = Me.LS.lmailPhone4.ToString.Trim
                    Me.NGS.M_FIRST_NAME = Me.LS.lmailFname.ToString.Trim
                    Me.NGS.M_LAST_NAME = Me.LS.lmailLname.ToString.Trim
                    Me.NGS.SELECT32 = Me.LS.lmailMname.ToString.Trim
                    Me.NGS.M_ADDRESS1 = Me.LS.lmailAdd1.ToString.Trim
                    Me.NGS.M_ADDRESS2 = Me.LS.lmailAdd2.ToString.Trim
                    Me.NGS.M_CITY = Me.LS.lmailCity.ToString.Trim
                    Me.NGS.M_STATE = Me.LS.lmailState.ToString.Trim
                    Me.NGS.M_ZIP = Me.LS.lmailZip.ToString.Trim
                    Me.LS.lDNC1 = Me.NGS.SELECT10.ToString.Trim
                    Me.LS.lSELECT135 = Me.LS.lConfirmLetter.ToString.Trim 'set for confirmation letter
                    Me.LS.lSELECT136 = Me.LS.lPolicyLetter.ToString.Trim 'set for policy letter
                    Me.LS.lDNC1NOADD = Me.NGS.SELECT108.ToString.Trim 'set for agent report
                    Me.NGS.PH_1 = Me.NGS.SELECT10.ToString.Trim
                    If Me.NGS.SELECT10.ToString.Trim.Equals("B") Then
                        If Me.NGS.M_FIRST_NAME.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.M_LAST_NAME.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.SELECT32.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.M_ADDRESS1.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.M_ADDRESS2.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.M_CITY.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.M_STATE.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.M_ZIP.ToString.Trim.Equals(String.Empty) Then
                            '  if all fields above are empty... do nothing
                        Else
                            Me.NGS.PH_1 = "D"   'see comments above CASE statement
                        End If
                    End If
                    Me.LS.lDNCBPA1 = Me.LS.lDNCBPA.ToString.Trim
                    Me.LS.lDNCdec1 = Me.LS.lDNCdec.ToString.Trim
                    Me.LS.lDNCbn1 = Me.LS.lDNCbn.ToString.Trim
                Case 2
                    Me.NGS.ZIP_2 = Me.LS.lmailZip.ToString.Trim
                    Me.NGS.FirstName2 = Me.LS.lmailFname.ToString.Trim
                    Me.NGS.SELECT35 = Me.LS.lmailMname.ToString.Trim
                    Me.NGS.LastName2 = Me.LS.lmailLname.ToString.Trim
                    Me.NGS.ADDRESSONE2 = Me.LS.lmailAdd1.ToString.Trim
                    Me.NGS.ADDRESSTWO2 = Me.LS.lmailAdd2.ToString.Trim
                    Me.NGS.CITY_2 = Me.LS.lmailCity.ToString.Trim
                    Me.NGS.STATE_2 = Me.LS.lmailState.ToString.Trim
                    Me.LS.lDNC2AREAC = Me.LS.lmailAreaC.ToString.Trim
                    Me.NGS.PHONE_3_2 = Me.LS.lmailPhone3.ToString.Trim
                    Me.NGS.PHONE_4_2 = Me.LS.lmailPhone4.ToString.Trim
                    Me.LS.lDNC2 = Me.NGS.SELECT10.ToString.Trim
                    Me.LS.lSELECT137 = Me.LS.lConfirmLetter.ToString.Trim
                    Me.LS.lSELECT138 = Me.LS.lPolicyLetter.ToString.Trim
                    Me.LS.lDNC2NOADD = Me.NGS.SELECT108.ToString.Trim
                    Me.NGS.PH_2 = Me.NGS.SELECT10.ToString.Trim
                    If Me.NGS.SELECT10.ToString.Trim.Equals("B") Then
                        If Me.NGS.ZIP_2.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.FirstName2.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.SELECT35.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.LastName2.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.ADDRESSONE2.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.ADDRESSTWO2.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.CITY_2.ToString.Trim.Equals(String.Empty) And
                         Me.NGS.STATE_2.ToString.Trim.Equals(String.Empty) Then
                            '  if all fields above are empty... do nothing
                        Else
                            Me.NGS.PH_2 = "D"  'see comments above CASE statement
                        End If
                    End If
                    Me.LS.lDNCBPA2 = Me.LS.lDNCBPA.ToString.Trim
                    Me.LS.lDNCdec2 = Me.LS.lDNCdec.ToString.Trim
                    Me.LS.lDNCbn2 = Me.LS.lDNCbn.ToString.Trim
                Case 3
                    Me.LS.lDNC3ZIP = Me.LS.lmailZip.ToString.Trim
                    Me.LS.lDNC3FNAME = Me.LS.lmailFname.ToString.Trim
                    Me.LS.lDNC3MI = Me.LS.lmailMname.ToString.Trim
                    Me.LS.lDNC3LNAME = Me.LS.lmailLname.ToString.Trim
                    Me.LS.lDNC3ADD1 = Me.LS.lmailAdd1.ToString.Trim
                    Me.LS.lDNC3ADD2 = Me.LS.lmailAdd2.ToString.Trim
                    Me.LS.lDNC3CITY = Me.LS.lmailCity.ToString.Trim
                    Me.LS.lDNC3STATE = Me.LS.lmailState.ToString.Trim
                    Me.LS.lDNC3AREAC = Me.LS.lmailAreaC.ToString.Trim
                    Me.LS.lDNC3PHONE3 = Me.LS.lmailPhone3.ToString.Trim
                    Me.LS.lDNC3PHONE4 = Me.LS.lmailPhone4.ToString.Trim
                    Me.LS.lDNC3 = Me.NGS.SELECT10.ToString.Trim
                    Me.LS.lSELECT139 = Me.LS.lConfirmLetter.ToString.Trim
                    Me.LS.lSELECT140 = Me.LS.lPolicyLetter.ToString.Trim
                    Me.LS.lDNC3NOADD = Me.NGS.SELECT108.ToString.Trim
                    Me.NGS.PH_3 = Me.NGS.SELECT10.ToString.Trim
                    If Me.NGS.SELECT10.ToString.Trim.Equals("B") Then
                        If Me.LS.lDNC3ZIP.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC3FNAME.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC3MI.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC3LNAME.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC3ADD1.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC3ADD2.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC3CITY.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC3STATE.ToString.Trim.Equals(String.Empty) Then
                            '  if all fields above are empty... do nothing
                        Else
                            Me.NGS.PH_3 = "D"   'see comments above CASE statement
                        End If
                    End If
                    Me.LS.lDNCBPA3 = Me.LS.lDNCBPA.ToString.Trim
                    Me.LS.lDNCdec3 = Me.LS.lDNCdec.ToString.Trim
                    Me.LS.lDNCbn3 = Me.LS.lDNCbn.ToString.Trim
                Case 4
                    Me.LS.lDNC4ZIP = Me.LS.lmailZip.ToString.Trim
                    Me.LS.lDNC4FNAME = Me.LS.lmailFname.ToString.Trim
                    Me.LS.lDNC4MI = Me.LS.lmailMname.ToString.Trim
                    Me.LS.lDNC4LNAME = Me.LS.lmailLname.ToString.Trim
                    Me.LS.lDNC4ADD1 = Me.LS.lmailAdd1.ToString.Trim
                    Me.LS.lDNC4ADD2 = Me.LS.lmailAdd2.ToString.Trim
                    Me.LS.lDNC4CITY = Me.LS.lmailCity.ToString.Trim
                    Me.LS.lDNC4STATE = Me.LS.lmailState.ToString.Trim
                    Me.LS.lDNC4AREAC = Me.LS.lmailAreaC.ToString.Trim
                    Me.LS.lDNC4PHONE3 = Me.LS.lmailPhone3.ToString.Trim
                    Me.LS.lDNC4PHONE4 = Me.LS.lmailPhone4.ToString.Trim
                    Me.LS.lDNC4 = Me.NGS.SELECT10.ToString.Trim
                    Me.LS.lSELECT141 = Me.LS.lConfirmLetter.ToString.Trim
                    Me.LS.lSELECT142 = Me.LS.lPolicyLetter.ToString.Trim
                    Me.LS.lDNC4NOADD = Me.NGS.SELECT108.ToString.Trim
                    Me.NGS.PH_4 = Me.NGS.SELECT10.ToString.Trim
                    If Me.NGS.SELECT10.ToString.Trim.Equals("B") Then
                        If Me.LS.lDNC4ZIP.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC4FNAME.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC4MI.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC4LNAME.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC4ADD1.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC4ADD2.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC4CITY.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC4STATE.ToString.Trim.Equals(String.Empty) Then
                            '  if all fields above are empty... do nothing
                        Else
                            Me.NGS.PH_4 = "D"   'see comments above CASE statement
                        End If
                    End If
                    Me.LS.lDNCBPA4 = Me.LS.lDNCBPA.ToString.Trim
                    Me.LS.lDNCdec4 = Me.LS.lDNCdec.ToString.Trim
                    Me.LS.lDNCbn4 = Me.LS.lDNCbn.ToString.Trim
                Case 5
                    Me.LS.lDNC5ZIP = Me.LS.lmailZip.ToString.Trim
                    Me.LS.lDNC5FNAME = Me.LS.lmailFname.ToString.Trim
                    Me.LS.lDNC5MI = Me.LS.lmailMname.ToString.Trim
                    Me.LS.lDNC5LNAME = Me.LS.lmailLname.ToString.Trim
                    Me.LS.lDNC5ADD1 = Me.LS.lmailAdd1.ToString.Trim
                    Me.LS.lDNC5ADD2 = Me.LS.lmailAdd2.ToString.Trim
                    Me.LS.lDNC5CITY = Me.LS.lmailCity.ToString.Trim
                    Me.LS.lDNC5STATE = Me.LS.lmailState.ToString.Trim
                    Me.LS.lDNC5AREAC = Me.LS.lmailAreaC.ToString.Trim
                    Me.LS.lDNC5PHONE3 = Me.LS.lmailPhone3.ToString.Trim
                    Me.LS.lDNC5PHONE4 = Me.LS.lmailPhone4.ToString.Trim
                    Me.LS.lDNC5 = Me.NGS.SELECT10.ToString.Trim
                    Me.LS.lSELECT143 = Me.LS.lConfirmLetter.ToString.Trim
                    Me.LS.lSELECT144 = Me.LS.lPolicyLetter.ToString.Trim
                    Me.LS.lDNC5NOADD = Me.NGS.SELECT108.ToString.Trim
                    Me.NGS.PH_5 = Me.NGS.SELECT10.ToString.Trim
                    If Me.NGS.SELECT10.ToString.Trim.Equals("B") Then
                        If Me.LS.lDNC5ZIP.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC5FNAME.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC5MI.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC5LNAME.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC5ADD1.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC5ADD2.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC5CITY.ToString.Trim.Equals(String.Empty) And
                         Me.LS.lDNC5STATE.ToString.Trim.Equals(String.Empty) Then
                            '  if all fields above are empty... do nothing
                        Else
                            Me.NGS.PH_5 = "D"  'see comments above CASE statement
                        End If
                    End If
                    Me.LS.lDNCBPA5 = Me.LS.lDNCBPA.ToString.Trim
                    Me.LS.lDNCdec5 = Me.LS.lDNCdec.ToString.Trim
                    Me.LS.lDNCbn5 = Me.LS.lDNCbn.ToString.Trim

                Case Else
            End Select


            Me.NGS.LOGXTDAT = "Y"
            Me.LS.lXLFdnc = "Y"
            'set first layout for do not contact
            If Not Me.LS.lDNC1.ToString.Trim.Equals(String.Empty) Then
                Me.NGS.SELECT4 = "1"
            End If
            'set second layout for do not contact
            If Not Me.LS.lDNC6.ToString.Trim.Equals(String.Empty) Then
                Me.NGS.SELECT4 = "2"
            End If
            'set third layout for do not contact
            If Not Me.LS.lDNC11.ToString.Trim.Equals(String.Empty) Then
                Me.NGS.SELECT4 = "3"
            End If
            'set for confirmation letter
            If Me.LS.lSELECT135.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT137.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT139.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT141.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT143.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT145.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT147.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT149.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT151.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT153.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT155.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT157.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT159.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT161.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT163.ToString.Trim.Equals("Y") Then
                Me.NGS.SELECT22 = "Y"
            End If
            'set for policy letter
            If Me.LS.lSELECT136.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT138.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT140.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT142.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT144.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT146.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT148.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT150.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT152.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT154.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT156.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT158.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT160.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT162.ToString.Trim.Equals("Y") OrElse
             Me.LS.lSELECT164.ToString.Trim.Equals("Y") Then
                Me.NGS.SELECT23 = "Y"
            End If


        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfDoNotContact: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub



    Public Sub gfWebIVL()
        'Created: ScriptConvert:5/5/2010 11:51:29 AM


        Dim phone As String = Me.LS.lIVLparea.ToString.Trim & Me.LS.lIVLp3.ToString.Trim & Me.LS.lIVLp4.ToString.Trim
        Try
            Me.LogSystemMessageDB("Script", "Calling IVL Web Service - " & phone, True)


            Dim objReply As IVLLookupBOA.Reply


            Dim objWS As New IVLLookupBOA.Service1


            If Me.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") Then
                'production environment URL
                objWS.Url = Me.GetWebserviceValueByName("BOAWebIVLProd")
                Me.LogSystemMessageDB("Script", "IVL Web Service in Prod ", True)
            Else
                'developement enviornment URL
                objWS.Url = Me.GetWebserviceValueByName("BOAWebIVLTest")
            End If
            Try
                objReply = objWS.HomePhoneLookup(phone)
                Me.LogObjectMessageDB(objReply, True)
            Catch ex As Exception
                Me.LogException(ex)
                Me.LogSystemMessageDB("Script", "Communication error in ME.gfWebIVL - " & ex.Message, True)
                Exit Sub
            End Try
            If objReply.ReplyCode <> 0 Then
                Me.LS.lIVLweb = "N"


                Me.LogSystemMessageDB("Script", "IVL Web Service Error ", True)
            Else
                Me.LS.lIVLweb1 = objReply.ReplyCode
                Me.LS.lIVLweb2 = objReply.ReplyMessage
                Me.LS.lIVLweb3 = objReply.HomePhone
                Me.LS.lIVLweb4 = objReply.Title
                Me.LS.lIVLweb5 = objReply.FirstName
                Me.LS.lIVLweb6 = objReply.MiddleName
                Me.LS.lIVLweb7 = objReply.LastName
                Me.LS.lIVLweb8 = objReply.SecondLastName
                Me.LS.lIVLweb9 = objReply.Suffix
                Me.LS.lIVLweb10 = objReply.Address1
                Me.LS.lIVLweb11 = objReply.Address2
                Me.LS.lIVLweb12 = objReply.Address3
                Me.LS.lIVLweb13 = objReply.City
                Me.LS.lIVLweb14 = objReply.State
                Me.LS.lIVLweb15 = objReply.Zip
                Me.LS.lIVLweb16 = objReply.Last4Account
                Me.LS.lIVLweb17 = objReply.ProgramCode
                Me.LS.lIVLweb18 = objReply.GroupTransparent
                Me.LS.lIVLweb19 = objReply.GroupName
                Me.LS.lIVLweb20 = objReply.CardType
                Me.LS.lIVLweb = "Y"
                If Me.LS.lIVLweb3.ToString.Trim <> String.Empty Then
                    Me.LS.lmailAreaC = Me.LS.lIVLweb3.Substring(0, 3)
                    Me.LS.lmailPhone3 = Me.LS.lIVLweb3.Substring(3, 3)
                    Me.LS.lmailPhone4 = Me.LS.lIVLweb3.Substring(6, 4)
                End If


                Me.LS.lHomePhone = objReply.HomePhone
                Me.LS.lmailFname = objReply.FirstName
                Me.LS.lmailMname = objReply.MiddleName
                Me.LS.lmailLname = objReply.LastName
                Me.LS.lmailAdd1 = objReply.Address1
                Me.LS.lmailAdd2 = objReply.Address2
                Me.LS.lmailCity = objReply.City
                Me.LS.lmailState = objReply.State
                Me.LS.lmailZip = objReply.Zip
            End If


            Me.LS.lWebReply = "Y"


        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Function error in ME.gfWebIVL - " & ex.Message, True)
        End Try
    End Sub

    Public Sub LogObjectMessageDB(objReply As Object, v As Boolean)

    End Sub

    Public Sub gfDataShareRetrieveWS_NotUsed()
        Try
            'Set the Key
            Me.LS.lDataShareKeySend = Me.UPC.CallData.ani.ToString.Trim

            'New Datashare Library Logic
            Dim dsDictionary As New Dictionary(Of String, String)

            'Retrieve the data
            dsDictionary = Me.RetrieveDataShareWs(Me.LS.lDataShareKeySend)

            If dsDictionary.Count > 0 Then
                For Each nvp As KeyValuePair(Of String, String) In dsDictionary
                    Select Case nvp.Key
                        Case "ani"
                            Me.LS.lDSani = nvp.Value

                            If Not Me.LS.lDSani.ToString.Trim.Equals(String.Empty) Then
                                Me.NGS.M_ANI_AREA_C = Me.LS.lDSani.Substring(0, 3)
                                Me.NGS.M_ANI_PHONE = Me.LS.lDSani.Substring(3, 7)
                                Me.NGS.M_AREA_C = Int(Me.LS.lDSani.Substring(0, 3))
                                Me.NGS.M_PHONE_3 = Int(Me.LS.lDSani.Substring(3, 3))
                                Me.NGS.M_PHONE_4 = Int(Me.LS.lDSani.Substring(6, 4))
                            End If
                        Case "800num"
                            Me.LS.lDS800num = nvp.Value
                        Case "dmol"
                            Me.LS.lDSdmol = nvp.Value
                        Case "170"
                            Me.LS.lDS170 = nvp.Value
                        Case "218"
                            Me.LS.lDS218 = nvp.Value
                        Case "132"
                            Me.LS.lDS132 = nvp.Value
                        Case "135"
                            Me.LS.lDS135 = nvp.Value
                        Case "217"
                            Me.LS.lDS217 = nvp.Value
                        Case "180"
                            Me.LS.lDS180 = nvp.Value
                        Case "182"
                            Me.LS.lDS182 = nvp.Value
                        Case "184"
                            Me.LS.lDS184 = nvp.Value
                        Case "187"
                            Me.LS.lDS187 = nvp.Value
                        Case "152"
                            Me.LS.lDS152 = nvp.Value
                    End Select
                Next
            Else
                Me.LS.ldataShareErr = "Y"
                Me.NGS.M_ANI_AREA_C = "000"
                Me.NGS.M_ANI_PHONE = "0000000"
                Me.NGS.M_AREA_C = "000"
                Me.NGS.M_PHONE_3 = "000"
                Me.NGS.M_PHONE_4 = "0000"
                Me.LS.lDatapassSuccessful = "N"
                Me.LogSystemMessage("gfDataShareRetrieve - ", "Datashare retrieve is returning error")
            End If

            If LS.lDS182.Length > 0 Then
                If Not Me.LS.lDS182.Equals("0") Then
                    Me.LS.lIVRdisp = Me.LS.lDS182.ToString.Trim
                    Me.NGS.CODE20_1 = Me.LS.lDS182.ToString.Trim
                    Me.LS.lDatapassSuccessful = "Y"
                End If
            End If

            If LS.lDS184.Length > 0 Then
                If Not Me.LS.lDS184.Equals("0") Then
                    Me.LS.lIVRdisp = Me.LS.lDS184.ToString.Trim
                    Me.NGS.CODE15_13 = Me.LS.lDS184.ToString.Trim
                    Me.LS.lDatapassSuccessful = "Y"
                End If
            End If
        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfDataShareRetrieve: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try
    End Sub

    Private Function RetrieveDataShareWs(lDataShareKeySend As String) As Dictionary(Of String, String)
        Throw New NotImplementedException()
    End Function

    Private Sub bgw_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs) Handles bgw.DoWork
        Thread.Sleep(1000 * 3) 'delay for 3seconds
        e.Result = IsRetry() ' return false if webservice has a value
        retryCtr += 1 ' iterate every retry
    End Sub


    Private Sub bgw_RunWorkerCompleted(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs) Handles bgw.RunWorkerCompleted
        Dim iSNoWsResult As Boolean = Convert.ToBoolean(e.Result)
        If iSNoWsResult And retryCtr < retryCount Then
            If bgw.IsBusy = False Then
                bgw.RunWorkerAsync()
            End If
        Else

            If BOA_VDNslist.Count <= 0 Then
                InitializeBOARouteCallVDNList()
            End If

            'var5var1lbl = "Wge3Dgb4Cg-8882248735-4760571"
            Dim wsArray() As String = var5var1lbl.Split("-") 'get the first part of Var5Var1Label and set as callID
            callID = wsArray(0)

            If wsArray.Count >= 3 Then
                Me.NGS.BusinessData37 = callID 'callID from CSG webservice
                Me.NGS.BusinessData38 = wsArray(1) 'Originating Number from CSG webservice
                Me.NGS.BusinessData39 = wsArray(2) 'VDN from CSG webservice
                Me.NGS.BusinessData40 = wsSuccess 'Result Success or Not
            Else
                Me.NGS.BusinessData37 = ""
                Me.NGS.BusinessData38 = ""
                Me.NGS.BusinessData39 = ""
                Me.NGS.BusinessData40 = wsSuccess
            End If

            ' RS05092018 Set lOriginalRTN to VDN from CSG webservice 
            If String.IsNullOrWhiteSpace(NGS.BusinessData39) Then
                LS.lOriginalRTN = UPC.CallData.rtn
            Else
                LS.lOriginalRTN = NGS.BusinessData39
            End If

            Call LogSystemMessage("BOA Route Call Detail", String.Format("Var5Var1Label = {0}, callID = {3}, wsMessage = {1}, wsSuccess = {2}", var5var1lbl, wsMessage, wsSuccess, callID))

            CSGWebServiceFunc((UPC.CallData.rtn = "4760206" Or UPC.CallData.rtn = "5907125") And (BOA_VDNslist.ContainsKey(Me.NGS.BusinessData39.Trim())))
            RaiseEvent OnBOARouteCallDetailsOnLoad("", Nothing)
        End If
    End Sub

    'Public Custom Event OnBOARouteCallDetailsOnLoad As EventHandler
    '    AddHandler(ByVal value As EventHandler)
    '        Me.Events.AddHandler("ThemeChangedEvent", value)
    '    End AddHandler

    '    RemoveHandler(ByVal value As EventHandler)
    '        Me.Events()
    '        Me.Events.RemoveHandler("ThemeChangedEvent", value)
    '    End RemoveHandler

    '    RaiseEvent(ByVal sender As Object, ByVal e As System.EventArgs)
    '        CType(Me.Events("ThemeChangedEvent"), EventHandler).Invoke(sender, e)
    '    End RaiseEvent
    'End Event

    Public Event OnBOARouteCallDetailsOnLoad As EventHandler
    Protected Overridable Sub OnCountdownCompleted(ByVal e As EventArgs)
        RaiseEvent OnBOARouteCallDetailsOnLoad(Me, e)
    End Sub

    Private Sub InitializeBOARouteCallVDNList()
        Try

            BOA_VDNslist.Clear()

            BOA_VDNslist.Add("4760482", "SAT")
            BOA_VDNslist.Add("4760571", "SAT")
            BOA_VDNslist.Add("4760179", "SAT")
            BOA_VDNslist.Add("4760604", "SAT")
            BOA_VDNslist.Add("4760058", "SAT")
            BOA_VDNslist.Add("4760244", "SAT")
            BOA_VDNslist.Add("4760224", "SAT")
            BOA_VDNslist.Add("4760658", "SAT")
            BOA_VDNslist.Add("4760248", "SAT")
            BOA_VDNslist.Add("4760669", "SAT")
            BOA_VDNslist.Add("4760208", "SAT")
            BOA_VDNslist.Add("4760070", "SAT")
            BOA_VDNslist.Add("4760619", "SAT")

            BOA_VDNslist.Add("5907326", "UTICA")
            BOA_VDNslist.Add("5907650", "UTICA")
            BOA_VDNslist.Add("5907110", "UTICA")
            BOA_VDNslist.Add("5907539", "UTICA")
            BOA_VDNslist.Add("5907510", "UTICA")
            BOA_VDNslist.Add("5907145", "UTICA")
            BOA_VDNslist.Add("5907584", "UTICA")
            BOA_VDNslist.Add("5907527", "UTICA")
            BOA_VDNslist.Add("5907146", "UTICA")
            BOA_VDNslist.Add("5907538", "UTICA")
            BOA_VDNslist.Add("5907579", "UTICA")
            BOA_VDNslist.Add("5907027", "UTICA")
            BOA_VDNslist.Add("5907135", "UTICA")

        Catch ex As Exception

        End Try
    End Sub

    Function IsRetry() As Boolean
        Try

            var5var1lbl = boaRoute.GetVar5Var1Label(UPC.CallData.ani).Var5Var1Label
            wsMessage = boaRoute.GetVar5Var1Label(UPC.CallData.ani).wsMessage
            wsSuccess = boaRoute.GetVar5Var1Label(UPC.CallData.ani).wsSuccess

            Return String.IsNullOrWhiteSpace(var5var1lbl)

        Catch ex As Exception
            Return True
        End Try

    End Function



    Private Sub CSGWebServiceFunc(ByVal IsValidDefaultCallOrNotADefaultCall As Boolean)
        Dim url As String = "https://im.csgsystems.com/ctiRestService/CTIData.php?appId=" & appID & "&callId=" & callID
        Call LogSystemMessage("CSG Web Service", "URL = " & url)

        '20170223 cosaih xp80643: Added timeout
        Dim sPingTimeString As String = "PINGTIMECSGWEBSERVICE:"
        Dim starttime As New DateTime
        Dim endtime As New DateTime
        Dim elapsedtime As TimeSpan
        Dim response As System.Net.HttpWebResponse
        Try

            starttime = DateTime.Now
            System.Net.ServicePointManager.SecurityProtocol = DirectCast(3072, Net.SecurityProtocolType)
            Dim request As System.Net.HttpWebRequest = CType(System.Net.WebRequest.Create(url), System.Net.HttpWebRequest)

            'Set defualt timout value to 30 seconds
            request.Timeout = 30000

            'Send request and load its returned value into the response object we declared earlier.  Any exceptions will be thrown to the catch block
            response = CType(request.GetResponse(), System.Net.HttpWebResponse)

            Dim jsonResponse As String = String.Empty

            'Read result into srText
            jsonResponse = New System.IO.StreamReader(response.GetResponseStream()).ReadToEnd()
            Call LogSystemMessage("CSG Web Service", "RESPONSE FROM from WEB SERVICE IS =" & jsonResponse)
            Dim parsedJSONResponse As JObject = JObject.Parse(jsonResponse)


            If IsValidDefaultCallOrNotADefaultCall Then
                Select Case parsedJSONResponse.SelectToken("ctiInfo").SelectToken("result").ToString()
                    Case "success"
                        If parsedJSONResponse.SelectToken("ctiInfo").SelectToken("ivrInfo").SelectToken("application").ToString() = "Call ID" Then
                            Dim jToken As JToken = parsedJSONResponse.SelectToken("ctiInfo").SelectToken("ivrInfo").SelectToken("ID")
                            If IsNothing(jToken) Then
                                Exit Sub
                            End If
                            Me.LS.lDatapassSuccessful = "Y"
                            NGS.DataShareCallID = jToken.ToString()
                            Me.LS.lIVRdisp = jToken.ToString()
                            Me.NGS.CODE20_1 = jToken.ToString()
                        End If
                    Case "failed"
                        Me.LS.lDatapassSuccessful = "N"
                        Dim errMessage As String = parsedJSONResponse.SelectToken("ctiInfo").SelectToken("error").ToString()
                        Call LogSystemMessage("CSG Web Service", "Error Retrieving CSG Data - Exception in WS is " & errMessage)
                End Select
            End If


        Catch ex1 As Exception
            Call LogException(ex1)
            Call LogSystemMessage("CSG Web Service", "Error Writing CSG Data - Exception in WS is " & ex1.Message())

            endtime = DateTime.Now
            elapsedtime = endtime.Subtract(starttime)
            Call LogSystemMessage("CSG Web Service", "START TIME: " & starttime)
            Call LogSystemMessage("CSG Web Service", "END TIME: " & endtime)
            Call LogSystemMessage("CSG Web Service elapsedtime: ", sPingTimeString & elapsedtime.TotalMilliseconds.ToString)
            Exit Sub
        End Try
    End Sub

    Public Sub gfDataShareRetrieveWS()
        Try
            'perform the hit
            callID = UPC.CallData.ApplicationData
            appID = String.Empty
            'If ready to go live, uncomment the Select Case statement
            'Select Case UPC.System.ScriptEnv.ToString().ToUpper()
            '    Case "PRD"
            '        appID = "12256"
            '    Case "TST", "TRN"
            '        appID = "12255"
            'End Select
            appID = "12255" '"12256" 'If ready to go live, uncomment the Select Case statement and comment this code
            If String.IsNullOrEmpty(UPC.CallData.ApplicationData) Then
                LogSystemMessage("Script", "Error - UPC.CallData.ApplicationData has no value")
            ElseIf callID.IndexOf("|", 0) > 0 Then
                Dim appData As String() = callID.Split("|", 2, StringSplitOptions.RemoveEmptyEntries)
                Select Case appData.Length
                    Case 1, 2
                        callID = appData(appData.Length - 1)
                End Select
            End If

            If UPC.CallData.rtn = "4760206" Or UPC.CallData.rtn = "5907125" Then 'XP82260 default BOA VDNs
                If boaRoute Is Nothing Then
                    boaRoute = New BOARouteCall.BOARouteCallDetail()
                End If

                retryCtr = 0
                If bgw.IsBusy = False Then
                    bgw.RunWorkerAsync()
                End If
            Else
                LS.lOriginalRTN = UPC.CallData.rtn
                CSGWebServiceFunc(True)
                RaiseEvent OnBOARouteCallDetailsOnLoad("", Nothing)
            End If

        Catch ex As Exception
            Call LogException(ex)
            Call LogSystemMessage("CSG", "Error Writing CSG Data - Exception in WS is " & ex.Message())
        End Try
    End Sub

    Public Sub gfDataShareRetrieve()
        'Created: ScriptConvert:5/5/2010 11:51:30 AM
        '********************************************************************************************************************************
        'Description : 
        'This function Get Wic Layout for 800 Numbers and save 170, 184, 182... Fields to local store lDS170, lDS184. 
        ' We store 182 - Employee Id --> Code20_1
        '		   184 - Branch Id   --> Code15_13
        '*********************************************************************************************************************************
        Try
            'Set the Key
            Me.LS.lDataShareKeySend = Me.UPC.CallData.ani.ToString.Trim
            Me.RetrieveDataShareSOAP(Me.LS.ldsStringFromIVR, Me.LS.lDataShareKeySend.ToString.Trim, Me.UPC.System.ScriptEnv, Me.UPC.StationConfiguration.ScriptEnv)

            If Me.LS.ldsStringFromIVR.Contains("ERROR") Or Me.LS.ldsStringFromIVR.ToString.Trim.Equals(String.Empty) Then
                Me.LS.ldataShareErr = "Y"
                Me.NGS.M_ANI_AREA_C = "000"
                Me.NGS.M_ANI_PHONE = "0000000"
                Me.NGS.M_AREA_C = "000"
                Me.NGS.M_PHONE_3 = "000"
                Me.NGS.M_PHONE_4 = "0000"
                Me.LS.lDatapassSuccessful = "N"
                Me.LogSystemMessage("lDataShareKeySend - ", "Datashare retrieve is returning error")
                'ElseIf Me.LS.ldsStringFromIVR.ToString.Trim.Equals(String.Empty) Then
                '    Me.LS.ldataShareErr = "Y"
                '    Me.NGS.M_ANI_AREA_C = "000"
                '    Me.NGS.M_ANI_PHONE = "0000000"
                '    Me.NGS.M_AREA_C = "000"
                '    Me.NGS.M_PHONE_3 = "000"
                '    Me.NGS.M_PHONE_4 = "0000"
                '    Me.LS.lDatapassSuccessful = "N"
                '    Me.LogSystemMessage("lDataShareKeySend - ", "Datashare not retrieving any record")
            Else
                Dim MyString As String = Me.LS.ldsStringFromIVR.ToString.Trim
                Me.LS.lMyString = MyString
                Me.LS.lDSani = Me.gfParseIt("ani", MyString)
                Me.LS.lDS800num = Me.gfParseIt("800num", MyString)
                Me.LS.lDSdmol = Me.gfParseIt("dmol", MyString)
                Me.LS.lDS170 = Me.gfParseIt("170", MyString)
                Me.LS.lDS218 = Me.gfParseIt("218", MyString)
                Me.LS.lDS132 = Me.gfParseIt("132", MyString)
                Me.LS.lDS135 = Me.gfParseIt("135", MyString)
                Me.LS.lDS217 = Me.gfParseIt("217", MyString)
                Me.LS.lDS180 = Me.gfParseIt("180", MyString)
                Me.LS.lDS182 = Me.gfParseIt("182", MyString)
                Me.LS.lDS184 = Me.gfParseIt("184", MyString)
                Me.LS.lDS187 = Me.gfParseIt("187", MyString)
                Me.LS.lDS152 = Me.gfParseIt("152", MyString)

                If Not Me.LS.lDSani.ToString.Trim.Equals(String.Empty) Then
                    Me.NGS.M_ANI_AREA_C = Me.LS.lDSani.Substring(0, 3)
                    Me.NGS.M_ANI_PHONE = Me.LS.lDSani.Substring(3, 7)
                    Me.NGS.M_AREA_C = Int(Me.LS.lDSani.Substring(0, 3))
                    Me.NGS.M_PHONE_3 = Int(Me.LS.lDSani.Substring(3, 3))
                    Me.NGS.M_PHONE_4 = Int(Me.LS.lDSani.Substring(6, 4))
                End If
            End If

            Dim ShareMsg As System.Text.StringBuilder = New System.Text.StringBuilder(500)
            ShareMsg.Append("DataShare=").Append(Me.LS.lDataShareKeySend.ToString.Trim)
            ShareMsg.Append(" - HTTP Response - ").Append(Me.LS.lBadHttp.ToString.Trim)
            ShareMsg.Append(" - My string before replaces - ").Append(Me.LS.lMyString.ToString.Trim)
            ShareMsg.Append(" - My string after replaces - ").Append(Me.LS.lMyString1.ToString.Trim)
            ShareMsg.Append(" - ANI - ").Append(Me.LS.lDSani.ToString.Trim)
            ShareMsg.Append(" - 800Num - ").Append(Me.LS.lDS800num.ToString.Trim)
            ShareMsg.Append(" - lDSdmol - ").Append(Me.LS.lDSdmol.ToString.Trim)
            ShareMsg.Append(" - lDS170 - ").Append(Me.LS.lDS170.ToString.Trim)
            ShareMsg.Append(" - lDS218 - ").Append(Me.LS.lDS218.ToString.Trim)
            ShareMsg.Append(" - lDS132 - ").Append(Me.LS.lDS132.ToString.Trim)
            ShareMsg.Append(" - lDS135 - ").Append(Me.LS.lDS135.ToString.Trim)
            ShareMsg.Append(" - lDS217 - ").Append(Me.LS.lDS217.ToString.Trim)
            ShareMsg.Append(" - lDS180 - ").Append(Me.LS.lDS180.ToString.Trim)
            ShareMsg.Append(" - lDS182 - ").Append(Me.LS.lDS182.ToString.Trim)
            'ShareMsg.Append(" - lDS184 - ").Append(getDataTrim ("LS", "lDS132")) kvyas it was storing on wrong local store filed
            ShareMsg.Append(" - lDS184 - ").Append(Me.LS.lDS184.ToString.Trim)
            ShareMsg.Append(" - lDS187 - ").Append(Me.LS.lDS187.ToString.Trim)
            ShareMsg.Append(" - lDS217 - ").Append(Me.LS.lDS217.ToString.Trim)
            ShareMsg.Append(" - lDS152 - ").Append(Me.LS.lDS152.ToString.Trim)
            ShareMsg.Append(" - ldataShareErr - ").Append(Me.LS.ldataShareErr.ToString.Trim)
            ShareMsg.Append("lDataPassSuccessful - ").Append(Me.LS.lDatapassSuccessful.ToString.Trim)
            Me.LogSystemMessage("lDataShareKeySend - ", ShareMsg.ToString())
            '	call LogMessage ( "lDataShareKeySend - " &  getData ("LocalStore", "lDataShareKeySend") & " - HTTP Response - " &  getData ("LS", "lBadHttp") &  _
            '	" - My string before replaces - " &  getData ("LS", "lMyString" ) & " - My string after replaces - " &  getData ("LS", "lMyString1" ) & _
            '	" - ANI - " &  getData ("LS", "lDSani") & " - 800Num - " &  getData ("LS", "lDS800num") & _
            '	" - lDSdmol - " &  getData ("LS", "lDSdmol") & " - lDS170 - " &  getData ("LS", "lDS170") & _
            '	" - lDS218 - " &  getData ("LS", "lDS218") & " - lDS132 - " &  getData ("LS", "lDS132") & _
            '	" - lDS135 - " &  getData ("LS", "lDS135") & " - lDS135 - " &  getData ("LS", "lDS135") & _
            '	" - lDS217 - " &  getData ("LS", "lDS217") & " - lDS180 - " &  getData ("LS", "lDS180") & _
            '	" - lDS182 - " &  getData ("LS", "lDS182") & " - lDS184 - " &  getData ("LS", "lDS184") & _
            '	" - lDS187 - " &  getData ("LS", "lDS187") & " - lDS152 - " &  getData ("LS", "lDS152") & _
            '	" - ldataShareErr - " &  getData ("LocalStore", "ldataShareErr") &  "lDataPassSuccessful - " &  getData ("LocalStore", "lDataPassSuccessful"))

            '  Dim lDS182Compare As Boolean = Int32.TryParse(Me.LS.lDS182, 0)
            'If Not LS.lDS182.Equals(String.Empty) Then
            If LS.lDS182.Length > 0 Then
                If Not Me.LS.lDS182.Equals("0") Then
                    'If Not lDS182Compare Then
                    Me.LS.lIVRdisp = Me.LS.lDS182.ToString.Trim
                    Me.NGS.CODE20_1 = Me.LS.lDS182.ToString.Trim
                    Me.LS.lDatapassSuccessful = "Y"
                End If
            End If
            ' Dim lDS184Compare As Boolean = Int32.TryParse(Me.LS.lDS184, 0)

            'kvyas added seperated If statement for Code15_13 field. 08/16/2011

            ' If Not lDS184Compare Then
            If LS.lDS184.Length > 0 Then
                If Not Me.LS.lDS184.Equals("0") Then
                    Me.LS.lIVRdisp = Me.LS.lDS184.ToString.Trim
                    '    call setData  ("DataStore", "CODE20_1", getDataTrim ("LocalStore", "lDS184")  ) 'IDS184 was storing as Code20_1 but its rightw data store is CODE15_13
                    Me.NGS.CODE15_13 = Me.LS.lDS184.ToString.Trim
                    Me.LS.lDatapassSuccessful = "Y"
                End If
            End If
        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfDataShareRetrieve: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try



    End Sub

    Private Sub RetrieveDataShareSOAP(ldsStringFromIVR As String, trim As String, scriptEnv1 As Object, scriptEnv2 As Object)
        Throw New NotImplementedException()
    End Sub

    Public Function gfParseIt(ByVal pName As String, ByVal pMyString As String) As String
        'Created: ScriptConvert:5/5/2010 11:51:30 AM


        'TODO:  20100520 lapeters - Make sure the dataTypes are correct.
        Try
            Dim returnValue As String = String.Empty
            Dim myarray As Array
            myarray = Split(pMyString, "&")
            Dim MyArray2 As Array
            Dim x As String = String.Empty


            For Each x In myarray
                MyArray2 = Split(x, "=")
                If MyArray2(0) = pName Then
                    gfParseIt = MyArray2(1)
                    Return gfParseIt
                End If
            Next

            Return Nothing
        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfParseIt: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
            Return Nothing
        End Try


    End Function


    Public Sub gfSendEMailEscalation()
        'Created:OM6356D1:cshepler:05/13/2010 07:36:14 PM
        ' -------------------------------------------------------------------
        ' Name:
        '   gfSendEmailEscalation
        ' Description:
        '	Formats Escalation Form Email
        ' Author:
        '   Converted from BW4
        ' Revision:
        '   XP 26279    20110207    cgossman      changed To: CC: From: and body of email
        '   XP 61501    20131030    wzhang      Update CC email
        ' -------------------------------------------------------------------
        Try
            Dim toAddr As String = String.Empty
            Dim ccAddr As String = String.Empty
            Dim strEmail As New System.Text.StringBuilder(3000)
            strEmail.Append("Time: ").Append(Me.LS.ltodaysDate.ToString.Trim).Append(Environment.NewLine)
            strEmail.Append("Site: ").Append(Me.LS.lSiteName.ToString.Trim).Append(Environment.NewLine)
            strEmail.Append("Agent Name: ").Append(Me.UPC.AgentInfo.fullname.ToString.Trim).Append(Environment.NewLine)
            strEmail.Append("Supervisor Name: ").Append(Me.LS.lTLName.ToString.Trim).Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Contact Number: (815) 312-3444").Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Alternate Contact: Paul Breeden   TeamWiser@gmail.com").Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Supplier Name: ALORICA").Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Customer Name: ").Append(Me.LS.lCustName.ToString.Trim).Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Customer Phone Number: ").Append(Me.LS.lCustPhone.ToString.Trim).Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Customer Zip Code: ").Append(Me.LS.lCustZip.ToString.Trim).Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Transparent: ").Append(Me.NGS.Transparency.ToString.Trim).Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Best Time To Contact: ").Append(Me.LS.lCustBestTime.ToString.Trim).Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Customer Concern: ").Append(Me.LS.lCustConcern.ToString.Trim).Append(Environment.NewLine).Append(Environment.NewLine)
            strEmail.Append("Steps Taken: ").Append(Me.NGS.ManagerResolution.ToString.Trim).Append(Environment.NewLine)


            If Me.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") Then   'production
                toAddr = "CS_Escalation_NE_CS@bankofamerica.com"
                ccAddr = Me.GetEmailValueByName("BOAEscalationList", "PRD")
            Else
                toAddr = Me.GetEmailValueByName("BOAEscalationListTest", "TST")
            End If
            SendEmailFourOh(toAddr, ccAddr, "UPCTeam@gmail.com", "West - Complaint", strEmail.ToString())


        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfSendEMailEscalation: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub

    Private Function GetEmailValueByName(v1 As String, v2 As String) As String
        Throw New NotImplementedException()
    End Function

    Public Sub gfCalcIncome2()
        'Created:OM6356D1:cshepler:05/15/2010 10:34:40 AM
        'TODO 20100520 lapeters/caryn - find and replace the Local Stores similar to lSELECT45 or 46 and lCheckAmt1 or 2 with there new names.
        Try
            Dim pensiontotal As Integer = 0
            Dim pensionamount As Integer = 0
            Dim salaryammount As Integer = 0
            Dim salarytotal As Integer = 0
            Dim selftotal As Integer = 0
            Dim incomeammount As Integer = 0
            Dim studentammount As Integer = 0
            Dim studenttotal As Integer = 0
            Dim totalannualIncome As Integer = 0


            'There are 52 weeks in a year
            '2080 is the number of hours when you work full time for a year (40*52)


            'Not calculating anything for refused option a
            '''''''''''''''''''''''''''''''''''''''''''''''
            'retired -option b
            'lSubtot1 is pension amount to be calculated annually
            'lCheckAmt1 is current salary amount
            'lSELECT45 is the frequency for currrnt salary
            'lHours = number of hours for current employer


            If Me.LS.lManualOccupation.ToString.Trim.Equals("B") Then
                'pensionamount = getDataInt ("LocalStore", "lSubtot1") 
                'salaryammount = getDataInt ("LocalStore", "lCheckAmt1")
                pensionamount = CInt(Me.LS.lSubtot1)
                salaryammount = CInt(Me.LS.lCheckAmt1)
                Select Case Me.LS.lPensionFrequency.ToString.Trim
                    Case "A"    'Weekly
                        pensiontotal = pensionamount * 52
                    Case "B"    'Bi-Weekly
                        pensiontotal = pensionamount * 26
                    Case "C"    'Monthly
                        pensiontotal = pensionamount * 12
                    Case "D"    'Annually
                        pensiontotal = pensionamount
                    Case Else
                End Select
                If Me.LS.lSELECT46.ToString.Trim.Equals("Y") Then
                    Select Case Me.LS.lSELECT45.ToString.Trim
                        Case "A"    'Weekly
                            salarytotal = salaryammount * 52
                        Case "B"    'Monthly
                            salarytotal = salaryammount * 12
                        Case "C"    'Annually
                            salarytotal = salaryammount
                        Case "D"    'Hourly
                            If CInt(Me.LS.lHours) > 0 Then
                                salarytotal = salaryammount * CInt(Me.LS.lHours) * 52
                            Else
                                salarytotal = salaryammount * 2080
                            End If
                        Case "E"    'Bi-Weekly
                            salarytotal = salaryammount * 26
                        Case Else
                    End Select
                Else
                    salarytotal = 0
                End If
                totalannualIncome = pensiontotal + salarytotal
            End If
            'end of retired''''''''''''''''''''''''''
            '''''''''''''''''''''''''''''''''''''''''''''''
            'self employed -option c
            'lCheckAmt3 is Income amount
            'lSELECT52 is the frequency for Income
            If Me.LS.lManualOccupation.ToString.Trim.Equals("C") Then
                incomeammount = CInt(Me.LS.lCheckAmt3)
                Select Case Me.LS.lSELECT52.ToString.Trim
                    Case "A"    'Weekly
                        selftotal = incomeammount * 52
                    Case "B"    'Monthly
                        selftotal = incomeammount * 12
                    Case "C"    'Yearly
                        selftotal = incomeammount
                    Case "E"    'Bi-Weekly
                        selftotal = incomeammount * 26
                    Case Else
                End Select
                totalannualIncome = selftotal
            End If
            'end of self employed
            '''''''''''''''''''''''''''''''''''''''''''''''
            'student -option d
            'lCheckAmt2 is Income amount
            'lSELECT50 is the frequency for Income
            'lHoursStudents is the number of hours 
            If Me.LS.lManualOccupation.ToString.Trim.Equals("D") Then
                studentammount = CInt(Me.LS.lCheckAmt2)
                Select Case Me.LS.lSELECT50.ToString.Trim
                    Case "A"    'Weekly
                        studenttotal = studentammount * 52
                    Case "B"    'Monthly
                        studenttotal = studentammount * 12
                    Case "C"    'Annually
                        studenttotal = studentammount
                    Case "D"    'Hourly
                        If CInt(Me.LS.lHoursStudents) > 0 Then
                            studenttotal = studentammount * CInt(Me.LS.lHoursStudents) * 52
                        Else
                            studenttotal = studentammount * 2080
                        End If
                    Case "E"    'Bi-Weekly
                        studenttotal = studentammount * 26
                    Case Else
                End Select
                totalannualIncome = studenttotal
            End If
            'end of student
            ''''''''''''''''''''''''''''''''''''''''''''''''''''
            'Not calculating anything for unemployment option e
            ''''''''''''''''''''''''''''''''''''''''''''''''''''
            'other -option f
            'lCheckAmt1 is Income amount
            'lSELECT45 is the frequency for Income
            'lHours = number of hours for current employer
            If Me.LS.lManualOccupation.ToString.Trim.Equals("F") Then
                salaryammount = CInt(Me.LS.lCheckAmt1)
                Select Case Me.LS.lSELECT45.ToString.Trim
                    Case "A"    'Weekly
                        salarytotal = salaryammount * 52
                    Case "B"    'Monthly
                        salarytotal = salaryammount * 12
                    Case "C"    'Annually
                        salarytotal = salaryammount
                    Case "D"    'Hourly
                        If CInt(Me.LS.lHours) > 0 Then
                            salarytotal = salaryammount * CInt(Me.LS.lHours) * 52
                        Else
                            salarytotal = salaryammount * 2080
                        End If
                    Case "E"    'Bi-Weekly
                        salarytotal = salaryammount * 26
                    Case Else
                End Select
                totalannualIncome = salarytotal
            End If
            ' end of other


            'sets the total annual income
            'changed from lManualTotalIncome num 7 to lAnnualSalary num 10 tmf 6/14/06
            'call setData  ("LocalStore", "lManualTotalIncome", totalannualIncome )
            Me.LS.lAnnualSalary = totalannualIncome


            '2-7-06 TMF added field for total pension ammount 
            Me.LS.lAnnualPensionAmt = pensiontotal




        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfCalcIncome2: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub

    Public Sub gfIncrementNGSCounters()
        'Created:BW Conversion:5/17/2010 12:00:29 PM


        Try
            'Start of code from the SetFixedCounters counter rule.
            If Me.NGS.M_PROB_CALL_I = "O" Then
                'ORIGINAL CODE ->     call setData("CounterRules","1",1)
                ' Counter # "1" = ORDER-COUNT
                Me.NGS.CountersORDERCOUNT = 1
            End If
            If Me.NGS.M_PROB_CALL_I = "R" Then
                'ORIGINAL CODE ->     call setData("CounterRules","3",1)
                ' Counter # "3" = REFERRAL-COUNT
                Me.NGS.CountersREFERRALCOUNT = 1
            End If
            If Me.NGS.M_PROB_CALL_I = "I" Then
                'ORIGINAL CODE ->     call setData("CounterRules","4",1)
                ' Counter # "4" = INQUIRY-COUNT
                Me.NGS.CountersINQUIRYCOUNT = 1
            End If
            If Me.NGS.M_PROB_CALL_I = "P" Then
                'ORIGINAL CODE ->     call setData("CounterRules","5",1)
                ' Counter # "5" = DOC-CS-COUNT
                Me.NGS.CountersDOCCSCOUNT = 1
            End If
            'End of code from the SetFixedCounters counter rule.
            '******************************************************************
        Catch ex As Exception
            Throw
        End Try


        '***********
        'copied from BOATESTFORBW6
        Try
            'Start of code from the DCC counter rule.
            'End of code from the DCC counter rule.
            '******************************************************************
            'Start of code from the MaualApp counter rule.
            Select Case Me.NGS.SELECT82
                Case "A"   'CC Rate Issue
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "317", 1 )
                    ' Counter #  "317" = CC-RATE-ISSUE
                    Me.NGS.CountersCCRATEISSUE = 1
                Case "B"    'CC System Down
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "318", 1 )
                    ' Counter #  "318" = CC-SYS-DOWN
                    Me.NGS.CountersCCSYSDOWN = 1
                Case "C"    'CF pricing Issue
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "319", 1 )
                    ' Counter #  "319" = CF-MANUAL-APP
                    Me.NGS.CountersCFMANUALAPP = 1
                Case Else
            End Select
            'End of code from the MaualApp counter rule.
            '******************************************************************
            'Start of code from the OtherStuff counter rule.
            If Me.NGS.SELECT89 = "A" Or
             Me.NGS.SELECT98 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "129", 1 )
                ' Counter #  "129" = FRIEND-FAMILY
                Me.NGS.CountersFRIENDFAMILY = 1
            End If
            If Me.NGS.SELECT113 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "95", 1 )
                ' Counter #  "95" = TAC-RATES-HIGH
                Me.NGS.CountersTACRATESHIGH = 1
            End If
            If Me.NGS.SELECT111 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "96", 1 )
                ' Counter #  "96" = TAC-PROMO-SHORT
                Me.NGS.CountersTACPROMOSHORT = 1
            End If
            If Me.NGS.SELECT112 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "97", 1 )
                ' Counter #  "97" = TAC-CREDIT-CHECK
                Me.NGS.CountersTACCREDITCHECK = 1
            End If
            'End of code from the OtherStuff counter rule.
            '******************************************************************
            'Start of code from the CreditCardAutoDecline counter rule.
            If Me.NGS.SELECT92.ToString.Trim = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "82", 1 )
                ' Counter #  "82" = WHY-DENIED
                Me.NGS.CountersWHYDENIED = 1
            End If
            If Me.NGS.SELECT92.ToString.Trim = "N" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "135", 1 )
                ' Counter #  "135" = TACS_QUES_EX_BNK
                Me.NGS.CountersTACS_QUES_EX_BNK = 1
            End If
            If Me.NGS.SELECT91.ToString.Trim = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "87", 1 )
                ' Counter #  "87" = MEMBER-BENEFITS
                Me.NGS.CountersMEMBERBENEFITS = 1
            End If
            Select Case Me.NGS.SELECT89
                Case "A"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "21", 1 )  'Housecalls only
                    ' Counter #  "21" = INQ-QST-ADVER
                    Me.NGS.CountersINQQSTADVER = 1  'Housecalls only
                Case "B"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "32", 1 )  'housecalls or SLC
                    ' Counter #  "32" = CS-CLOSE-EXIST
                    Me.NGS.CountersCSCLOSEEXIST = 1  'housecalls or SLC
                Case "C"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "55", 1 )  'Student loan consolidation only
                    ' Counter #  "55" = HEARING-IMPARED
                    Me.NGS.CountersHEARINGIMPARED = 1  'Student loan consolidation only
                Case "D"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "51", 1 ) 'none
                    ' Counter #  "51" = INQ-DISCONNECT
                    Me.NGS.CountersINQDISCONNECT = 1 'none
            End Select
            Select Case Me.NGS.SELECT90 'AT LEAST 7500 IN STUDENT LOANS TO CONSOLIDATE?
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "52", 1 )
                    ' Counter #  "52" = GOLD-OPTION
                    Me.NGS.CountersGOLDOPTION = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "53", 1 )
                    ' Counter #  "53" = INQUIRY
                    Me.NGS.CountersINQUIRY = 1
                Case Else
            End Select
            'End of code from the CreditCardAutoDecline counter rule.
            '******************************************************************
            'Start of code from the AutoApproval counter rule.
            If Me.NGS.SELECT86.ToString.Trim = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "246", 1 )
                ' Counter #  "246" = AFW-ANNUAL-RWRD
                Me.NGS.CountersAFWANNUALRWRD = 1
            End If
            If Me.NGS.SELECT86.ToString.Trim = "N" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "271", 1 )
                ' Counter #  "271" = ANNUAL_REWARDS
                Me.NGS.CountersANNUAL_REWARDS = 1
            End If
            If Me.NGS.SELECT87.ToString.Trim = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "258", 1 )
                ' Counter #  "258" = CA-CA-AUTO-APP
                Me.NGS.CountersCACAAUTOAPP = 1
            End If
            If Me.NGS.SELECT87.ToString.Trim = "N" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "134", 1 )
                ' Counter #  "134" = APPLY_BUSINESS
                Me.NGS.CountersAPPLY_BUSINESS = 1
            End If
            If Me.NGS.SELECT88.ToString.Trim = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "257", 1 )
                ' Counter #  "257" = CA-CA-AUTO-DCLN
                Me.NGS.CountersCACAAUTODCLN = 1
            End If
            If Me.NGS.SELECT88.ToString.Trim = "N" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "133", 1 )
                ' Counter #  "133" = CLOSE_BANKCARD
                Me.NGS.CountersCLOSE_BANKCARD = 1
            End If
            'End of code from the AutoApproval counter rule.
            '******************************************************************
            'Start of code from the DISPOSITIONS counter rule.
            Select Case Me.NGS.Init_Disp
                Case "A000"  'Application
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "59", 1 )
                    ' Counter #  "59" = APPLICATION
                    Me.NGS.CountersAPPLICATION = 1
                Case "B000"   'Telecom
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "60", 1 )
                    ' Counter #  "60" = TELECOM
                    Me.NGS.CountersTELECOM = 1
                Case "C000"   'Customer Assistance
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "54", 1 )
                    ' Counter #  "54" = CUSTOMER-SERVICE
                    Me.NGS.CountersCUSTOMERSERVICE = 1
                Case "D000"   'Referrals
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "62", 1 )
                    ' Counter #  "62" = REFERRALS
                    Me.NGS.CountersREFERRALS = 1
                Case "G000"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "217", 1 )
                    ' Counter #  "217" = CON-APPLICATION
                    Me.NGS.CountersCONAPPLICATION = 1
                Case "H000"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "218", 1 )
                    ' Counter #  "218" = CON-TELECOM
                    Me.NGS.CountersCONTELECOM = 1
                Case "I000" 'Customer Assistance
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "219", 1 )
                    ' Counter #  "219" = CON-CUST-ASSIST
                    Me.NGS.CountersCONCUSTASSIST = 1
                Case "J000"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "220", 1 )
                    ' Counter #  "220" = CON-REFERRALS
                    Me.NGS.CountersCONREFERRALS = 1
                Case "K000"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "67", 1 )
                    ' Counter #  "67" = SALE
                    Me.NGS.CountersSALE = 1
                Case "L000"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "90", 1 )
                    ' Counter #  "90" = NO-SALE
                    Me.NGS.CountersNOSALE = 1
                Case "R000"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "88", 1 )
                    ' Counter #  "88" = CLOSE-ACCOUNT
                    Me.NGS.CountersCLOSEACCOUNT = 1
                Case "S000"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "214", 1 )
                    ' Counter #  "214" = RSND-DECLINE-LTR
                    Me.NGS.CountersRSNDDECLINELTR = 1
                Case "T000"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "296", 1 )
                    ' Counter #  "296" = STATUS-APP-CALL
                    Me.NGS.CountersSTATUSAPPCALL = 1
                Case Else
            End Select
            Select Case Me.NGS.Second_Disp
                Case "A100"  'Sale
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "222", 1 )
                    ' Counter #  "222" = APP-SALE
                    Me.NGS.CountersAPPSALE = 1
                Case "A200"  'No Sale
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "223", 1 )
                    ' Counter #  "223" = APP-NO-SALE
                    Me.NGS.CountersAPPNOSALE = 1
                Case "B100"   'Wrong Number
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "71", 1 )
                    ' Counter #  "71" = WRONG-NUMBER
                    Me.NGS.CountersWRONGNUMBER = 1
                Case "B200"   'Ghost Call
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "72", 1 )
                    ' Counter #  "72" = GHOST-CALL
                    Me.NGS.CountersGHOSTCALL = 1
                Case "B300"   'Test Call
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "73", 1 )
                    ' Counter #  "73" = TEST-CALL
                    Me.NGS.CountersTESTCALL = 1
                Case "B400"   'Caller Disconnected
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "92", 1 )
                    ' Counter #  "92" = CALL-DISCONNECT
                    Me.NGS.CountersCALLDISCONNECT = 1
                Case "B500"
                    Me.NGS.CountersSTS_DOWN = 1
                Case "C100"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "74", 1 )
                    ' Counter #  "74" = MAIL-DELECTION
                    Me.NGS.CountersMAILDELECTION = 1
                Case "C200"  'cancel application
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "75", 1 )
                    ' Counter #  "75" = CANCEL-APP
                    Me.NGS.CountersCANCELAPP = 1
                Case "IB00"  'cancel application
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "75", 1 )
                    ' Counter #  "75" = CANCEL-APP
                    Me.NGS.CountersCANCELAPP = 1
                Case "C300"    'Bank call for information
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "76", 1 )
                    ' Counter #  "76" = BANK-INFO
                    Me.NGS.CountersBANKINFO = 1
                Case "C400"    'CSI (customer service issue)
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "77", 1 )
                    ' Counter #  "77" = CSI
                    Me.NGS.CountersCSI = 1
                Case "C500"    'Other
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "78", 1 )
                    ' Counter #  "78" = OTHER-CUST-ASSIS
                    Me.NGS.CountersOTHERCUSTASSIS = 1
                Case "C600"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "273", 1 )
                    ' Counter #  "273" = CA-STATUS-APP
                    Me.NGS.CountersCASTATUSAPP = 1
                    Me.NGS.CountersResend_Decline = 1
                Case "C700"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "215", 1 )
                    ' Counter #  "215" = DO-NOT-CONTACT
                    Me.NGS.CountersDONOTCONTACT = 1
                    Me.NGS.CountersCancel_Application = 1
                Case "C800"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "277", 1 )
                    ' Counter #  "277" = INWARD-CALL
                    Me.NGS.CountersINWARDCALL = 1
                    Me.NGS.CountersOnline_Change_Request = 1
                Case "C900"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "305", 1 )
                    ' Counter #  "305" = STATUS-NOT-TRANS
                    Me.NGS.CountersSTATUSNOTTRANS = 1
                Case "D100"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "79", 1 )
                    ' Counter #  "79" = STATUS-CHECK
                    Me.NGS.CountersSTATUSCHECK = 1
                Case "D400"   'Consumer Finance
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "81", 1 )
                    ' Counter #  "81" = CONSUMER-FINANCE
                    Me.NGS.CountersCONSUMERFINANCE = 1
                Case "D600"   'Business Customer Service
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "85", 1 )
                    ' Counter #  "85" = BUSINESS-C/S
                    Me.NGS.CountersBUSINESSCS = 1
                Case "D700"   'Apply for different Product
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "80", 1 )
                    ' Counter #  "80" = DIFFERENT-MBNA
                    Me.NGS.CountersDIFFERENTMBNA = 1
                Case "D800"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "84", 1 )
                    ' Counter #  "84" = ACTIVATE-CARD
                    Me.NGS.CountersACTIVATECARD = 1
                Case "D900"   'Balance Transfers
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "56", 1 )
                    ' Counter #  "56" = BALANCE-TRANSFER
                    Me.NGS.CountersBALANCETRANSFER = 1
                Case "DA00"   'Spanish Call
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "86", 1 )
                    ' Counter #  "86" = SPANISH-CALL
                    Me.NGS.CountersSPANISHCALL = 1
                Case "DB00"   'Spanish Customer Service
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "58", 1 )
                    ' Counter #  "58" = SPANISH-C/S
                    Me.NGS.CountersSPANISHCS = 1
                Case "DF00"   'Other
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "89", 1 )
                    ' Counter #  "89" = OTHER-REFERRAL
                    Me.NGS.CountersOTHERREFERRAL = 1
                Case "DH00"   'Question About Existing Account
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "282", 1 )
                    ' Counter #  "282" = QUESTION-ACCOUNT
                    Me.NGS.CountersQUESTIONACCOUNT = 1
                Case "DI00"   'NEA Member Benefits
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "281", 1 )
                    ' Counter #  "281" = NEA-BENEFITS
                    Me.NGS.CountersNEABENEFITS = 1
                Case "DJ00"   'Close Account
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "88", 1 )
                    ' Counter #  "88" = CLOSE-ACCOUNT
                    Me.NGS.CountersCLOSEACCOUNT = 1
                Case "DK00"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "284", 1 )
                    ' Counter #  "284" = INWARD-LOW-RATE
                    Me.NGS.CountersINWARDLOWRATE = 1
                Case "DL00"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "285", 1 )
                    ' Counter #  "285" = INWARD-CHNGASSOC
                    Me.NGS.CountersINWARDCHNGASSOC = 1
                Case "DM00"   'Customer Marketing
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "304", 1 )
                    ' Counter #  "304" = CUST-MARKETING-1
                    Me.NGS.CountersCUSTMARKETING1 = 1
                Case "DN00"  'product change unit
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "270", 1 )
                    ' Counter #  "270" = TAC-DEPT
                    Me.NGS.CountersTACDEPT = 1
                Case "G100"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "225", 1 )
                    ' Counter #  "225" = CON-APP-SALE
                    Me.NGS.CountersCONAPPSALE = 1
                Case "G200"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "226", 1 )
                    ' Counter #  "226" = CON-APP-NO-SALE
                    Me.NGS.CountersCONAPPNOSALE = 1
                Case "H100"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "227", 1 )
                    ' Counter #  "227" = CON-TEL-WRONGNUM
                    Me.NGS.CountersCONTELWRONGNUM = 1
                Case "H200"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "24", 1 )
                    ' Counter #  "24" = INQ-GHOST-CALL
                    Me.NGS.CountersINQGHOSTCALL = 1
                Case "H300"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "228", 1 )
                    ' Counter #  "228" = CON-TEL-TEST
                    Me.NGS.CountersCONTELTEST = 1
                Case "H400"      ' Counter for Telecom - Caller disconnected
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "93", 1 )
                    ' Counter #  "93" = TELE-CALL-DISC
                    Me.NGS.CountersTELECALLDISC = 1
                Case "I100"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "229", 1 )
                    ' Counter #  "229" = CON-MAIL-DELET
                    Me.NGS.CountersCONMAILDELET = 1
                Case "I200"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "164", 1 )
                    ' Counter #  "164" = PHONE-NONE
                    Me.NGS.CountersPHONENONE = 1
                Case "I300"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "296", 1 )
                    ' Counter #  "296" = STATUS-APP-CALL
                    Me.NGS.CountersSTATUSAPPCALL = 1
                Case "I500"   ' Customer Assistance - Bank Call for Info
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "175", 1 )
                    ' Counter #  "175" = CHECK-INFO
                    Me.NGS.CountersCHECKINFO = 1
                Case "I600"   ' Customer Assistance -Customer Service Issues
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "132", 1 )
                    ' Counter #  "132" = QUES_EXIS_BNKCRD
                    Me.NGS.CountersQUES_EXIS_BNKCRD = 1
                Case "I700"   ' Customer Assistance - Other
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "30", 1 )
                    ' Counter #  "30" = C/S-OTHER
                    Me.NGS.CountersCSOTHER = 1
                Case "I800"   ' Consumer Finance - Do Not Contact
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "47", 1 )
                    ' Counter #  "47" = INQ-CANCEL-APP
                    Me.NGS.CountersINQCANCELAPP = 1
                Case "I900"   ' Consumer Finance - STATUS OF APPLICATION
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "286", 1 )
                    ' Counter #  "286" = INWARD-CLOSE-ACT
                    Me.NGS.CountersINWARDCLOSEACT = 1
                Case "IA00"   ' Consumer Finance - Resend Decline
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "94", 1 )
                    ' Counter #  "94" = TAC-SALE
                    Me.NGS.CountersTACSALE = 1
                Case "J100"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "83", 1 )
                    ' Counter #  "83" = QUES-EXIST-ACCT
                    Me.NGS.CountersQUESEXISTACCT = 1
                Case "J200"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "33", 1 )
                    ' Counter #  "33" = CS-STATUS-OF-APP
                    Me.NGS.CountersCSSTATUSOFAPP = 1
                Case "J900"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "165", 1 )
                    ' Counter #  "165" = SPEC-LOAN-YES
                    Me.NGS.CountersSPECLOANYES = 1
                Case "J400"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "166", 1 )
                    ' Counter #  "166" = SPANISH-TR
                    Me.NGS.CountersSPANISHTR = 1
                Case "J500"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "230", 1 )
                    ' Counter #  "230" = CON-REF-OTHER
                    Me.NGS.CountersCONREFOTHER = 1
                Case "J600"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "136", 1 )
                    ' Counter #  "136" = TACS_CLOSE_BNKCD
                    Me.NGS.CountersTACS_CLOSE_BNKCD = 1
                Case "J700"   'consumer finance - returning call 04-08-04 ble
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "276", 1 )
                    ' Counter #  "276" = TRAN-CUST-SERV
                    Me.NGS.CountersTRANCUSTSERV = 1
                Case "J800"   'consumer finance - Spanish Customer Service 06-08-04 tmf
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "64", 1 )
                    ' Counter #  "64" = TACS-APP
                    Me.NGS.CountersTACSAPP = 1
                Case "R100"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "233", 1 )
                    ' Counter #  "233" = CLOSE-ACCT-REF
                    Me.NGS.CountersCLOSEACCTREF = 1
                Case "T100"  'Status of Application Transfer Yes
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "299", 1 )
                    ' Counter #  "299" = CO-APPL-YES
                    Me.NGS.CountersCOAPPLYES = 1
                Case "T200"  'Status of Application Transfer No
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "300", 1 )
                    ' Counter #  "300" = CO-APPL-NO
                    Me.NGS.CountersCOAPPLNO = 1
                Case "SC00"
                    Me.NGS.CountersSUPER = 1
            End Select
            Select Case Me.NGS.Third_Disp
                Case "A1A6"  '30-day application(Standard Decision)
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "207", 1 )
                    ' Counter #  "207" = APS-APPLICATION
                    Me.NGS.CountersAPSAPPLICATION = 1
                Case "A1A1"  'Auto Decline
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "208", 1 )
                    ' Counter #  "208" = AUTO-DECLINE
                    Me.NGS.CountersAUTODECLINE = 1
                Case "A1A2"   'Auto Approval
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "209", 1 )
                    ' Counter #  "209" = AUTO-APPROVAL
                    Me.NGS.CountersAUTOAPPROVAL = 1
                Case "A1A3"   'Credit Transfer
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "210", 1 )
                    ' Counter #  "210" = CREDIT-TRANSFER
                    Me.NGS.CountersCREDITTRANSFER = 1
                Case "A1A4"    'Credit is Closed
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "211", 1 )
                    ' Counter #  "211" = CREDIT-IS-CLOSED
                    Me.NGS.CountersCREDITISCLOSED = 1
                Case "A1A5"    'Instant Decision
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "34", 1 )
                    ' Counter #  "34" = CS-APPLY-DIFF
                    Me.NGS.CountersCSAPPLYDIFF = 1
                Case "A2A0"  'Rates too high
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "68", 1 )
                    ' Counter #  "68" = RATES-TOO-HIGH
                    Me.NGS.CountersRATESTOOHIGH = 1
                Case "A2A1"  'Promo period too short
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "91", 1 )
                    ' Counter #  "91" = PROMO-TOO-SHORT
                    Me.NGS.CountersPROMOTOOSHORT = 1
                Case "A2A2"  'Does not want credit check
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "234", 1 )
                    ' Counter #  "234" = APP-NO-CHECK
                    Me.NGS.CountersAPPNOCHECK = 1
                Case "A2A3"  'Other
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "70", 1 )
                    ' Counter #  "70" = NO-SALE-OTHER
                    Me.NGS.CountersNOSALEOTHER = 1
                Case "A2A4"  'Credit is closed
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "213", 1 )
                    ' Counter #  "213" = CREDIT-CLOSED
                    Me.NGS.CountersCREDITCLOSED = 1
                Case "A2A5"  'Sts down - no rate info
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "125", 1 )
                    ' Counter #  "125" = DUES-YES
                    Me.NGS.CountersDUESYES = 1
                Case "A2A6"  'Balance transfer fee too high
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "247", 1 )
                    ' Counter #  "247" = AFW-APS-APP
                    Me.NGS.CountersAFWAPSAPP = 1
                Case "A2A7"  'CONTRACT RATE (APR)
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "325", 1 )
                    ' Counter #  "325" = NS_CONT_RATE
                    Me.NGS.CountersNS_CONT_RATE = 1
                Case "A2A8"  'ANNUAL FEE / FOREIGN TRANSACTION FEE
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "326", 1 )
                    ' Counter #  "326" = NS_ANNL_FEE
                    Me.NGS.CountersNS_ANNL_FEE = 1
                Case "A2A9"  'DOES NOT WANT ANOTHER CREDIT CARD
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "327", 1 )
                    ' Counter #  "327" = NS_ACC
                    Me.NGS.CountersNS_ACC = 1
                Case "A2AA"  'DON'T ALLOW BAC TO BAC TRANSFER
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "328", 1 )
                    ' Counter #  "328" = NS_NO_TRANS_BAC
                    Me.NGS.CountersNS_NO_TRANS_BAC = 1
                Case "A2AB"  'DOES NOT HAVE TIME TO APPLY
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "329", 1 )
                    ' Counter #  "329" = NS_NO_TIME
                    Me.NGS.CountersNS_NO_TIME = 1
                Case "A2AC"  'OUT OF MARKET AREA / UNDER 18 / LANGUAGE NOT SUPPORTED
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "330", 1 )
                    ' Counter #  "330" = NS_OUT_OF_MRKT
                    Me.NGS.CountersNS_OUT_OF_MRKT = 1
                Case "A2AD"  'WANTS OFFER MAILED TO THEM
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "331", 1 )
                    ' Counter #  "331" = NS_MAIL_OFFER
                    Me.NGS.CountersNS_MAIL_OFFER = 1
                Case "A2AE"  'CREDIT LINE NOT HIGH ENOUGH
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "332", 1 )
                    ' Counter #  "332" = NS_INSUFF_LINE
                    Me.NGS.CountersNS_INSUFF_LINE = 1
                Case "C7A0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "152", 1 )
                    ' Counter #  "152" = DO-NOT-MAIL
                    Me.NGS.CountersDONOTMAIL = 1
                Case "C7A1"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "153", 1 )
                    ' Counter #  "153" = DO-NOT-CALL
                    Me.NGS.CountersDONOTCALL = 1
                Case "C7A2"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "154", 1 )
                    ' Counter #  "154" = DO-NOT-MAIL-CALL
                    Me.NGS.CountersDONOTMAILCALL = 1
                Case "C8A0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "196", 1 )
                    ' Counter #  "196" = ANNUAL-FEE-WAIVR
                    Me.NGS.CountersANNUALFEEWAIVR = 1
                Case "C8A1"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "199", 1 )
                    ' Counter #  "199" = WRONG-PLASTIC
                    Me.NGS.CountersWRONGPLASTIC = 1
                Case "C8A2"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "200", 1 )
                    ' Counter #  "200" = CHANGE-BRAND
                    Me.NGS.CountersCHANGEBRAND = 1
                Case "C8A3"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "214", 1 )
                    ' Counter #  "214" = RSND-DECLINE-LTR
                    Me.NGS.CountersRSNDDECLINELTR = 1
                Case "D1A0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "278", 1 )
                    ' Counter #  "278" = CUST-MARKETING
                    Me.NGS.CountersCUSTMARKETING = 1
                Case "D1A1"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "279", 1 )
                    ' Counter #  "279" = STATUS-CREDIT
                    Me.NGS.CountersSTATUSCREDIT = 1
                Case "D1A2"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "280", 1 )
                    ' Counter #  "280" = STATUS-TACS
                    Me.NGS.CountersSTATUSTACS = 1
                Case "DKA0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "201", 1 )
                    ' Counter #  "201" = LOWER-RATE
                    Me.NGS.CountersLOWERRATE = 1
                Case "DLA0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "221", 1 )
                    ' Counter #  "221" = CHANGE-ASSOC
                    Me.NGS.CountersCHANGEASSOC = 1
                Case "G1A0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "158", 1 )
                    ' Counter #  "158" = LOAN-YES
                    Me.NGS.CountersLOANYES = 1
                Case "G1A1"
                    If Me.NGS.SELECT105 = "Y" Then
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "57", 1 )
                        ' Counter #  "57" = INVEST-SERV
                        Me.NGS.CountersINVESTSERV = 1
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "159", 1 )
                        ' Counter #  "159" = LOAN-NO
                        Me.NGS.CountersLOANNO = 1
                    Else
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "159", 1 )
                        ' Counter #  "159" = LOAN-NO
                        Me.NGS.CountersLOANNO = 1
                    End If
                Case "G1A2"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "160", 1 )
                    ' Counter #  "160" = DECLINE
                    Me.NGS.CountersDECLINE = 1
                Case "G1A3"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "293", 1 )
                    ' Counter #  "293" = APP-APPROVED
                    Me.NGS.CountersAPPAPPROVED = 1
                Case "G1A4"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "294", 1 )
                    ' Counter #  "294" = APP-REFERRED
                    Me.NGS.CountersAPPREFERRED = 1
                Case "G1A5"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "295", 1 )
                    ' Counter #  "295" = APP-DECLINED
                    Me.NGS.CountersAPPDECLINED = 1
                Case "G1A6"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "303", 1 )
                    ' Counter #  "303" = CF-AUTO-APPROVAL
                    Me.NGS.CountersCFAUTOAPPROVAL = 1
                Case "G2A0"  'Out of market area/ Under 18/ Language not supported
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "161", 1 )
                    ' Counter #  "161" = UNDER-18
                    Me.NGS.CountersUNDER18 = 1
                Case "G2A1"  'Check with significant other
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "162", 1 )
                    ' Counter #  "162" = CHECK-W-SPOUSE
                    Me.NGS.CountersCHECKWSPOUSE = 1
                Case "G2A2"  'Interest Rate (APR)
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "163", 1 )
                    ' Counter #  "163" = APR-HIGH
                    Me.NGS.CountersAPRHIGH = 1
                Case "G2A3"  'Other
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "338", 1 )
                    ' Counter #  "338" = OTHER
                    Me.NGS.CountersOTHER = 1
                Case "G2A4"  'Fees
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "50", 1 )
                    ' Counter #  "50" = INQ-BALANCE-TRAN
                    Me.NGS.CountersINQBALANCETRAN = 1
                Case "G2A5"  'Credit Closed
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "260", 1 )
                    ' Counter #  "260" = CA-CA-CRDT-CLOSE
                    Me.NGS.CountersCACACRDTCLOSE = 1
                Case "G2A6"  'Doesn't want credit check
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "275", 1 )
                    ' Counter #  "275" = TRAN-CREDIT
                    Me.NGS.CountersTRANCREDIT = 1
                Case "G2A8"  'Can't provide interest rate information
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "333", 1 )
                    ' Counter #  "333" = CS-NO-RATE-INFO
                    Me.NGS.CountersCSNORATEINFO = 1
                Case "G2A9"  'Wants offer mailed to them
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "335", 1 )
                    ' Counter #  "335" = CS-NO-MAIL-INFO
                    Me.NGS.CountersCSNOMAILINFO = 1
                Case "G2AA"  'Doesn't have time to apply
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "336", 1 )
                    ' Counter #  "336" = CS-NO-TIME-APPLY
                    Me.NGS.CountersCSNOTIMEAPPLY = 1
                Case "G2AB"  'Doesn't want another financial product/ new account
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "334", 1 )
                    ' Counter #  "334" = CS-NO-PRDCT-INFO
                    Me.NGS.CountersCSNOPRDCTINFO = 1
                Case "G2AC"  'UNITE System Down
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "316", 1 )
                    ' Counter #  "316" = CANCEL-APPROVE
                    Me.NGS.CountersCANCELAPPROVE = 1
                Case "I8A0" 'CONSUMER FINANCE - MAIL DELETION
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "46", 1 )
                    ' Counter #  "46" = INQ-MAIL-DELETE
                    Me.NGS.CountersINQMAILDELETE = 1
                Case "I8A1" 'CONSUMER FINANCE - PHONE DELETION
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "22", 1 )
                    ' Counter #  "22" = INQ-WRONG-NUMBER
                    Me.NGS.CountersINQWRONGNUMBER = 1
                Case "I8A2" 'CONSUMER FINANCE - MAIL/PHONE DELETION
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "49", 1 )
                    ' Counter #  "49" = INQ-CHANGE-ADDR
                    Me.NGS.CountersINQCHANGEADDR = 1
                Case "I9A0" 'CONSUMER FINANCE - APPLICATION APPROVED
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "253", 1 )
                    ' Counter #  "253" = LOWER-PROMO-REF
                    Me.NGS.CountersLOWERPROMOREF = 1
                Case "I9A1" 'CONSUMER FINANCE - APPLICATION DELCINED
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "254", 1 )
                    ' Counter #  "254" = LOWER-CONT-REF
                    Me.NGS.CountersLOWERCONTREF = 1
                Case "I9A2" 'CONSUMER FINANCE - APPLICATION PENDING
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "255", 1 )
                    ' Counter #  "255" = CA-NOGRACE-REF
                    Me.NGS.CountersCANOGRACEREF = 1
                Case "J3A0" 'Status of App-Transfered App Approved
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "251", 1 )
                    ' Counter #  "251" = AFW-CRDT-CLOSED
                    Me.NGS.CountersAFWCRDTCLOSED = 1
                Case "J3A1" 'Status of App-Transfered App Declined
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "252", 1 )
                    ' Counter #  "252" = AFW-CUST-ASSIST
                    Me.NGS.CountersAFWCUSTASSIST = 1
                Case "T8A0"  'MAIL DELETION
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "44", 1 )
                    ' Counter #  "44" = INQ-QST-OFFER
                    Me.NGS.CountersINQQSTOFFER = 1
                Case "T8A1"  'PHONE DELETION
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "45", 1 )
                    ' Counter #  "45" = INQ-RATES-HIGH
                    Me.NGS.CountersINQRATESHIGH = 1
                Case "T8A2"  'MAIL/PHONE DELETION
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "48", 1 )
                    ' Counter #  "48" = INQ-ADD-AUTH-USE
                    Me.NGS.CountersINQADDAUTHUSE = 1
                Case "T9A0" 'Status of App-Not Transfered App Approved
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "248", 1 )
                    ' Counter #  "248" = AFW-AUTO-DECLINE
                    Me.NGS.CountersAFWAUTODECLINE = 1
                Case "T9A1" 'Status of App-Not Transfered App Pending
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "249", 1 )
                    ' Counter #  "249" = AFW-AUTO-APPROV
                    Me.NGS.CountersAFWAUTOAPPROV = 1
                Case "T9A2" 'Status of App-Not Transfered App Declined
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "250", 1 )
                    ' Counter #  "250" = AFW-CREDIT-TRANS
                    Me.NGS.CountersAFWCREDITTRANS = 1
                Case Else
            End Select
            Select Case Me.NGS.Fourth_Disp
                Case "A1A5", "A1A8" 'Auto Approved
                    'ORIGINAL CODE -> 		call setData  ("CounterRules", "209", "1" )
                    ' Counter #  "209" = AUTO-APPROVAL
                    Me.NGS.CountersAUTOAPPROVAL = 1
                Case "A1A6", "A1A9"   'Auto Decline
                    'ORIGINAL CODE -> 		call setData  ("CounterRules", "208", "1" )
                    ' Counter #  "208" = AUTO-DECLINE
                    Me.NGS.CountersAUTODECLINE = 1
                Case "A1A7", "A1AA"   'Referred
                    'ORIGINAL CODE -> 		call setData  ("CounterRules", "235", "1" )
                    ' Counter #  "235" = REF-TRANSFER
                    Me.NGS.CountersREFTRANSFER = 1
                Case Else
            End Select
            Select Case Me.NGS.Fifth_Disp
                Case "A1A5"
                    'ORIGINAL CODE -> 		call setData  ("CounterRules", "210", "1" )
                    ' Counter #  "210" = CREDIT-TRANSFER
                    Me.NGS.CountersCREDITTRANSFER = 1
                Case "A1A6"
                    'ORIGINAL CODE -> 		call setData  ("CounterRules", "211", "1" )
                    ' Counter #  "211" = CREDIT-IS-CLOSED
                    Me.NGS.CountersCREDITISCLOSED = 1
                Case "A1A7"
                    'ORIGINAL CODE -> 		call setData  ("CounterRules", "127", "1" )
                    ' Counter #  "127" = EAGLE
                    Me.NGS.CountersEAGLE = 1
                Case "A1AA"
                    Me.NGS.CountersGroup_Name_Search_Used_Yes = 1
                Case "A1AB"
                    Me.NGS.CountersGroup_Name_Search_Used_No = 1
                Case Else
            End Select
            Select Case Me.NGS.Sixth_Disp
                Case "A1A6"
                    Me.NGS.CountersCustomer_had_no_Mail_Offer = 1
                Case "A1A7"
                    Me.NGS.CountersCustomer_did_not_have_Source_Code = 1
                Case "A1A8"
                    Me.NGS.CountersCustomer_requested_specific_card = 1
            End Select

            If Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACNFH" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACNFN" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFRS" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFHS" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFSH" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFSF" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFCR" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFCH" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACNFM" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACNFS" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFSS" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACRRO" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACRHO" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACRSO" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACRMO" Then
                Select Case Me.NGS.Fourth_Disp
                    Case "G1A6" 'Auto-Approved
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "303", 1 )
                        ' Counter #  "303" = CF-AUTO-APPROVAL
                        Me.NGS.CountersCFAUTOAPPROVAL = 1
                    Case "G1A0" 'transfered to loan specialist
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "158", 1 )
                        ' Counter #  "158" = LOAN-YES
                        Me.NGS.CountersLOANYES = 1
                    Case "G1A1" 'not transfered to loan specialist
                        If Me.NGS.SELECT105 = "Y" Then
                            'ORIGINAL CODE -> 				Call setData ("CounterRules", "57", 1 )
                            ' Counter #  "57" = INVEST-SERV
                            Me.NGS.CountersINVESTSERV = 1
                            'ORIGINAL CODE -> 				Call setData ("CounterRules", "159", 1 )
                            ' Counter #  "159" = LOAN-NO
                            Me.NGS.CountersLOANNO = 1
                        Else
                            'ORIGINAL CODE -> 				Call setData ("CounterRules", "159", 1 )
                            ' Counter #  "159" = LOAN-NO
                            Me.NGS.CountersLOANNO = 1
                        End If
                    Case "G1A2" 'auto-declined
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "160", 1 )
                        ' Counter #  "160" = DECLINE
                        Me.NGS.CountersDECLINE = 1
                    Case Else
                End Select
            End If
            Select Case Me.NGS.Fourth_Disp
                Case "C8A0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "283", 1 )
                    ' Counter #  "283" = ANNUAL-REWARD
                    Me.NGS.CountersANNUALREWARD = 1
                Case "C8A1"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "198", 1 )
                    ' Counter #  "198" = ANNUAL-NO-REWARD
                    Me.NGS.CountersANNUALNOREWARD = 1
                Case "DKA0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "202", 1 )
                    ' Counter #  "202" = PROMO-RATE
                    Me.NGS.CountersPROMORATE = 1
                Case "DKA1"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "203", 1 )
                    ' Counter #  "203" = CONTACT-RATING-1
                    Me.NGS.CountersCONTACTRATING1 = 1
                Case "DLA0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "205", 1 )
                    ' Counter #  "205" = NO-GRACE
                    Me.NGS.CountersNOGRACE = 1
                Case "I9A0" 'CONSUMER FINANCE - TRANSFER
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "274", 1 )
                    ' Counter #  "274" = REF-BAL-TRAN
                    Me.NGS.CountersREFBALTRAN = 1
                Case "I9A1" 'CONSUMER FINANCE - NOT TRANSFERRED
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "272", 1 )
                    ' Counter #  "272" = REF-RETENTION
                    Me.NGS.CountersREFRETENTION = 1
                Case Else
            End Select
            If Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACNFH" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACNFN" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFRS" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFHS" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFSH" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFSF" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFCR" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFCH" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACNFM" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACNFS" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACFSS" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACRRO" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACRHO" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACRSO" Or
             Me.NGS.M_PRODUCT_ID.ToString.Trim = "MBNACRMO" Then
                Select Case Me.NGS.Fifth_Disp
                    Case "G1A6" 'Auto-Approved
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "303", 1 )
                        ' Counter #  "303" = CF-AUTO-APPROVAL
                        Me.NGS.CountersCFAUTOAPPROVAL = 1
                    Case "G1A0" 'transfered to loan specialist
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "158", 1 )
                        ' Counter #  "158" = LOAN-YES
                        Me.NGS.CountersLOANYES = 1
                    Case "G1A1" 'not transfered to loan specialist
                        If Me.NGS.SELECT105 = "Y" Then
                            'ORIGINAL CODE -> 				Call setData ("CounterRules", "57", 1 )
                            ' Counter #  "57" = INVEST-SERV
                            Me.NGS.CountersINVESTSERV = 1
                            'ORIGINAL CODE -> 				Call setData ("CounterRules", "159", 1 )
                            ' Counter #  "159" = LOAN-NO
                            Me.NGS.CountersLOANNO = 1
                        Else
                            'ORIGINAL CODE -> 				Call setData ("CounterRules", "159", 1 )
                            ' Counter #  "159" = LOAN-NO
                            Me.NGS.CountersLOANNO = 1
                        End If
                    Case "G1A2" 'auto-declined
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "160", 1 )
                        ' Counter #  "160" = DECLINE
                        Me.NGS.CountersDECLINE = 1
                    Case Else
                End Select
            End If
            Select Case Me.NGS.Fifth_Disp
                Case "C8A0"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "288", 1 )
                    ' Counter #  "288" = ANNUAL-APP
                    Me.NGS.CountersANNUALAPP = 1
                Case "C8A1"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "289", 1 )
                    ' Counter #  "289" = ANNUAL-DECLINE
                    Me.NGS.CountersANNUALDECLINE = 1
                Case "C8A2"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "290", 1 )
                    ' Counter #  "290" = ANNUAL-APPROVAL
                    Me.NGS.CountersANNUALAPPROVAL = 1
                Case "C8A3"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "291", 1 )
                    ' Counter #  "291" = ANNUAL-TRANSFER
                    Me.NGS.CountersANNUALTRANSFER = 1
                Case "C8A4"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "292", 1 )
                    ' Counter #  "292" = ANNUAL-CRD-CLOSE
                    Me.NGS.CountersANNUALCRDCLOSE = 1
                Case "C8A5"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "40", 1 ) 'NO REWARDS-SALE
                    ' Counter #  "40" = CS-ACTIVATE-CARD
                    Me.NGS.CountersCSACTIVATECARD = 1 'NO REWARDS-SALE
                Case Else
            End Select
            Select Case Me.NGS.SELECT19
                Case "E"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "337", 1 )
                    ' Counter #  "337" = CREDIT-WEEKEND
                    Me.NGS.CountersCREDITWEEKEND = 1
                Case Else
            End Select
            'End of code from the DISPOSITIONS counter rule.
            '******************************************************************
            'Start of code from the InwardCall counter rule.
            If Me.NGS.SELECT31 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "206", 1 )
                ' Counter #  "206" = VERIFY-GOOD
                Me.NGS.CountersVERIFYGOOD = 1
            End If
            If Me.NGS.SELECT40 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "287", 1 )
                ' Counter #  "287" = VERIFY-LESS-90
                Me.NGS.CountersVERIFYLESS90 = 1
            End If
            If Me.NGS.SELECT109 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "298", 1 )
                ' Counter #  "298" = TAC-CUST-MARKET
                Me.NGS.CountersTACCUSTMARKET = 1
            End If
            If Me.NGS.SELECT110.ToString.Trim <> "" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "212", 1 )
                ' Counter #  "212" = CHANGE-CON-RATE
                Me.NGS.CountersCHANGECONRATE = 1
            End If
            'End of code from the InwardCall counter rule.
            '******************************************************************
            'Start of code from the Activation counter rule.
            Select Case Me.LS.lDatapassSuccessful
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "155", 1 )
                    ' Counter #  "155" = DATA-TRAN-SUCCES
                    Me.NGS.CountersDATATRANSUCCES = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "156", 1 )
                    ' Counter #  "156" = DATA-TRAN-FAIL
                    Me.NGS.CountersDATATRANFAIL = 1
                Case Else
            End Select
            Select Case Me.LS.lRepeatCall
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "173", 1 )
                    ' Counter #  "173" = REPEAT-YES
                    Me.NGS.CountersREPEATYES = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "174", 1 )
                    ' Counter #  "174" = REPEAT-NO
                    Me.NGS.CountersREPEATNO = 1
                Case Else
            End Select
            Select Case Me.LS.lMbna0002
                Case "B"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "176", 1 )
                    ' Counter #  "176" = BAL-TRANS-YES
                    Me.NGS.CountersBALTRANSYES = 1
                Case "C"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "177", 1 )
                    ' Counter #  "177" = BAL-TRANS-NO
                    Me.NGS.CountersBALTRANSNO = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "169", 1 )
                    ' Counter #  "169" = TRANSFER-NO
                    Me.NGS.CountersTRANSFERNO = 1
                Case Else
            End Select
            Select Case Me.LS.lAccept
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "178", 1 )
                    ' Counter #  "178" = TRANS-CMPLT
                    Me.NGS.CountersTRANSCMPLT = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "190", 1 )
                    ' Counter #  "190" = TRANS-FAILED-1
                    Me.NGS.CountersTRANSFAILED1 = 1
                Case Else
            End Select
            Select Case Me.LS.lBTOptions
                Case "1"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "179", 1 )
                    ' Counter #  "179" = ADD-CHK-BALTRAN
                    Me.NGS.CountersADDCHKBALTRAN = 1
                Case "2"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "180", 1 )
                    ' Counter #  "180" = DEL-CHK-BALTRAN
                    Me.NGS.CountersDELCHKBALTRAN = 1
                Case "3"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "181", 1 )
                    ' Counter #  "181" = CHG-CHK-BALTRAN
                    Me.NGS.CountersCHGCHKBALTRAN = 1
                Case "4"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "182", 1 )
                    ' Counter #  "182" = CHANGE-NO
                    Me.NGS.CountersCHANGENO = 1
                Case Else
            End Select
            Select Case Me.LS.lBTDelete
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "183", 1 )
                    ' Counter #  "183" = DELETE-YES
                    Me.NGS.CountersDELETEYES = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "184", 1 )
                    ' Counter #  "184" = DELETE-NO
                    Me.NGS.CountersDELETENO = 1
                Case Else
            End Select
            Select Case Me.LS.lChangeMajorCC
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "187", 1 )
                    ' Counter #  "187" = CHANGE-CC-NUMBER
                    Me.NGS.CountersCHANGECCNUMBER = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "182", 1 )
                    ' Counter #  "182" = CHANGE-NO
                    Me.NGS.CountersCHANGENO = 1
                Case Else
            End Select
            Select Case Me.LS.lAddMajorCC
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "188", 1 )
                    ' Counter #  "188" = ADDITIONAL-CARD
                    Me.NGS.CountersADDITIONALCARD = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "189", 1 )
                    ' Counter #  "189" = ADDITIONAL-NO
                    Me.NGS.CountersADDITIONALNO = 1
                Case Else
            End Select
            Select Case Me.LS.lBTAddYN
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "176", 1 )
                    ' Counter #  "176" = BAL-TRANS-YES
                    Me.NGS.CountersBALTRANSYES = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "177", 1 )
                    ' Counter #  "177" = BAL-TRANS-NO
                    Me.NGS.CountersBALTRANSNO = 1
                Case Else
            End Select
            Select Case Me.LS.lBTChangeYN
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "181", 1 )
                    ' Counter #  "181" = CHG-CHK-BALTRAN
                    Me.NGS.CountersCHGCHKBALTRAN = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "182", 1 )
                    ' Counter #  "182" = CHANGE-NO
                    Me.NGS.CountersCHANGENO = 1
                Case Else
            End Select
            Select Case Me.LS.lCTAddYN
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "179", 1 )
                    ' Counter #  "179" = ADD-CHK-BALTRAN
                    Me.NGS.CountersADDCHKBALTRAN = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "189", 1 )
                    ' Counter #  "189" = ADDITIONAL-NO
                    Me.NGS.CountersADDITIONALNO = 1
                Case Else
            End Select
            Select Case Me.LS.lCTDelete
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "183", 1 )
                    ' Counter #  "183" = DELETE-YES
                    Me.NGS.CountersDELETEYES = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "184", 1 )
                    ' Counter #  "184" = DELETE-NO
                    Me.NGS.CountersDELETENO = 1
                Case Else
            End Select
            Select Case Me.LS.lCTChangeYN
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "181", 1 )
                    ' Counter #  "181" = CHG-CHK-BALTRAN
                    Me.NGS.CountersCHGCHKBALTRAN = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "182", 1 )
                    ' Counter #  "182" = CHANGE-NO
                    Me.NGS.CountersCHANGENO = 1
                Case Else
            End Select
            Select Case Me.LS.lTransferCall
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "194", 1 )
                    ' Counter #  "194" = TRANSFER-CALL
                    Me.NGS.CountersTRANSFERCALL = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "195", 1 )
                    ' Counter #  "195" = TRANSFER-CALL-NO
                    Me.NGS.CountersTRANSFERCALLNO = 1
                Case Else
            End Select
            'End of code from the Activation counter rule.
            '******************************************************************
            'Start of code from the HOMEEQUITY counter rule.
            If Me.NGS.SELECT13.ToString.Trim = "Y" Then
                If Me.LS.lhomequity.ToString.Trim = "Y" Then
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "170", 1 )
                    ' Counter #  "170" = TRANSFER-YES
                    Me.NGS.CountersTRANSFERYES = 1
                End If
                If Me.LS.lhomequity.ToString.Trim = "N" Then
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "169", 1 )
                    ' Counter #  "169" = TRANSFER-NO
                    Me.NGS.CountersTRANSFERNO = 1
                End If
            End If
            If Me.NGS.SELECT92 = "Y" Or
             Me.NGS.SELECT101 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "170", 1 )
                ' Counter #  "170" = TRANSFER-YES
                Me.NGS.CountersTRANSFERYES = 1
            End If
            If Me.NGS.SELECT92 = "N" Or
             Me.NGS.SELECT101 = "N" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "169", 1 )
                ' Counter #  "169" = TRANSFER-NO
                Me.NGS.CountersTRANSFERNO = 1
            End If
            If Me.NGS.SELECT13.ToString.Trim = "Y" Or
             Me.NGS.SELECT99 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "168", 1 )
                ' Counter #  "168" = HOMEOWNER-YES
                Me.NGS.CountersHOMEOWNERYES = 1
            End If
            If Me.NGS.SELECT13.ToString.Trim = "N" Or
             Me.NGS.SELECT99 = "N" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "167", 1 )
                ' Counter #  "167" = HOMEOWNER-NO
                Me.NGS.CountersHOMEOWNERNO = 1
            End If
            If Me.LS.ldatabasematch = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "119", 1 )
                ' Counter #  "119" = MARINE-YES
                Me.NGS.CountersMARINEYES = 1
            End If
            If Me.LS.ldatabasematch = "N" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "120", 1 )
                ' Counter #  "120" = MARINE-NO
                Me.NGS.CountersMARINENO = 1
            End If
            If Me.NGS.SELECT108 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "297", 1 )
                ' Counter #  "297" = TAC-CREDIT
                Me.NGS.CountersTACCREDIT = 1
            End If
            'End of code from the HOMEEQUITY counter rule.
            '******************************************************************
            'Start of code from the ConsumerFinance counter rule.
            Select Case Me.NGS.SELECT80
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "299", 1 )
                    ' Counter #  "299" = CO-APPL-YES
                    Me.NGS.CountersCOAPPLYES = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "300", 1 )
                    ' Counter #  "300" = CO-APPL-NO
                    Me.NGS.CountersCOAPPLNO = 1
                Case Else
            End Select
            Select Case Me.NGS.SELECT81
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "301", 1 )
                    ' Counter #  "301" = COAPP-AVAIL-YES
                    Me.NGS.CountersCOAPPAVAILYES = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "302", 1 )
                    ' Counter #  "302" = COAPP-AVAIL-NO
                    Me.NGS.CountersCOAPPAVAILNO = 1
                Case Else
            End Select
            If Me.NGS.M_PRODUCT_ID = "MBNACNFN" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFRS" Or
             Me.NGS.M_PRODUCT_ID = "MBNACNFH" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFHS" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFSH" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFSF" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFCR" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFCH" Or
             Me.NGS.M_PRODUCT_ID = "MBNACNFM" Or
             Me.NGS.M_PRODUCT_ID = "MBNACNFS" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFSS" Or
             Me.NGS.M_PRODUCT_ID = "MBNACRRO" Or
             Me.NGS.M_PRODUCT_ID = "MBNACRHO" Or
             Me.NGS.M_PRODUCT_ID = "MBNACRSO" Or
             Me.NGS.M_PRODUCT_ID = "MBNACRMO" Then
                If Me.NGS.M_PROB_CALL_I = "O" Then
                    'ORIGINAL CODE -> 		call setData  ("CounterRules", "185",  getData ("DS", "QTY_CARD99") )
                    ' Counter #  "185" = COMP-BAL-TRANS
                    Me.NGS.CountersCOMPBALTRANS = Me.NGS.QTY_CARD99
                End If
            Else
                If Me.NGS.M_PROB_CALL_I = "O" Then
                    'ORIGINAL CODE -> 		call setData  ("CounterRules", "23",  getData ("DS", "QTY_CARD99") )
                    ' Counter #  "23" = COMPLETE-APPLICA
                    Me.NGS.CountersCOMPLETEAPPLICA = Me.NGS.QTY_CARD99
                End If
            End If
            If Me.LS.lOnline = "Y" Then
                If Me.NGS.M_PRODUCT_ID = "MBNACNFN" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACFRS" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACNFH" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACFHS" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACFSH" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACFSF" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACFCR" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACFCH" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACNFM" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACNFS" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACFSS" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACRRO" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACRHO" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACRSO" Or
                 Me.NGS.M_PRODUCT_ID = "MBNACRMO" Then
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "232", 1 )
                    ' Counter #  "232" = CH-BRND-CUS-ASSI
                    Me.NGS.CountersCHBRNDCUSASSI = 1
                Else
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "204", 1 )
                    ' Counter #  "204" = CHG-ASSOCIATIONS
                    Me.NGS.CountersCHGASSOCIATIONS = 1
                End If
            End If
            Select Case Me.NGS.SELECT37
                Case "A"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "256", 1 )
                    ' Counter #  "256" = CA-CA-APS-APP
                    Me.NGS.CountersCACAAPSAPP = 1
                Case "B"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "259", 1 )
                    ' Counter #  "259" = CA-CA-CRDT-TRANS
                    Me.NGS.CountersCACACRDTTRANS = 1
                Case Else
            End Select
            Select Case Me.NGS.SELECT93
                Case "Y" 'CONSUMER EMAIL ADDRESS CAPTURED -YES
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "186", 1 )
                    ' Counter #  "186" = COMP-CHK-TRANS
                    Me.NGS.CountersCOMPCHKTRANS = 1
                Case "N" 'CONSUMER EMAIL ADDRESS CAPTURED -NO
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "224", 1 )
                    ' Counter #  "224" = REF-CUST-SERVICE
                    Me.NGS.CountersREFCUSTSERVICE = 1
                Case Else
            End Select
            Select Case Me.NGS.SELECT94
                Case "Y" 'CONSUMER EMAIL TO MARKET-YES
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "197", 1 )
                    ' Counter #  "197" = REWARD-PROGRAM
                    Me.NGS.CountersREWARDPROGRAM = 1
                Case "N" 'CONSUMER EMAIL TO MARKET-NO
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "231", 1 )
                    ' Counter #  "231" = WR-PLASTIC-ASSIS
                    Me.NGS.CountersWRPLASTICASSIS = 1
                Case Else
            End Select
            If Me.NGS.M_PRODUCT_ID = "MBNACNFN" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFRS" Or
             Me.NGS.M_PRODUCT_ID = "MBNACNFH" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFHS" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFSH" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFSF" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFCR" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFCH" Or
             Me.NGS.M_PRODUCT_ID = "MBNACNFM" Or
             Me.NGS.M_PRODUCT_ID = "MBNACNFS" Or
             Me.NGS.M_PRODUCT_ID = "MBNACFSS" Or
             Me.NGS.M_PRODUCT_ID = "MBNACRRO" Or
             Me.NGS.M_PRODUCT_ID = "MBNACRHO" Or
             Me.NGS.M_PRODUCT_ID = "MBNACRSO" Or
             Me.NGS.M_PRODUCT_ID = "MBNACRMO" Then
                Select Case Me.NGS.SELECT103
                    Case "Y"
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "121", 1 )
                        ' Counter #  "121" = ACTIVE
                        Me.NGS.CountersACTIVE = 1
                    Case "N"
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "122", 1 )
                        ' Counter #  "122" = RETIRED
                        Me.NGS.CountersRETIRED = 1
                    Case Else
                End Select
                Select Case Me.NGS.SELECT104
                    Case "Y"
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "123", 1 )
                        ' Counter #  "123" = OFFICER
                        Me.NGS.CountersOFFICER = 1
                    Case "N"
                        'ORIGINAL CODE -> 			Call setData ("CounterRules", "124", 1 )
                        ' Counter #  "124" = ENLISTED
                        Me.NGS.CountersENLISTED = 1
                    Case Else
                End Select
            End If
            'End of code from the ConsumerFinance counter rule.
            '******************************************************************
            'Start of code from the MailDeletion counter rule.
            If Me.NGS.SELECT12 = "Y" Or
             Me.LS.lSELECT127 = "Y" Or
             Me.LS.lSELECT131 = "Y" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "157", 1 )
                ' Counter #  "157" = ADDL-FORMS
                Me.NGS.CountersADDLFORMS = 1
            End If
            If Me.NGS.SELECT22 = "Y" Then
                'ORIGINAL CODE -> 		Call setData ("CounterRules", "193", 1 )
                ' Counter #  "193" = CONFIRMATION-STM
                Me.NGS.CountersCONFIRMATIONSTM = 1
            End If
            Select Case Me.NGS.SELECT23
                Case "Y"
                    'ORIGINAL CODE -> 			Call setData ("CounterRules", "191", 1 )
                    ' Counter #  "191" = POLICY-YES
                    Me.NGS.CountersPOLICYYES = 1
                Case "N"
                    'ORIGINAL CODE -> 			Call setData ("CounterRules", "192", 1 )
                    ' Counter #  "192" = POLICY-NO
                    Me.NGS.CountersPOLICYNO = 1
                Case Else
            End Select
            If Me.NGS.SELECT109 = "N" Then
                'ORIGINAL CODE -> 	Call setData ("CounterRules", "323", 1 )
                ' Counter #  "323" = REFUSE-ADDRESS
                Me.NGS.CountersREFUSEADDRESS = 1
            End If
            'End of code from the MailDeletion counter rule.
            '******************************************************************
            'Start of code from the DataPassSolicitation counter rule.
            If Me.LS.lDatapassSuccessful = "Y" Then
                'ORIGINAL CODE -> call setData ("CounterRules", "155", 1 )
                ' Counter #  "155" = DATA-TRAN-SUCCES
                Me.NGS.CountersDATATRANSUCCES = 1
            End If
            If Me.LS.lDatapassSuccessful = "N" Then
                'ORIGINAL CODE -> call setData ("CounterRules", "156", 1 )
                ' Counter #  "156" = DATA-TRAN-FAIL
                Me.NGS.CountersDATATRANFAIL = 1
            End If
            'End of code from the DataPassSolicitation counter rule.
            '******************************************************************
            'Start of code from the MBNACounters counter rule.
            If Me.NGS.SELECT8 = "A" Then
                'ORIGINAL CODE -> 	call setData  ("CounterRules", "145", "1" )
                ' Counter #  "145" = BILLBOARD
                Me.NGS.CountersBILLBOARD = 1
            End If
            If Me.NGS.SELECT8 = "C" Then
                'ORIGINAL CODE -> 	call setData  ("CounterRules", "146", "1" )
                ' Counter #  "146" = NEWSPAPER
                Me.NGS.CountersNEWSPAPER = 1
            End If
            If Me.NGS.SELECT8 = "B" Then
                'ORIGINAL CODE -> 	call setData  ("CounterRules", "147", "1" )
                ' Counter #  "147" = MOVIE_TRAILER
                Me.NGS.CountersMOVIE_TRAILER = 1
            End If
            If Me.NGS.SELECT8 = "D" Then
                'ORIGINAL CODE -> 	call setData  ("CounterRules", "148", "1" )
                ' Counter #  "148" = TAKE_TROLLY
                Me.NGS.CountersTAKE_TROLLY = 1
            End If
            If Me.NGS.SELECT8 = "E" Then
                'ORIGINAL CODE -> 	call setData  ("CounterRules", "149", "1" )
                ' Counter #  "149" = AD_DELIVERY_TRUC
                Me.NGS.CountersAD_DELIVERY_TRUC = 1
            End If
            If Me.NGS.SELECT8 = "F" Then
                'ORIGINAL CODE -> 	call setData  ("CounterRules", "150", "1" )
                ' Counter #  "150" = SHOP_MALL_AD
                Me.NGS.CountersSHOP_MALL_AD = 1
            End If
            If Me.NGS.SELECT8 = "G" Then
                'ORIGINAL CODE -> 	call setData  ("CounterRules", "151", "1" )
                ' Counter #  "151" = AD_ON_TROLLY
                Me.NGS.CountersAD_ON_TROLLY = 1
            End If
            Select Case Me.NGS.SELECT21
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "171", 1 )
                    ' Counter #  "171" = CREDIT-ANALYST-Y
                    Me.NGS.CountersCREDITANALYSTY = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "172", 1 )
                    ' Counter #  "172" = CREDIT-ANALYST-N
                    Me.NGS.CountersCREDITANALYSTN = 1
                Case Else
            End Select
            Select Case Me.LS.lPGAWinner
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "19", 1 )
                    ' Counter #  "19" = INQ-OTHER
                    Me.NGS.CountersINQOTHER = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "20", 1 )
                    ' Counter #  "20" = INQ-TEST
                    Me.NGS.CountersINQTEST = 1
                Case Else
            End Select
            Select Case Me.NGS.SELECT97
                Case "Y"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "181", 1 )
                    ' Counter #  "181" = CHG-CHK-BALTRAN
                    Me.NGS.CountersCHGCHKBALTRAN = 1
                Case "N"
                    'ORIGINAL CODE -> 		Call setData ("CounterRules", "182", 1 )
                    ' Counter #  "182" = CHANGE-NO
                    Me.NGS.CountersCHANGENO = 1
                Case Else
            End Select
            'End of code from the MBNACounters counter rule.
            '******************************************************************
            'Start of code from the Calltime counter rule.
            'ORIGINAL CODE -> Call SetData("CounterRules", "140", GetData("DataStore", "TALK_TIME"))
            ' Counter #  "140" = ADE-TALKTIME
            Me.NGS.CountersADETALKTIME = Me.NGS.TALK_TIME
            'ORIGINAL CODE -> Call SetData("CounterRules", "141", GetData("DataStore", "HOLD_TIME"))
            ' Counter #  "141" = ADE-HOLDTIME
            Me.NGS.CountersADEHOLDTIME = Me.NGS.HOLD_TIME
            'ORIGINAL CODE -> Call SetData("CounterRules", "142", GetData("DataStore", "WRAP_TIME"))
            ' Counter #  "142" = ADE-WRAPTIME
            Me.NGS.CountersADEWRAPTIME = Me.NGS.WRAP_TIME
            'ORIGINAL CODE -> Call SetData("CounterRules", "143", GetData("DataStore", "OTHER_TIME"))
            ' Counter #  "143" = ADE-OTHRTIME
            Me.NGS.CountersADEOTHRTIME = Me.NGS.OTHER_TIME
            'ORIGINAL CODE -> Call setData("CounterRules", "139", getDataInt("DataStore", "TALK_TIME") + getDataInt("DataStore", "HOLD_TIME") + getDataInt("DataStore", "WRAP_TIME") + getDataInt("DataStore", "OTHER_TIME"))
            ' Counter #  "139" = ADE-TOTLTIME
            Me.NGS.CountersADETOTLTIME = CInt(Me.NGS.TALK_TIME) + CInt(Me.NGS.HOLD_TIME) + CInt(Me.NGS.WRAP_TIME) + CInt(Me.NGS.OTHER_TIME)
            'End of code from the Calltime counter rule.
            '******************************************************************
            'Start of code from the SetFixedCounters counter rule.
            If Me.NGS.M_PROB_CALL_I = "O" Then
                'ORIGINAL CODE ->     call setData("CounterRules","1",1)
                ' Counter # "1" = ORDER-COUNT
                Me.NGS.CountersORDERCOUNT = 1
            End If
            If Me.NGS.M_PROB_CALL_I = "R" Then
                'ORIGINAL CODE ->     call setData("CounterRules","3",1)
                ' Counter # "3" = REFERRAL-COUNT
                Me.NGS.CountersREFERRALCOUNT = 1
            End If
            If Me.NGS.M_PROB_CALL_I = "I" Then
                'ORIGINAL CODE ->     call setData("CounterRules","4",1)
                ' Counter # "4" = INQUIRY-COUNT
                Me.NGS.CountersINQUIRYCOUNT = 1
            End If
            If Me.NGS.M_PROB_CALL_I = "P" Then
                'ORIGINAL CODE ->     call setData("CounterRules","5",1)
                ' Counter # "5" = DOC-CS-COUNT
                Me.NGS.CountersDOCCSCOUNT = 1
            End If
            'End of code from the SetFixedCounters counter rule.
            '******************************************************************
        Catch ex As Exception
            Throw
        End Try




    End Sub


    Public Sub gfSendEmailThreat()
        'Created:OM5794D1:lapeters:05/18/2010 10:46:19 AM

        '*************************************************
        'Created 20100518 lapeters 
        'Developed from gfSendEmailEscalation
        'For use by the THREAT panel
        'When a button on the panel is clicked...
        '			''A message is sent to pagers
        '	''then...
        '			A message is sent to emails
        '*************************************************

        'Dim toAddrPager As String = String.Empty
        Dim toAddrEmail As String = String.Empty
        Dim strEmail As New System.Text.StringBuilder(3500)
        Dim subjectline As String = String.Empty
        Dim AgentInfoMessage As String = String.Empty

        '***********************************
        ' Configure message for pager and email
        '***********************************

        Try
            ''production
            If Me.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") Then   'production
                toAddrEmail = Me.GetEmailValueByName("BOAThreatEmail", "PRD")
            Else
                toAddrEmail = Me.GetEmailValueByName("BOAThreatEmailTest", "TST")
            End If

            '06/29/17 took out pager notification no longer used
            '*************************************************
            ' PAGER:  Alert to presence of an email regarding a threatening call received by an agent.
            '*************************************************


        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfSendEMailThreat send Page: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try

        '*************************************************
        ' Format the text before it is emailed 
        '*************************************************

        ' Prepare for reuse.
        strEmail.Length = 0
        subjectline = "BOA - Threatening Call"


        Try


            Dim mydate As DateTime
            'Dim time As DateTime


            mydate = Format(Date.Now, "MM/dd/yyyy hh:mm:ss")
            strEmail.Append("  Order Date/Time: ").Append(mydate).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Site: ").Append(Me.UPC.System.SITE.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Agent Name: ").Append(Me.UPC.AgentInfo.fullname.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Agent ID: ").Append(Me.UPC.AgentInfo.uid.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.AppendFormat("{0}", Environment.NewLine)


            strEmail.Append(" Threat: ").AppendFormat("{0}", Environment.NewLine)
            If Not Me.LS.lTThreat1.ToString.Trim.Equals(String.Empty) Then
                strEmail.Append(Me.LS.lTThreat1.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Not Me.LS.lTThreat2.ToString.Trim.Equals(String.Empty) Then
                strEmail.Append(Me.LS.lTThreat2.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat3.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat3.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat4.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat4.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat5.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat5.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat6.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat6.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat7.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat7.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat8.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat8.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat9.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat9.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat10.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat10.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat11.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat11.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat12.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat12.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat13.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat13.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat14.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat14.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat15.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat15.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat16.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat16.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat17.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat17.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat18.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat18.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat19.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat19.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTThreat20.ToString.Trim <> "" Then
                strEmail.Append(Me.LS.lTThreat20.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            End If


            'New Line
            strEmail.AppendFormat("{0}", Environment.NewLine)


            strEmail.Append("  Caller Name: ").Append(Me.LS.lTFirstName.ToString.Trim).Append(" ").Append(Me.LS.lTLastName.ToString.Trim).AppendFormat("{0}", Environment.NewLine)


            strEmail.Append("  Caller Address: ").AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  One: ").Append(Me.LS.lTAdd1.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Two: ").Append(Me.LS.lTAdd2.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  City: ").Append(Me.LS.lTCity.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  State: ").Append(Me.LS.lTState.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Zip: ").Append(Me.LS.lTZip.ToString.Trim).AppendFormat("{0}", Environment.NewLine)


            If Me.LS.lTPhoneArea.ToString.Trim <> "" Then
                strEmail.Append("  Caller Phone Number: ").Append(Me.LS.lTPhoneArea.ToString.Trim).Append("-").Append(Me.LS.lTPhone3.ToString.Trim).Append("-").Append(Me.LS.lTPhone4.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            Else
                strEmail.Append("  Caller Phone Number:  ").AppendFormat("{0}", Environment.NewLine)
            End If


            'New Line
            strEmail.AppendFormat("{0}", Environment.NewLine)


            strEmail.Append("  Calling From: ").Append(Me.LS.lTCallingFrom.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Sex Of Caller: ").Append(Me.LS.lTSex.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Age Of Caller: ").Append(Me.LS.lTAge.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Possible Race Of Caller: ").Append(Me.LS.lTRace.ToString.Trim).AppendFormat("{0}", Environment.NewLine)

            'New Line
            strEmail.AppendFormat("{0}", Environment.NewLine)

            'Bomb Section:
            strEmail.Append("  Bomb Threat ").AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  How many bombs are there: ").Append(Me.NGS.Bomb_Number.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  When is the bomb going to explode: ").Append(Me.NGS.Bomb_When_Explode.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Where is the bomb located: ").Append(Me.NGS.Bomb_Located.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  What type of bomb is it: ").Append(Me.NGS.Bomb_Type.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  How do I know this is not a prank: ").Append(Me.NGS.Bomb_Prank.ToString.Trim).AppendFormat("{0}", Environment.NewLine)

            'New Line
            strEmail.AppendFormat("{0}", Environment.NewLine)

            'Kidnapping Section:
            strEmail.Append("  Kidnapping or Extortion ").AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Who is this: ").Append(Me.NGS.Kidnapping_Who_Is_This.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  How do I know this is not a prank: ").Append(Me.NGS.Kidnapping_Prank.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Is the victim all right: ").Append(Me.NGS.Kidnapping_Victim.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  What is he or she wearing: ").Append(Me.NGS.Kidnapping_Victim_What_Wearing.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  What do you want: ").Append(Me.NGS.Kidnapping_What_Do_You_Want.ToString.Trim).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  How, where and when do you want the money delivered: ").Append(Me.NGS.Kidnapping_How_Where_When_Delivered.ToString.Trim).AppendFormat("{0}", Environment.NewLine)

            'New Line
            strEmail.AppendFormat("{0}", Environment.NewLine)

            strEmail.Append("  Callers Voice: ").AppendFormat("{0}", Environment.NewLine)
            If Me.LS.lTVoice1.ToString.Trim = "Y" Then
                strEmail.Append("     Calm").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice2.ToString.Trim = "Y" Then
                strEmail.Append("     Angry").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice3.ToString.Trim = "Y" Then
                strEmail.Append("     Slow").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice4.ToString.Trim = "Y" Then
                strEmail.Append("     Excited").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice5.ToString.Trim = "Y" Then
                strEmail.Append("     Slurred").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice6.ToString.Trim = "Y" Then
                strEmail.Append("     Laughing").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice7.ToString.Trim = "Y" Then
                strEmail.Append("     Crying").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice8.ToString.Trim = "Y" Then
                strEmail.Append("     Normal").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice9.ToString.Trim = "Y" Then
                strEmail.Append("     Distinct").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice10.ToString.Trim = "Y" Then
                strEmail.Append("     Nasal").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice11.ToString.Trim = "Y" Then
                strEmail.Append("     Cracking").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice12.ToString.Trim = "Y" Then
                strEmail.Append("     Lisp").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice13.ToString.Trim = "Y" Then
                strEmail.Append("     Raspy").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice14.ToString.Trim = "Y" Then
                strEmail.Append("     Deep").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice15.ToString.Trim = "Y" Then
                strEmail.Append("     Accent").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice16.ToString.Trim = "Y" Then
                strEmail.Append("     Stutter").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice17.ToString.Trim = "Y" Then
                strEmail.Append("     Soft").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice18.ToString.Trim = "Y" Then
                strEmail.Append("     High").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice19.ToString.Trim = "Y" Then
                strEmail.Append("     Familiar").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice20.ToString.Trim = "Y" Then
                strEmail.Append("     Disguised").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice21.ToString.Trim = "Y" Then
                strEmail.Append("     Deep Breathing").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice22.ToString.Trim = "Y" Then
                strEmail.Append("     Loud").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice23.ToString.Trim = "Y" Then
                strEmail.Append("     Ragged").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTVoice24.ToString.Trim = "Y" Then
                strEmail.Append("     Rapid").AppendFormat("{0}", Environment.NewLine)
            End If


            strEmail.Append("  Language Used by Caller: ").Append(Me.LS.lTLanguage.ToString.Trim).AppendFormat("{0}", Environment.NewLine)


            strEmail.Append("  Background Noises: ").AppendFormat("{0}", Environment.NewLine)
            If Me.LS.lTNoise1.ToString.Trim = "Y" Then
                strEmail.Append("     Street Noise").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTNoise2.ToString.Trim = "Y" Then
                strEmail.Append("     Machinery").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTNoise3.ToString.Trim = "Y" Then
                strEmail.Append("     Office").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTNoise4.ToString.Trim = "Y" Then
                strEmail.Append("     P A System").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTNoise5.ToString.Trim = "Y" Then
                strEmail.Append("     Airport Noise").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTNoise6.ToString.Trim = "Y" Then
                strEmail.Append("     Voices").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTNoise7.ToString.Trim = "Y" Then
                strEmail.Append("     Music").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTNoise8.ToString.Trim = "Y" Then
                strEmail.Append("     House Noise").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTNoise9.ToString.Trim = "Y" Then
                strEmail.Append("     Motor").AppendFormat("{0}", Environment.NewLine)
            End If
            If Me.LS.lTNoise10.ToString.Trim = "Y" Then
                strEmail.Append("     Animal").AppendFormat("{0}", Environment.NewLine)
            End If

            strEmail.Append("  Incident:  Date and Time: ").Append(Me.NGS.Threat_DATE_TIME.ToString.Trim).Append(" ").Append(Me.NGS.Threat_Time).AppendFormat("{0}", Environment.NewLine)
            strEmail.Append("  Printed name of person who received the threat: ").Append(Me.NGS.Threat_Person_Received.ToString.Trim).AppendFormat("{0}", Environment.NewLine)

            LogSystemMessage("Script", "Email: " & strEmail.ToString())

            'Send formatted string...
            'Example: SendEmail(To, CC, From, Subject, Body)
            SendEmailFourOh(toAddrEmail, "", "UPCTeam@gmail.com", "Threatening Call Notification", strEmail.ToString())

        Catch ex2 As Exception
            Me.LogException(ex2)
            Me.LogSystemMessageDB("Script", "Error in ME.gfSendEMailThreat send Email: " & ex2.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub



    Public Sub gfCalcIncome6()
        'Created:OM6356D1:cshepler:05/18/2010 05:09:18 PM
        'TODO 20100520 lapeters/caryn - find and replace the Local Stores similar to lSELECT45 or 46 and lCheckAmt1 or 2 with there new names.
        Try
            Dim pensiontotal As Integer = 0
            Dim pensionamount As Integer = 0
            Dim salaryammount As Integer = 0
            Dim salarytotal As Integer = 0
            Dim selftotal As Integer = 0
            Dim incomeammount As Integer = 0
            Dim studentammount As Integer = 0
            Dim studenttotal As Integer = 0
            Dim totalannualIncome As Integer = 0
            Dim displaytotal As Integer = 0


            'Not calculating anything for refused option a
            '''''''''''''''''''''''''''''''''''''''''''''''
            'retired -option b
            'lPensionAmount is pension amount to be calculated annually
            'lSalary is current salary amount
            'lSELECT45 is the frequency for currrnt salary
            'lHours = number of hours for current employer


            'There are 52 weeks in a year
            '2080 is the number of hours when you work full time for a year (40*52)


            If Me.LS.lManualOccupation.ToString.Trim.Equals("B") Then
                pensionamount = CInt(Me.LS.lPensionAmount)
                salaryammount = CInt(Me.LS.lSalary)
                Select Case Me.LS.lPensionFrequency.ToString.Trim
                    Case "A"    'Weekly
                        pensiontotal = pensionamount * 52
                    Case "B"    'Bi-Weekly
                        pensiontotal = pensionamount * 26
                    Case "C"    'Monthly
                        pensiontotal = pensionamount * 12
                    Case "D"    'Annually
                        pensiontotal = pensionamount
                    Case Else
                End Select
                If Me.LS.lSELECT46.ToString.Trim.Equals("Y") Then
                    Select Case Me.LS.lSELECT45.ToString.Trim
                        Case "A"    'Weekly
                            salarytotal = salaryammount * 52
                        Case "B"    'Monthly
                            salarytotal = salaryammount * 12
                        Case "C"    'Annually
                            salarytotal = salaryammount
                        Case "D"    'Hourly
                            If CInt(Me.LS.lHours) > 0 Then
                                salarytotal = salaryammount * CInt(Me.LS.lHours) * 52
                            Else
                                salarytotal = salaryammount * 2080
                            End If
                        Case "E"    'Bi-Weekly
                            salarytotal = salaryammount * 26
                        Case Else
                    End Select
                Else
                    salarytotal = 0
                End If
                totalannualIncome = salarytotal
                displaytotal = salarytotal + pensiontotal
            End If


            'end of retired''''''''''''''''''''''''''
            '''''''''''''''''''''''''''''''''''''''''''''''
            'self employed -option c
            'lSalary is Income amount
            'lSELECT52 is the frequency for Income
            If Me.LS.lManualOccupation.ToString.Trim.Equals("C") Then
                incomeammount = CInt(Me.LS.lSalary)
                Select Case Me.LS.lSELECT52.ToString.Trim
                    Case "A"    'Weekly
                        selftotal = incomeammount * 52
                    Case "B"    'Monthly
                        selftotal = incomeammount * 12
                    Case "C"    'Yearly
                        selftotal = incomeammount
                    Case "E"    'Bi-Weekly
                        selftotal = incomeammount * 26
                    Case Else
                End Select
                totalannualIncome = selftotal
            End If
            'end of self employed
            '''''''''''''''''''''''''''''''''''''''''''''''
            'student -option d
            'lSalary is Income amount
            'lSELECT50 is the frequency for Income
            'lHoursStudents is the number of hours 
            If Me.LS.lManualOccupation.ToString.Trim.Equals("D") Then
                studentammount = CInt(Me.LS.lSalary)
                Select Case Me.LS.lSELECT50.ToString.Trim
                    Case "A"    'Weekly
                        studenttotal = studentammount * 52
                    Case "B"    'Monthly
                        studenttotal = studentammount * 12
                    Case "C"    'Annually
                        studenttotal = studentammount
                    Case "D"    'Hourly
                        If CInt(Me.LS.lHoursStudents) > 0 Then
                            studenttotal = studentammount * CInt(Me.LS.lHoursStudents) * 52
                        Else
                            studenttotal = studentammount * 2080
                        End If
                    Case "E"    'Bi-Weekly
                        studenttotal = studentammount * 26
                    Case Else
                End Select
                totalannualIncome = studenttotal
            End If
            'end of student
            ''''''''''''''''''''''''''''''''''''''''''''''''''''
            'Not calculating anything for unemployment option e
            ''''''''''''''''''''''''''''''''''''''''''''''''''''
            'other -option f
            'lSalary is Income amount
            'lSELECT45 is the frequency for Income
            'lHours = number of hours for current employer
            If Me.LS.lManualOccupation.ToString.Trim.Equals("F") Then
                salaryammount = CInt(Me.LS.lSalary)
                Select Case Me.LS.lSELECT45.ToString.Trim
                    Case "A"    'Weekly
                        salarytotal = salaryammount * 52
                    Case "B"    'Monthly
                        salarytotal = salaryammount * 12
                    Case "C"    'Annually
                        salarytotal = salaryammount
                    Case "D"    'Hourly
                        If CInt(Me.LS.lHours) > 0 Then
                            salarytotal = salaryammount * CInt(Me.LS.lHours) * 52
                        Else
                            salarytotal = salaryammount * 2080
                        End If
                    Case "E"    'Bi-Weekly
                        salarytotal = salaryammount * 26
                    Case Else
                End Select
                totalannualIncome = salarytotal
            End If
            ' end of other


            'sets the total annual income


            Me.LS.lAnnualSalary = totalannualIncome
            Me.LS.lAnnualPensionAmt = pensiontotal


            'adds pension amount to annual income for retired
            If Me.LS.lManualOccupation.ToString.Trim.Equals("B") Then
                Me.LS.lDisplayTotalIncome = displaytotal
            Else
                Me.LS.lDisplayTotalIncome = totalannualIncome
            End If


        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfCalcIncome6: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub

    Public Sub gfVerbiageLookup(pTollFree As Double, pSpanish As String, gDLR As Object)
        gfVerbiageLookup(pTollFree, pSpanish)
    End Sub

    Public Sub gfVerbiageLookup(ByVal pTollFree As Double, ByVal pSpanish As String)
        'Created:OM6356D1:cshepler:05/19/2010 12:59:57 PM
        Try
            ' -------------------------------------------------------------------
            ' Name:  
            '	gfVerbiageLookup
            ' Description:  
            '	Fetchs Opening, Closing, Agent Information, Agent Instruction, Additional Verbiage, Capture field titles
            '   and number of capture fields based on the TFN and the language flag via Generic File Loader (GFL).
            ' Remarks:  
            '	This replaces the needed to have individual panels for TFN verbiage. 
            '	This also enforces the verbiage display standards across TFNs
            ' Author:
            '	C. Shepler
            ' Note :
            '	We are using File Name CreditVerbiageLookUp for BOA GFL look up
            ' Revision:
            '	1		20100518	C. Shepler	Initial Release
            '   2       20111128	Kvyas		XP - 36687 Update the link for the GFL Lookup web service for PRODUCTION
            '	3 		20120227	Kvyas		XP - 40953 Added New Case "CAPTURE3" In the function and GFL file.
            '	4		20130607	Kvyas		Due to Production Issue we are making Schema/Client Name as Amex. 
            '									Create list name under Amex Client Name until we fix production issue


            ' -------------------------------------------------------------------


            Dim starttime As New DateTime
            Dim endtime As New DateTime
            Dim elapsedtime As TimeSpan
            Dim sPingTimeString As String = "PINGTIMESOAPCheckDebugStatus:"


            Dim objWS As New GenericDataLookup.GenericDataLookup

            objWS.Url = SL.ScriptSLWebserviceValues.CommonGenericDataLookup

            objWS.Timeout = 40000
            Me.LogSystemMessageDB("Script", "gfVerbiageLookup Getting Verbiage: " & objWS.Url & ".", True)
            Dim objReply As GenericDataLookup.GenericReply = Nothing
            'Calls the WebService
            Try
                GDLR = New GenericDataLookup.Request
                GDLR.Environment = "OLTP"
                GDLR.ListName = "CreditVerbiageLookUp"
                GDLR.Schema = "AMEX"

                Dim tfnKey As GenericDataLookup.Keys = New GenericDataLookup.Keys
                tfnKey.KeyColumn = "TOLLFREENUMBER"
                tfnKey.KeyValue = pTollFree
                GDLR.SearchKeys(0) = tfnKey

                Dim isSpanishKey As GenericDataLookup.Keys = New GenericDataLookup.Keys
                isSpanishKey.KeyColumn = "SPANISH"
                isSpanishKey.KeyValue = pSpanish
                GDLR.SearchKeys(1) = isSpanishKey

                Dim gldrObject As Object = GLDR
                LogObjectMessageDB(gldrObject, True)

                starttime = DateTime.Now
                objReply = objWS.LookupByMultipleKey(GDLR)
                Dim objReply2 As Object = objReply
                LogObjectMessageDB(objReply2, True)
                endtime = DateTime.Now
                elapsedtime = endtime.Subtract(starttime)
                Me.LogSystemMessageDB("Special Server Reply", sPingTimeString & elapsedtime.TotalMilliseconds.ToString, True)
            Catch ex As Exception
                Me.LogSystemMessageDB("Script", "gfVerbiageLookup - " & ex.Message, True)
                Me.LogException(ex)
            End Try


            'Sets the Verbiage
            Try
                Dim agentname As String = Me.UPC.AgentInfo.fullname.ToString.Trim


                If objReply Is Nothing Then
                    Me.LS.lGreeting = "Thank you for calling BOA,  " & agentname & " speaking. May I complete an application for you?"
                    '20100525. cshepler. Call the service a second time to prevent incorrect displays
                Else
                    If objReply.ReplyCode = 0 Then
                        For i As Integer = LBound(objReply.Data) To UBound(objReply.Data)
                            '0  TOLLFREENUMBER  Numeric
                            '1  SPANISH  Alpha 
                            '2  GREETING  Alpha
                            '3  AGENTINFORMATION  Alpha
                            '4  AGENTINSTRUCTION  Alpha
                            '5  ADDITIONALVERBIAGE  Alpha
                            '6  CLOSING  Alpha
                            '7  CAPTURE1  Alpha
                            '8  CAPTURE2  Alpha	
                            '9  CAPTURE3  Alpha	
                            '10  CAPTURENUMBER  Alpha  


                            Select Case objReply.Data(i).Name.ToUpper()
                                Case "GREETING"
                                    Try
                                        Me.LS.lGreeting = objReply.Data(i).Value.ToString()
                                        Me.LogSystemMessageDB("Script", "Greeting is set to " & objReply.Data(i).Value.ToString() & " for " & pTollFree & " Spanish" & pSpanish & ".", True)
                                        Me.LS.lGreeting = Replace(Me.LS.lGreeting.ToString.Trim, "|agent name|", agentname)
                                    Catch ex As Exception
                                        Me.LogSystemMessageDB("Script", "Greeting Fetch Issue:  " & ex.Message, True)
                                        Me.LogException(ex)
                                    End Try
                                    'Case "AGENTINFORMATION"
                                Case "AGENTINFORMATION"
                                    Me.LS.lAgentInformation = objReply.Data(i).Value.ToString()
                                Case "AGENTINSTRUCTION"
                                    'TODO. 20100519. cshepler. update this to be a loop to parse out the returns on ;.
                                    '20100713 cgossman - add a return when ; is found
                                    Dim strBuilder As New System.Text.StringBuilder(550)
                                    Me.LS.lAgentInstructions = objReply.Data(i).Value.ToString()
                                    For j As Integer = 1 To Len(Me.LS.lAgentInstructions.ToString.Trim)
                                        If Mid(Me.LS.lAgentInstructions.ToString.Trim, j, 1) <> ";" Then
                                            strBuilder.Append(Mid(Me.LS.lAgentInstructions.ToString.Trim, j, 1))
                                        Else
                                            strBuilder.Append("<br>")
                                        End If
                                    Next j
                                    Me.LS.lAgentInstructions = strBuilder.ToString()
                                Case "ADDITIONALVERBIAGE"
                                    Me.LS.lAdditionalVerbiage = objReply.Data(i).Value.ToString()
                                Case "CLOSING"
                                    Me.LS.lclose = objReply.Data(i).Value.ToString()
                                Case "CAPTURE1"
                                    Me.LS.lCaptureLabel1 = objReply.Data(i).Value.ToString()
                                Case "CAPTURE2"
                                    Me.LS.lCaptureLabel2 = objReply.Data(i).Value.ToString()
                                Case "CAPTURE3"
                                    Me.LS.lCaptureLabel3 = objReply.Data(i).Value.ToString()
                                Case "CAPTURENUMBER"
                                    Me.LS.lCaptureNum = objReply.Data(i).Value.ToString()
                            End Select
                        Next i
                    Else
                        Me.LogSystemMessageDB("Script", "Server returned " & objReply.ReplyCode.ToString() & " so not setting data.", True)
                    End If
                End If
            Catch Ex As Exception
                Me.LogSystemMessageDB("Script", "gfVerbiageLookup Fetch Issue:  " & Ex.Message, True)
                Me.LogException(Ex)
            End Try


        Catch ex As Exception
            Throw
        End Try


    End Sub

    Public Sub gfCalcIncome4()
        'Created:OM5794D1:lapeters:05/20/2010 02:38:29 PM

        Try
            Dim addincome As Integer = CInt(Me.LS.lSalary)
            Dim addtotal As Integer = 0
            'lSalary is the previous Income
            'lManPrevFreq is previous frequency
            'lManUnEmpHours is the number of hours


            'There are 52 weeks in a year
            '2080 is the number of hours when you work full time for a year (40*52)


            Select Case Me.LS.lManPrevFreq.ToString.Trim
                Case "A"    'Hourly
                    If CInt(Me.LS.lManUnEmpHours) > 0 Then
                        addtotal = addincome * CInt(Me.LS.lManUnEmpHours) * 52
                    Else
                        addtotal = addincome * 2080
                    End If
                Case "B"    'Weekly
                    addtotal = addincome * 52
                Case "C"    'Bi-Weekly
                    addtotal = addincome * 26
                Case "D"    'Monthly
                    addtotal = addincome * 12
                Case "E"    'Annualy
                    addtotal = addincome
                Case Else
            End Select


            Me.LS.lAnnualPrevSalary = addtotal


        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfCalcIncome4: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
        End Try


    End Sub

    Public Sub gfLogBusinessData()
        'Created:OM7321D1:TJFlesher:02/14/2013 03:27:35 PM
        ' -------------------------------------------------------------------
        ' Name:  
        '	gfLogBusinessData
        ' Description:  
        '	Sets the standard business data fields to log to NGS
        ' Parameters:
        '   None
        ' Return Type
        '   None
        ' Notes:
        '	All 40 business data fields must be populated with a value, no empty fields!
        ' Author:
        '	T. J. Flesher
        ' Revision:
        '	0.0.0.1 	20130214	tjflesher		Initial Release.
        ' -------------------------------------------------------------------
        Try
            Me.LogSystemMessageDB("Script", "Setting Business Data Fields for NGS Logging", True)
            Me.NGS.AgentInfoDomainUserName = Me.UPC.System.DOMAIN_BACKSLASH_USERNAME.ToString.Trim
            Me.NGS.UCID = Me.UPC.CallData.UCID
            Me.NGS.PhoneExtension = Me.UPC.StationConfiguration.CTI_EXT.ToString.Trim


            If Me.NGS.UCID.ToString.Trim.Equals(String.Empty) Then
                Me.NGS.CountersUCIDNo = 1
            Else
                Me.NGS.CountersUCIDYes = 1
            End If
            '**** STANDARD BUSINESS DATA *************************************************************
            'Client
            Me.NGS.BusinessData1 = "BankOfAmerica"
            'ProjectID
            Me.NGS.BusinessData2 = Me.UPC.System.PROJECT_ID.ToString.Trim
            'ScriptID
            Me.NGS.BusinessData3 = Me.UPC.System.ScriptName.ToString.Trim
            'Skill
            Me.NGS.BusinessData4 = "Not Used"
            'VDN
            Me.NGS.BusinessData5 = Me.UPC.CallData.rtn.ToString.Trim
            'Disposition
            Me.NGS.BusinessData6 = Me.NGS.Init_Disp.ToString.Trim
            'Sale
            Me.NGS.BusinessData7 = "Y"
            'Archive
            Me.NGS.BusinessData8 = "Y"
            'Archive Retention in Days
            Me.NGS.BusinessData9 = "730"
            'Universal Call ID
            Me.NGS.BusinessData10 = "Not Used"
            'ANI
            Me.NGS.BusinessData11 = Me.UPC.CallData.ani.ToString.Trim
            'Captured Phone Number
            Me.NGS.BusinessData12 = Me.NGS.M_AREA_C.ToString.Trim + Me.NGS.M_PHONE_3.ToString.Trim + Me.NGS.M_PHONE_4.ToString.Trim
            'WestCallID
            Me.NGS.BusinessData13 = Me.NGS.VRU_REP_FUNC.ToString.Trim
            '**** CLIENT SPECIFIC BUSINESS DATA ******************************************************
            '(WestData1)
            Me.NGS.BusinessData14 = Guid.NewGuid.ToString.Replace("-", String.Empty).Substring(1, 10)
            '(WestData2)
            Me.NGS.BusinessData15 = Me.NGS.M_PRODUCT_ID.ToString.Trim
            '(WestData3)
            Me.NGS.BusinessData16 = Me.NGS.M_PROB_CALL_I.ToString.Trim
            '(WestData4)
            Me.NGS.BusinessData17 = "Not Used"
            '(WestData5)
            Me.NGS.BusinessData18 = "Not Used"
            '(WestData6)
            Me.NGS.BusinessData19 = "Not Used"
            '(WestData7)
            Me.NGS.BusinessData20 = "Not Used"
            '(WestData8)
            Me.NGS.BusinessData21 = "Not Used"
            '(WestData9)
            Me.NGS.BusinessData22 = "Not Used"
            '(WestData10)
            Me.NGS.BusinessData23 = "Not Used"
            '**** UNUSED BUSINESS DATA ****
            Me.NGS.BusinessData24 = "Not Used"
            Me.NGS.BusinessData25 = "Not Used"
            Me.NGS.BusinessData26 = "Not Used"
            Me.NGS.BusinessData27 = "Not Used"
            Me.NGS.BusinessData28 = "Not Used"
            Me.NGS.BusinessData29 = "Not Used"
            Me.NGS.BusinessData30 = "Not Used"
            Me.NGS.BusinessData31 = "Not Used"
            'Me.NGS.BusinessData32 = "Not Used" 'set as 800NumberToDialForMRA
            Me.NGS.BusinessData33 = NGS.Dispo1 'set as MBKID for MRAProj // Disposition Report RITM2435448
            Me.NGS.BusinessData34 = NGS.lCCOtherNotes 'set as avayaPhone Extension // Other Reason RITM2435448
            Me.NGS.BusinessData35 = LS.lTransferNumber 'RITM1923754 
            Me.NGS.BusinessData36 = NGS.Language_Requested 'RITM1923754 
            'Me.NGS.BusinessData37 = "Not Used" 'used and set on BOA Route Call Details method
            'Me.NGS.BusinessData38 = "Not Used" 'used and set on BOA Route Call Details method
            'Me.NGS.BusinessData39 = "Not Used" 'used and set on BOA Route Call Details method
            'Me.NGS.BusinessData40 = "Not Used" 'used and set on BOA Route Call Details method

            '*****************************************************************************************
        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("BusinessData", "Exception in ME.gfLogBusinessData: " & ex.ToString(), True)
        Finally
            'Check to make sure all fields are populated with something
            For x As Integer = 1 To 40
                If Me.GetPropValueByNameTrim(Me.NGS, "BusinessData" & x).Equals(String.Empty) Then
                    Me.SetPropValueByName(Me.NGS, "BusinessData" & x, "Not Populated")
                    Me.LogSystemMessageDB("Business Data", "Field was supposed to have a value but did not: BusinessData" & x, True)
                End If
            Next x
        End Try


    End Sub

    Private Sub SetPropValueByName(nGS As DataStoreVariables, v1 As String, v2 As String)
        Throw New NotImplementedException()
    End Sub

    Private ReadOnly Property GetPropValueByNameTrim(nGS As DataStoreVariables, v As String) As Object
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Property GLDR As Object

    Friend ReadOnly Property IsDebugOn(trim As String, v As Integer) As Object
        Get
            Throw New NotImplementedException()
        End Get
    End Property

    Public Property sessionDataset As Object

    Public Sub gfHandleNotReadyWithAux(ByVal pAuxCode As Integer)
        'Created:BW Shared Std panel Conversion:9/14/2012 4:12:49 PM
        Try
            'call MyBase.HandleNotReadyWithAux(pAuxCode)
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfAutoLogFromUPC()
        Try


            'this code may be changed to suit your needs as long as the path is set to LOG when you want ADE to force log the call
            If Me.CheckForLoggingPath() Then
                If Me.UPC.Script.DEBUGON = True Then
                    Me.LogSystemMessage("Script", "In ME.gfAutoLogFromUPC, already in the logging path, calling PageDown")
                End If
                '---------------------------------------------------------------------------------------------------------------------------------------------
                'use this code if you want to force log the call even if we are already in the logging path
                Me.NGS.ADEautoLog = "Y"
                'call setData ("DataStore", "INIT_DISP", "G000") 'set default disposition (hangup)
                'PageDown()  'in this script, there is only 1 panel in the logging path, we advance to PRELOGGING if ADEautoLog = Y
                '---------------------------------------------------------------------------------------------------------------------------------------------
            Else
                If Me.UPC.Script.DEBUGON = True Then
                    Me.LogSystemMessage("Script", "In ME.gfAutoLogFromUPC, NOT in logging path, Setting current path to LOG")
                End If
                Me.NGS.ADEautoLog = "Y"
                'call setData  ("DataStore", "INIT_DISP", "G000" ) 'set default disposition (hangup)
                Set_CurrPath(ScriptPaths.LOG) 'be sure set branching to PRELOGGING on first RST panel if ADEautoLog = Y
            End If


        Catch ex As Exception
            Throw
        End Try


    End Sub

    Private Function CheckForLoggingPath() As Boolean
        Throw New NotImplementedException()
    End Function

    Public Sub gfMakeNotReadyWithAuxCode(ByVal pAuxCode As String)
        Try

            ' dynamic debugging
            Me.LogSystemMessageDB("gfMakeNotReadyWithAuxCode", "Agent toggled to NotReady with Aux before logging; auxCode was " & pAuxCode, CBool(Me.UPC.Script.DEBUGON))
            MyBase.MakeNotReadyWithAuxcode(pAuxCode)
            'reset AUXCODE
            Me.UPC.Script.AuxCode = String.Empty

        Catch ex As Exception
            Throw
        End Try
    End Sub


    Public Sub gfNGSLogCall(Optional ByVal pTimeout As Integer = 30000)
        '**********************************************************************************************************************************************************
        '***************************** SYSTXB - PUT A CALL TO THIS IN ALL LOGGING PANELS, REPLACING NGSLOGCALL!!!
        '**********************************************************************************************************************************************************
        Try
            'We will do 2 attempts at logging, change accordingly ....
            Dim iMaxAttempts As Integer = 2

            'Set the max dispositions number for this script (whatever was set in logging for ls.ngsmaxdisp)
            Dim iMaxDispositions As Integer = 5

            For iSub = 1 To iMaxAttempts
                'call to set ngs datafields for loggging and disposition levels
                SetNGSDataForLogging(iSub, iMaxDispositions)

                'TODO - get the XML for any lists in the script...
                If SLNGSLogCall(pTimeout, iSub, GetLoggingXML(NGS.GetNgsXml()), String.Empty) Then
                    'Logging went well so exit subroutine!
                    Exit Sub
                End If
            Next
        Catch ex As Exception
            LogSystemMessage("NGS Logging Exception", ex.ToString)
            LogException(ex)
        End Try
    End Sub

    Private Function SLNGSLogCall(pTimeout As Integer, iSub As Integer, v As Object, empty As String) As Boolean
        Throw New NotImplementedException()
    End Function

    Private Sub SetNGSDataForLogging(iSub As Integer, iMaxDispositions As Integer)
        Throw New NotImplementedException()
    End Sub

    Private Function GetLoggingXML(v As String) As Object
        Throw New NotImplementedException()
    End Function

    Public Sub gfHandleDisconnectPal()
        Try
            'now that we have a GF to handle this specific condition,
            'you might wish to do something instead of the previous, 
            'which just called the base function HandleOffHold.
            MyBase.HandleOffHold()
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandlePalAnswered()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleCTCPalConferenced()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleDialInProgress()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleFACExecuted()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandlePhoneEventsSuppressed()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleUnmuteAllInConf()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleMuteCustInConf()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleMuteThirdPartyInConf()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleMuteAgentInConf()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleMuteAgentMic()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleUnmuteAgentMic()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleMuteAllInConf()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandlePALDisconnectFromConfMute()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandlePALDisconnectFromConference()
        'needed stub, add code as needed when needed
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleThirdDisconnectFromConfMute()
        'needed stub, add code as needed when needed
        Try
            LS.l3rdPartyOrCallerDisconConference = "Y"
            Call LogSystemMessage("gfHandleThirdDisconnectFromConfMuteAgent", "Third Party Has Been Disconnected from Conference Mute")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleThirdDisconnectFromConfMuteAgent()
        'signifies the disconnect of the Secure Credit Card Capture IVR
        'meaning the transaction is expected to be complete and the record can be fetched
        Try
            LS.l3rdPartyOrCallerDisconConference = "Y"
            Call LogSystemMessage("gfHandleThirdDisconnectFromConfMuteAgent", "Third Party Has Been Disconnected from Conference Mute Agent")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleThirdDisconnectFromConf()
        'needed stub, add code as needed when needed
        Try
            LS.l3rdPartyOrCallerDisconConference = "Y"
            Call LogSystemMessage("gfHandleThirdDisconnectFromConf", "Third Party Has Been Disconnected from Conference")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleCallerDisconnectFromConfMute()
        'needed stub, add code as needed when needed
        Try
            LS.l3rdPartyOrCallerDisconConference = "N"
            LS.IsMBKNullRecorded = "N"
            Call LogSystemMessage("gfHandleCallerDisconnectFromConfMute", "Caller Disconnect From Conference Mute")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleCallerDisconnectFromConference()
        'needed stub, add code as needed when needed
        Try
            LS.l3rdPartyOrCallerDisconConference = "N"
            LS.IsMBKNullRecorded = "N"
            Call LogSystemMessage("gfHandleCallerDisconnectFromConference", "Caller Disconnect From Conference")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleCustDisconnectFromConfMute()
        'needed stub, add code as needed when needed
        Try
            LS.l3rdPartyOrCallerDisconConference = "N"
            LS.IsMBKNullRecorded = "N"
            Call LogSystemMessage("gfHandleCustDisconnectFromConfMute", "Customer Disconnect From Conference Mute")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleCustDisconnectFromConfMuteAgent()
        'used when caller bails from WIC Secure Credit Card Capture IVR
        'before completing the CC capture process
        Try
            LS.l3rdPartyOrCallerDisconConference = "N"
            LS.IsMBKNullRecorded = "N"
            Call LogSystemMessage("gfHandleCustDisconnectFromConfMute", "Customer Disconnect From Conference Mute")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleCustDisconnectFromConf()
        'needed stub, add code as needed when needed
        Try
            LS.l3rdPartyOrCallerDisconConference = "N"
            Call LogSystemMessage("gfHandleCustDisconnectFromConf", "Customer Disconnect From Conference Mute")
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Public Sub gfHandleColdTransferFailed()
        'we got a busy or an out-of-service response, better try again or
        'at least resume talking to the customer
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub



    Public Function gfCheckFieldValidity(ByVal pfieldStr As String, ByVal pvalueStr As String) As Boolean
        'Created:OM6356D1:cshepler:05/17/2010 10:16:24 AM

        Try
            Dim regEx As New System.Text.RegularExpressions.Regex(pvalueStr, System.Text.RegularExpressions.RegexOptions.IgnoreCase)
            If regEx.IsMatch(pfieldStr) Then
                Return True
            Else
                Return False
            End If


        Catch ex As Exception
            Me.LogException(ex)
            Me.LogSystemMessageDB("Script", "Error in ME.gfCheckFieldValidity: " & ex.Message(), CBool(Me.UPC.Script.DEBUGON))
            Return False
        End Try


    End Function

    Sub gfHandleServiceLinkStatusDown()
        Try
            Me.LogSystemMessage("Script", "Received ServiceLinkStatusDown message, entering gfHandleServiceLinkStatusDOWN...")

            Me.HandleServiceLinkStatusDown()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub HandleServiceLinkStatusDown()
        Throw New NotImplementedException()
    End Sub

    Sub gfHandleServiceLinkStatusUp()
        Try
            Me.LogSystemMessage("Script", "Received ServiceLinkStatusUp message, entering gfHandleServiceLinkStatusUP...")

            Me.HandleServiceLinkStatusUp()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub HandleServiceLinkStatusUp()
        Throw New NotImplementedException()
    End Sub

    Sub gfHandleOutboundDestRinging()
        Try
            Me.LogSystemMessage("Script", "Received OutboundDestRinging message, entering gfHandleOutboundDestRinging...")

            Me.HandleOutboundDestRinging()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub HandleOutboundDestRinging()
        Throw New NotImplementedException()
    End Sub

    Public Sub gfHandleScriptMessageEnableMakeReadyButton()
        Try
            'stub method
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Public Sub gfHandleScriptMessageDisableMakeReadyButton()
        Try
            'stub method
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Friend Sub SLNGSIDLookup(uid As Object, sITE As Object)
        Throw New NotImplementedException()
    End Sub

    Friend Sub SLProductResolution(lOriginalRTN As String, defaultRTN As Object)
        Throw New NotImplementedException()
    End Sub

    Friend Sub MVDataPop2(empty As String)
        Throw New NotImplementedException()
    End Sub

    Friend Function ConvertToDate(debugFlagCheck As Object) As Date
        Throw New NotImplementedException()
    End Function

    Friend Sub SetupBaseGlobalSessionVariables(sessionDataset As Object)
        Throw New NotImplementedException()
    End Sub
End Class

Namespace SLSharedLib
    Public Class SLSharedFunctions
        Friend NGS As Object

        Friend ReadOnly Property SignOn As Object
            Get
                Throw New NotImplementedException()
            End Get
        End Property

        Friend Sub ResetPhoneControlState(v As String)
            Throw New NotImplementedException()
        End Sub

        Friend Sub SignOff()
            Throw New NotImplementedException()
        End Sub

        Friend Sub MakeReady()
            Throw New NotImplementedException()
        End Sub

        Friend Sub MakeNotReady()
            Throw New NotImplementedException()
        End Sub

        Friend Sub Hold()
            Throw New NotImplementedException()
        End Sub

        Friend Sub OffHold()
            Throw New NotImplementedException()
        End Sub

        Friend Sub Disconnect()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleRemoteDisconnect()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleAgentFailedToAnswer(preplyCode As String)
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleForceNotReady()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleForceSignOff()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleNewCall()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleSignOn()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleMakeReady()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleSignOff()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleNotReady()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleOffHold()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleHold()
            Throw New NotImplementedException()
        End Sub

        Friend Sub LogOn()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleDisconnect()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleDialThirdParty()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleTransfer()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleConference()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleLoggedOn()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleDisconnectThirdParty()
            Throw New NotImplementedException()
        End Sub

        Friend Sub ScriptLoad()
            Throw New NotImplementedException()
        End Sub

        Friend Sub Preloads()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleStartBrowseEvent()
            Throw New NotImplementedException()
        End Sub

        Friend Sub DialThirdParty(pPhoneNumber As String, pDialType As String)
            Throw New NotImplementedException()
        End Sub

        Friend Sub Conference()
            Throw New NotImplementedException()
        End Sub

        Friend Sub Transfer()
            Throw New NotImplementedException()
        End Sub

        Friend Sub DisconnectThirdParty()
            Throw New NotImplementedException()
        End Sub

        Friend Sub SignonEnabled()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleSignonFailed(pReplyCode As String, pErrorText As String)
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleMakeReadyFailed()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleCallCompleteEvent()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleExternalProcedureComplete()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleExternalProcedureFailed()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleDialThirdPartyFailed()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleAgentAnswered()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleDataEntryCallAnswered()
            Throw New NotImplementedException()
        End Sub

        Friend Sub HandleDataEntryCallFailed(pErrorCode As String)
            Throw New NotImplementedException()
        End Sub

        Friend Sub SendAuxCodeToADE(pAuxCodeValue As String)
            Throw New NotImplementedException()
        End Sub

        Friend Sub AnswerCall(gUID As Object)
            Throw New NotImplementedException()
        End Sub

        Friend Sub MakeNotReadyWithAuxcode(pAuxCode As String)
            Throw New NotImplementedException()
        End Sub

        Friend Function CheckSchedule() As Boolean
            Throw New NotImplementedException()
        End Function

        Friend Function CheckSchedule2() As Boolean
            Throw New NotImplementedException()
        End Function
    End Class
End Namespace
