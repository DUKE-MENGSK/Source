﻿Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("")>
<Assembly: AssemblyCopyright("")>
<Assembly: AssemblyTrademark("")>
<Assembly: CLSCompliant(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("7834539D-3C87-4C53-8204-BE182F110892")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.*")>
<Assembly: AssemblyDescription("BOA MRA QA")>
<Assembly: BWAssemblyCreatedFrom("BOAMRA")>
<Assembly: BWAssemblyCreatedBy("USER\HM004265238")>
<Assembly: BWAssemblyCreatedUtcTimestamp("2020-06-05 16:55:33Z")>
#Region "BW Assembly Attributes"

<AttributeUsage(AttributeTargets.Assembly)> _
Public Class BWAssemblyCreatedUtcTimestamp
    Inherits System.Attribute

    Private _utcTimestamp As String

    Public Sub New(ByVal utcTimestamp As String)
        If DateTime.TryParse(utcTimestamp, Nothing) = False Then
            Throw New ArgumentException(String.Format("The utcTimestamp ({0}) passed in invalid."))
        End If
        _utcTimestamp = utcTimestamp
    End Sub

    Public Overridable ReadOnly Property CreatedUtcTimestamp() As String
        Get
            Return _utcTimestamp
        End Get
    End Property
End Class

<AttributeUsage(AttributeTargets.Assembly)> _
Public Class BWAssemblyCreatedBy
    Inherits System.Attribute

    Private _createdBy As String

    Public Sub New(ByVal createdBy As String)
        _createdBy = createdBy
    End Sub

    Public Overridable ReadOnly Property CreatedBy() As String
        Get
            Return _createdBy
        End Get
    End Property
End Class

<AttributeUsage(AttributeTargets.Assembly)> _
Public Class BWAssemblyCreatedFrom
    Inherits System.Attribute

    Private _createdFrom As String

    Public Sub New(ByVal createdFrom As String)
        _createdFrom = createdFrom
    End Sub

    Public Overridable ReadOnly Property CreatedFrom() As String
        Get
            Return _createdFrom
        End Get
    End Property
End Class

#End Region
