﻿
Imports System.Web
Imports System.Web.SessionState

Public Class GlobalEvents
    Inherits System.Web.HttpApplication

    Dim myFunction As New Object

#Region " Component Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application is started

        ' soap changes 7-26-2006 tws
        'set the max svd point idle time - time to stay in existence before garbage collection,
        'to 5 seconds.
        System.Net.ServicePointManager.MaxServicePointIdleTime = 5000
        System.Net.ServicePointManager.Expect100Continue = False

    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session is started

        '*********************************************************************
        '**** Cannot use dataaccessfunctions (getdata, setdata, etc) here ****
        '**** Because the sessiondataset is not instantiated in the shared ***
        '**** functions assembly until stdpanel is loaded.
        '*********************************************************************

        '*********************************************************************
        '**** Populate all the script tables from the startup page       *****
        '*********************************************************************

        Session("gSessionDataSet") = New DataSet("sessionDataSet")

        Session("DataStores") = New DataStoreVariables()
        Session("UPCVariables") = New BaseGlobalSessionVariables()
        Session("LocalStores") = New LocalStoreVariables()
        Session("Lists") = New BWLists()
        Session("SLVariables") = New SLSharedLib.BaseSLVariables

        '=============================================================================
        'Create all Callscript tables here
        '=============================================================================
        myFunction.CreateDatatable(Session("gSessionDataSet"), "System")

        'myFunction.CreateHistoryDataTables(Session("gSessionDataSet"))
        CreateHistoryDataTables(Session("gSessionDataSet"))

        myFunction.CreateDatatable(Session("gSessionDataSet"), "ConfigOptions")
        myFunction.CreateDatatable(Session("gSessionDataSet"), "Script")
        myFunction.CreateDatatable(Session("gSessionDataSet"), "VRU")
        myFunction.CreateDatatable(Session("gSessionDataSet"), "Verification")
        myFunction.CreateDatatable(Session("gSessionDataSet"), "AgentInfo")
        myFunction.CreateDatatable(Session("gSessionDataSet"), "PcRouter")
        myFunction.CreateDatatable(Session("gSessionDataSet"), "CallData")
        myFunction.CreateDatatable(Session("gSessionDataSet"), "CallBack")

        '=============================================================================
        'NAVIGATION SETUP
        '=============================================================================
        Dim dtScriptData As New DataTable("NavigationData")

        Dim dcScriptPathName As New DataColumn("pathName", System.Type.GetType("System.String"))
        dcScriptPathName.Unique = True
        dtScriptData.Columns.Add(dcScriptPathName)

        Dim dcScriptPathDesc As New DataColumn("pathDesc", System.Type.GetType("System.String"))
        dtScriptData.Columns.Add(dcScriptPathDesc)

        Dim dcScriptFirstPanel As New DataColumn("firstPanel", System.Type.GetType("System.String"))
        dtScriptData.Columns.Add(dcScriptFirstPanel)

        Dim dcScriptScriptAvail As New DataColumn("scriptAvailable", System.Type.GetType("System.String"))
        dtScriptData.Columns.Add(dcScriptScriptAvail)

        'Dim dcScriptSaveScrollPos As New DataColumn("saveScrollPos", System.Type.GetType("System.String"))
        'dtScriptData.Columns.Add(dcScriptSaveScrollPos)

        Dim dcScriptRestartPath As New DataColumn("restartPath", System.Type.GetType("System.String"))
        dtScriptData.Columns.Add(dcScriptRestartPath)

        Dim dcScriptCollapsedOnStartup As New DataColumn("collapsedOnStartup", System.Type.GetType("System.String"))
        dtScriptData.Columns.Add(dcScriptCollapsedOnStartup)

        Dim dcScriptLogging As New DataColumn("isLogging", System.Type.GetType("System.String"))
        dtScriptData.Columns.Add(dcScriptLogging)

        Dim dcScriptLevel As New DataColumn("level", System.Type.GetType("System.String"))
        dtScriptData.Columns.Add(dcScriptLevel)

        Dim pkey() As DataColumn = {dcScriptPathName}
        dtScriptData.PrimaryKey = pkey

        Session("gSessionDataSet").Tables.Add(dtScriptData)
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires at the beginning of each request
    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when an error occurs
    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session ends
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
    End Sub

    Public Sub CreateHistoryDataTables(ByRef ds As DataSet)
        '************************************************************************
        'Method Name: CreateHistoryDatatables.
        'Argument List: ds as dataset, tableName as string.
        'Return Type: None.
        'Scope: Public.
        'Pre-Condition: N/A.
        'Stored Procedures: N/A.
        'Description: Adds 2 new datatables called tblHistPath and tblHistPanel
        '              to the dataset passed in.  This function is to create the
        '               history tables for use with the navigation tree.
        'Formula:
        '************************************************************************

        Try
            Dim dtHistPath As New DataTable("HistoryPath")

            Dim dcHistPanelPathID As New DataColumn("PathID", System.Type.GetType("System.Int32"))
            dcHistPanelPathID.AutoIncrement = True        ' Make it auto-incremnt.
            dcHistPanelPathID.AutoIncrementSeed = 1
            dcHistPanelPathID.AllowDBNull = False         ' Default is True.
            dcHistPanelPathID.Unique = True
            dtHistPath.Columns.Add(dcHistPanelPathID)

            Dim dcHistPanelPath As New DataColumn("Path", System.Type.GetType("System.String"))
            dtHistPath.Columns.Add(dcHistPanelPath)

            ds.Tables.Add(dtHistPath)

            Dim dtHistPanel As New DataTable("HistoryPanel")
            Dim dcHistPathPathID As New DataColumn("PathID", System.Type.GetType("System.Int32"))
            dtHistPanel.Columns.Add(dcHistPathPathID)

            Dim dcHistPathPathSeqNbr As New DataColumn("SeqNbr", System.Type.GetType("System.String"))
            dtHistPanel.Columns.Add(dcHistPathPathSeqNbr)

            Dim dcHistPathPanel As New DataColumn("Panel", System.Type.GetType("System.String"))
            dtHistPanel.Columns.Add(dcHistPathPanel)

            'Dim dcHistScrollPos As New DataColumn("ScrollPos", System.Type.GetType("System.String"))
            'dtHistPanel.Columns.Add(dcHistScrollPos)

            ds.Tables.Add(dtHistPanel)

        Catch e As Exception
            Throw e
        End Try

    End Sub

    Public Overloads Function GetDataGlobal(ByVal tableName As String, ByVal pName As String) As String
        '************************************************************************
        'Method Name: GetDataGlobal
        'Argument List: tableName as string, pName as string.
        'Return Type: String.
        'Scope: Public.
        'Pre-Condition: N/A.
        'Stored Procedures: N/A.
        'Description: Finds the pName in the tableName of the shared sessionDataset and
        '               returns the value from the value column.
        'Formula:
        '************************************************************************
        Try
            Dim sessionDataset As DataSet = Session("gSessionDataSet")

            Dim dtInput As DataTable = sessionDataset.Tables(tableName)

            If Not dtInput Is Nothing Then
                Dim drKeyFind As DataRow = dtInput.Rows.Find(pName)
                If Not drKeyFind Is Nothing Then
                    Return CType(drKeyFind.Item("Value"), String)
                Else
                    Return ""
                End If
            Else
                Return ""
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Function
End Class
