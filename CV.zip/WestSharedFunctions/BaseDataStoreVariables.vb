﻿Namespace WestSharedFunctions
    Friend Class BaseDataStoreVariables
    End Class
End Namespace
