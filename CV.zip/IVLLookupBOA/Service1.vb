﻿Namespace IVLLookupBOA
    Friend Class Service1
        Public Property Url As Object

        Friend Function HomePhoneLookup(phone As String) As Reply
            Throw New NotImplementedException()
        End Function
    End Class
End Namespace
