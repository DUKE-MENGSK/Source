﻿Namespace IVLLookupBOA
    Friend Class Reply
        Public Property HomePhone As String
        Public Property Title As String
        Public Property FirstName As String
        Public Property MiddleName As String
        Public Property LastName As String
        Public Property SecondLastName As String
        Public Property Suffix As String
        Public Property Address1 As String
        Public Property Address2 As String
        Public Property Address3 As String
        Public Property City As String
        Public Property State As String
        Public Property Zip As String
        Public Property Last4Account As String
        Public Property ProgramCode As String
        Public Property GroupTransparent As String
        Public Property GroupName As String
        Public Property CardType As String

        Friend Function ReplyCode() As Integer
            Throw New NotImplementedException()
        End Function

        Friend Function ReplyMessage() As String
            Throw New NotImplementedException()
        End Function
    End Class
End Namespace
