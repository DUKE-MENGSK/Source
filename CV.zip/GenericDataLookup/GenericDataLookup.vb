﻿Namespace GenericDataLookup
    Friend Class GenericDataLookup
        Public Property Timeout As Integer
        Public Property Url As String

        Friend Function LookupByMultipleKey(gDLR As Request) As GenericReply
            Throw New NotImplementedException()
        End Function
    End Class
End Namespace
