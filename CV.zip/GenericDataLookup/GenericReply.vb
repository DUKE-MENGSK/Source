﻿Namespace GenericDataLookup
    Friend Class GenericReply
        Public Property ReplyCode As Object
        Public Property Data As Array

    End Class
End Namespace
