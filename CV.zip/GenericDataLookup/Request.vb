﻿Namespace GenericDataLookup
    Friend Class Request
        Public Property Environment As String
        Public Property ListName As String
        Public Property Schema As String

        Friend Property SearchKeys(v As Integer) As Keys
            Get
                Throw New NotImplementedException()
            End Get
            Set(value As Keys)
                Throw New NotImplementedException()
            End Set
        End Property
    End Class
End Namespace
