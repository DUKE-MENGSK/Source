﻿Namespace GenericDataLookup
    Friend Class Keys
        Public Property KeyColumn As String
        Public Property KeyValue As Double
    End Class
End Namespace
