﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class escalfrm0002
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0001.Text = GF.LS.ltodaysDate
        OBJLBL0002.Text = GF.LS.lSiteName
        OBJLBL0003.Text = GF.UPC.AgentInfo.fullname
        OBJTXT0001.Text = GF.LS.lTLName
        SetFocus("OBJTXT0001")
        OBJTXT0002.Text = GF.LS.lCustName
        OBJTXT0003.Text = GF.LS.lCustZip
        OBJSEL0002.SelectedValue = GF.LS.lEscalationReason
        OBJSEL0001.SelectedValue = GF.NGS.SELECT121
        OBJSEL0003.SelectedValue = GF.NGS.TransferReason
        OBJTAR0002.Text = GF.LS.lCustBestTime
        OBJTAR0001.Text = GF.LS.lCustConcern
        OBJTAR0003.Text = GF.NGS.ManagerResolution
        SCRIPT0001.PhoneNumber = GF.LS.lCustPhone
        SCRIPT0001.AreaCode = GF.LS.lCustAreaCode
        SCRIPT0001.Prefix = GF.LS.lCustPhone3
        SCRIPT0001.Extension = GF.LS.lCustPhone4
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.ltodaysDate = OBJLBL0001.Text
        GF.LS.lSiteName = OBJLBL0002.Text
        GF.UPC.AgentInfo.fullname = OBJLBL0003.Text
        GF.LS.lTLName = OBJTXT0001.Text
        GF.LS.lCustName = OBJTXT0002.Text
        GF.LS.lCustZip = OBJTXT0003.Text
        GF.LS.lEscalationReason = OBJSEL0002.SelectedValue
        GF.NGS.SELECT121 = OBJSEL0001.SelectedValue
        GF.NGS.TransferReason = OBJSEL0003.SelectedValue
        GF.LS.lCustBestTime = OBJTAR0002.Text
        GF.LS.lCustConcern = OBJTAR0001.Text
        GF.NGS.ManagerResolution = OBJTAR0003.Text
        GF.LS.lCustPhone = SCRIPT0001.PhoneNumber
        GF.LS.lCustAreaCode = SCRIPT0001.AreaCode
        GF.LS.lCustPhone3 = SCRIPT0001.Prefix
        GF.LS.lCustPhone4 = SCRIPT0001.Extension
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            SCRIPT0001.Prompt = "Customer Phone Number: "
            GF.LS.ltodaysDate = Format(Now, "MM/dd/yyyy")

            OBJTAR0001.Text = OBJTAR0001.Text & GF.LS.lCustConcern.ToString.Trim
            GF.NGS.LOGXTDAT = "Y"
            GF.LS.lXLFmain = "Y"

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            SCRIPT0001.PhoneRequired = False
            If GF.LS.lCustConcern.Length <= 50 Then
                GF.LS.lCustConcern501 = GF.LS.lCustConcern.Substring(0, GF.LS.lCustConcern.Length)
            Else
                GF.LS.lCustConcern501 = GF.LS.lCustConcern.Substring(0, 50)
            End If
            If GF.LS.lCustConcern.Length > 50 And GF.LS.lCustConcern.Length <= 100 Then

                GF.LS.lCustConcern502 = GF.LS.lCustConcern.Substring(50, GF.LS.lCustConcern.Length - 50)
            Else
                If GF.LS.lCustConcern.Length > 100 Then
                    GF.LS.lCustConcern502 = GF.LS.lCustConcern.Substring(50, 50)
                End If
            End If
            If GF.LS.lCustConcern.Length > 100 And GF.LS.lCustConcern.Length <= 150 Then

                GF.LS.lCustConcern503 = GF.LS.lCustConcern.Substring(100, GF.LS.lCustConcern.Length - 100)
            Else
                If GF.LS.lCustConcern.Length > 150 Then
                    GF.LS.lCustConcern503 = GF.LS.lCustConcern.Substring(100, 50)
                End If
            End If
            If GF.LS.lCustConcern.Length > 150 And GF.LS.lCustConcern.Length <= 200 Then

                GF.LS.lCustConcern504 = GF.LS.lCustConcern.Substring(150, GF.LS.lCustConcern.Length - 150)
            Else
                If GF.LS.lCustConcern.Length > 200 Then
                    GF.LS.lCustConcern504 = GF.LS.lCustConcern.Substring(150, 50)
                End If
            End If
            If GF.LS.lCustConcern.Length > 200 And GF.LS.lCustConcern.Length <= 250 Then

                GF.LS.lCustConcern505 = GF.LS.lCustConcern.Substring(200, GF.LS.lCustConcern.Length - 200)
            Else
                If GF.LS.lCustConcern.Length > 250 Then
                    GF.LS.lCustConcern505 = GF.LS.lCustConcern.Substring(200, 50)
                End If
            End If
            If GF.LS.lCustConcern.Length > 250 And GF.LS.lCustConcern.Length <= 300 Then

                GF.LS.lCustConcern506 = GF.LS.lCustConcern.Substring(250, GF.LS.lCustConcern.Length - 250)
            Else
                If GF.LS.lCustConcern.Length > 300 Then
                    GF.LS.lCustConcern506 = GF.LS.lCustConcern.Substring(250, 50)
                End If
            End If
            If GF.LS.lCustConcern.Length > 300 And GF.LS.lCustConcern.Length <= 350 Then

                GF.LS.lCustConcern507 = GF.LS.lCustConcern.Substring(300, GF.LS.lCustConcern.Length - 300)
            Else
                If GF.LS.lCustConcern.Length > 350 Then
                    GF.LS.lCustConcern507 = GF.LS.lCustConcern.Substring(300, 50)
                End If
            End If
            If GF.LS.lCustConcern.Length > 350 And GF.LS.lCustConcern.Length <= 400 Then

                GF.LS.lCustConcern508 = GF.LS.lCustConcern.Substring(350, GF.LS.lCustConcern.Length - 350)
            Else
                If GF.LS.lCustConcern.Length > 400 Then
                    GF.LS.lCustConcern508 = GF.LS.lCustConcern.Substring(350, 50)
                End If
            End If
            If GF.LS.lCustConcern.Length > 400 And GF.LS.lCustConcern.Length <= 450 Then

                GF.LS.lCustConcern509 = GF.LS.lCustConcern.Substring(400, GF.LS.lCustConcern.Length - 400)
            Else
                If GF.LS.lCustConcern.Length > 450 Then
                    GF.LS.lCustConcern509 = GF.LS.lCustConcern.Substring(400, 50)
                End If
            End If
            If GF.LS.lCustConcern.Length > 450 Then

                GF.LS.lCustConcern5010 = GF.LS.lCustConcern.Substring(450, GF.LS.lCustConcern.Length - 450)
            End If

            'GF.LS.lCustConcern501 = GF.LS.lCustConcern.Substring(0, 50)
            'GF.LS.lCustConcern502 = GF.LS.lCustConcern.Substring(50, 50)
            'GF.LS.lCustConcern503 = GF.LS.lCustConcern.Substring(100, 50)
            'GF.LS.lCustConcern504 = GF.LS.lCustConcern.Substring(150, 50)
            'GF.LS.lCustConcern505 = GF.LS.lCustConcern.Substring(200, 50)
            'GF.LS.lCustConcern506 = GF.LS.lCustConcern.Substring(250, 50)
            'GF.LS.lCustConcern507 = GF.LS.lCustConcern.Substring(300, 50)
            'GF.LS.lCustConcern508 = GF.LS.lCustConcern.Substring(350, 50)
            'GF.LS.lCustConcern509 = GF.LS.lCustConcern.Substring(400, 50)
            'GF.LS.lCustConcern5010 = GF.LS.lCustConcern.Substring(450, 50)



            If source.Equals("B") Then
                If GF.LS.lCustConcern.ToString.Trim.Equals(String.Empty) Then
                    EditError = 2
                    ErrorMsg = "Please enter a customer concern"
                    SetFocus("OBJTAR0001")
                ElseIf GF.LS.lCustConcern.ToString.Trim.Length > 501 Then
                    EditError = 2
                    ErrorMsg = "Customer concern is limited to 500 characters"
                    SetFocus("OBJTAR0001")
                ElseIf GF.LS.lTLName.ToString.Trim.Equals(String.Empty) Then
                    EditError = 2
                    ErrorMsg = "Please enter the Team Leads name"
                    SetFocus("OBJTXT0001")
                ElseIf GF.LS.lCustName.ToString.Trim.Equals(String.Empty) Then
                    EditError = 2
                    ErrorMsg = "Please enter the Customer name"
                    SetFocus("OBJTXT0002")
                ElseIf GF.LS.lCustZip.ToString.Trim.Length <> 5 Then
                    EditError = 2
                    ErrorMsg = "Please enter a full zipcode"
                    SetFocus("OBJTXT0003")
                ElseIf Not IsNumeric(GF.LS.lCustZip.ToString.Trim) Then
                    EditError = 2
                    ErrorMsg = "Please enter a numeric zipcode"
                    SetFocus("OBJTXT0003")
                ElseIf GF.LS.lEscalationReason.ToString.Trim.Equals(String.Empty) Then
                    EditError = 2
                    ErrorMsg = "Please select Reason for Escalation"
                    SetFocus("OBJSEL0002")
                ElseIf GF.NGS.ManagerResolution.ToString.Trim.Equals(String.Empty) Then
                    EditError = 2
                    ErrorMsg = "Please enter a manager resolution"
                    SetFocus("OBJTAR0003")
                ElseIf GF.NGS.ManagerResolution.ToString.Trim.Length > 501 Then
                    EditError = 2
                    ErrorMsg = "Manager Resolution is limited to 500 characters"
                    SetFocus("OBJTAR0003")
                Else
                    Select Case GF.NGS.SELECT121.ToString.Trim
                        Case String.Empty
                            EditError = 2
                            ErrorMsg = "Please select an outcome"
                            SetFocus("OBJSEL0001")
                        Case "A", "B"
                            Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                                Case "MBNACNFM", "MBNACNFS", "MBNACFSS"
                                    set_currPath(ScriptPaths.CONSUMER)
                                    EditError = 1
                                Case "MBNAMAKC", "MBNASANC", "MBNASANS"
                                    set_currPath(ScriptPaths.MBNA)
                                    EditError = 1
                            End Select
                        Case "C"
                            SCRIPT0001.PhoneRequired = True
                            If GF.LS.lCustBestTime.ToString.Trim.Equals(String.Empty) Then
                                EditError = 2
                                ErrorMsg = "The best time to contact must be entered"
                            End If
                            Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                                Case "MBNACNFM", "MBNACNFS", "MBNACFSS"
                                    set_currPath(ScriptPaths.CONSUMER)
                                    EditError = 1
                                Case "MBNAMAKC", "MBNASANC", "MBNASANS"
                                    set_currPath(ScriptPaths.MBNA)
                                    EditError = 1
                            End Select
                        Case "D"
                            If GF.NGS.TransferReason.ToString.Trim.Equals(String.Empty) Then
                                EditError = 2
                                ErrorMsg = "Please select reason for transfer"
                                SetFocus("OBJSEL0003")
                            End If
                            GF.NGS.EscalationType = "E"
                    End Select
                End If
            End If

            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False

            If GF.NGS.SELECT121.ToString.Trim.Equals("D") Then
                nextPanel = Panels.ESCALFRM.escalfrm0003
            Else
                endOfPath = True
            End If


        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

    Private Sub OBJSEL0002_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0002.SelectedIndexChanged
        PanelEditAutoMapping()

        '20110201 cgossman - setting escalation reason for FOCUS solution
        Select Case GF.LS.lEscalationReason.ToString.Trim
            Case "A"
                GF.NGS.EscalationReason = "Associate Conduct"
            Case "B"
                GF.NGS.EscalationReason = "Misinformation"
            Case "C"
                GF.NGS.EscalationReason = "Permission to Submit"
            Case "D"
                GF.NGS.EscalationReason = "Call Disconnect"
            Case "E"
                GF.NGS.EscalationReason = "Mail/Phone Suppression"
            Case "F"
                GF.NGS.EscalationReason = "Minor Receiving Application"
            Case "G"
                GF.NGS.EscalationReason = "Credit Department Concern"
            Case Else
                GF.NGS.EscalationReason = "Other"
        End Select

        '            select case GF.NGS.SELECT121.ToString.Trim
        '	Case "A"
        '		GF.NGS.EscResolved = "Y"
        '	Case "B"
        '		GF.NGS.EscTransferOther = "Y"
        '	Case "C"
        '		GF.NGS.EscCallBack = "Y"
        '            End Select
        '
        '            select case GF.NGS.TransferReason.ToString.Trim
        '	Case "A"
        '		GF.NGS.TrnGoOnRecord = "Y"
        '	Case "B"
        '		GF.NGS.TrnLegalAction = "Y"
        '	Case "C"
        '		GF.NGS.TrnNotifyMedia = "Y"
        '	Case "D"
        '		GF.NGS.TrnCEO_President = "Y"
        '            End Select
        '

    End Sub
    Private Sub OBJSEL0001_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0001.SelectedIndexChanged
        PanelEditAutoMapping()

        If GF.NGS.SELECT121.ToString.Trim.Equals("D") Then
            OBJDIV0001.Visible = True
        Else
            OBJDIV0001.Visible = False
        End If

        GF.NGS.EscResolved = String.Empty
        GF.NGS.EscTransferOther = String.Empty
        GF.NGS.EscCallBack = String.Empty
        GF.NGS.TrnGoOnRecord = String.Empty
        GF.NGS.TrnLegalAction = String.Empty
        GF.NGS.TrnNotifyMedia = String.Empty
        GF.NGS.TrnCEO_President = String.Empty

        '20110201 cgossman - setting escalation reason for FOCUS solution
        'Select Case GF.LS.lEscalationReason.ToString.Trim
        '    Case "A"
        '        GF.NGS.EscalationReason = "Associate Conduct"
        '    Case "B"
        '        GF.NGS.EscalationReason = "Misinformation"
        '    Case "C"
        '        GF.NGS.EscalationReason = "Permission to Submit"
        '    Case "D"
        '        GF.NGS.EscalationReason = "Call Disconnect"
        '    Case "E"
        '        GF.NGS.EscalationReason = "Mail/Phone Suppression"
        '    Case "F"
        '        GF.NGS.EscalationReason = "Minor Receiving Application"
        '    Case "G"
        '        GF.NGS.EscalationReason = "Credit Department Concern"
        '    Case Else
        '        GF.NGS.EscalationReason = "Other"
        'End Select

        Select Case GF.NGS.SELECT121.ToString.Trim
            Case "A"
                GF.NGS.EscResolved = "Y"
            Case "B"
                GF.NGS.EscTransferOther = "Y"
            Case "C"
                GF.NGS.EscCallBack = "Y"
        End Select

        'Select Case GF.NGS.TransferReason.ToString.Trim
        '    Case "A"
        '        GF.NGS.TrnGoOnRecord = "Y"
        '    Case "B"
        '        GF.NGS.TrnLegalAction = "Y"
        '    Case "C"
        '        GF.NGS.TrnNotifyMedia = "Y"
        '    Case "D"
        '        GF.NGS.TrnCEO_President = "Y"
        'End Select


    End Sub
    Private Sub OBJSEL0003_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0003.SelectedIndexChanged
        PanelEditAutoMapping()

        Select Case GF.NGS.TransferReason.ToString.Trim
            Case "A"
                GF.NGS.TrnGoOnRecord = "Y"
            Case "B"
                GF.NGS.TrnLegalAction = "Y"
            Case "C"
                GF.NGS.TrnNotifyMedia = "Y"
            Case "D"
                GF.NGS.TrnCEO_President = "Y"
        End Select


    End Sub



End Class
