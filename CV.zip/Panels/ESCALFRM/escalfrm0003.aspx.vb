﻿Imports System.Web.Mail

Public Class escalfrm0003
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0001.Text = GF.LS.lTLName
        OBJLBL0009.Text = GF.LS.lSwap1
        OBJLBL0002.Text = GF.LS.lCustName
        OBJLBL0003.Text = GF.LS.lCustPhone
        OBJLBL0004.Text = GF.LS.lCustZip
        OBJLBL0005.Text = GF.NGS.Transparency
        OBJLBL0006.Text = GF.LS.lCustBestTime
        OBJLBL0007.Text = GF.LS.lCustConcern
        OBJLBL0008.Text = GF.NGS.ManagerResolution
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lTLName = OBJLBL0001.Text
        GF.LS.lSwap1 = OBJLBL0009.Text
        GF.LS.lCustName = OBJLBL0002.Text
        GF.LS.lCustPhone = OBJLBL0003.Text
        GF.LS.lCustZip = OBJLBL0004.Text
        GF.NGS.Transparency = OBJLBL0005.Text
        GF.LS.lCustBestTime = OBJLBL0006.Text
        GF.LS.lCustConcern = OBJLBL0007.Text
        GF.NGS.ManagerResolution = OBJLBL0008.Text
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            OBJTID0001.Text = String.Empty

            ' determine whether to transfer or send email based on date / time
            ' Monday - Friday	800AM - 700PM transfer
            ' 					otherwise send email
            ' Saturday			830AM - 500PM transfer
            ' 					otherwise send email
            ' Sunday			email only

            'test call
            'call setData  ("LocalStore", "lSwap1", "(wzhang@west.com)" )

            GF.LS.lSwap1 = "(UPCTeam@gmail.com)"

            'DateTime.Now is based on server time which is Central.  Converting to Eastern
            Dim EastDate As DateTime = DateAdd(DateInterval.Hour, 1, DateTime.Now)

            GF.LS.lDayOfWeek = Now.DayOfWeek()

            Select Case GF.LS.lDayOfWeek
                Case "0" ' sunday
                    GF.NGS.EscalationType = "E"
                Case "1", "2", "3", "4", "5" ' mon, tues, wed, thurs, fri
                    If EastDate.Hour < 8 Or EastDate.Hour > 19 Then
                        GF.NGS.EscalationType = "E"
                    Else
                        GF.NGS.EscalationType = "T"
                    End If
                Case Else ' saturday
                    If (EastDate.Hour < 8 Or EastDate.Hour > 17) Or (EastDate.Hour = 8 And EastDate.Minute < 30) Then
                        GF.NGS.EscalationType = "E"
                    Else
                        GF.NGS.EscalationType = "T"
                    End If
            End Select

            Select Case GF.NGS.EscalationType.ToString.Trim
                Case "T"
                    ' display if transferring
                    If GF.NGS.Transparency.ToString.Trim.Equals("N") Then
                        OBJTID0001.Text = "I'm sorry that we have not been able to resolve your concern today.  At this time I'm going to bring a BOA associate on the line to assist you further."
                    Else
                        OBJTID0001.Text = "I'm sorry that we have not been able to resolve your concern today.  At this time I'm going to bring a FIA Card Services associate on the line to assist you further."
                    End If
                    GF.NGS.EscTransferESC = "Y"
                Case Else
                    ' display if sending email
                    If GF.NGS.Transparency.ToString.Trim.Equals("N") Then
                        OBJTID0001.Text = "I'm sorry that we have not been able to resolve your concern today.  A BOA associate will contact you by phone within the next business day."
                    Else
                        OBJTID0001.Text = "I'm sorry that we have not been able to resolve your concern today.  A FIA Card Services associate will contact you by phone within the next business day."
                    End If
                    GF.NGS.ESCEmail = "Y"
            End Select

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source.Equals("B") Then
                Select Case GF.NGS.EscalationType.ToString.Trim
                    Case "E"
                        GF.gfSendEMailEscalation()
                        Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                            Case "MBNACNFM", "MBNACNFS", "MBNACFSS"
                                set_currPath(ScriptPaths.CONSUMER)
                                EditError = 1
                            Case "MBNAMAKC", "MBNASANC", "MBNASANS"
                                set_currPath(ScriptPaths.MBNA)
                                EditError = 1
                        End Select
                    Case Else
                        GF.LS.lTransferNumber = "8663440015"
                        set_currPath(ScriptPaths.TRANSFER)
                End Select
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            Select Case GF.NGS.EscalationType.ToString.Trim
                Case "E"
                    endOfPath = True
                Case Else
                    nextPanel = Panels.TRANSFER.transfer0002
                    endOfPath = False
            End Select

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region










End Class
