﻿Friend Class TandemUserProxy
    Friend Function GetUserData(userIdentifier As String) As Object
        Throw New NotImplementedException()
    End Function
End Class
