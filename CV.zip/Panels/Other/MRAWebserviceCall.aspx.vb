﻿' THIS IS THE SL VERSION
Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions
Imports System.Web.Services
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.Script.Services
Imports System.Web.Script.Serialization


Public Class MRAWebserviceCall
    Inherits BaseSTDPanel

    Private mraService As MRAService.MRAServiceClient 'boa mra webservice

    <WebMethod()> _
    Public Shared Function GetData(ByVal t As String) As String
        'Public Shared Function OnSubmit(ByVal name As String, ByVal isGoing As Boolean, ByVal returnAddress As String) As String
        Try
            Return "it worked"
        Catch ex As Exception
            Throw ex
        End Try
    End Function


    Public Function GetMRADATAviaAgentID() As String()

        '***Get MBK from TandemID in the Table

        Dim tblMBK = String.Empty
        Dim tblNAME = String.Empty
        Dim tblPHONE = String.Empty

        Select Case GF.UPC.AgentInfo.uid
            Case "1390"
                tblMBK = "TESTMBK"
                tblNAME = "RAYMART SANTIAGO"
                tblPHONE = "8888888"
            Case "9998"
                tblMBK = "TSTMBK2"
                tblNAME = "HANSEN MENDOZA"
                tblPHONE = "8888888"
            Case "9610"
                tblMBK = "TSTMBK3"
                tblNAME = "KEVIN PIERSON"
                tblPHONE = "8888888"
            Case Else
                tblMBK = ""
                tblNAME = ""
                tblPHONE = ""
        End Select

        If String.IsNullOrEmpty(GF.NGS.CommonLanguageScript) AndAlso String.IsNullOrEmpty(GF.SL.ScriptSLWebserviceValues.CommonGenericDataLookup) Then
            GF.LogSystemMessage("GetMRADATAviaAgentID", "NULL ScriptSLWebserviceValues DETECTED!!!")
            Return New String() {"NULLURL", "", ""}
        End If

        If String.IsNullOrEmpty(GF.NGS.CommonLanguageScript) AndAlso
            Not String.IsNullOrEmpty(GF.SL.ScriptSLWebserviceValues.CommonGenericDataLookup) Then
            GF.NGS.CommonLanguageScript = CType(GF.SL.ScriptSLWebserviceValues.CommonGenericDataLookup, String)
        End If

        Dim objReply = GetMRADataTable(GF.NGS.CommonLanguageScript, GF.UPC.AgentInfo.uid)

        If (objReply Is Nothing) OrElse (objReply.Data Is Nothing) Then
            Return New String() {"", "", ""}
        End If
        For Each data As GenericDataLookup.GenericData In objReply.Data
            If data.Name.ToUpper = "MBK" Then
                tblMBK = data.Value
            ElseIf data.Name.ToUpper = "NAME" Then
                tblNAME = data.Value
            ElseIf data.Name = "PHONE" Then
                tblPHONE = data.Value
            End If

            If tblPHONE = GF.UPC.StationConfiguration.BM_AVAYA_ID.Trim Then
                Exit For
            End If
        Next


        Return New String() {tblMBK, tblNAME, tblPHONE}

    End Function

    Public Function GetMRADataTable(ByVal url As String, ByVal colValue As String) As GenericDataLookup.GenericReply
        Dim objReply As GenericDataLookup.GenericReply
        Dim objWS As New GenericDataLookup.GenericDataLookup

        Try
            If String.IsNullOrEmpty(url) Then
                Return Nothing
            End If

            objWS.Url = url

            objWS.Timeout = 40000

            Dim GDLR As New GenericDataLookup.Request

            GDLR.Environment = "oltp"
            GDLR.ListName = "MRABOA"
            GDLR.Schema = "AMEX"

            ReDim GDLR.SearchKeys(0)
            GDLR.SearchKeys(0) = New GenericDataLookup.Keys
            GDLR.SearchKeys(0).KeyColumn = "AGENTID"
            GDLR.SearchKeys(0).KeyValue = colValue


            Try
                objReply = objWS.LookupByMultipleKey(GDLR)
                Return objReply

            Catch ex As Exception
                Return Nothing
            End Try

        Catch ex As Exception
            GF.LogSystemMessage("MRA GetMRADataTable", ex.Message())
            GF.LogException(ex)
            Return Nothing
        End Try
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Response.Clear()
            Response.ContentType = "application/json"

            If String.IsNullOrEmpty(GF.LS.MBK) Then
                Dim mraData As String() = GetMRADATAviaAgentID()
                If mraData(0) = "NULLURL" Then
                    Response.Write("9999999999")
                    Response.Flush()
                    Response.SuppressContent = True
                    HttpContext.Current.ApplicationInstance.CompleteRequest()
                    Exit Sub
                End If

                GF.LS.IsMBKNullRecorded = ""
                GF.LS.MBK = mraData(0) 'RITM2435448 assign temp MBK
                GF.NGS.BusinessData41 = mraData(0) 'MBK ID
                GF.NGS.BusinessData42 = GF.UPC.StationConfiguration.CTI_EXT.ToString.Trim 'agent Station Extension ID

                If String.IsNullOrWhiteSpace(GF.LS.MBK) And (String.IsNullOrWhiteSpace(GF.LS.IsMBKNullRecorded) Or GF.LS.IsMBKNullRecorded = "N") Then
                    GF.LogSystemMessage("MRAWsCallPage Page_Load", "MBK ID Not Found on the Table")

                    GF.LS.IsMBKNullRecorded = "Y"
                End If

                If GF.LS.IsMBKNullRecorded = "" Then
                    GF.LogSystemMessage("MRA Page_Load", "TFN REQUEST FOR " + mraData(0) + " NAME: " + mraData(1))
                End If
            End If


            If mraService Is Nothing Then
                mraService = New MRAService.MRAServiceClient()
            End If
            Dim bankData As String = mraService.GetDataThruBankID(GF.LS.MBK)


            Dim l800No As String = ""
            If Regex.IsMatch(bankData, "^[0-9 ]+$") Then 'supposedly they pass 800number
                l800No = bankData
            ElseIf bankData.Contains("{") Then ' supposedly they pass json
                Dim jss As New JavaScriptSerializer()
                Dim values As Dictionary(Of String, String) = jss.Deserialize(Of Dictionary(Of String, String))(bankData.ToUpper) 'Dim values = JsonConvert.DeserializeObject(Of Dictionary(Of String, String))("{" & bankData.ToUpper() & "}")

                If values.ContainsKey("DIAL") Then
                    l800No = values("DIAL")
                End If
            Else
                l800No = ""
            End If

            GF.NGS.BusinessData32 = l800No

            Response.Write(l800No)

            Response.Flush() '; // Sends all currently buffered output to the client.
            Response.SuppressContent = True ';  // Gets or sets a value indicating whether to send HTTP content to the client.
            HttpContext.Current.ApplicationInstance.CompleteRequest() '; //

            If Not (String.IsNullOrWhiteSpace(GF.NGS.BusinessData32) OrElse String.IsNullOrEmpty(GF.NGS.BusinessData32)) Then
                GF.LogSystemMessage("MRA Page_Load", String.Format("MBK = {0}, 800Number = {1} Group = {2}  FSite = {3} AVAYA_ID = {4} COMPUTER = {5} IDENTITY = {6}", GF.LS.MBK, GF.NGS.BusinessData32,
                    GF.UPC.StationConfiguration.fkGroup, GF.UPC.StationConfiguration.fkSite, GF.UPC.StationConfiguration.BM_AVAYA_ID,
                    GF.NGS.SERVER, GF.UPC.StationConfiguration.ComputerIdentifier))
            End If


        Catch ex As Exception

            'todo:  check a localstore variable and log this exception if it is false, then set the localstore variable to true so it doesn't log again.
            GF.LogSystemMessage("MRA Page_Load", ex.Message())
            GF.LogException(ex)
        End Try



    End Sub

    Private Function GetTFN() As String

        If Not String.IsNullOrWhiteSpace(GF.NGS.BusinessData32) Then
            Return GF.NGS.BusinessData32
        End If

        Return "empty"
    End Function


End Class
