﻿Imports System.Web.Mail

Public Class SCREENPOP
    Inherits STDPanel
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Protected WithEvents OBJTXT0001 As System.Web.UI.HtmlControls.HtmlInputText
    '
#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            'systxb 6/2011 added to the template for 'in call' mode to work correctly
            '<begin nav add>
            ' code is here to help with making conditional nav links appear when in a call
            GF.UPC.Script.NAVMODE = "999"
            updateNavTree()
            ' <end nav add>

            'Stach 12/18/09
            'No Actions should ever take place on this panels OnLoad Code section
            'as the goal of this panel is to load quickly and everytime.

            'The Display field on this panel is special and should not be used
            'for any attempted scripting.


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit

        Try
            'Stach 12/18/09
            'You sould always leave this panel so do not add edits that would
            'trap a user on this panel.
            EditError = 0
            ErrorMsg = String.Empty


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next
    ''' endOfPath = True means there are no more panels on the current path
    ''' endOfPath = False means there are more panels on the current path.  This must be combined 
    ''' with a call to nextPanel noting the next panel in the sequence.
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch

        'Stach 12/18/09
        'Branch to the greeting panel
        'endOfPath = True

        '20100927 cgossman - trying to reduce screenpop latency

        endOfPath = False

        Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
            Case "MBNACNFM", "MBNACNFS", "MBNACFSS"
                nextPanel = Panels.CONS.cons0002
            Case Else
                Select Case GF.LS.l800NumberDialed.ToString.Trim
                    Case "8005449832", "8006432074", "8006435631", "8007105797", _
                     "8007105805", "8007603147", "8008234508", "8008234729", _
                     "8008234763", "8008234893", "8008235075", "8008235191", _
                     "8008394227", "8662660185", "8662660213", "8662775344", _
                     "8662775382", "8662824208", "8662939160", "8662986718", _
                     "8664345390", "8664345392", "8664610207", "8664610208", _
                     "8665309824", "8665309826", "8666002282", "8666288885", _
                     "8667486245", "8667982007", "8667982011", "8668098555", _
                     "8668300297", "8668677293", "8669335626", "8773991665", _
                     "8882055722", "8882153852", "8883366262", "8884667711", _
                     "8006100700", "8662824209"
                        nextPanel = Panels.CC.cc0005 'IVL 
                    Case "8887267322", "8662480226" 'PHONE NUMBER DIALED
                        nextPanel = Panels.CC.cc0003
                    Case "8008234538", "8008234712" ' IVL WELCOME CALL
                        Select Case GF.LS.lIVLweb1.ToString.Trim
                            Case "0", "1"
                                nextPanel = Panels.CC.cc0240
                            Case Else
                                nextPanel = Panels.CC.cc0003 'PHONE NUMBER DIALED
                        End Select
                    Case Else
                        nextPanel = Panels.CC.cc0002
                End Select
        End Select



    End Sub


    '


#End Region


    Public Sub WorkerProcess(ByVal lOriginalRTNhasValue As System.String)
        'Stach 12/18/09
        'All heavy lifting, Web service hits etc.., should take place on this button click.
        'The button will be hidden from view and the click triggered automaticly
        'after the page has loaded.
        'You need to ensure that in all cases you branch away from this panel
        'after your code executes.

        'Stach 12/18/09
        'All heavy lifting, Web service hits etc.., should take place on this button click.
        'The button will be hidden from view and the click triggered automaticly
        'after the page has loaded.
        'You need to ensure that in all cases you branch away from this panel 
        'after your code executes.

        Try
            'Cache Debug Flag for 60 minutes before checking flag again.
            If Val(DateDiff(DateInterval.Minute, GF.ConvertToDate(GF.UPC.Script.DebugFlagCheck), Now())) >= 60 Then
                GF.UPC.Script.DEBUGON = GF.IsDebugOn(GF.NGS.M_ScriptName.ToString.Trim, CInt(GF.NGS.M_Version))
                GF.UPC.Script.DebugFlagCheck = Now.ToString()
            End If
        Catch EX As Exception
            GF.UPC.Script.DEBUGON = False
            GF.UPC.Script.DebugFlagCheck = Now.ToString()
            GF.LogSystemMessageDB("Script", "Failure on ScreenPop with setting DEBUGFLAG - " & EX.Message, True)
            GF.LogException(EX)
        End Try

        Try
            If Not CInt(GF.UPC.Script.CALLMODE).Equals(1) Then
                GF.LogSystemMessageDB("Script", "Greeting Panel selected outside call...ignoring lookups for now.", True)
            ElseIf CBool(GF.UPC.Script.PerformedLookup) Then
                GF.LogSystemMessage("SCREENPOP panel", "Lookup has already been completed.  Bypassing a repeat lookup")
            Else
                If lOriginalRTNhasValue = "Y" Then
                    GF.UPC.Script.AliasLookupSuccess = "True"
                    GF.UPC.Script.PerformedLookup = "True"
                End If



                Try

                    If lOriginalRTNhasValue = "Y" Then

                        'Try each lookup
                        GF.LogSystemMessageDB("ScriptTest", "Start of NGSlookup.", CBool(GF.UPC.Script.DEBUGON))

                        'NGS ID Lookup (required for NGS Logging)
                        GF.SLNGSIDLookup(GF.UPC.AgentInfo.uid, GF.UPC.System.SITE)
                        'NGS Product Resolution (Replacement for Alias Lookup)
                        GF.SLProductResolution(GF.LS.lOriginalRTN, GF.UPC.System.DefaultRTN)

                        GF.MVDataPop2(String.Empty)
                        '20100823 cgossman - Add code that was executed in Tandem Alias Lookup
                        GF.NGS.M_PRODUCT_ID = GF.NGS.CallInfoProductCode.ToString.Trim
                        GF.NGS.M_CLIENT_N = GF.NGS.CallInfoLegacyClientNumber.ToString.Trim
                        GF.NGS.M_TRAN_DATE = Now.ToString("yyMMdd")
                        GF.NGS.M_END_TRANTIME = Now.ToString("HHmmssff")
                        GF.NGS.M_NBR_DIALED = GF.NGS.CallInfoNumberDialed.Substring(3, 7)
                        GF.NGS.M_NBR_DIALED_A = GF.NGS.CallInfoNumberDialed.Substring(0, 3)
                        GF.NGS.RTN_7 = GF.UPC.CallData.rtn.ToString.Trim
                        GF.NGS.M_EXTENSION = GF.UPC.CallData.rtn.Substring(3, 4)
                        GF.LS.l800NumberDialed = GF.NGS.M_NBR_DIALED_A.ToString.Trim & GF.NGS.M_NBR_DIALED.ToString.Trim

                    End If

                    '20110201 cgossman - populating SiteName for FOCUS solution
                    Select Case GF.NGS.CallInfoSiteID.ToString.Trim
                        Case "9"
                            GF.NGS.SiteName = "CYBERGATE"
                        Case "41"
                            GF.NGS.SiteName = "SAN ANTONIO"
                        Case "32"
                            GF.NGS.SiteName = "MAKATI"
                            '10132016 cosaih Added Utica, NY
                        Case "52"
                            GF.NGS.SiteName = "UTICA"
                        Case Else
                            GF.NGS.SiteName = "OTHER"
                    End Select

                    '20100924 cgossman - code was in gfPreloads
                    'Sets Referral Transfer Number
                    Select Case GF.LS.l800NumberDialed.ToString.Trim
                        Case "8002268893", "8003489688", "8004687632", "8668676326", "8777219398", "8778260930", "8887587946"
                            GF.LS.lRefNumber = "8008547338"
                        Case "8005214443", "8662298023", "8664082769"
                            GF.LS.lRefNumber = "8774652733"
                        Case "8002059989"
                            GF.LS.lRefNumber = "8667249224"
                        Case "8667456882", "8882297111", "8883523227", "8883937489", "8888402742"
                            GF.LS.lRefNumber = "8884560687"
                        Case "8005988748", "8008639693", "8665066268", "8665066272", "8668046586"
                            GF.LS.lRefNumber = "8002972326"
                        Case Else
                            Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                                Case "MBNACNFM", "MBNACNFS", "MBNACFSS" 'Consumer Finance
                                    GF.LS.lRefNumber = "8008928349"
                                Case "MBNASANS"
                                    GF.LS.lRefNumber = "8005987684"
                                Case Else
                                    GF.LS.lRefNumber = "8888844950"
                            End Select
                    End Select

                Catch exNGS As Exception
                    GF.LogSystemMessageDB("Script", "ID Lookup Failed at DP" & exNGS.Message, True)
                    GF.LogException(exNGS)
                End Try
                Try
                    If lOriginalRTNhasValue = "N" Then
                        GF.gfDataShareRetrieveWS()  'Using the new DS Function
                        'GF.gfDataShareRetrieve()
                    End If
                Catch dsex As Exception
                    GF.LogException(dsex)
                    GF.LogSystemMessageDB("ScreenPop Datashare", dsex.Message, True)
                End Try

            End If
            'SETTING SPANISH FLAG
            Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                Case "MBNASANS"
                    GF.LS.lSpanishFlag = "Y"
                Case Else
                    GF.LS.lSpanishFlag = "N"
            End Select

            Try
                If GF.LS.l800NumberDialed.ToString.Trim.Length = 10 Then
                    'Sets Verbiage based on TFN
                    GF.gfVerbiageLookup(CDbl(GF.LS.l800NumberDialed), GF.LS.lSpanishFlag.ToString.Trim)
                Else
                    GF.LogSystemMessageDB("Script", "TFN not available, not calling GF.gfVerbiageLookup!", True)
                End If
            Catch verbex As Exception
                GF.LogSystemMessageDB("ScreenPop: Error with Verbiage Set", verbex.Message, True)
            End Try

            '20110201 cgossman - setting Transparency flag

            If GF.LS.lclose.Length >= 37 AndAlso GF.LS.lclose.Substring(0, 37).Equals("Thank you for calling BOA") Then
                GF.NGS.Transparency = "N"
            Else
                GF.NGS.Transparency = "Y"
            End If

        Catch ex As Exception
            GF.LogException(ex)
            GF.LogSystemMessageDB("ScreenPop", ex.Message, True)
        Finally
            'No matter what happens need to move on from this panel
            If lOriginalRTNhasValue = "Y" Then
                PageDown()
            End If
        End Try



    End Sub

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Client side will post back with querystring DoWork appened on load.
        'This allows the client side progress bar to kick off before we do our work
        If Not IsNothing(Request.QueryString("DoWork")) Then
            WorkerProcess("N")
        End If

    End Sub

    Private Sub OnBOARouteCallDetailsOnLoad(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GF.OnBOARouteCallDetailsOnLoad
        If Not IsNothing(Request.QueryString("DoWork")) Then
            WorkerProcess("Y")
        End If
    End Sub



End Class






































