﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class logcomplete
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            WindowOnLoadAutoMapping()

            'call gfManageAicToggleCount (  )

            If GF.UPC.Script.DEBUGON.Equals("True") Then
                GF.LogSystemMessage("Script", "In PanelOnload of LOGCOMPLETE, makebusyon flag = " & GF.UPC.Script.MAKEBUSYON.ToString() & " isCallLogged: " & GF.UPC.Script.isCallLogged.ToString())
            End If

            If GF.UPC.Script.LoggedOffDuringCall.Equals("True") Then
                GF.UPC.Script.LoggedOffDuringCall = "False"
                GF.ResetPhoneControlState("SignOff")
                Exit Sub
            End If

            If GF.UPC.Script.MAKEBUSYON.Equals("Y") Then
                Try
                    'manage VACD rule hits, if any
                    If GF.UPC.Script.ForceSignoffReceived.Equals("Y") Then
                        If GF.UPC.Script.DEBUGON.Equals("True") Then
                            GF.LogSystemMessage("Script", "In PanelOnload of LOGCOMPLETE, makebusyon=y AND forcesignoffreceived=y; resetting phone control to signoff...")
                        End If

                        'Then rule 2 and 1 have both hit. Allow the signoff.
                        GF.ResetPhoneControlState("SignOff")

                    ElseIf GF.UPC.Script.ForceNotReadyReceived <> "Y" Then
                        If GF.UPC.Script.DEBUGON.Equals("True") Then
                            GF.LogSystemMessage("Script", "In PanelOnload of LOGCOMPLETE, makebusyon=y AND forcenotreadyreceived <> y; calling GF.gfmakenotready...")
                        End If

                        ' Then no rule has hit at all. Respond to the makebusy toggle.
                        If GF.UPC.Script.AuxCode.ToString.Trim.Equals(String.Empty) Then
                            GF.gfMakeNotReady()
                        Else
                            GF.gfMakeNotReadyWithAuxCode(GF.UPC.Script.AuxCode)
                        End If
                    Else
                        If GF.UPC.Script.DEBUGON = "True" Then
                            GF.LogSystemMessage("Script", "In PanelOnload of LOGCOMPLETE, makebusyon=y AND in ELSE condition; resetting phone control to notready and going to MSG path...")
                        End If

                        ' then only rule 1 has hit. Set phone control to match 'not ready' state.
                        GF.ResetPhoneControlState("NotReady")
                        set_currPath(ScriptPaths.MSG)

                    End If

                Catch phEx As West.CorpSysDev.ADE.FrameworkServices.FrameworkServiceExceptions.BaseException
                    If (Not phEx.InnerException Is Nothing) AndAlso TypeOf phEx.InnerException Is CtConnectException Then
                        If DirectCast(phEx.InnerException, CtConnectException).ErrorCode = 3024 Then
                            GF.ResetPhoneControlState("NotReady")
                        Else
                            Throw (phEx)
                        End If
                    End If
                End Try

            Else

                'condition added to disallow multiple next button clicks from occurring
                If String.IsNullOrWhiteSpace(GF.LS.MakeReadyFlag) Then
                    GF.LS.MakeReadyFlag = "Y"
                    GF.LogSystemMessage("LogComplete Panel", "Calling GF.gfMakeReady")
                    GF.gfMakeReady()
                End If
            End If


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next
    ''' endOfPath = True means there are no more panels on the current path
    ''' endOfPath = False means there are more panels on the current path.  This must be combined 
    ''' with a call to nextPanel noting the next panel in the sequence.
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = True


        Catch ex As Exception
            Throw
        End Try
    End Sub


    '


#End Region

    Private Sub OBJBTN0001_Click(sender As System.Object, e As System.EventArgs) Handles OBJBTN0001.Click
            Try
            GF.gfSendLoggedOffEvent (  )
            Catch ex as exception
            Throw
        End Try
    End Sub


    Private Sub AgentSignOn()
        Try
            'GSC Put this code here to retry this logic in case
            ' The rules kicked the agent off
            If GF.UPC.Script.MAKEBUSYON.ToString.Trim.Equals("Y") Then
                GF.gfMakeNotReady()
            Else
                GF.gfMakeReady()
            End If
        Catch ex As exception
            Throw
        End Try
    End Sub

    Sub Page_panelAgentMakeReadyFailed(ByVal pErrorCode As String, ByVal pErrorText As String) Handles MyBase.panelAgentMakeReadyFailed
        ' Sub panelAgentMakeReadyFailed(pErrorCode as String, pErrorText as String)
        ' Created:OM0610L1:Sysgsc:10/22/2004 02:44:41 PM
        Try
            'GSC if the Rules boot the agent out of the system,
            ' Let's try to gracefully sign them back in
            ' 201 means agent does not exist in the system

            If CInt(pErrorCode) = 201 Then
                If GF.UPC.Script.MakeReadyFailedRetries > 1 Then
                    Dim errmsg As String
                    errmsg = "Unable to Synchronize Phone state after 2 tries. " & pErrorText
                    GF.UPC.Script.LoggingErrorMessage = errmsg
                    OBJDIV0001.Style.Item("Display") = "Block"
                Else
                    GF.UPC.Script.MakeReadyFailedRetries += 1
                    GF.gfSignOn()
                End If
            End If
            Call windowOnloadAutoMapping()
        Catch ex As exception
            Throw
        End Try

    End Sub


End Class
