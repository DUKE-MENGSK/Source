﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class logging
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            WindowOnLoadAutoMapping()

            OBJLBL0001.Text = "Please Wait Saving"

            Try
                If GF.UPC.Script.DEBUGON = "True" Then
                    GF.LogSystemMessage("Script", "In PanelOnload of LOGGING, isInlogging flag = " & GF.UPC.Script.isInLogging.ToString() & " isCallLogged: " & GF.UPC.Script.isCallLogged.ToString())
                End If

                'Duplicate Logging Code Update
                If GF.UPC.Script.isInLogging <> "Y" Then
                    GF.UPC.Script.isCallLogged = "Y"
                    LogCall()
                Else
                    If GF.CheckCurrentRelease(GF.UPC.System.ScriptRelease) Then
                        PageDown()
                    Else
                        GF.UPC.System.GracefulAbandon = "Y"
                        'destroy the session
                        Session.Abandon()
                        PageDown()
                    End If
                End If
                'End Duplicate Logging Code Update

                'SYSTXB - add sleep to try to recreate slow logging error
                'REMOVE FOR PRODUCTION
                'system.threading.thread.sleep(2000)

            Catch aEx As ApplicationException
                OBJLBL0001.Text = "Error Logging - " & aEx.Message
                Throw (aEx)

            Catch ex As Exception
                OBJLBL0001.Text = "Error Logging - " & ex.Message
                Throw (ex)
            End Try
            OBJLBL0001.Text = "Call Has Been Logged"
            ' If we succeed here , lets send the make ready request


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            PanelEditAutoMapping()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next
    ''' endOfPath = True means there are no more panels on the current path
    ''' endOfPath = False means there are more panels on the current path.  This must be combined 
    ''' with a call to nextPanel noting the next panel in the sequence.
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            'Stach branch to LOGCOMPLETE or LOGFAILED if a showstopping error took place.
            endOfPath = False
            If GF.UPC.Script.Logging = "Error" Then
                nextPanel = Panels.Other.logfailed
            Else
                nextPanel = Panels.Other.logcomplete
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub


    '


#End Region



    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LogCall()

        '20130214 49120 tjflesher - nice business data (gfLogBusinessData)
        'SYSTXB - added to avoid logging twice
        GF.UPC.Script.isInLogging = "Y"

        GF.UPC.Script.CallType = "O"
        GF.UPC.Script.callEndTime = Now().ToString()
        'KVYAS 10252011 ADDED FOR XP# 35689 
        GF.LogSystemMessageDB("Logging", "In LogCall function of LOGGING = M_PROB_CALL_I = " & GF.NGS.M_PROB_CALL_I.ToString(), CBool(GF.UPC.Script.DEBUGON))

        'Stach - Handle missing callinfo station name if present.
        If GF.UPC.AgentInfo.term_id.ToString.Trim.Equals(String.Empty) Then
            GF.UPC.AgentInfo.term_id = GF.UPC.StationConfiguration.CTI_EXT.ToString.Trim
            GF.LogSystemMessage("Script", "AgentInfo.Term_id is missing.  This is pulled from UPC Config file")
        End If

        GF.gfCallComplete()

        '20100823 cgossman - unplugging Tandem logging
        'logords prep
        'select case getDatatrim ("Script","CALLTYPE")
        'case "O"
        'call setData("DataStore","M_LAYOUT_NAME",getDataTrim("Script","orderLayoutName"))
        'case "P"
        'call setData("DataStore","M_LAYOUT_NAME",getDataTrim("Script","problemLayoutName"))
        'end select
        '
        'if getDatatrim ("DataStore", "LOGXTDAT").Equals("Y") then
        'Dim temp as String
        'call setData  ("DataStore", "M_CONV_FLAG", "3" )
        ''first xvo
        'temp = SendLogXordsSoap ( "XMBNA10", gfFormatXVOFromKeyedList ( "lXLFData" ), "1", String.Empty)
        'call setData  ("DataStore", "XLF_KEY", temp ) 
        '' second xvo
        'temp = SendLogXordsSoap ( "XDNC02", gfFormatXVOFromKeyedList ( "lXLFDNC" ), "2", String.Empty )
        'call setData  ("DataStore", "XLF_KEY2", temp )
        '' third xvo
        'temp = SendLogXordsSoap ( "XRATE04", gfFormatXVOFromKeyedList ( "lXLFRate" ), "3", String.Empty )  
        'call setData  ("DataStore", "XLF_KEY3", temp )
        'else
        'call setData  ("DataStore", "M_CONV_FLAG", "0" ) 
        'end if

        'if getDatatrim ("DataStore", "SECXTDAT").Equals("Y") then
        'if getDataTrim ("DataStore", "SELECT36").Equals(String.Empty) then 'change request form, cancel application
        'gfSendSLogOrdsSoap ("XMBNA04", gfFormatXVOFromKeyedList ("lSecureChangeRequest"), "978", String.Empty, "1") 
        'else   
        'Select Case getDatatrim ("DataStore", "SELECT82")   
        'Case "A" 'Rate Issue - Paper manuals
        'gfSendSLogOrdsSoap ( "XMBNA04", gfFormatXVOFromKeyedList ("lSecureCCManual"), "3000", String.Empty, "2")  
        'Case "B" 'System Down - Manuals  
        'gfSendSLogOrdsSoap ( "XMBNA04", gfFormatXVOFromKeyedList ("lSecureSystemDown"), "1268", String.Empty, "3")  
        'Case "C" 'Consumer Pricing Issue - Manuals 
        'gfSendSLogOrdsSoap ( "XMBNA04", gfFormatXVOFromKeyedList ("lSecureCFManual"), "1176", String.Empty, "4")  
        'End Select  
        'end if   
        'end if
        '
        'call SetFixedCounters (  )
        GF.gfLogBusinessData()
        GF.IncrementCounterRules()
        'JFrum - Changed to use NGS logging param.
        'call FormatVariableArea (  ) 
        'call  FormatVariableAreaFORBW6 ()
        'JFrum - Remove line above when tandem logging goes away.

        'call logords via SOAP...
        'parameter = timeout -> leave blank for default of 10 seconds

        'call SendLogordsSoap (getData  ("Script", "SoapTimeout")) 

        'Used for NGS Logging
        ' XVO logging
        'if XVOCopy("lXLFData,lXLFDNC,lXLFRate,lSecureChangeRequest,lSecureCCManual,lSecureSystemDown,lSecureCFManual") then
        If GF.XVOCopy(GF.NGS, GF.LS, "lXLFData,lXLFDNC,lXLFRate,lSecureChangeRequest,lSecureCCManual,lSecureSystemDown,lSecureCFManual") Then
        Else
            GF.LogSystemMessageDB("Script", "XVOCopy failed...", True)
        End If
        ''END TODO

        'IF ID Lookup Failed during data pop, go ahead and retry.
        'Try
        '    If Not (GF.NGS.CallInfoSiteID.ToString.Trim.Equals(String.Empty)) Then
        '        If CInt(GF.NGS.CallInfoSiteID) < 1 Then
        '            GF.LogSystemMessageDB("Script", "ID Lookup Failed at DataPop, Retrying...", True)
        '            GF.NGSIDLookup(GF.UPC.AgentInfo.uid, GF.UPC.System.SITE)
        '        End If
        '    End If
        'Catch EX As Exception
        '    GF.LogSystemMessageDB("Script", "ID Lookup Exception at Logging..." & EX.Message, True)
        '    GF.LogException(EX)
        'End Try
        GF.LogSystemMessageDB("Script", "AT NGS LOGGING NOW", True)

        Try
            Dim tempInt As Integer = 0
            If Not Integer.TryParse(GF.NGS.CallInfoSiteID, tempInt) Then
                GF.LogSystemMessageDB("Script", "GF.NGS.CallInfoSiteID is blank", True)
            End If

            If tempInt < 1 Then
                GF.LogSystemMessageDB("Script", "ID Lookup Failed at DataPop, Retrying...", True)
                GF.SLNGSIDLookup(GF.UPC.AgentInfo.uid, GF.UPC.System.SITE)
            End If
        Catch EX As Exception
            GF.LogSystemMessageDB("Script", "ID Lookup Exception at Logging..." & EX.Message, True)
            GF.LogException(EX)
        End Try

        'Retry Prod Res if not already performed during DP.
        'Try
        '    If Not (GF.NGS.CallInfoClientId.ToString.Trim.Equals(String.Empty)) Then
        '        If CInt(GF.NGS.CallInfoClientId) < 1 Then
        '            GF.LogSystemMessageDB("Script", "Prod Res Failed at DataPop, Retrying...", True)
        '            GF.ProductResolution(GF.UPC.CallData.rtn, GF.UPC.System.DefaultRTN)
        '        End If
        '    End If
        '    'Per NGS Team if Prod Res Fails, go ahead and log the original RTN.
        '    If Not (GF.NGS.CallInfoClientId.ToString.Trim.Equals(String.Empty)) Then
        '        If CInt(GF.NGS.CallInfoClientId) < 1 Then
        '            GF.LogSystemMessageDB("Script", "No ClientID, Setting Callinfo.RTN to " & GF.LS.lOriginalRTN, True)
        '            'call setDataEqual2  ("LocalStore", "lOriginalRTN", "DataStore", "CallInfo.Rtn" ) 
        '            GF.NGS.CallInfoRtn = GF.LS.lOriginalRTN
        '        End If
        '    End If
        Try
            Dim tempInt As Integer = 0
            If Not Integer.TryParse(GF.NGS.CallInfoClientId, tempInt) Then
                GF.LogSystemMessageDB("Script", "GF.NGS.CallInfoClientId is blank", True)
            End If

            If tempInt < 1 Then
                GF.LogSystemMessageDB("Script", "Prod Res Failed at DataPop, Retrying...", True)
                GF.SLProductResolution(GF.UPC.CallData.rtn, GF.UPC.System.DefaultRTN)
            End If

            tempInt = 0
            If Not Integer.TryParse(GF.NGS.CallInfoClientId, tempInt) Then
                GF.LogSystemMessageDB("Script", " GF.NGS.CallInfoClientId is still blank", True)
            End If
            'Per NGS Team if Prod Res Fails, go ahead and log the original RTN.
            If tempInt < 1 Then
                GF.LogSystemMessageDB("Script", "No ClientID, Setting Callinfo.RTN to " & GF.LS.lOriginalRTN, True)
                'call setDataEqual2  ("LocalStore", "lOriginalRTN", "DataStore", "CallInfo.Rtn" ) 
                GF.NGS.CallInfoRtn = GF.LS.lOriginalRTN
            End If


            ' RS05092018 Set CallInfoRTN for Default Calls
            If GF.UPC.CallData.rtn = "4760206" Or GF.UPC.CallData.rtn = "5907125" Then
                GF.NGS.CallInfoRtn = GF.UPC.CallData.rtn
            End If

        Catch EX As Exception
            GF.LogSystemMessageDB("Script", "ProdRes Exception at Logging..." & EX.Message, True)
            GF.LogException(EX)
        End Try


        'NGS Logging
        '**********************************************************
        '**** New generation language 2015 Logging *******
        Try
            'IMPORTANT NOTE: YOU MUST SET MAX DISPOSTIONS (default = 1) to the highest logging level
            '        you need for this script
            'set the max dispositions for this script
            Dim iMaxDispositions As Integer = 1

            'set the initial call logging variables to defaults if they are missing
            'call to set ngs datafields for logging and disposition levels
            'IMPORTANT NOTE: YOU MUST SET MAX DISPOSTIONS ABOVE (default = 1) to the highest logging level
            GF.SetNGSDataForLogging(1, iMaxDispositions)

            'IMPORTANT NOTE: YOU MUST UPDATE any optional parameters as needed when calling this logging function!!!
            '                       MAXATTEMPTS - default 2, MaxDispositions, NGSDBTimeout)
            '                       NGSDBTIMEOUT - default = 30000 (30 secs)
            '  YOU ALSO MUST get the XML for any lists in the script...change string.empty to valid LIST XML
            GF.SLNGLLogCall(GF.GetScriptWebRoot(Server), GF.GetLoggingXML(GF.NGS.GetNgsXml()), String.Empty, iMaxDispositions)
        Catch EX As Exception
            GF.LogSystemMessageDB("Script", String.Format("NGL Call Logging EXCEPTION!!.  TOTAL FAILURE, CALL LOGS WILL NOT BE SAVED!!  Exception: {0}", EX.ToString), True)
            'NOTE:  add list xml to this concatenation as above...
            GF.WriteMVLogDataOnError(String.Concat(GF.GetLoggingXML(GF.NGS.GetNgsXml()), String.Empty), New Exception("NGLCALLLOGGINGEXCEPTION:  Total failure, the call will not be logged due to exception: " & EX.ToString))
            GF.LogException(EX)
        Finally
        End Try
        '**** New generation language 2015 Logging *******
        '**********************************************************

        'Try
        '    GF.NGSLogCall()
        'Catch EX As Exception
        '    GF.LogSystemMessage("NGS Logging Exception", EX.ToString)
        '    GF.LogException(EX)
        'Finally
        '    'Also set in gfPreloads. Some calls are not setting this field in gfPreloads, doing it here to make sure it happens.
        '    'GF.UPC.Script.NGSLookupSuccess = "False"
        'End Try

        'NGS Logging


        GF.UPC.Script.Logging = "N"

        'Stach - Removed duplicat call to PageDown and now calling CheckCurrentRelease directly
        If Not GF.CheckCurrentRelease(GF.UPC.System.ScriptRelease) Then
            GF.UPC.System.GracefulAbandon = "Y"
            'destroy the session 
            Session.Abandon()
            Exit Sub
        End If

        PageDown()



    End Sub



End Class
