﻿Public Class LOGINIT
    Inherits STDPanel
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Protected WithEvents OBJTXT0001 As System.Web.UI.HtmlControls.HtmlInputText
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try

            ' !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            ' !! DO NOT call PageDown from the onload of this panel !!
            ' !!!!!!!!!!!!!!!!!!!!!!!!!!!!ow!!!!!!!!!!!!!!!!!!!!!!!!!!!!

            GF.LS.LogInitCount += 1

            Call windowOnLoadAutoMapping()

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = ""

            Call panelEditAutoMapping()

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False
            nextPanel = Panels.Other.PRELOGGING
        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    Private Sub Page_panelSubmit() Handles MyBase.panelSubmit
        Try
        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    Public Sub windowOnLoadAutoMapping()
        Try
            OBJTXT0001.Value = GF.LS.LogInitCount.ToString
        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    Public Sub panelEditAutoMapping()
        Try

            GF.LS.LogInitCount = OBJTXT0001.Value
        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

End Class




