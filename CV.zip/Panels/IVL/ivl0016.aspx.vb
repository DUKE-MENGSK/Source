﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class ivl0016
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJRAD0004.SelectedValue = GF.LS.lIVLcustomerIrate
        OBJRAD0001.SelectedValue = GF.LS.lIVLDNC
        OBJRAD0002.SelectedValue = GF.LS.lIVLletter
        OBJRAD0003.SelectedValue = GF.LS.lIVLSatisfied
        OBJTAR0001.Text = GF.LS.lIVLnotes1
        OBJTAR0002.Text = GF.LS.lIVLnotes4
        SCRIPT0001.ZipCode = GF.LS.lmailZip
        SCRIPT0001.Address1 = GF.LS.lmailAdd1
        SCRIPT0001.Address2 = GF.LS.lmailAdd2
        SCRIPT0001.City = GF.LS.lmailCity
        SCRIPT0001.State = GF.LS.lmailState
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lIVLcustomerIrate = OBJRAD0004.SelectedValue
        GF.LS.lIVLDNC = OBJRAD0001.SelectedValue
        GF.LS.lIVLletter = OBJRAD0002.SelectedValue
        GF.LS.lIVLSatisfied = OBJRAD0003.SelectedValue
        GF.LS.lIVLnotes1 = OBJTAR0001.Text
        GF.LS.lIVLnotes4 = OBJTAR0002.Text
        GF.LS.lmailZip = SCRIPT0001.ZipCode
        GF.LS.lmailAdd1 = SCRIPT0001.Address1
        GF.LS.lmailAdd2 = SCRIPT0001.Address2
        GF.LS.lmailCity = SCRIPT0001.City
        GF.LS.lmailState = SCRIPT0001.State
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            OBJTAR0001.Text = OBJTAR0001.Text & GF.LS.lIVLnotes1.ToString.Trim
            OBJTAR0002.Text = OBJTAR0002.Text & GF.LS.lIVLnotes4
            GF.LS.lIVLApp = String.Empty
            SCRIPT0001.Address1Req = False
            SCRIPT0001.CityReq = False
            SCRIPT0001.StateReq = False
            SCRIPT0001.ZipReq = False
            SCRIPT0001.MiddleInitialReq = False

            '20100515. cshepler. This will have run on IVL calls that were calling the web service.
            If Not GF.LS.lIVLweb3.ToString.Trim.Equals(String.Empty) Then
                GF.LS.lIVlzip = GF.LS.lIVLweb15
                GF.LS.lIVLaddress1 = GF.LS.lIVLweb10.ToString.Trim
                GF.LS.lIVLaddress2 = GF.LS.lIVLweb11.ToString.Trim
                GF.LS.lIVLcity = GF.LS.lIVLweb13.ToString.Trim
                GF.LS.lIVLstate = GF.LS.lIVLweb14.ToString.Trim
            End If

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            'moves comment to smaller fields to help with output
            'customer concern
            If GF.LS.lIVLnotes1.Length <= 50 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, GF.LS.lIVLnotes1.Length)
            End If
            If GF.LS.lIVLnotes1.Length > 50 And GF.LS.lIVLnotes1.Length <= 100 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, 50)
                GF.LS.lIVLOtherNotes2 = GF.LS.lIVLnotes1.Substring(50, GF.LS.lIVLnotes1.Length - 50)
            End If
            If GF.LS.lIVLnotes1.Length > 100 And GF.LS.lIVLnotes1.Length <= 150 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, 50)
                GF.LS.lIVLOtherNotes2 = GF.LS.lIVLnotes1.Substring(50, 50)
                GF.LS.lIVLOtherNotes3 = GF.LS.lIVLnotes1.Substring(100, GF.LS.lIVLnotes1.Length - 100)
            End If
            If GF.LS.lIVLnotes1.Length > 150 And GF.LS.lIVLnotes1.Length <= 200 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, 50)
                GF.LS.lIVLOtherNotes2 = GF.LS.lIVLnotes1.Substring(50, 50)
                GF.LS.lIVLOtherNotes3 = GF.LS.lIVLnotes1.Substring(100, 50)
                GF.LS.lIVLOtherNotes4 = GF.LS.lIVLnotes1.Substring(150, GF.LS.lIVLnotes1.Length - 150)
            End If
            If GF.LS.lIVLnotes1.Length > 200 And GF.LS.lIVLnotes1.Length <= 250 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, 50)
                GF.LS.lIVLOtherNotes2 = GF.LS.lIVLnotes1.Substring(50, 50)
                GF.LS.lIVLOtherNotes3 = GF.LS.lIVLnotes1.Substring(100, 50)
                GF.LS.lIVLOtherNotes4 = GF.LS.lIVLnotes1.Substring(150, 50)
                GF.LS.lIVLOtherNotes5 = GF.LS.lIVLnotes1.Substring(200, GF.LS.lIVLnotes1.Length - 200)
            End If
            If GF.LS.lIVLnotes1.Length > 250 And GF.LS.lIVLnotes1.Length <= 300 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, 50)
                GF.LS.lIVLOtherNotes2 = GF.LS.lIVLnotes1.Substring(50, 50)
                GF.LS.lIVLOtherNotes3 = GF.LS.lIVLnotes1.Substring(100, 50)
                GF.LS.lIVLOtherNotes4 = GF.LS.lIVLnotes1.Substring(150, 50)
                GF.LS.lIVLOtherNotes5 = GF.LS.lIVLnotes1.Substring(200, 50)
                GF.LS.lIVLOtherNotes6 = GF.LS.lIVLnotes1.Substring(250, GF.LS.lIVLnotes1.Length - 250)

            End If
            If GF.LS.lIVLnotes1.Length > 300 And GF.LS.lIVLnotes1.Length <= 350 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, 50)
                GF.LS.lIVLOtherNotes2 = GF.LS.lIVLnotes1.Substring(50, 50)
                GF.LS.lIVLOtherNotes3 = GF.LS.lIVLnotes1.Substring(100, 50)
                GF.LS.lIVLOtherNotes4 = GF.LS.lIVLnotes1.Substring(150, 50)
                GF.LS.lIVLOtherNotes5 = GF.LS.lIVLnotes1.Substring(200, 50)
                GF.LS.lIVLOtherNotes6 = GF.LS.lIVLnotes1.Substring(250, 50)
                GF.LS.lIVLOtherNotes7 = GF.LS.lIVLnotes1.Substring(300, GF.LS.lIVLnotes1.Length - 300)
            End If
            If GF.LS.lIVLnotes1.Length > 350 And GF.LS.lIVLnotes1.Length <= 400 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, 50)
                GF.LS.lIVLOtherNotes2 = GF.LS.lIVLnotes1.Substring(50, 50)
                GF.LS.lIVLOtherNotes3 = GF.LS.lIVLnotes1.Substring(100, 50)
                GF.LS.lIVLOtherNotes4 = GF.LS.lIVLnotes1.Substring(150, 50)
                GF.LS.lIVLOtherNotes5 = GF.LS.lIVLnotes1.Substring(200, 50)
                GF.LS.lIVLOtherNotes6 = GF.LS.lIVLnotes1.Substring(250, 50)
                GF.LS.lIVLOtherNotes7 = GF.LS.lIVLnotes1.Substring(300, 50)
                GF.LS.lIVLOtherNotes8 = GF.LS.lIVLnotes1.Substring(350, GF.LS.lIVLnotes1.Length - 350)
            End If
            If GF.LS.lIVLnotes1.Length > 400 And GF.LS.lIVLnotes1.Length <= 450 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, 50)
                GF.LS.lIVLOtherNotes2 = GF.LS.lIVLnotes1.Substring(50, 50)
                GF.LS.lIVLOtherNotes3 = GF.LS.lIVLnotes1.Substring(100, 50)
                GF.LS.lIVLOtherNotes4 = GF.LS.lIVLnotes1.Substring(150, 50)
                GF.LS.lIVLOtherNotes5 = GF.LS.lIVLnotes1.Substring(200, 50)
                GF.LS.lIVLOtherNotes6 = GF.LS.lIVLnotes1.Substring(250, 50)
                GF.LS.lIVLOtherNotes7 = GF.LS.lIVLnotes1.Substring(300, 50)
                GF.LS.lIVLOtherNotes8 = GF.LS.lIVLnotes1.Substring(350, 50)
                GF.LS.lIVLOtherNotes9 = GF.LS.lIVLnotes1.Substring(400, GF.LS.lIVLnotes1.Length - 400)
            End If
            If GF.LS.lIVLnotes1.Length > 450 And GF.LS.lIVLnotes1.Length <= 500 Then
                GF.LS.lIVLOtherNotes1 = GF.LS.lIVLnotes1.Substring(0, 50)
                GF.LS.lIVLOtherNotes2 = GF.LS.lIVLnotes1.Substring(50, 50)
                GF.LS.lIVLOtherNotes3 = GF.LS.lIVLnotes1.Substring(100, 50)
                GF.LS.lIVLOtherNotes4 = GF.LS.lIVLnotes1.Substring(150, 50)
                GF.LS.lIVLOtherNotes5 = GF.LS.lIVLnotes1.Substring(200, 50)
                GF.LS.lIVLOtherNotes6 = GF.LS.lIVLnotes1.Substring(250, 50)
                GF.LS.lIVLOtherNotes7 = GF.LS.lIVLnotes1.Substring(300, 50)
                GF.LS.lIVLOtherNotes8 = GF.LS.lIVLnotes1.Substring(350, 50)
                GF.LS.lIVLOtherNotes9 = GF.LS.lIVLnotes1.Substring(400, 50)
                GF.LS.lIVLOtherNotes10 = GF.LS.lIVLnotes1.Substring(450, GF.LS.lIVLnotes1.Length - 450)
            End If
            'additional action required
            If GF.LS.lIVLnotes4.Length <= 50 Then
                GF.LS.lIVLFollowUpNotes1 = GF.LS.lIVLnotes4.Substring(0, GF.LS.lIVLnotes4.Length)
            Else
                GF.LS.lIVLFollowUpNotes1 = GF.LS.lIVLnotes4.Substring(0, 50)
            End If
            If GF.LS.lIVLnotes4.Length > 50 And GF.LS.lIVLnotes4.Length <= 100 Then

                GF.LS.lIVLFollowUpNotes2 = GF.LS.lIVLnotes4.Substring(50, GF.LS.lIVLnotes4.Length - 50)
            Else
                If GF.LS.lIVLnotes4.Length > 100 Then
                    GF.LS.lIVLFollowUpNotes2 = GF.LS.lIVLnotes4.Substring(50, 50)
                End If
            End If
            If GF.LS.lIVLnotes4.Length > 100 And GF.LS.lIVLnotes4.Length <= 150 Then

                GF.LS.lIVLFollowUpNotes3 = GF.LS.lIVLnotes4.Substring(100, GF.LS.lIVLnotes4.Length - 100)
            Else
                If GF.LS.lIVLnotes4.Length > 150 Then
                    GF.LS.lIVLFollowUpNotes3 = GF.LS.lIVLnotes4.Substring(100, 50)
                End If
            End If
            If GF.LS.lIVLnotes4.Length > 150 And GF.LS.lIVLnotes4.Length <= 200 Then

                GF.LS.lIVLFollowUpNotes4 = GF.LS.lIVLnotes4.Substring(150, GF.LS.lIVLnotes4.Length - 150)
            Else
                If GF.LS.lIVLnotes4.Length > 200 Then
                    GF.LS.lIVLFollowUpNotes4 = GF.LS.lIVLnotes4.Substring(150, 50)
                End If
            End If
            If GF.LS.lIVLnotes4.Length > 200 And GF.LS.lIVLnotes4.Length <= 250 Then

                GF.LS.lIVLFollowUpNotes5 = GF.LS.lIVLnotes4.Substring(200, GF.LS.lIVLnotes4.Length - 200)
            End If


                If source.Equals("B") Then
                    If GF.LS.lIVLnotes1.ToString.Trim.Equals(String.Empty) Then
                        EditError = 1
                        ErrorMsg = "Please explain concern"
                        SetFocus("OBJTAR0001")
                    ElseIf GF.LS.lIVLcustomerIrate.ToString.Trim.Equals(String.Empty) Then
                        EditError = 1
                        ErrorMsg = "Select yes or no"
                        SetFocus("OBJRAD0004001")
                    ElseIf GF.LS.lIVLDNC.ToString.Trim.Equals(String.Empty) Then
                        EditError = 1
                        ErrorMsg = "Please select if Customer added to the Do Not Call list."
                        SetFocus("OBJRAD0001001")
                    ElseIf GF.LS.lIVLletter.ToString.Trim.Equals(String.Empty) Then
                        EditError = 1
                        ErrorMsg = "Please select if Customer requires letter."
                        SetFocus("OBJRAD0002001")
                    ElseIf GF.LS.lIVLSatisfied.ToString.Trim.Equals(String.Empty) Then
                        EditError = 1
                        ErrorMsg = "Please select if Customer was satisfied."
                        SetFocus("OBJRAD0003001")
                    ElseIf (GF.LS.lIVLSatisfied.ToString.Trim.Equals("N") And GF.LS.lIVLnotes4.ToString.Trim.Equals(String.Empty)) Then
                        EditError = 1
                        ErrorMsg = "Please explain what action is needed."
                        SetFocus("OBJTAR0002")
                    ElseIf GF.LS.lIVLnotes1.ToString.Trim.Length > 501 Then
                        EditError = 1
                        ErrorMsg = "Limit Customer's concern notes to 500 characters"
                        SetFocus("OBJTAR0001")
                    ElseIf GF.LS.lIVLnotes4.ToString.Trim.Length > 251 Then
                        EditError = 1
                        ErrorMsg = "Limit additional action notes to 250 characters"
                        SetFocus("OBJTAR0002")
                    ElseIf GF.LS.lIVLApp.ToString.Trim.Equals(String.Empty) Then
                        EditError = 1
                        ErrorMsg = "Please submit form"
                        SetFocus("OBJBTN0001")
                    Else
                        GF.NGS.SELECT111 = "Y"
                        Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                            Case "MBNACNFM", "MBNACNFS", "MBNACFSS"
                                EditError = 1
                                set_currPath(ScriptPaths.CONSUMER)
                            Case Else
                                EditError = 1
                                set_currPath(ScriptPaths.MBNA)
                        End Select
                    End If
                End If

                If Not SCRIPT0001.IsValid Then
                    DisplayError(SCRIPT0001.ErrorMessages())
                    EditError = 1
                    Exit Sub
                End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = True

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub


#End Region


Private Sub OBJRAD0002_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles OBJRAD0002.SelectedIndexChanged
        PanelEditAutoMapping()

        Select Case GF.LS.lIVLletter.ToString.Trim
            Case "N"
                OBJDIV0001.Visible = False
                SCRIPT0001.Address1Req = False
                SCRIPT0001.CityReq = False
                SCRIPT0001.StateReq = False
                SCRIPT0001.ZipReq = False
            Case "Y"
                OBJDIV0001.Visible = True
                SCRIPT0001.Address1Req = True
                SCRIPT0001.CityReq = True
                SCRIPT0001.StateReq = True
                SCRIPT0001.ZipReq = True
        End Select

        Select Case GF.LS.lIVLSatisfied.ToString.Trim
            Case "N"
                OBJDIV0002.Visible = True
            Case "Y"
                OBJDIV0002.Visible = False
        End Select

End Sub
Private Sub OBJRAD0003_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles OBJRAD0003.SelectedIndexChanged
        PanelEditAutoMapping()

        Select Case GF.LS.lIVLletter.ToString.Trim
            Case "N"
                OBJDIV0001.Visible = False
                SCRIPT0001.Address1Req = False
                SCRIPT0001.CityReq = False
                SCRIPT0001.StateReq = False
                SCRIPT0001.ZipReq = False
            Case "Y"
                OBJDIV0001.Visible = True
                SCRIPT0001.Address1Req = True
                SCRIPT0001.CityReq = True
                SCRIPT0001.StateReq = True
                SCRIPT0001.ZipReq = True
        End Select

        Select Case GF.LS.lIVLSatisfied.ToString.Trim
            Case "N"
                OBJDIV0002.Visible = True
            Case "Y"
                OBJDIV0002.Visible = False
        End Select

End Sub


    Private Sub OBJBTN0001_Click(sender As System.Object, e As System.EventArgs) Handles OBJBTN0001.Click
        Try
            'Code added by converter to duplicate button mapping in BW6
            GF.LS.lIVLApp = "Y"
            PageDown()
        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub






End Class
