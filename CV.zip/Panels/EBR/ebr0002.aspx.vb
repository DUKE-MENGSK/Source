﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class ebr0002
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJTXT0001.Text = GF.LS.lEBRFirstName
        OBJTXT0002.Text = GF.LS.lEBRLastName
        OBJTXT0003.Text = GF.LS.lEBRRefNumb
        OBJRAD0002.SelectedValue = GF.LS.lEBRTone
        OBJRAD0003.SelectedValue = GF.LS.lEBRComment
        OBJTAR0001.Text = GF.LS.lEBRNotes
        SCRIPT0001.PhoneNumber = GF.LS.lEBRPhone
        SCRIPT0001.AreaCode = GF.NGS.M_AREA_C
        SCRIPT0001.Prefix = GF.NGS.M_PHONE_3
        SCRIPT0001.Extension = GF.NGS.M_PHONE_4
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lEBRFirstName = OBJTXT0001.Text
        GF.LS.lEBRLastName = OBJTXT0002.Text
        GF.LS.lEBRRefNumb = OBJTXT0003.Text
        GF.LS.lEBRTone = OBJRAD0002.SelectedValue
        GF.LS.lEBRComment = OBJRAD0003.SelectedValue
        GF.LS.lEBRNotes = OBJTAR0001.Text
        GF.LS.lEBRPhone = SCRIPT0001.PhoneNumber
        GF.NGS.M_AREA_C = SCRIPT0001.AreaCode
        GF.NGS.M_PHONE_3 = SCRIPT0001.Prefix
        GF.NGS.M_PHONE_4 = SCRIPT0001.Extension
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            OBJTAR0001.Text = OBJTAR0001.Text & GF.LS.lEBRNotes
            SCRIPT0001.Prompt = "Customer Phone Number: "
            GF.LS.lEBRApp = String.Empty
            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg.Equals(String.Empty)

            PanelEditAutoMapping()

            'moves comment to smaller fields to help with output
            If GF.LS.lEBRNotes.Length <= 50 Then
                GF.LS.lEBRNotes1 = GF.LS.lEBRNotes.Substring(0, GF.LS.lEBRNotes.Length)
            Else
                GF.LS.lEBRNotes1 = GF.LS.lEBRNotes.Substring(0, 50)
            End If
            If GF.LS.lEBRNotes.Length > 50 And GF.LS.lEBRNotes.Length <= 100 Then

                GF.LS.lEBRNotes2 = GF.LS.lEBRNotes.Substring(50, GF.LS.lEBRNotes.Length - 50)
            Else
                If GF.LS.lEBRNotes.Length > 100 Then
                    GF.LS.lEBRNotes2 = GF.LS.lEBRNotes.Substring(50, 50)
                End If
            End If
            If GF.LS.lEBRNotes.Length > 100 And GF.LS.lEBRNotes.Length <= 150 Then

                GF.LS.lEBRNotes3 = GF.LS.lEBRNotes.Substring(100, GF.LS.lEBRNotes.Length - 100)
            Else
                If GF.LS.lEBRNotes.Length > 150 Then
                    GF.LS.lEBRNotes3 = GF.LS.lEBRNotes.Substring(100, 50)
                End If
            End If
            If GF.LS.lEBRNotes.Length > 150 Then
                GF.LS.lEBRNotes4 = GF.LS.lEBRNotes.Substring(150, GF.LS.lEBRNotes.Length - 150)
            End If
            

            'sets cust phone
            If Not GF.LS.lEBRPhone.ToString.Trim.Equals(String.Empty) Then
                GF.NGS.PHONE_NUM = GF.LS.lEBRPhone.ToString.Trim
            End If
            GF.NGS.M_FIRST_NAME = GF.LS.lEBRFirstName.ToString.Trim.ToUpper
            GF.NGS.M_LAST_NAME = GF.LS.lEBRLastName.ToString.Trim.ToUpper

            GF.LS.lFixedFieldXLF1 = GF.LS.lEBRFirstName.ToString.Trim & " " & GF.LS.lEBRLastName.ToString.Trim

            'MOVES REFERNCE NUMBER TO DATASTORE
            GF.NGS.CODE11_1 = GF.LS.lEBRRefNumb.ToString.Trim

            'SETS XLF FLAG TO A Y
            GF.NGS.LOGXTDAT = "Y"
            GF.LS.lXLFmain = "Y"

            If source.Equals("B") Then
                If GF.LS.lEBRFirstName.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please enter First Name"
                    SetFocus("OBJTXT0001")
                ElseIf GF.gfCheckFieldValidity(GF.NGS.M_FIRST_NAME.ToString.Trim, "^0-9A-Z ") Then
                    EditError = 1
                    ErrorMsg = "First name is invalid."
                    SetFocus("OBJTXT0001")
                ElseIf GF.LS.lEBRLastName.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please enter Last Name"
                    SetFocus("OBJTXT0002")
                ElseIf GF.gfCheckFieldValidity(GF.NGS.M_LAST_NAME.ToString.Trim, "^0-9A-Z ") Then
                    EditError = 1
                    ErrorMsg = "Last name is invalid."
                    SetFocus("OBJTXT0002")
                ElseIf Not IsNumeric(GF.LS.lEBRRefNumb.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Reference Number must be numeric"
                    SetFocus("OBJTXT0003")
                ElseIf GF.LS.lEBRTone.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please select Tone of Call"
                    SetFocus("OBJRAD0002001")
                ElseIf GF.LS.lEBRComment.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please select Tone of Call"
                    SetFocus("OBJRAD0003001")
                ElseIf GF.LS.lEBRNotes.ToString.Trim.Length > 201 Then
                    EditError = 1
                    ErrorMsg = "Limit Notes to 200 characters"
                    SetFocus("OBJTAR0001")

                ElseIf GF.LS.lEBRApp.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please submit form"
                    SetFocus("OBJBTN0001")
                End If
            End If

            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False
            nextpanel = Panels.EBR.EBR0004

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub


#End Region



    Private Sub OBJBTN0001_Click(sender As System.Object, e As System.EventArgs) Handles OBJBTN0001.Click
        Try
            'Code added by converter to duplicate button mapping in BW6
            GF.LS.lEBRApp = "Y"
            PageDown()
        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub






End Class
