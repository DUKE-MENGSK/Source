﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class manual0028
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0009.Text = GF.LS.lmailFname
        OBJLBL0010.Text = GF.LS.lmailLname
        OBJLBL0001.Text = GF.UPC.AgentInfo.fullname
        OBJLBL0005.Text = GF.LS.lTranDate
        OBJLBL0008.Text = GF.LS.lTranTime
        OBJLBL0002.Text = GF.LS.lName
        OBJLBL0011.Text = GF.LS.lclose
        OBJTXT0001.Text = GF.LS.lAgentFullName
        OBJTXT0002.Text = GF.LS.lcomment501
        OBJTXT0003.Text = GF.LS.lChkCity6
        OBJTXT0004.Text = GF.LS.lNum41Alpha
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lmailFname = OBJLBL0009.Text
        GF.LS.lmailLname = OBJLBL0010.Text
        GF.UPC.AgentInfo.fullname = OBJLBL0001.Text
        GF.LS.lTranDate = OBJLBL0005.Text
        GF.LS.lTranTime = OBJLBL0008.Text
        GF.LS.lName = OBJLBL0002.Text
        GF.LS.lclose = OBJLBL0011.Text
        GF.LS.lAgentFullName = OBJTXT0001.Text
        GF.LS.lcomment501 = OBJTXT0002.Text
        GF.LS.lChkCity6 = OBJTXT0003.Text
        GF.LS.lNum41Alpha = OBJTXT0004.Text
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            GF.LS.lTranDate = Format(Now, "MM/dd/yyyy")
            GF.LS.lTranTime = Format(Now, "HH:mm")
            GF.LS.lCODE51 = GF.LS.lTranTime.ToString.Trim
            GF.LS.lName = (GF.LS.lmailFname.ToString.Trim & " " & GF.LS.lmailLname.ToString.Trim)

            ''to pull actual country name for the rate issue manual
            ''lCountryName for secured file
            ''lCountry50 for xlf
            Dim y As Integer
            For y = 1 To GF.GetListRows("lCountryCodesNames")
                If Trim(GF.GetListData("lCountryCodesNames", y, 0)) = GF.LS.lCountryCitizenship.ToString.Trim Then
                    GF.LS.lDilCountryNamesState = GF.GetListData("lCountryCodesNames", y, 1)
                End If
            Next

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty
            PanelEditAutoMapping()

            If source.Equals("B") Then
                If GF.LS.lAgentFullName.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please enter CSR FullName"
                    SetFocus("OBJTXT0001")
                ElseIf GF.LS.lcomment501.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please enter Reason for manual application"
                    SetFocus("OBJTXT0002")
                ElseIf GF.LS.lChkCity6.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please enter Supervisor name"
                    SetFocus("OBJTXT0003")
                ElseIf CInt(GF.LS.lNum41Alpha).Equals(0) Then
                    EditError = 1
                    ErrorMsg = "Please enter Supervisor ID"
                    SetFocus("OBJTXT0004")
                ElseIf Not IsNumeric(GF.LS.lNum41Alpha.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please enter only numbers"
                    SetFocus("OBJTXT0004")
                Else
                    GF.LS.lNum41 = GF.LS.lNum41Alpha.ToString.Trim
                    GF.NGS.Init_Disp = "A000"
                    GF.NGS.Second_Disp = "A100"
                    GF.NGS.Third_Disp = "A1A0"
                    GF.NGS.Fourth_Disp = String.Empty
                    GF.NGS.Fifth_Disp = String.Empty
                    GF.NGS.Sixth_Disp = String.Empty
                    GF.NGS.Seventh_Disp = String.Empty
                    GF.NGS.Eighth_Disp = String.Empty
                    GF.NGS.NINTH_DISP = String.Empty
                    GF.NGS.SELECT36 = "Y"
                    GF.NGS.SECXTDAT = "Y"
                    GF.NGS.M_PROB_CALL_I = "O"
                    set_currPath(ScriptPaths.LOG)
                End If
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = True

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region









End Class
