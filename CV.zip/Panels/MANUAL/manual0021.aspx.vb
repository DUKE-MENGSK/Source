﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class manual0021
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJTXT0014.Text = GF.LS.lman21a
        OBJSEL0001.SelectedValue = GF.LS.lYear2
        OBJSEL0002.SelectedValue = GF.LS.lPOBoxUsed
        OBJSEL0003.SelectedValue = GF.LS.lSELECT44
        OBJSEL0004.SelectedValue = GF.LS.lManualOccupation
        If GF.LS.lRefusedBirth = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lRefusedBirth = "N" Then OBJCHK0001.Checked = False
        SCRIPT0001.ZipCode = GF.LS.lmailZip
        SCRIPT0001.Address1 = GF.LS.lmailAdd1
        SCRIPT0001.Address2 = GF.LS.lmailAdd2
        SCRIPT0001.City = GF.LS.lmailCity
        SCRIPT0001.State = GF.LS.lmailState
        SCRIPT0001.FirstName = GF.LS.lmailFname
        SCRIPT0001.LastName = GF.LS.lmailLname
        SCRIPT0001.MiddleInitial = GF.LS.lmailMname
        SCRIPT0002.ZipCode = GF.LS.lPhysicalZip
        SCRIPT0002.Address1 = GF.LS.lPhysicalAddress1
        SCRIPT0002.Address2 = GF.LS.lPhysicalAddress2
        SCRIPT0002.City = GF.LS.lPhysicalCity
        SCRIPT0002.State = GF.LS.lPhysicalState
        SCRIPT0003.PhoneNumber = GF.LS.lHomePhone
        SCRIPT0003.AreaCode = GF.LS.lmailAreaC
        SCRIPT0003.Prefix = GF.LS.lmailPhone3
        SCRIPT0003.Extension = GF.LS.lmailPhone4
        SCRIPT0004.Month = GF.LS.lmonth4
        SCRIPT0004.Day = GF.LS.lday4
        SCRIPT0004.Year = GF.LS.lyear4
        If GF.LS.lAge4 IsNot String.Empty Then
            SCRIPT0004.Age = CInt(GF.LS.lAge4)
        End If
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lman21a = OBJTXT0014.Text
        GF.LS.lYear2 = OBJSEL0001.SelectedValue
        GF.LS.lPOBoxUsed = OBJSEL0002.SelectedValue
        GF.LS.lSELECT44 = OBJSEL0003.SelectedValue
        GF.LS.lManualOccupation = OBJSEL0004.SelectedValue
        If OBJCHK0001.Checked Then GF.LS.lRefusedBirth = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lRefusedBirth = "N"
        GF.LS.lmailZip = SCRIPT0001.ZipCode
        GF.LS.lmailAdd1 = SCRIPT0001.Address1
        GF.LS.lmailAdd2 = SCRIPT0001.Address2
        GF.LS.lmailCity = SCRIPT0001.City
        GF.LS.lmailState = SCRIPT0001.State
        GF.LS.lmailFname = SCRIPT0001.FirstName
        GF.LS.lmailLname = SCRIPT0001.LastName
        GF.LS.lmailMname = SCRIPT0001.MiddleInitial
        GF.LS.lPhysicalZip = SCRIPT0002.ZipCode
        GF.LS.lPhysicalAddress1 = SCRIPT0002.Address1
        GF.LS.lPhysicalAddress2 = SCRIPT0002.Address2
        GF.LS.lPhysicalCity = SCRIPT0002.City
        GF.LS.lPhysicalState = SCRIPT0002.State
        GF.LS.lHomePhone = SCRIPT0003.PhoneNumber
        GF.LS.lmailAreaC = SCRIPT0003.AreaCode
        GF.LS.lmailPhone3 = SCRIPT0003.Prefix
        GF.LS.lmailPhone4 = SCRIPT0003.Extension
        GF.LS.lmonth4 = SCRIPT0004.Month
        GF.LS.lday4 = SCRIPT0004.Day
        GF.LS.lyear4 = SCRIPT0004.Year

        GF.LS.lAge4 = CStr(SCRIPT0004.Age)

        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            SCRIPT0003.PhoneRequired = False
            SCRIPT0003.Prompt = "Home Phone: "
            SCRIPT0004.MonthPrompt = "Date of Birth: "

            Select Case GF.LS.lPOBoxUsed.ToString.Trim
                Case "N"
                    OBJDIV0001.Visible = False
                Case "Y"
                    OBJDIV0001.Visible = True
            End Select
            SCRIPT0001.MiddleInitialReq = False
            SCRIPT0002.MiddleInitialReq = False
            SCRIPT0002.Address1Req = False
            SCRIPT0002.CityReq = False
            SCRIPT0002.StateReq = False
            SCRIPT0002.ZipReq = False

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source = "B" Then
                If CInt(GF.LS.lYear2).Equals(0) Then
                    EditError = 1
                    ErrorMsg = "Enter the Years at current address"
                    SetFocus("OBJSEL0001")
                ElseIf GF.LS.lPOBoxUsed.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "PO BOX Used is a required field"
                    SetFocus("OBJSEL0002")
                ElseIf GF.LS.lSELECT44.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please select Housing Information"
                    SetFocus("OBJSEL0003")
                ElseIf (CInt(GF.LS.lAge4) < 18 And GF.LS.lRefusedBirth.ToString.Trim.Equals("N")) Then
                    EditError = 1
                    ErrorMsg = "Customer must be 18 years of age to apply. Please check date."
                ElseIf GF.LS.lManualOccupation.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please select Occuption"
                    SetFocus("OBJSEL0004")
                ElseIf Not IsNumeric(GF.LS.lman21a.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please round upto nearest dollar. No commas or periods"
                    SetFocus("OBJTXT0014")
                Else
                    '20100603  cgossman  storing full DOB
                    '	call setData  ("LocalStore", "lDate3", getDatatrim ("LocalStore", "lmonth4") & getDatatrim ("LocalStore", "lday4") & getDatatrim ("LocalStore", "lyear4"))
                    Dim bdate As DateTime
                    If IsDate(GF.LS.lmonth4.ToString.Trim & "/" & GF.LS.lday4.ToString.Trim & "/" & GF.LS.lyear4.ToString.Trim) Then
                        bdate = GF.LS.lmonth4.ToString.Trim & "/" & GF.LS.lday4.ToString.Trim & "/" & GF.LS.lyear4.ToString.Trim
                        GF.LS.lDate3 = Format(bdate, "MMddyyyy")
                    Else
                        GF.LS.lDate3 = String.Empty
                    End If

                    GF.LS.lAmt4 = CInt(GF.LS.lman21a)
                    Select Case GF.LS.lManualOccupation.ToString.Trim
                        Case "A"
                            GF.LS.lNum21 = "97"
                        Case "B"
                            GF.LS.lNum21 = "10"
                        Case "C"
                            GF.LS.lNum21 = "60"
                        Case "D"
                            GF.LS.lNum21 = "20"
                        Case "E"
                            GF.LS.lNum21 = "99"
                        Case "F"
                            GF.LS.lNum21 = "98"
                        Case Else
                    End Select
                End If
            End If
            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0002.IsValid Then
                DisplayError(SCRIPT0002.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0003.IsValid Then
                DisplayError(SCRIPT0003.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

            If Not SCRIPT0004.IsValid Then
                DisplayError(SCRIPT0004.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False

            If CInt(GF.LS.lAge4) >= 18 Or GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
                Select Case GF.LS.lManualOccupation
                    Case "A"
                        nextPanel = Panels.MANUAL.manual0027
                    Case "B"
                        nextPanel = Panels.MANUAL.manual0022
                    Case "C"
                        nextPanel = Panels.MANUAL.manual0059
                    Case "D"
                        nextPanel = Panels.MANUAL.manual0057
                    Case "E"
                        nextPanel = Panels.MANUAL.manual0025
                    Case "F"
                        nextPanel = Panels.MANUAL.manual0054
                    Case Else
                        endOfPath = True
                End Select
            Else
                endOfPath = True
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

Private Sub OBJCHK0001_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0001.CheckedChanged
        PanelEditAutoMapping()

        If GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
            SCRIPT0004.Required = False
            GF.LS.lmonth4 = String.Empty
            GF.LS.lday4 = String.Empty
            GF.LS.lyear4 = String.Empty
            GF.LS.lDate3 = "00000000"
            GF.LS.lAge4 = "0"
        Else
            GF.LS.lDate3 = GF.LS.lmonth4.ToString.Trim & GF.LS.lday4.ToString.Trim & GF.LS.lyear4.ToString.Trim
        End If

End Sub

Private Sub OBJSEL0002_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles OBJSEL0002.SelectedIndexChanged
        PanelEditAutoMapping()
        Select Case GF.LS.lPOBoxUsed.ToString.Trim
            Case "N"
                OBJDIV0001.Visible = False
            Case "Y"
                OBJDIV0001.Visible = True
        End Select

        If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
            SCRIPT0002.Address1Req = True
            SCRIPT0002.CityReq = True
            SCRIPT0002.StateReq = True
            SCRIPT0002.ZipReq = True
        End If

End Sub


End Class
