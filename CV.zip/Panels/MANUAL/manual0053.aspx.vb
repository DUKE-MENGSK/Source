﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class manual0053
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJTXT0001.Text = GF.LS.lPromo1D
        OBJTXT0002.Text = GF.LS.lPromo1C
        OBJTXT0003.Text = GF.LS.lPromo1Duration
        OBJTXT0004.Text = GF.LS.lPromo2D
        OBJTXT0005.Text = GF.LS.lPromo2C
        OBJTXT0006.Text = GF.LS.lPromo2Duration
        OBJTXT0007.Text = GF.LS.lContractRate
        OBJSEL0001.SelectedValue = GF.LS.lPromo1EndDate
        OBJSEL0002.SelectedValue = GF.LS.lPromo2EndDate
        If GF.LS.lPromo1Retail = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lPromo1Retail = "N" Then OBJCHK0001.Checked = False
        If GF.LS.lPromo1Checks = "Y" Then OBJCHK0002.Checked = True
        If GF.LS.lPromo1Checks = "N" Then OBJCHK0002.Checked = False
        If GF.LS.lPromo1BT = "Y" Then OBJCHK0003.Checked = True
        If GF.LS.lPromo1BT = "N" Then OBJCHK0003.Checked = False
        If GF.LS.lPromo1DirectDeposits = "Y" Then OBJCHK0004.Checked = True
        If GF.LS.lPromo1DirectDeposits = "N" Then OBJCHK0004.Checked = False
        If GF.LS.lPromo1BankATMcash = "Y" Then OBJCHK0005.Checked = True
        If GF.LS.lPromo1BankATMcash = "N" Then OBJCHK0005.Checked = False
        If GF.LS.lPromo2Retail = "Y" Then OBJCHK0006.Checked = True
        If GF.LS.lPromo2Retail = "N" Then OBJCHK0006.Checked = False
        If GF.LS.lPromo2Checks = "Y" Then OBJCHK0007.Checked = True
        If GF.LS.lPromo2Checks = "N" Then OBJCHK0007.Checked = False
        If GF.LS.lPromo2BT = "Y" Then OBJCHK0008.Checked = True
        If GF.LS.lPromo2BT = "N" Then OBJCHK0008.Checked = False
        If GF.LS.lPromo2DirectDeposits = "Y" Then OBJCHK0009.Checked = True
        If GF.LS.lPromo2DirectDeposits = "N" Then OBJCHK0009.Checked = False
        If GF.LS.lPromo2BankATMcash = "Y" Then OBJCHK0010.Checked = True
        If GF.LS.lPromo2BankATMcash = "N" Then OBJCHK0010.Checked = False
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lPromo1D = OBJTXT0001.Text
        GF.LS.lPromo1C = OBJTXT0002.Text
        GF.LS.lPromo1Duration = OBJTXT0003.Text
        GF.LS.lPromo2D = OBJTXT0004.Text
        GF.LS.lPromo2C = OBJTXT0005.Text
        GF.LS.lPromo2Duration = OBJTXT0006.Text
        GF.LS.lContractRate = OBJTXT0007.Text
        GF.LS.lPromo1EndDate = OBJSEL0001.SelectedValue
        GF.LS.lPromo2EndDate = OBJSEL0002.SelectedValue
        If OBJCHK0001.Checked Then GF.LS.lPromo1Retail = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lPromo1Retail = "N"
        If OBJCHK0002.Checked Then GF.LS.lPromo1Checks = "Y"
        If Not OBJCHK0002.Checked Then GF.LS.lPromo1Checks = "N"
        If OBJCHK0003.Checked Then GF.LS.lPromo1BT = "Y"
        If Not OBJCHK0003.Checked Then GF.LS.lPromo1BT = "N"
        If OBJCHK0004.Checked Then GF.LS.lPromo1DirectDeposits = "Y"
        If Not OBJCHK0004.Checked Then GF.LS.lPromo1DirectDeposits = "N"
        If OBJCHK0005.Checked Then GF.LS.lPromo1BankATMcash = "Y"
        If Not OBJCHK0005.Checked Then GF.LS.lPromo1BankATMcash = "N"
        If OBJCHK0006.Checked Then GF.LS.lPromo2Retail = "Y"
        If Not OBJCHK0006.Checked Then GF.LS.lPromo2Retail = "N"
        If OBJCHK0007.Checked Then GF.LS.lPromo2Checks = "Y"
        If Not OBJCHK0007.Checked Then GF.LS.lPromo2Checks = "N"
        If OBJCHK0008.Checked Then GF.LS.lPromo2BT = "Y"
        If Not OBJCHK0008.Checked Then GF.LS.lPromo2BT = "N"
        If OBJCHK0009.Checked Then GF.LS.lPromo2DirectDeposits = "Y"
        If Not OBJCHK0009.Checked Then GF.LS.lPromo2DirectDeposits = "N"
        If OBJCHK0010.Checked Then GF.LS.lPromo2BankATMcash = "Y"
        If Not OBJCHK0010.Checked Then GF.LS.lPromo2BankATMcash = "N"
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            GF.LS.lPromo1Rate = "00.00"
            GF.LS.lPromo2Rate = "00.00"

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source.Equals("B") Then

                If IsNumeric(GF.LS.lPromo1D.ToString.Trim) AndAlso IsNumeric(GF.LS.lPromo1C.ToString.Trim) Then
                    GF.LS.lPromo1Rate = CInt(GF.LS.lPromo1D) & "." & CInt(GF.LS.lPromo1C)
                Else
                    GF.LS.lPromo1D = String.Empty
                    GF.LS.lPromo1C = String.Empty
                    EditError = 1
                    ErrorMsg = "Please enter currency only"
                    SetFocus("OBJTXT0001")
                End If

                If IsNumeric(GF.LS.lPromo2D.ToString.Trim) AndAlso IsNumeric(GF.LS.lPromo2C.ToString.Trim) Then
                    GF.LS.lPromo2Rate = CInt(GF.LS.lPromo2D) & "." & CInt(GF.LS.lPromo2C)
                Else
                    GF.LS.lPromo2D = "00"
                    GF.LS.lPromo2C = String.Empty
                    EditError = 1
                    ErrorMsg = "Please enter currency only"
                    SetFocus("OBJTXT0004")
                End If
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False
            nextPanel = Panels.MANUAL.manual0021

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region









End Class
