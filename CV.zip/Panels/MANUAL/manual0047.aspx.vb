﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class manual0047
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0002.Text = GF.LS.lmailFname
        OBJLBL0003.Text = GF.LS.lmailLname
        OBJLBL0001.Text = GF.LS.lDisplayTotalIncome
        OBJTXT0001.Text = GF.LS.lCardName1
        OBJTXT0002.Text = GF.LS.lCardName2
        OBJTXT0005.Text = GF.LS.lmanual36a
        OBJTXT0003.Text = GF.LS.lman36a
        OBJTXT0006.Text = GF.LS.lCardName4
        OBJSEL0002.SelectedValue = GF.LS.lSELECT50
        OBJSEL0012.SelectedValue = GF.LS.lHoursStudents
        If GF.LS.lEmpRefused = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lEmpRefused = "N" Then OBJCHK0001.Checked = False
        If GF.LS.lRefusedEmp = "Y" Then OBJCHK0002.Checked = True
        If GF.LS.lRefusedEmp = "N" Then OBJCHK0002.Checked = False
        SCRIPT0002.ZipCode = GF.LS.lCRZip2
        SCRIPT0002.Address1 = GF.LS.lHomeAdd
        SCRIPT0002.Address2 = GF.LS.lHomeAdd1
        SCRIPT0002.City = GF.LS.lSchoolCity
        SCRIPT0002.State = GF.LS.lState2
        SCRIPT0001.PhoneNumber = GF.LS.lEmpPhone
        SCRIPT0001.AreaCode = GF.LS.lEmpAreaC
        SCRIPT0001.Prefix = GF.LS.lEmpPhone3
        SCRIPT0001.Extension = GF.LS.lEmpPhone4
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lmailFname = OBJLBL0002.Text
        GF.LS.lmailLname = OBJLBL0003.Text
        GF.LS.lDisplayTotalIncome = OBJLBL0001.Text
        GF.LS.lCardName1 = OBJTXT0001.Text
        GF.LS.lCardName2 = OBJTXT0002.Text
        GF.LS.lmanual36a = OBJTXT0005.Text
        GF.LS.lman36a = OBJTXT0003.Text
        GF.LS.lCardName4 = OBJTXT0006.Text
        GF.LS.lSELECT50 = OBJSEL0002.SelectedValue
        GF.LS.lHoursStudents = OBJSEL0012.SelectedValue
        If OBJCHK0001.Checked Then GF.LS.lEmpRefused = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lEmpRefused = "N"
        If OBJCHK0002.Checked Then GF.LS.lRefusedEmp = "Y"
        If Not OBJCHK0002.Checked Then GF.LS.lRefusedEmp = "N"
        GF.LS.lCRZip2 = SCRIPT0002.ZipCode
        GF.LS.lHomeAdd = SCRIPT0002.Address1
        GF.LS.lHomeAdd1 = SCRIPT0002.Address2
        GF.LS.lSchoolCity = SCRIPT0002.City
        GF.LS.lState2 = SCRIPT0002.State
        GF.LS.lEmpPhone = SCRIPT0001.PhoneNumber
        GF.LS.lEmpAreaC = SCRIPT0001.AreaCode
        GF.LS.lEmpPhone3 = SCRIPT0001.Prefix
        GF.LS.lEmpPhone4 = SCRIPT0001.Extension
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            SCRIPT0001.Prompt = "Work Phone Number: "
            'If GF.LS.lSELECT50.ToString.Trim.Equals("D") Then
            OBJDIV0001.Visible = True
            'Else
            'OBJDIV0001.Visible = False
            'End If
            If GF.LS.lDisplayTotalIncome IsNot String.Empty Then
                GF.gfCalcIncome6()
                OBJLBL0001.Text = GF.LS.lDisplayTotalIncome

            End If
            SCRIPT0002.MiddleInitialReq = False
            WindowOnLoadAutoMapping()
        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()
            'College/University
            GF.LS.lCardName1 = GF.LS.lCardName1.ToString.Trim.ToUpper
            'Major
            GF.LS.lCardName2 = GF.LS.lCardName2.ToString.Trim.ToUpper
            'Income Source
            GF.LS.lCardName4 = GF.LS.lCardName4.ToString.Trim.ToUpper

            '---------------------
            'street adress1
            GF.LS.lHomeAdd = GF.LS.lHomeAdd.ToString.Trim.ToUpper
            'street adress 2
            GF.LS.lHomeAdd1 = GF.LS.lHomeAdd1.ToString.Trim.ToUpper
            'product city
            GF.LS.lSchoolCity = GF.LS.lSchoolCity.ToString.Trim.ToUpper
            'program state
            GF.LS.lState2 = GF.LS.lState2.ToString.Trim.ToUpper

            If source.Equals("B") Then
                If Not IsNumeric(GF.LS.lmanual36a.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please enter 2 digit nuber for year"
                    SetFocus("OBJTXT0005")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lCardName1.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "College Name invalid. No special characters."
                    SetFocus("OBJTXT0001")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lCardName2.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Major invalid. No special characters."
                    SetFocus("OBJTXT0002")
                ElseIf (GF.LS.lman36a.ToString.Trim.Equals(String.Empty) And GF.LS.lEmpRefused.ToString.Trim.Equals("N")) Then
                    EditError = 1
                    ErrorMsg = "Enter in Salary amount or Check Refused"
                    SetFocus("OBJTXT0003")
                ElseIf (GF.LS.lCardName4.ToString.Trim.Equals(String.Empty) And GF.LS.lRefusedEmp.ToString.Trim.Equals("N")) Then
                    EditError = 1
                    ErrorMsg = "Enter in Income Source or Check Refused"
                    SetFocus("OBJTXT0006")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lCardName4.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Income Source invalid. No special characters."
                    SetFocus("OBJTXT0006")
                ElseIf (Not GF.LS.lCardName4.ToString.Trim.Equals("REFUSED") And Not GF.LS.lCardName4.ToString.Trim.Equals(String.Empty) And GF.LS.lRefusedEmp.ToString.Trim.Equals("Y")) Then
                    EditError = 1
                    ErrorMsg = "Enter in Income Source or Check Refused not both"
                    SetFocus("OBJTXT0006")

                ElseIf GF.LS.lSELECT50.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Select Frequency"
                    SetFocus("OBJSEL0002")
                ElseIf (GF.LS.lSELECT50.ToString.Trim.Equals("D") And CInt(GF.LS.lHoursStudents).Equals(0)) Then
                    EditError = 1
                    ErrorMsg = "Please enter Hours worked"
                    SetFocus("OBJSEL0012")
                ElseIf Not IsNumeric(GF.LS.lman36a.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please enter currency only"
                    SetFocus("OBJTXT0003")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lHomeAdd.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Address1 invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address1
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lHomeAdd.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Address2 invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address2
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lSchoolCity.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "City invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.City
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lState2.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "State invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.State
                ElseIf GF.LS.lAnnualSalary.ToString.Trim.Length > 7 Then
                    EditError = 1
                    ErrorMsg = "Annual Salary exceeds 7 digits"
                    SetFocus("OBJTXT0003")
                Else
                    GF.LS.lSalary = CInt(GF.LS.lman36a)
                    If GF.LS.lHoursStudents.ToString.Trim.Equals(String.Empty) Then
                        GF.LS.lHoursStudents = 0
                    End If
                    GF.LS.lCCExpd1 = ("20" & GF.LS.lmanual36a.ToString.Trim)
                    GF.LS.lYears6 = CInt(GF.LS.lmanual36a)
                End If
            End If
            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0002.IsValid Then
                DisplayError(SCRIPT0002.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False
            nextPanel = Panels.MANUAL.manual0048

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

    Private Sub OBJCHK0001_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJCHK0001.CheckedChanged
        PanelEditAutoMapping()
               
        If GF.LS.lEmpRefused.ToString.Trim.Equals("Y") Then
            GF.LS.lSalary = 0
            GF.LS.lman36a = String.Empty
            GF.LS.lHoursStudents = 0
            GF.LS.lSELECT50 = String.Empty
            OBJTXT0003.Text = String.Empty
            OBJSEL0002.Text = String.Empty
        End If
        

    End Sub
    Private Sub OBJCHK0002_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJCHK0002.CheckedChanged
        PanelEditAutoMapping()
       
        If GF.LS.lRefusedEmp.ToString.Trim.Equals("Y") Then
            GF.LS.lCardName4 = "REFUSED"
            OBJTXT0006.Text = "REFUSED"
        End If



    End Sub
    Private Sub OBJSEL0002_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0002.SelectedIndexChanged
        PanelEditAutoMapping()

        If GF.LS.lSELECT50.ToString.Trim.Equals("D") Then
            OBJDIV0001.Visible = True
        Else
            OBJDIV0001.Visible = False
        End If

        GF.LS.lSalary = CInt(GF.LS.lman36a)
        
        '
        GF.gfCalcIncome6()
        OBJLBL0001.Text = GF.LS.lDisplayTotalIncome
        'PanelEditAutoMapping()

    End Sub
 


    Private Sub OBJTXT0003_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJTXT0003.TextChanged, OBJSEL0012.SelectedIndexChanged
        PanelEditAutoMapping()
        GF.LS.lSalary = CInt(GF.LS.lman36a)
        GF.gfCalcIncome6()
        OBJLBL0001.Text = GF.LS.lDisplayTotalIncome
    End Sub
End Class
