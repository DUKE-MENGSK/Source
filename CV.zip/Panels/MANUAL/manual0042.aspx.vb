﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class manual0042
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJSEL0001.SelectedValue = GF.LS.lManualOccupation
        OBJSEL0002.SelectedValue = GF.LS.lEmployed
        OBJSEL0003.SelectedValue = GF.LS.lNum21
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lManualOccupation = OBJSEL0001.SelectedValue
        GF.LS.lEmployed = OBJSEL0002.SelectedValue
        GF.LS.lNum21 = OBJSEL0003.SelectedValue
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            GF.LS.lManualOccupation = String.Empty
            GF.LS.lEmployed = String.Empty
            GF.LS.lNum21 = String.Empty
            OBJTID0001.Text = String.Empty
            OBJSEL0002.Visible = False

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source.Equals("B") Then
                If GF.LS.lManualOccupation.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please select Occuption"
                    SetFocus("OBJSEL0001")
                ElseIf (GF.LS.lManualOccupation.ToString.Trim.Equals("F") And GF.LS.lEmployed.ToString.Trim.Equals(String.Empty)) Then
                    EditError = 1
                    ErrorMsg = "Please select Employment Type"
                    SetFocus("OBJSEL0002")
                ElseIf CInt(GF.LS.lNum21).Equals(0) Then
                    EditError = 1
                    ErrorMsg = "Please select Occuption Type"
                    SetFocus("OBJSEL0003")
                Else
                    'moves lManualOccupation to lSELECT54 to log in secured file
                    'for Kent to branch off of type of app
                    GF.LS.lSELECT54 = GF.LS.lManualOccupation.ToString.Trim
                End If
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False
            Select Case GF.LS.lManualOccupation.ToString.Trim
                Case "B" 'retired
                    nextPanel = Panels.MANUAL.manual0034
                Case "C"  'Self-Employed
                    nextPanel = Panels.MANUAL.manual0035
                Case "D"  'STUDENT
                    nextPanel = Panels.MANUAL.manual0047
                Case "E"  'UNEMPLOYED
                    nextPanel = Panels.MANUAL.manual0037
                Case "F"  'EMPLOYED
                    nextPanel = Panels.MANUAL.manual0038
                Case Else
                    endOfPath = True
            End Select

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

    Private Sub OBJSEL0001_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0001.SelectedIndexChanged, OBJSEL0002.SelectedIndexChanged
        PanelEditAutoMapping()

        If GF.LS.lManualOccupation.ToString.Trim.Equals("F") Then
            OBJTID0001.Text = "Employed How:"
            OBJSEL0002.Visible = True
        Else
            OBJTID0001.Text = String.Empty
            OBJSEL0002.Visible = False
        End If

        'Dim temp As String = GF.LS.lManualOccupation.ToString.Trim & GF.LS.lEmployed.ToString.Trim
        'Dim x As Integer = 1
        'Dim y As Integer
        'Dim z As Integer = 0



        Select Case GF.LS.lManualOccupation.ToString.Trim
            Case "B" ', "C", "D", "E"
                OBJSEL0003.Items.Clear()
                OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                OBJSEL0003.Items.Add(New ListItem("21-Retired", 21))

            Case "C"
                OBJSEL0003.Items.Clear()
                OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                OBJSEL0003.Items.Add(New ListItem("60-Non-Profit Business Owner", 60))
                OBJSEL0003.Items.Add(New ListItem("61-Farmer Rancher", 61))
                OBJSEL0003.Items.Add(New ListItem("62-Retail Business owner", 62))
                OBJSEL0003.Items.Add(New ListItem("63-Consultant/Professional Business Owner", 63))
                OBJSEL0003.Items.Add(New ListItem("65-Actor/Musician/Artist", 65))
                OBJSEL0003.Items.Add(New ListItem("66-Mechanic/Skilled Trade Owner", 66))
                OBJSEL0003.Items.Add(New ListItem("67-Self-Employed/Other", 67))
            Case "D"

                OBJSEL0003.Items.Clear()
                OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                OBJSEL0003.Items.Add(New ListItem("20-College Freshman", 20))
                OBJSEL0003.Items.Add(New ListItem("21-College Sophomore", 21))
                OBJSEL0003.Items.Add(New ListItem("22-College Junior", 22))
                OBJSEL0003.Items.Add(New ListItem("24-Gradute Student", 24))
                OBJSEL0003.Items.Add(New ListItem("25-Student Other", 25))
                OBJSEL0003.Items.Add(New ListItem("26-Trade School Student", 26))
                OBJSEL0003.Items.Add(New ListItem("27-Non Traditional Student", 27))
            Case "E"

                OBJSEL0003.Items.Clear()
                OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                OBJSEL0003.Items.Add(New ListItem("91-Homemaker", 91))
                OBJSEL0003.Items.Add(New ListItem("99-Unemployed", 99))
            Case "F"
                'OBJSEL0003.Items.Clear()
                'OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                Select Case GF.LS.lEmployed.ToString.Trim
                    Case "A"
                        OBJSEL0003.Items.Clear()
                        OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                        OBJSEL0003.Items.Add(New ListItem("31-School Administrator", 31))
                        OBJSEL0003.Items.Add(New ListItem("39-School Counselor", 39))
                    Case "B"
                        OBJSEL0003.Items.Clear()
                        OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                        OBJSEL0003.Items.Add(New ListItem("40-Doctor/Intern/Resident", 40))
                        OBJSEL0003.Items.Add(New ListItem("42-Dentist", 42))
                        OBJSEL0003.Items.Add(New ListItem("43-STUDENT Dentist", 43))
                        OBJSEL0003.Items.Add(New ListItem("44-Engineer", 44))
                        OBJSEL0003.Items.Add(New ListItem("45-Lawyer/Judge", 45))
                        OBJSEL0003.Items.Add(New ListItem("46-Law STUDENT", 46))
                        OBJSEL0003.Items.Add(New ListItem("49-Peferred Professional Other", 49))

                    Case "C"
                        OBJSEL0003.Items.Clear()
                        OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                        OBJSEL0003.Items.Add(New ListItem("50-RN-Registerd Nurse", 50))

                    Case "D"
                        OBJSEL0003.Items.Clear()
                        OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                        OBJSEL0003.Items.Add(New ListItem("51-Architect", 51))
                        OBJSEL0003.Items.Add(New ListItem("52-Account (CPA)", 52))
                        OBJSEL0003.Items.Add(New ListItem("53-Manager, CEO, VP", 53))
                        OBJSEL0003.Items.Add(New ListItem("54-Professional Sales", 54))
                        OBJSEL0003.Items.Add(New ListItem("55-Airline Pilot", 55))

                        OBJSEL0003.Items.Add(New ListItem("56-Social Worker", 56))
                        OBJSEL0003.Items.Add(New ListItem("59-Programmer/Analyst/Other", 59))

                    Case "E"
                        OBJSEL0003.Items.Clear()
                        OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                        OBJSEL0003.Items.Add(New ListItem("70-Mechanic", 70))
                        OBJSEL0003.Items.Add(New ListItem("72-LPN/Medic Tech", 72))
                        OBJSEL0003.Items.Add(New ListItem("73-Police/Fireman", 73))
                        OBJSEL0003.Items.Add(New ListItem("74-Clergy", 74))
                        OBJSEL0003.Items.Add(New ListItem("79-Manager/Other Skilled Labor", 79))
                    Case "F"
                        OBJSEL0003.Items.Clear()
                        OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                        OBJSEL0003.Items.Add(New ListItem("80-Unskilled Labor", 80))
                    Case "G"
                        OBJSEL0003.Items.Clear()
                        OBJSEL0003.Items.Add(New ListItem("Make a Selection", 0))
                        OBJSEL0003.Items.Add(New ListItem("92-Military Enlisted", 92))
                        OBJSEL0003.Items.Add(New ListItem("93-Military Officer", 93))

                        OBJSEL0003.Items.Add(New ListItem("40-Military Doctor/Intern/Resident", 40))
                        OBJSEL0003.Items.Add(New ListItem("42-Military Dentist", 42))
                        OBJSEL0003.Items.Add(New ListItem("45-Military Lawyer/Judge", 45))
                        OBJSEL0003.Items.Add(New ListItem("50-MilitaryRN-Registered Nurse", 50))



                End Select



                'For y = 1 To GF.GetListRows("lOccCodes")
                '    If Trim(GetListData("lOccCodes", y, 2)) = GF.LS.lManualOccupation.ToString.Trim Then
                '        Dim aSelectOption As ListItem = New ListItem(GetListData("lOccCodes", y, 0), GetListData("lOccCodes", y, 1))
                '        OBJSEL0003.Items.Add(aSelectOption)
                '        z = z + 1
                '    End If
                'Next
                'Case "F"
                '    For y = 1 To GF.GetListRows("lOccCodes")
                '        If Trim(GetListData("lOccCodes", y, 2)) = GF.LS.lManualOccupation.ToString.Trim And Trim(GetListData("lOccCodes", y, 3)) = GF.LS.lEmployed.ToString.Trim Then
                '            Dim aSelectOption As ListItem = New ListItem(GetListData("lOccCodes", y, 0), GetListData("lOccCodes", y, 1))
                '            OBJSEL0003.Items.Add(aSelectOption)
                '            z = z + 1
                '        End If
                '    Next

        End Select
        PanelEditAutoMapping()

        WindowOnLoadAutoMapping()

    End Sub








End Class
