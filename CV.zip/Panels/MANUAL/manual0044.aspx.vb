﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class manual0044
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0001.Text = GF.LS.lman30a
        OBJTXT0002.Text = GF.LS.lSourceCode2
        OBJTXT0011.Text = GF.LS.lAcctType
        OBJTXT0012.Text = GF.LS.lAssocBank
        OBJTXT0007.Text = GF.LS.lProdOfrCd
        OBJTXT0010.Text = GF.LS.lCode30
        OBJSEL0003.SelectedValue = GF.LS.lSELECT42
        OBJSEL0004.SelectedValue = GF.LS.lSELECT41
        OBJSEL0005.SelectedValue = GF.LS.lSELECT41
        OBJSEL0006.SelectedValue = GF.LS.lSELECT41
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lman30a = OBJLBL0001.Text
        GF.LS.lSourceCode2 = OBJTXT0002.Text
        GF.LS.lAcctType = OBJTXT0011.Text
        GF.LS.lAssocBank = OBJTXT0012.Text
        GF.LS.lProdOfrCd = OBJTXT0007.Text
        GF.LS.lCode30 = OBJTXT0010.Text
        GF.LS.lSELECT42 = OBJSEL0003.SelectedValue
        GF.LS.lSELECT41 = OBJSEL0004.SelectedValue
        GF.LS.lSELECT41 = OBJSEL0005.SelectedValue
        GF.LS.lSELECT41 = OBJSEL0006.SelectedValue
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            'call setData  ("LocalStore", "lman30a", getDatatrim ("LocalStore", "lReference") )

            Select Case GF.LS.lSELECT42
                Case "V"
                    OBJDIV0001.Visible = True
                    OBJDIV0002.Visible = False
                    OBJDIV0003.Visible = False
                Case "M"
                    OBJDIV0001.Visible = False
                    OBJDIV0002.Visible = True
                    OBJDIV0003.Visible = False
                Case "A"
                    OBJDIV0001.Visible = False
                    OBJDIV0002.Visible = False
                    OBJDIV0003.Visible = True
                Case Else
            End Select

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            ''SOURCE CODE
            GF.LS.lSourceCode2 = GF.LS.lSourceCode2.ToString.Trim.ToUpper
            ''account type
            GF.LS.lAcctType = GF.LS.lAcctType.ToString.Trim.ToUpper
            ''product code
            GF.LS.lProdOfrCd = GF.LS.lProdOfrCd.ToString.Trim.ToUpper
            ''program name
            GF.LS.lCode30 = GF.LS.lCode30.ToString.Trim.ToUpper

            If source.Equals("B") Then
                If GF.LS.lSourceCode2.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please enter Source code"
                    SetFocus("OBJTXT0002")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lSourceCode2.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Source Code invalid. No special characters."
                    SetFocus("OBJTXT0002")
                ElseIf (GF.LS.lSourceCode2.ToString.Trim.Length <> 4 And GF.LS.lSourceCode2.ToString.Trim.Length <> 6) Then
                    EditError = 1
                    ErrorMsg = "Enter all 4 or 6 digits of the Source Code"
                    SetFocus("OBJTXT0002")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lAcctType.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Account Type invalid. No special characters."
                    SetFocus("OBJTXT0011")
                ElseIf Not IsNumeric(GF.LS.lAssocBank.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Associate Bank Number must be numeric"
                    SetFocus("OBJTXT0012")
                ElseIf GF.LS.lProdOfrCd.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please enter the Product Offer Code"
                    SetFocus("OBJTXT0007")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lProdOfrCd.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Product Offer Code invalid. No special characters."
                    SetFocus("OBJTXT0007")
                ElseIf GF.LS.lCode30.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Enter a Group Name"
                    SetFocus("OBJTXT0010")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lCode30.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Group Name invalid. No special characters."
                    SetFocus("OBJTXT0010")
                ElseIf GF.LS.lSELECT42.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Choose MasterCard, Visa or American Express"
                    SetFocus("OBJSEL0003")
                ElseIf GF.LS.lSELECT41.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Select Card Type"
                    Select Case GF.LS.lSELECT42.ToString.Trim
                        Case "V"
                            SetFocus("OBJSEL0004")
                        Case "M"
                            SetFocus("OBJSEL0005")
                        Case "A"
                            SetFocus("OBJSEL0006")
                        Case Else
                    End Select
                End If
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False

            If GF.LS.lErrorCust.ToString.Trim.Equals("Y") Then
                nextPanel = Panels.MANUAL.manual0046
            Else
                nextPanel = Panels.MANUAL.manual0049
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

    Private Sub OBJSEL0003_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0003.SelectedIndexChanged
        PanelEditAutoMapping()

                    Select GF.LS.lSELECT42
            Case "V"
                OBJDIV0001.Visible = True
                OBJDIV0002.Visible = False
                OBJDIV0003.Visible = False
            Case "M"
                OBJDIV0001.Visible = False
                OBJDIV0002.Visible = True
                OBJDIV0003.Visible = False
            Case "A"
                OBJDIV0001.Visible = False
                OBJDIV0002.Visible = False
                OBJDIV0003.Visible = True
            Case Else
        End Select

    End Sub
End Class
