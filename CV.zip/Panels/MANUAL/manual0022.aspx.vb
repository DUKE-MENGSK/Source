﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class manual0022
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0002.Text = GF.LS.lmailFname
        OBJLBL0003.Text = GF.LS.lmailLname
        OBJLBL0001.Text = GF.LS.lAnnualSalary
        OBJTXT0001.Text = GF.LS.lChkCity1
        OBJTXT0002.Text = GF.LS.lChkCity2
        OBJTXT0003.Text = GF.LS.lman22a
        OBJTXT0004.Text = GF.LS.lCode202
        OBJTXT0005.Text = GF.LS.lCode203
        OBJTXT0006.Text = GF.LS.lman22b
        OBJSEL0002.SelectedValue = GF.LS.lPensionFrequency
        OBJSEL0003.SelectedValue = GF.LS.lPensionYearsEmp
        OBJSEL0004.SelectedValue = GF.LS.lSELECT46
        OBJSEL0005.SelectedValue = GF.LS.lYears3
        OBJSEL0006.SelectedValue = GF.LS.lSELECT45
        OBJSEL0007.SelectedValue = GF.LS.lHours
        If GF.LS.lPensionRefused = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lPensionRefused = "N" Then OBJCHK0001.Checked = False
        If GF.LS.lEmpRefused = "Y" Then OBJCHK0002.Checked = True
        If GF.LS.lEmpRefused = "N" Then OBJCHK0002.Checked = False
        SCRIPT0001.PhoneNumber = GF.LS.lEmpPhone
        SCRIPT0001.AreaCode = GF.LS.lEmpAreaC
        SCRIPT0001.Prefix = GF.LS.lEmpPhone3
        SCRIPT0001.Extension = GF.LS.lEmpPhone4
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lmailFname = OBJLBL0002.Text
        GF.LS.lmailLname = OBJLBL0003.Text
        GF.LS.lAnnualSalary = OBJLBL0001.Text
        GF.LS.lChkCity1 = OBJTXT0001.Text
        GF.LS.lChkCity2 = OBJTXT0002.Text
        GF.LS.lman22a = OBJTXT0003.Text
        GF.LS.lCode202 = OBJTXT0004.Text
        GF.LS.lCode203 = OBJTXT0005.Text
        GF.LS.lman22b = OBJTXT0006.Text
        GF.LS.lPensionFrequency = OBJSEL0002.SelectedValue
        GF.LS.lPensionYearsEmp = OBJSEL0003.SelectedValue
        GF.LS.lSELECT46 = OBJSEL0004.SelectedValue
        GF.LS.lYears3 = OBJSEL0005.SelectedValue
        GF.LS.lSELECT45 = OBJSEL0006.SelectedValue
        GF.LS.lHours = OBJSEL0007.SelectedValue
        If OBJCHK0001.Checked Then GF.LS.lPensionRefused = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lPensionRefused = "N"
        If OBJCHK0002.Checked Then GF.LS.lEmpRefused = "Y"
        If Not OBJCHK0002.Checked Then GF.LS.lEmpRefused = "N"
        GF.LS.lEmpPhone = SCRIPT0001.PhoneNumber
        GF.LS.lEmpAreaC = SCRIPT0001.AreaCode
        GF.LS.lEmpPhone3 = SCRIPT0001.Prefix
        GF.LS.lEmpPhone4 = SCRIPT0001.Extension
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            SCRIPT0001.PhoneRequired = False
            SCRIPT0001.Prompt = "Employer Phone Number: "
            Select Case GF.LS.lSELECT46
                Case "N"
                    OBJDIV0001.Visible = False
                Case "Y"
                    OBJDIV0001.Visible = True
            End Select
            Select Case GF.LS.lSELECT45
                Case "D"
                    OBJDIV0002.Visible = True
                Case Else
                    OBJDIV0002.Visible = False
            End Select
            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source = "B" Then
                If (GF.LS.lman22a.ToString.Trim.Equals(String.Empty) And GF.LS.lPensionRefused.ToString.Trim.Equals("N")) Then
                    EditError = 1
                    ErrorMsg = "Enter in Pension amount or Check Refused"
                    SetFocus("OBJCHK0001")
                ElseIf (Not CInt(GF.LS.lman22a).Equals(0) And GF.LS.lPensionFrequency.ToString.Trim.Equals(String.Empty)) Then
                    EditError = 1
                    ErrorMsg = "Select Pension Frequency"
                    SetFocus("OBJSEL0002")
                End If
                If Not CInt(GF.LS.lman22a).Equals(0) Then
                    If Not IsNumeric(GF.LS.lman22a.ToString.Trim) Then
                        EditError = 1
                        ErrorMsg = "Please enter currency only"
                        SetFocus("OBJTXT0003")
                    End If
                End If
                If GF.LS.lSELECT46.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Currently Employed Yes/No?"
                    SetFocus("OBJSEL0004")
                End If
                If GF.LS.lSELECT46.ToString.Trim.Equals("Y") Then
                    If GF.LS.lman22b.ToString.Trim.Equals(String.Empty) And GF.LS.lEmpRefused.ToString.Trim.Equals("N") Then
                        EditError = 1
                        ErrorMsg = "Enter in Salary amount or Check Refused"
                        SetFocus("OBJCHK0002")

                    End If
                    If Not CInt(GF.LS.lman22b).Equals(0) Then
                        If GF.LS.lSELECT45.ToString.Trim.Equals(String.Empty) Then
                            EditError = 1
                            ErrorMsg = "Select Salary Frequency"
                            SetFocus("OBJSEL0006")
                        End If
                        If GF.LS.lSELECT45.ToString.Trim = "D" Then
                            If CInt(GF.LS.lHours).Equals(0) Then
                                EditError = 1
                                ErrorMsg = "Select hours per week"
                                SetFocus("OBJSEL0007")
                            End If
                        End If
                    End If
                End If
                If GF.LS.lman22b.ToString.Trim <> String.Empty Then
                    If IsNumeric(GF.LS.lman22b.ToString.Trim) Then
                        GF.LS.lCheckAmt1 = GF.LS.lman22b
                    Else
                        EditError = 1
                        ErrorMsg = "Please enter currency only"
                        SetFocus("OBJTXT0006")

                    End If

                    If GF.LS.lman22a IsNot String.Empty Then
                        GF.LS.lSubtot1 = GF.LS.lman22a

                    Else
                        GF.LS.lSubtot1 = 0
                    End If

                End If
            End If

            '20101110 cgossman  ... moved from submit
            GF.LS.lSubtot1 = GF.LS.lman22a
            GF.gfCalcIncome2()
            '20101110 cgossman  ... moved from submit

            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False
            nextPanel = Panels.MANUAL.manual0058

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

   
    Private Sub OBJSEL0004_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0004.SelectedIndexChanged
        PanelEditAutoMapping()
        Select Case GF.LS.lSELECT46.ToString.Trim
            Case "Y"
                OBJDIV0001.Visible = True
            Case "N"
                OBJDIV0001.Visible = False
            Case Else
        End Select
        'GF.gfCalcIncome2 (  )
       
    End Sub
   
    Private Sub OBJSEL0006_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0006.SelectedIndexChanged


        PanelEditAutoMapping()

        Select Case GF.LS.lSELECT45
            Case "D"
                OBJDIV0002.Visible = True
            Case Else
                OBJDIV0002.Visible = False
        End Select
       
    End Sub
    
    Private Sub OBJTXT0003_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJTXT0003.TextChanged, OBJTXT0006.TextChanged
        PanelEditAutoMapping()
        GF.gfCalcIncome2()
        WindowOnLoadAutoMapping()
    End Sub
End Class
