﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class manual0046
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0026.Text = GF.LS.lAppName
        OBJLBL0027.Text = GF.LS.lmailAdd1
        OBJLBL0028.Text = GF.LS.lmailAdd2
        OBJLBL0029.Text = GF.LS.lmailCity
        OBJLBL0030.Text = GF.LS.lmailState
        OBJLBL0031.Text = GF.LS.lmailZip
        OBJTXT0016.Text = GF.LS.lmailFname
        OBJTXT0017.Text = GF.LS.lmailMname
        OBJTXT0018.Text = GF.LS.lmailLname
        OBJTXT0015.Text = GF.LS.lAppName
        OBJTXT0014.Text = GF.LS.lman33a
        OBJSEL0001.SelectedValue = GF.LS.lYear2
        OBJSEL0002.SelectedValue = GF.LS.lPOBoxUsed
        OBJSEL0003.SelectedValue = GF.LS.lSELECT44
        If GF.LS.lRefusedBirth = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lRefusedBirth = "N" Then OBJCHK0001.Checked = False
        SCRIPT0002.ZipCode = GF.LS.lmailZip
        SCRIPT0002.Address1 = GF.LS.lmailAdd1
        SCRIPT0002.Address2 = GF.LS.lmailAdd2
        SCRIPT0002.City = GF.LS.lmailCity
        SCRIPT0002.State = GF.LS.lmailState
        SCRIPT0003.ZipCode = GF.LS.lPhysicalZip
        SCRIPT0003.Address1 = GF.LS.lPhysicalAddress1
        SCRIPT0003.Address2 = GF.LS.lPhysicalAddress2
        SCRIPT0003.City = GF.LS.lPhysicalCity
        SCRIPT0003.State = GF.LS.lPhysicalState
        SCRIPT0001.PhoneNumber = GF.LS.lHomePhone
        SCRIPT0001.AreaCode = GF.LS.lmailAreaC
        SCRIPT0001.Prefix = GF.LS.lmailPhone3
        SCRIPT0001.Extension = GF.LS.lmailPhone4
        SCRIPT0004.Month = GF.LS.lmonth4
        SCRIPT0004.Day = GF.LS.lday4
        SCRIPT0004.Year = GF.LS.lyear4
        SCRIPT0004.DateYYYYMMDD = GF.LS.lDate3
        If GF.LS.lAge4 IsNot String.Empty Then

            SCRIPT0004.Age = CInt(GF.LS.lAge4)
        End If
        'SCRIPT0004.Age = GF.LS.lAge4
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lAppName = OBJLBL0026.Text
        GF.LS.lmailAdd1 = OBJLBL0027.Text
        GF.LS.lmailAdd2 = OBJLBL0028.Text
        GF.LS.lmailCity = OBJLBL0029.Text
        GF.LS.lmailState = OBJLBL0030.Text
        GF.LS.lmailZip = OBJLBL0031.Text
        GF.LS.lmailFname = OBJTXT0016.Text
        GF.LS.lmailMname = OBJTXT0017.Text
        GF.LS.lmailLname = OBJTXT0018.Text
        GF.LS.lAppName = OBJTXT0015.Text
        GF.LS.lman33a = OBJTXT0014.Text
        GF.LS.lYear2 = OBJSEL0001.SelectedValue
        GF.LS.lPOBoxUsed = OBJSEL0002.SelectedValue
        GF.LS.lSELECT44 = OBJSEL0003.SelectedValue
        If OBJCHK0001.Checked Then GF.LS.lRefusedBirth = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lRefusedBirth = "N"
        GF.LS.lmailZip = SCRIPT0002.ZipCode
        GF.LS.lmailAdd1 = SCRIPT0002.Address1
        GF.LS.lmailAdd2 = SCRIPT0002.Address2
        GF.LS.lmailCity = SCRIPT0002.City
        GF.LS.lmailState = SCRIPT0002.State
        GF.LS.lPhysicalZip = SCRIPT0003.ZipCode
        GF.LS.lPhysicalAddress1 = SCRIPT0003.Address1
        GF.LS.lPhysicalAddress2 = SCRIPT0003.Address2
        GF.LS.lPhysicalCity = SCRIPT0003.City
        GF.LS.lPhysicalState = SCRIPT0003.State
        GF.LS.lHomePhone = SCRIPT0001.PhoneNumber
        GF.LS.lmailAreaC = SCRIPT0001.AreaCode
        GF.LS.lmailPhone3 = SCRIPT0001.Prefix
        GF.LS.lmailPhone4 = SCRIPT0001.Extension
        GF.LS.lmonth4 = SCRIPT0004.Month
        GF.LS.lday4 = SCRIPT0004.Day
        GF.LS.lyear4 = SCRIPT0004.Year
        GF.LS.lDate3 = SCRIPT0004.DateYYYYMMDD
        GF.LS.lAge4 = SCRIPT0004.Age
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            SCRIPT0001.PhoneRequired = False
            SCRIPT0001.Prompt = "Home Phone: "
            SCRIPT0004.MonthPrompt = "Date of Birth: "
            SCRIPT0002.MiddleInitialReq = False
            SCRIPT0003.MiddleInitialReq = False

            If GF.LS.lOverCardLimit IsNot String.Empty Then
                If CInt(GF.LS.lOverCardLimit) > 25 Then
                    OBJTID0001.Text = "The name on the card cannot exceed 25 character. Currently it is " & GF.LS.lOverCardLimit.ToString.Trim & " characters long. Name on Card:= " & GF.LS.lAppName.ToString.Trim & "." & vbCrLf & vbCrLf & "The Address needs to be corrected: "
                End If
            Else
                OBJTID0001.Text = "The Address needs to be corrected: "
            End If

            If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
                OBJTID0002.Text = "Physical Address:"
                SCRIPT0003.Visible = True
                SCRIPT0003.Address1Req = True
                SCRIPT0003.CityReq = True
                SCRIPT0003.StateReq = True
                SCRIPT0003.ZipReq = True
            Else
                OBJTID0002.Text = String.Empty
                SCRIPT0003.Visible = False
                SCRIPT0003.Address1Req = False
                SCRIPT0003.CityReq = False
                SCRIPT0003.StateReq = False
                SCRIPT0003.ZipReq = False
            End If

            If GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
                GF.LS.lmonth4 = String.Empty
                GF.LS.lday4 = String.Empty
                GF.LS.lyear4 = String.Empty
                GF.LS.lDate3 = "00000000"
                GF.LS.lAge4 = 0
                SCRIPT0004.Required = False
            Else
                SCRIPT0004.Required = True
            End If

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            GF.LS.lmailFname = GF.LS.lmailFname.ToString.Trim.ToUpper
            GF.LS.lmailMname = GF.LS.lmailMname.ToString.Trim.ToUpper
            GF.LS.lmailLname = GF.LS.lmailLname.ToString.Trim.ToUpper

            GF.LS.lAppName = GF.LS.lAppName.ToString.Trim.ToUpper
            GF.LS.lmailAdd1 = GF.LS.lmailAdd1.ToString.Trim.ToUpper
            GF.LS.lmailCity = GF.LS.lmailCity.ToString.Trim.ToUpper
            GF.LS.lmailState = GF.LS.lmailState.ToString.Trim.ToUpper
            GF.LS.lAppName = GF.LS.lAppName.ToString.Trim.ToUpper

            GF.LS.lPhysicialAddress1 = GF.LS.lPhysicialAddress1.ToString.Trim.ToUpper
            GF.LS.lPhysicialAddress2 = GF.LS.lPhysicialAddress2.ToString.Trim.ToUpper
            GF.LS.lPhysicialCity = GF.LS.lPhysicialCity.ToString.Trim.ToUpper
            GF.LS.lPhysicialState = GF.LS.lPhysicialState.ToString.Trim.ToUpper

            If source.Equals("B") Then
                If GF.LS.lmailFname.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "First Name is a Required Field"
                    SetFocus("OBJTXT0016")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailFname.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "First Name invalid. No special characters."
                    SetFocus("OBJTXT0016")
                ElseIf GF.LS.lmailLname.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Last Name is a Required Field"
                    SetFocus("OBJTXT0018")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailLname.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Last Name invalid. No special characters."
                    SetFocus("OBJTXT0018")
                ElseIf GF.LS.lAppName.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please enter name up to 25 characters."
                    SetFocus("OBJTXT0015")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lAppName.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Application Name invalid. No special characters."
                    SetFocus("OBJTXT0015")
                ElseIf GF.LS.lAppName.ToString.Trim.Length > 25 Then
                    EditError = 1
                    ErrorMsg = "Please shorten name to be 25 characters."
                    SetFocus("OBJTXT0015")
                    'ElseIf CInt(GF.LS.lAppName) > 25 Then
                    '    EditError = 1
                    '    ErrorMsg = "Please shorten name to be 25 characters."
                    '    SetFocus("OBJTXT0015")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailAdd1.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Address1 invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address1
                ElseIf GF.LS.lmailAdd1.ToString.Trim.Length > 40 Then
                    EditError = 1
                    ErrorMsg = "Please shorten Address1 to be 40 characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address1
                ElseIf (Not GF.LS.lmailAdd2.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lmailAdd2.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Address2 invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address2
                ElseIf GF.LS.lmailAdd2.ToString.Trim.Length > 40 Then
                    EditError = 1
                    ErrorMsg = "Please shorten Address2 to be 40 characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address2
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailCity.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "City invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.City
                ElseIf GF.LS.lmailCity.ToString.Trim.Length > 25 Then
                    EditError = 1
                    ErrorMsg = "Please shorten City to be 25 characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.City
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailState.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "State invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.State
                ElseIf GF.LS.lmailState.ToString.Trim.Length > 2 Then
                    EditError = 1
                    ErrorMsg = "Please shorten State to be 2 characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.State
                ElseIf CInt(GF.LS.lYear2) = 0 Then
                    EditError = 1
                    ErrorMsg = "Enter the Years at current address"
                    SetFocus("OBJSEL0001")
                ElseIf GF.LS.lPOBoxUsed.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "PO BOX Used is a required field"
                    SetFocus("OBJSEL0002")
                ElseIf (Not GF.LS.lPhysicalAddress1.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lPhysicalAddress1.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Physical Address 1 invalid. No special characters."
                    SCRIPT0003.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address1
                ElseIf (Not GF.LS.lPhysicalAddress2.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lPhysicalAddress2.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Physical Address 2 invalid. No special characters."
                    SCRIPT0003.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address2
                ElseIf (Not GF.LS.lPhysicalCity.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lPhysicalCity.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Physical City invalid. No special characters."
                    SCRIPT0003.FocusField = UserControlLib.NACSZNGS.FieldToFocus.City
                ElseIf (Not GF.LS.lPhysicalState.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lPhysicalState.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Physical State invalid. No special characters."
                    SCRIPT0003.FocusField = UserControlLib.NACSZNGS.FieldToFocus.State
                ElseIf GF.LS.lSELECT44.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please select Housing Information"
                    SetFocus("OBJSEL0003")
                ElseIf Not IsNumeric(GF.LS.lman33a.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please round upto nearest dollar. No commas or periods"
                    SetFocus("OBJTXT0014")
                ElseIf CInt(GF.LS.lAge4) < 18 And GF.LS.lRefusedBirth.ToString.Trim.Equals("N") Then
                    EditError = 1
                    ErrorMsg = "Customer must be 18 years of age to apply. Please check date."
                    set_currPath(ScriptPaths.LOG)
                Else
                    '20100603  cgossman  storing complete date
                    Dim bdate As DateTime
                    If IsDate(GF.LS.lmonth4.ToString.Trim & "/" & GF.LS.lday4.ToString.Trim & "/" & GF.LS.lyear4.ToString.Trim) Then
                        bdate = GF.LS.lmonth4.ToString.Trim & "/" & GF.LS.lday4.ToString.Trim & "/" & GF.LS.lyear4.ToString.Trim
                        GF.LS.lDate3 = Format(bdate, "MMddyyyy")
                    Else
                        GF.LS.lDate3 = String.Empty
                    End If

                    GF.LS.lROBPayment = CInt(GF.LS.lman33a)
                    'concate physical address
                    If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
                        If GF.LS.lPhysicalAddress2.ToString.Trim.Equals(String.Empty) Then
                            GF.LS.lPhysicalAddr = GF.LS.lPhysicalAddress1.ToString.Trim & " " & GF.LS.lPhysicalCity.ToString.Trim & " " & GF.LS.lPhysicalState.ToString.Trim & " " & GF.LS.lPhysicalZip.ToString.Trim
                        Else
                            GF.LS.lPhysicalAddr = GF.LS.lPhysicalAddress1.ToString.Trim & " " & GF.LS.lPhysicalAddress2.ToString.Trim & " " & GF.LS.lPhysicalCity.ToString.Trim & " " & GF.LS.lPhysicalState.ToString.Trim & " " & GF.LS.lPhysicalZip.ToString.Trim

                        End If
                    End If
                End If
            End If
            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0002.IsValid Then
                DisplayError(SCRIPT0002.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0003.IsValid Then
                DisplayError(SCRIPT0003.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0004.IsValid Then
                DisplayError(SCRIPT0004.ErrorMessages())
                EditError = 1
                Exit Sub
           

            End If


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False

            If CInt(GF.LS.lAge4) >= 18 Or GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
                nextPanel = Panels.MANUAL.manual0042
            Else
                endOfPath = True
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

    Private Sub OBJCHK0001_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJCHK0001.CheckedChanged
        PanelEditAutoMapping()
        

        If GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
            GF.LS.lmonth4 = String.Empty
            GF.LS.lday4 = String.Empty
            GF.LS.lyear4 = String.Empty
            GF.LS.lDate3 = "00000000"
            GF.LS.lAge4 = 0
            SCRIPT0004.Required = False
        Else
            SCRIPT0004.Required = True
        End If

        WindowOnLoadAutoMapping()


    End Sub
   
    Private Sub OBJSEL0002_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0002.SelectedIndexChanged
        PanelEditAutoMapping()

        If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
            OBJTID0002.Text = "Physical Address:"
            SCRIPT0003.Visible = True
            SCRIPT0003.Address1Req = True
            SCRIPT0003.CityReq = True
            SCRIPT0003.StateReq = True
            SCRIPT0003.ZipReq = True
        Else
            OBJTID0002.Text = String.Empty
            SCRIPT0003.Visible = False
            SCRIPT0003.Address1Req = False
            SCRIPT0003.CityReq = False
            SCRIPT0003.StateReq = False
            SCRIPT0003.ZipReq = False
        End If
       
        WindowOnLoadAutoMapping()


    End Sub
    






    Private Sub OBJTXT0015_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJTXT0015.TextChanged
        PanelEditAutoMapping()
        If GF.LS.lOverCardLimit IsNot String.Empty Then
            If CInt(GF.LS.lOverCardLimit) > 25 Then
                OBJTID0001.Text = "The name on the card cannot exceed 25 character. Currently it is " & GF.LS.lOverCardLimit.ToString.Trim & " characters long. Name on Card:= " & GF.LS.lAppName.ToString.Trim & "." & vbCrLf & vbCrLf & "The Address needs to be corrected: "
            Else
                OBJTID0001.Text = "The Address needs to be corrected: "
            End If
        End If
        WindowOnLoadAutoMapping()
    End Sub

    Private Sub OBJTXT0016_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJTXT0016.TextChanged
         PanelEditAutoMapping()

        GF.LS.lmailFname = GF.LS.lmailFname.ToString.Trim.ToUpper
        GF.LS.lmailMname = GF.LS.lmailMname.ToString.Trim.ToUpper
        GF.LS.lmailLname = GF.LS.lmailLname.ToString.Trim.ToUpper

        If GF.LS.lmailMname.ToString.Trim.Equals(String.Empty) Then
            GF.LS.lAppName = (GF.LS.lmailFname.ToString.Trim & " " & GF.LS.lmailLname.ToString.Trim)
        Else
            GF.LS.lAppName = (GF.LS.lmailFname.ToString.Trim & " " & GF.LS.lmailMname.ToString.Trim & " " & GF.LS.lmailLname.ToString.Trim)
        End If
        WindowOnLoadAutoMapping()
    End Sub
End Class
