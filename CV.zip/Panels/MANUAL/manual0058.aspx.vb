﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class manual0058
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0002.Text = GF.LS.lmailFname
        OBJLBL0003.Text = GF.LS.lmailLname
        OBJLBL0001.Text = GF.LS.lAnnualSalary
        OBJTXT0010.Text = GF.LS.lAdditionalIncome1
        OBJTXT0013.Text = GF.LS.lAddIncSource1
        OBJTXT0011.Text = GF.LS.lAdditionalIncome2
        OBJTXT0014.Text = GF.LS.lAddIncSource2
        OBJTXT0012.Text = GF.LS.lAdditionalIncome3
        OBJTXT0015.Text = GF.LS.lAddIncSource3
        OBJTXT0003.Text = GF.LS.lChkCity3
        OBJSEL0003.SelectedValue = GF.LS.lSELECT49
        If GF.LS.lSSNRefused = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lSSNRefused = "N" Then OBJCHK0001.Checked = False
        If GF.LS.lMaidenRefused = "Y" Then OBJCHK0002.Checked = True
        If GF.LS.lMaidenRefused = "N" Then OBJCHK0002.Checked = False
        'SCRIPT0001.SSN1 = GF.LS.lSSN1a
        'SCRIPT0001.SSN2 = GF.LS.lSSN2a
        'SCRIPT0001.SSN3 = GF.LS.lSSN3a
        TextBox1.Text = GF.LS.lSSN1a
        TextBox2.Text = GF.LS.lSSN2a
        TextBox3.Text = GF.LS.lSSN3a
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lmailFname = OBJLBL0002.Text
        GF.LS.lmailLname = OBJLBL0003.Text
        GF.LS.lAnnualSalary = OBJLBL0001.Text
        GF.LS.lAdditionalIncome1 = OBJTXT0010.Text
        GF.LS.lAddIncSource1 = OBJTXT0013.Text
        GF.LS.lAdditionalIncome2 = OBJTXT0011.Text
        GF.LS.lAddIncSource2 = OBJTXT0014.Text
        GF.LS.lAdditionalIncome3 = OBJTXT0012.Text
        GF.LS.lAddIncSource3 = OBJTXT0015.Text
        GF.LS.lChkCity3 = OBJTXT0003.Text
        GF.LS.lSELECT49 = OBJSEL0003.SelectedValue
        If OBJCHK0001.Checked Then GF.LS.lSSNRefused = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lSSNRefused = "N"
        If OBJCHK0002.Checked Then GF.LS.lMaidenRefused = "Y"
        If Not OBJCHK0002.Checked Then GF.LS.lMaidenRefused = "N"
        GF.LS.lSSN1a = TextBox1.Text 'SCRIPT0001.SSN1
        GF.LS.lSSN2a = TextBox2.Text 'SCRIPT0001.SSN2
        GF.LS.lSSN3a = TextBox3.Text 'SCRIPT0001.SSN3
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            If GF.LS.lSSNRefused.ToString.Trim.Equals("Y") Then
                GF.LS.lSSN1a = String.Empty
                GF.LS.lSSN2a = String.Empty
                GF.LS.lSSN3a = String.Empty
                GF.LS.lSSNum = 0
            End If
            If GF.LS.lManualOccupation.ToString.Trim.Equals("B") Then
                OBJTID0001.Text = "Alimony, child support or separate maintenance income need not be revealed if you do not wish it considered as a basis for repayment."
            Else
                OBJTID0001.Text = String.Empty
            End If
            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source.Equals("B") Then
                If Not (TextBox1.Text.Equals(String.Empty) AndAlso TextBox2.Text.Equals(String.Empty) AndAlso TextBox3.Text.Equals(String.Empty)) Then
                    If Not IsNumeric(TextBox1.Text) OrElse Not IsNumeric(TextBox2.Text) OrElse Not IsNumeric(TextBox3.Text) Then
                        EditError = 1
                        ErrorMsg = "Please Enter numeric values only in SSN"

                    End If
                End If
                If GF.LS.lSELECT49.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Select Residency"
                    SetFocus("OBJSEL0003")
                ElseIf Not GF.LS.lAdditionalIncome1.ToString.Trim.Equals(String.Empty) And Not IsNumeric(GF.LS.lAdditionalIncome1.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please enter currency only"
                    SetFocus("OBJTXT0010")
                ElseIf Not GF.LS.lAdditionalIncome2.ToString.Trim.Equals(String.Empty) And Not IsNumeric(GF.LS.lAdditionalIncome2.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please enter currency only"
                    SetFocus("OBJTXT0011")
                ElseIf Not GF.LS.lAdditionalIncome3.ToString.Trim.Equals(String.Empty) And Not IsNumeric(GF.LS.lAdditionalIncome3.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please enter currency only"
                    SetFocus("OBJTXT0012")
                ElseIf (GF.LS.lChkCity3.ToString.Trim.Equals(String.Empty) And GF.LS.lMaidenRefused.ToString.Trim.Equals("N")) Then
                    EditError = 1
                    ErrorMsg = "Enter in Maiden Name or Check Refused"
                    SetFocus("OBJTXT0003")
                Else
                    GF.LS.lSSNum = GF.LS.lSSN1a.ToString.Trim & GF.LS.lSSN2a.ToString.Trim & GF.LS.lSSN3a.ToString.Trim
                    If GF.LS.lAdditionalIncome1 IsNot String.Empty Then
                        GF.LS.lAnnualSalary = CStr(CInt(GF.LS.lAdditionalIncome1) + CInt(GF.LS.lAnnualSalary))
                    End If
                    If GF.LS.lAdditionalIncome2 IsNot String.Empty Then
                        GF.LS.lAnnualSalary = CStr(CInt(GF.LS.lAdditionalIncome2) + CInt(GF.LS.lAnnualSalary))
                    End If
                    If GF.LS.lAdditionalIncome3 IsNot String.Empty Then
                        GF.LS.lAnnualSalary = CStr(CInt(GF.LS.lAdditionalIncome3) + CInt(GF.LS.lAnnualSalary))
                    End If
                End If
            End If

            '20101110 cgossman ... code used to be in submit
            If Not GF.LS.lman27a Is String.Empty Then
                GF.LS.lCheckAmt5 = GF.LS.lman27a
            Else
                GF.LS.lCheckAmt5 = 0
            End If
            If GF.LS.lManualOccupation.ToString.Trim.Equals("B") Then
                GF.gfCalcIncome2()
                If GF.LS.lAdditionalIncome1 Is String.Empty Then
                    GF.LS.lAdditionalIncome1 = 0
                End If
                If GF.LS.lAdditionalIncome2 Is String.Empty Then
                    GF.LS.lAdditionalIncome2 = 0
                End If
                If GF.LS.lAdditionalIncome3 Is String.Empty Then
                    GF.LS.lAdditionalIncome3 = 0
                End If
                GF.LS.lTotalHouseInc = CStr(CInt(GF.LS.lAnnualSalary) + CInt(GF.LS.lAdditionalIncome1) + CInt(GF.LS.lAdditionalIncome2) + CInt(GF.LS.lAdditionalIncome3))
            Else
                GF.gfCalcIncome3()
            End If
            '20101110 cgossman ... code used to be in submit

            'If Not SCRIPT0001.IsValid Then
            '    DisplayError(SCRIPT0001.ErrorMessages())
            '    EditError = 1
            '    Exit Sub
            'End If


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False

            If GF.LS.lPOBoxUsed.Equals("Y") And GF.LS.lSSNRefused.Equals("Y") Then
                nextPanel = Panels.MANUAL.manual0061
            Else
                nextPanel = Panels.MANUAL.manual0056
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

    Private Sub OBJCHK0001_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJCHK0001.CheckedChanged
        PanelEditAutoMapping()
        ' GF.LS.lCheckAmt5 = CInt(GF.LS.lman27a)

        ' GF.gfCalcIncome3()
        If GF.LS.lSSNRefused.ToString.Trim.Equals("Y") Then
            GF.LS.lSSN1a = String.Empty
            GF.LS.lSSN2a = String.Empty
            GF.LS.lSSN3a = String.Empty
            GF.LS.lSSNum = 0
            'SCRIPT0001.Required = False
        End If

    End Sub
    
    Private Sub OBJLBL0001_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJLBL0001.Load

        PanelEditAutoMapping()
        GF.LS.lCheckAmt5 = GF.LS.lman27a

        GF.gfCalcIncome3()
    End Sub
End Class
