﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class manual0034
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0002.Text = GF.LS.lmailFname
        OBJLBL0003.Text = GF.LS.lmailLname
        OBJLBL0001.Text = GF.LS.lDisplayTotalIncome
        OBJTXT0001.Text = GF.LS.lPrevEmployer
        OBJTXT0002.Text = GF.LS.lPrevPosition
        OBJTXT0003.Text = GF.LS.lman34a
        OBJTXT0004.Text = GF.LS.lCardName4
        OBJTXT0005.Text = GF.LS.lCardName5
        OBJTXT0006.Text = GF.LS.lman34b
        OBJSEL0002.SelectedValue = GF.LS.lPensionFrequency
        OBJSEL0003.SelectedValue = GF.LS.lPensionYearsEmp
        OBJSEL0004.SelectedValue = GF.LS.lSELECT46
        OBJSEL0005.SelectedValue = GF.LS.lYears4
        OBJSEL0006.SelectedValue = GF.LS.lSELECT45
        OBJSEL0007.SelectedValue = GF.LS.lHours
        If GF.LS.lPensionRefused = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lPensionRefused = "N" Then OBJCHK0001.Checked = False
        If GF.LS.lRefusedEmp = "Y" Then OBJCHK0003.Checked = True
        If GF.LS.lRefusedEmp = "N" Then OBJCHK0003.Checked = False
        If GF.LS.lRefusedPosition = "Y" Then OBJCHK0004.Checked = True
        If GF.LS.lRefusedPosition = "N" Then OBJCHK0004.Checked = False
        If GF.LS.lRefusedYears = "Y" Then OBJCHK0005.Checked = True
        If GF.LS.lRefusedYears = "N" Then OBJCHK0005.Checked = False
        If GF.LS.lEmpRefused = "Y" Then OBJCHK0002.Checked = True
        If GF.LS.lEmpRefused = "N" Then OBJCHK0002.Checked = False
        SCRIPT0001.PhoneNumber = GF.LS.lEmpPhone
        SCRIPT0001.AreaCode = GF.LS.lEmpAreaC
        SCRIPT0001.Prefix = GF.LS.lEmpPhone3
        SCRIPT0001.Extension = GF.LS.lEmpPhone4
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lmailFname = OBJLBL0002.Text
        GF.LS.lmailLname = OBJLBL0003.Text
        GF.LS.lDisplayTotalIncome = OBJLBL0001.Text
        GF.LS.lPrevEmployer = OBJTXT0001.Text
        GF.LS.lPrevPosition = OBJTXT0002.Text
        GF.LS.lman34a = OBJTXT0003.Text
        GF.LS.lCardName4 = OBJTXT0004.Text
        GF.LS.lCardName5 = OBJTXT0005.Text
        GF.LS.lman34b = OBJTXT0006.Text
        GF.LS.lPensionFrequency = OBJSEL0002.SelectedValue
        GF.LS.lPensionYearsEmp = OBJSEL0003.SelectedValue
        GF.LS.lSELECT46 = OBJSEL0004.SelectedValue
        GF.LS.lYears4 = OBJSEL0005.SelectedValue
        GF.LS.lSELECT45 = OBJSEL0006.SelectedValue
        GF.LS.lHours = OBJSEL0007.SelectedValue
        If OBJCHK0001.Checked Then GF.LS.lPensionRefused = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lPensionRefused = "N"
        If OBJCHK0003.Checked Then GF.LS.lRefusedEmp = "Y"
        If Not OBJCHK0003.Checked Then GF.LS.lRefusedEmp = "N"
        If OBJCHK0004.Checked Then GF.LS.lRefusedPosition = "Y"
        If Not OBJCHK0004.Checked Then GF.LS.lRefusedPosition = "N"
        If OBJCHK0005.Checked Then GF.LS.lRefusedYears = "Y"
        If Not OBJCHK0005.Checked Then GF.LS.lRefusedYears = "N"
        If OBJCHK0002.Checked Then GF.LS.lEmpRefused = "Y"
        If Not OBJCHK0002.Checked Then GF.LS.lEmpRefused = "N"
        GF.LS.lEmpPhone = SCRIPT0001.PhoneNumber
        GF.LS.lEmpAreaC = SCRIPT0001.AreaCode
        GF.LS.lEmpPhone3 = SCRIPT0001.Prefix
        GF.LS.lEmpPhone4 = SCRIPT0001.Extension
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            ''TODO: 20100514 lapeters Check0002 may need recreated.
            'lost it's label and still gives error on closing after a label is added.

            SCRIPT0001.PhoneRequired = False
            SCRIPT0001.Prompt = "Employer Phone Number: "
            Select Case GF.LS.lSELECT46.ToString.Trim
	Case "Y"
		OBJDIV0001.Visible = True
	Case "N"
		OBJDIV0001.Visible = False
	Case Else
            End Select
            Select Case GF.LS.lSELECT45.ToString.Trim
	Case "D"
		OBJDIV0002.Visible = True
	Case Else
		OBJDIV0002.Visible = False
            End Select

            windowOnLoadAutoMapping()


        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            panelEditAutoMapping()

 GF.LS.lPrevEmployer = GF.LS.lPrevEmployer.ToString.Trim.ToUpper
 GF.LS.lPrevPosition = GF.LS.lPrevPosition.ToString.Trim.ToUpper
 GF.LS.lCardName4 = GF.LS.lCardName4.ToString.Trim.ToUpper
 GF.LS.lCardName5 = GF.LS.lCardName5.ToString.Trim.ToUpper
            GF.LS.lPensionAmount = CInt(GF.LS.lman34a)
            GF.LS.lSalary = CInt(GF.LS.lman34b)

            if source.Equals("B") then

	if not GF.gfCheckFieldValidity (GF.LS.lPrevEmployer.ToString.Trim,"([a-zA-Z0-9])") then
		editError = 1
		errorMsg = "Previous Employer name invalid. No special characters."
		SetFocus ( "OBJTXT0001" )
	elseif not GF.gfCheckFieldValidity (GF.LS.lPrevPosition.ToString.Trim,"([a-zA-Z0-9])") then
		editError = 1
		errorMsg = "Previous position invalid. No special characters."
		SetFocus ( "OBJTXT0002" )
	elseif (GF.LS.lman34a.ToString.Trim.Equals(String.Empty) and 		GF.LS.lPensionRefused.Equals("N")) then
		editError = 1
		errorMsg = "Enter in Pension amount or Check Refused"
		SetFocus ( "OBJTXT0003" )
                ElseIf (Not CInt(GF.LS.lman34a).Equals(0) And GF.LS.lPensionFrequency.ToString.Trim.Equals(String.Empty)) Then
                    EditError = 1
                    ErrorMsg = "Select Pension Frequency"
                    SetFocus("OBJSEL0002")
	elseIf not IsNumeric ( GF.LS.lman34a.ToString.Trim ) Then
		editError = 1
		errorMsg = "Please enter currency only"
		SetFocus ( "OBJTXT0003" )
	elseIf GF.LS.lSELECT46.ToString.Trim.Equals(String.Empty) then
		editError = 1
		errorMsg = "Currently Employed Yes/No?"
		SetFocus ( "OBJSEL0004" )
	elseIf GF.LS.lSELECT46.ToString.Trim.Equals("Y")then
		If (GF.LS.lCardName4.ToString.Trim.Equals(String.Empty) and 			GF.LS.lRefusedEmp.ToString.Trim.Equals("N")) then
			editError = 1
			errorMsg = "Enter in Current Employer or Check Refused"
			SetFocus ( "OBJTXT0004" )
		elseif (Not GF.LS.lCardName4.ToString.Trim.Equals(String.Empty) and 			Not GF.gfCheckFieldValidity (GF.LS.lCardName4.ToString.Trim,"([a-zA-Z0-9])")) then
			editError = 1
			errorMsg = "Current employer name invalid. No special characters."
			SetFocus ( "OBJTXT0004" )
		elseIf (Not GF.LS.lCardName4.ToString.Trim.Equals("REFUSED") and 			Not GF.LS.lCardName4.ToString.Trim.Equals(String.Empty) and 			GF.LS.lRefusedEmp.ToString.Trim.Equals("Y")) then
			editError = 1
			errorMsg = "Enter in Current Employer or Check Refused not both"
			SetFocus ( "OBJTXT0004" )
		elseIf (GF.LS.lCardName5.ToString.Trim.Equals(String.Empty) and 			GF.LS.lRefusedPosition.ToString.Trim.Equals("N")) then
			editError = 1
			errorMsg = "Enter in Position or Check Refused"
			SetFocus ( "OBJTXT0005" )
		elseif not GF.gfCheckFieldValidity (GF.LS.lCardName5.ToString.Trim,"([a-zA-Z0-9])") then
			editError = 1
			errorMsg = "Current position invalid. No special characters."
			SetFocus ( "OBJTXT0005" )
		elseIf (Not GF.LS.lCardName5.ToString.Trim.Equals("REFUSED") and 			Not GF.LS.lCardName5.ToString.Trim.Equals(String.Empty) and 			GF.LS.lRefusedPosition.ToString.Trim.Equals("Y")) then
			editError = 1
			errorMsg = "Enter in Position or Check Refused not both"
			SetFocus ( "OBJTXT0005" )
                    ElseIf (CInt(GF.LS.lYears4) <= 0 And GF.LS.lRefusedYears.ToString.Trim.Equals("N")) Then
                        EditError = 1
                        ErrorMsg = "Enter in Years Employed or Check Refused"
                        SetFocus("OBJSEL0005")
                    ElseIf (CInt(GF.LS.lYears4) > 0 And GF.LS.lRefusedYears.ToString.Trim.Equals("Y")) Then
                        EditError = 1
                        ErrorMsg = "Enter in Years Employed or Check Refused not both"
                        SetFocus("OBJSEL0005")
		elseIf ( GF.LS.lman34b.ToString.Trim.Equals(String.Empty) and 			GF.LS.lEmpRefused.ToString.Trim.Equals("N")) then
			editError = 1
			errorMsg = "Enter in Salary amount or Check Refused"
			SetFocus ( "OBJTXT0006" )
                    ElseIf (Not CInt(GF.LS.lman34b).Equals(0) And GF.LS.lSELECT45.ToString.Trim.Equals(String.Empty)) Then
                        EditError = 1
                        ErrorMsg = "Select Salary Frequency"
                        SetFocus("OBJSEL0006")
                    ElseIf (GF.LS.lSELECT45.ToString.Trim.Equals("D") And CInt(GF.LS.lHours) <= 0) Then
                        EditError = 1
                        ErrorMsg = "Select hours per week"
                        SetFocus("OBJSEL0007")
		elseif Not IsNumeric ( GF.LS.lman34b.ToString.Trim ) Then
			editError = 1
			errorMsg = "Please enter currency only"
			SetFocus ( "OBJTXT0006" )
		elseif GF.LS.lAnnualSalary.ToString.Trim.Length > 7 then
			editError = 1
			errorMsg = "Annual Salary exceeds 7 digits"
			SetFocus ( "OBJTXT0006" )
		elseif GF.LS.lAnnualPensionAmt.ToString.Trim.Length > 7 then
			editError = 1
			errorMsg = "Annual Pension exceeds 7 digits"
			SetFocus ( "OBJTXT0003" )
		elseif GF.LS.lEditError.ToString.Trim = "34" then
			editError = 1
			errorMsg = "letters or numbers are only allowed"
		End If
	End if
            end if

            If Not SCRIPT0001.isValid Then
	DisplayError(SCRIPT0001.ErrorMessages())
	EditError = 1
	Exit Sub
            End If

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False
            nextpanel = Panels.MANUAL.MANUAL0048

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub


#End Region

Private Sub OBJCHK0001_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0001.CheckedChanged
        PanelEditAutoMapping()

        ''from BW Check0001_OnClick
        If GF.LS.lPensionRefused.ToString.Trim.Equals("Y") Then
            GF.LS.lPensionAmount = 0
            GF.LS.lman34a = String.Empty
            GF.LS.lPensionFrequency = String.Empty
            OBJTXT0003.Text = String.Empty
            OBJSEL0002.Text = String.Empty
        Else
            GF.LS.lPensionAmount = CInt(GF.LS.lman34a)
        End If

        GF.gfCalcIncome6()

End Sub
Private Sub OBJCHK0003_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0003.CheckedChanged
        PanelEditAutoMapping()

        If GF.LS.lRefusedEmp.ToString.Trim.Equals("Y") Then
            GF.LS.lCardName4 = "REFUSED"
            OBJTXT0004.Text = "REFUSED"
        End If


End Sub
Private Sub OBJCHK0004_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0004.CheckedChanged
        PanelEditAutoMapping()
        If GF.LS.lPositionRefused.ToString.Trim.Equals("Y") Then
            GF.LS.lCardName5 = "REFUSED"
            OBJTXT0005.Text = "REFUSED"
        End If

End Sub
Private Sub OBJCHK0005_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0005.CheckedChanged
        PanelEditAutoMapping()

        If GF.LS.lRefusedYears.ToString.Trim.Equals("Y") Then
            GF.LS.lYears4 = 0
            OBJSEL0005.Text = String.Empty
        End If

End Sub
Private Sub OBJCHK0002_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0002.CheckedChanged
        PanelEditAutoMapping()

        If GF.LS.lEmpRefused.ToString.Trim.Equals("Y") Then
            GF.LS.lSalary = 0
            GF.LS.lman34b = String.Empty
            GF.LS.lHours = 0
            GF.LS.lSELECT45 = String.Empty
            OBJTXT0006.Text = String.Empty
            OBJSEL0006.Text = String.Empty
            OBJSEL0007.Text = String.Empty
        Else
            GF.LS.lSalary = CInt(GF.LS.lman34b)
        End If

End Sub


Private Sub OBJSEL0004_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles OBJSEL0004.SelectedIndexChanged
        PanelEditAutoMapping()

        Select Case GF.LS.lSELECT46.ToString.Trim
            Case "Y"
                OBJDIV0001.Visible = True
            Case "N"
                OBJDIV0001.Visible = False
            Case Else
        End Select


End Sub


    Private Sub OBJSEL0006_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0006.SelectedIndexChanged
        PanelEditAutoMapping()

        Select Case GF.LS.lSELECT45.ToString.Trim
            Case "D"
                OBJDIV0002.Visible = True
            Case Else
                OBJDIV0002.Visible = False
        End Select

    End Sub

End Class
