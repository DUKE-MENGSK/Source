﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class manual0049
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0003.Text = GF.LS.lDisplayName
        OBJLBL0004.Text = GF.LS.lmailAdd1
        OBJLBL0005.Text = GF.LS.lmailAdd2
        OBJLBL0019.Text = GF.LS.lmailCity
        OBJLBL0007.Text = GF.LS.lmailState
        OBJLBL0008.Text = GF.LS.lmailZip
        OBJLBL0001.Text = GF.LS.lOverCardLimit
        OBJLBL0002.Text = GF.LS.lAppName
        OBJTXT0017.Text = GF.LS.lmailFname
        OBJTXT0018.Text = GF.LS.lmailMname
        OBJTXT0019.Text = GF.LS.lmailLname
        OBJTXT0015.Text = GF.LS.lAppName
        OBJTXT0014.Text = GF.LS.lman33a
        OBJRAD0002.SelectedValue = GF.LS.lman49c
        OBJRAD0001.SelectedValue = GF.LS.lMan46b
        OBJSEL0001.SelectedValue = GF.LS.lYear2
        OBJSEL0002.SelectedValue = GF.LS.lPOBoxUsed
        OBJSEL0003.SelectedValue = GF.LS.lSELECT44
        OBJSEL0004.SelectedValue = GF.LS.lManualOccupation
        'If OBJSEL0006.Visible.Equals(False) AndAlso OBJSEL0007.Visible.Equals(False) AndAlso OBJSEL0008.Visible.Equals(False) Then
        Select Case GF.LS.lManualOccupation.ToString.Trim
            Case "C"
                OBJSEL0005.SelectedValue = GF.LS.lNum21
            Case "D"
                OBJSEL0006.SelectedValue = GF.LS.lNum21
            Case "E"
                OBJSEL0007.SelectedValue = GF.LS.lNum21
            Case "F"
                OBJSEL0008.SelectedValue = GF.LS.lEmployed
                Select Case GF.LS.lEmployed.ToString.Trim
                    Case "A"
                        OBJSEL0009.SelectedValue = GF.LS.lNum21
                    Case "B"
                        OBJSEL0010.SelectedValue = GF.LS.lNum21
                    Case "D"
                        OBJSEL0011.SelectedValue = GF.LS.lNum21
                    Case "E"
                        OBJSEL0012.SelectedValue = GF.LS.lNum21
                    Case "G"
                        OBJSEL0013.SelectedValue = GF.LS.lNum21
                End Select
        End Select
        'End If
        If GF.LS.lRefusedBirth = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lRefusedBirth = "N" Then OBJCHK0001.Checked = False
        SCRIPT0002.ZipCode = GF.LS.lmailZip
        SCRIPT0002.Address1 = GF.LS.lmailAdd1
        SCRIPT0002.Address2 = GF.LS.lmailAdd2
        SCRIPT0002.City = GF.LS.lmailCity
        SCRIPT0002.State = GF.LS.lmailState
        SCRIPT0003.ZipCode = GF.LS.lPhysicalZip
        SCRIPT0003.Address1 = GF.LS.lPhysicalAddress1
        SCRIPT0003.Address2 = GF.LS.lPhysicalAddress2
        SCRIPT0003.City = GF.LS.lPhysicalCity
        SCRIPT0003.State = GF.LS.lPhysicalState
        SCRIPT0001.PhoneNumber = GF.LS.lHomePhone
        SCRIPT0001.AreaCode = GF.LS.lmailAreaC
        SCRIPT0001.Prefix = GF.LS.lmailPhone3
        SCRIPT0001.Extension = GF.LS.lmailPhone4
        SCRIPT0004.Month = GF.LS.lmonth4
        SCRIPT0004.Day = GF.LS.lday4
        SCRIPT0004.Year = GF.LS.lyear4
        If GF.LS.lAge4 IsNot String.Empty Then
            SCRIPT0004.Age = CInt(GF.LS.lAge4)
        End If
        'SCRIPT0004.Age = GF.LS.lAge4
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lDisplayName = OBJLBL0003.Text
        GF.LS.lmailAdd1 = OBJLBL0004.Text
        GF.LS.lmailAdd2 = OBJLBL0005.Text
        GF.LS.lmailCity = OBJLBL0019.Text
        GF.LS.lmailState = OBJLBL0007.Text
        GF.LS.lmailZip = OBJLBL0008.Text
        GF.LS.lOverCardLimit = OBJLBL0001.Text
        GF.LS.lAppName = OBJLBL0002.Text
        GF.LS.lmailFname = OBJTXT0017.Text
        GF.LS.lmailMname = OBJTXT0018.Text
        GF.LS.lmailLname = OBJTXT0019.Text
        GF.LS.lAppName = OBJTXT0015.Text
        GF.LS.lman33a = OBJTXT0014.Text
        GF.LS.lman49c = OBJRAD0002.SelectedValue
        GF.LS.lMan46b = OBJRAD0001.SelectedValue
        GF.LS.lYear2 = OBJSEL0001.SelectedValue
        GF.LS.lPOBoxUsed = OBJSEL0002.SelectedValue
        GF.LS.lSELECT44 = OBJSEL0003.SelectedValue
        GF.LS.lManualOccupation = OBJSEL0004.SelectedValue
        Select Case GF.LS.lManualOccupation.ToString.Trim
            Case "C"
                GF.LS.lNum21 = OBJSEL0005.SelectedValue
            Case "D"
                GF.LS.lNum21 = OBJSEL0006.SelectedValue
            Case "E"
                GF.LS.lNum21 = OBJSEL0007.SelectedValue
            Case "F"
                GF.LS.lEmployed = OBJSEL0008.SelectedValue
                Select Case GF.LS.lEmployed.ToString.Trim
                    Case "A"
                        GF.LS.lNum21 = OBJSEL0009.SelectedValue
                    Case "B"
                        GF.LS.lNum21 = OBJSEL0010.SelectedValue
                    Case "D"
                        GF.LS.lNum21 = OBJSEL0011.SelectedValue
                    Case "E"
                        GF.LS.lNum21 = OBJSEL0012.SelectedValue
                    Case "G"
                        GF.LS.lNum21 = OBJSEL0013.SelectedValue
                End Select
        End Select
        'GF.LS.lNum21 = OBJSEL0005.SelectedValue
        'GF.LS.lNum21 = OBJSEL0006.SelectedValue
        'GF.LS.lNum21 = OBJSEL0007.SelectedValue
        'GF.LS.lEmployed = OBJSEL0008.SelectedValue
        'GF.LS.lNum21 = OBJSEL0009.SelectedValue
        'GF.LS.lNum21 = OBJSEL0010.SelectedValue
        'GF.LS.lNum21 = OBJSEL0011.SelectedValue
        'GF.LS.lNum21 = OBJSEL0012.SelectedValue
        'GF.LS.lNum21 = OBJSEL0013.SelectedValue
        If OBJCHK0001.Checked Then GF.LS.lRefusedBirth = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lRefusedBirth = "N"
        GF.LS.lmailZip = SCRIPT0002.ZipCode
        GF.LS.lmailAdd1 = SCRIPT0002.Address1
        GF.LS.lmailAdd2 = SCRIPT0002.Address2
        GF.LS.lmailCity = SCRIPT0002.City
        GF.LS.lmailState = SCRIPT0002.State
        GF.LS.lPhysicalZip = SCRIPT0003.ZipCode
        GF.LS.lPhysicalAddress1 = SCRIPT0003.Address1
        GF.LS.lPhysicalAddress2 = SCRIPT0003.Address2
        GF.LS.lPhysicalCity = SCRIPT0003.City
        GF.LS.lPhysicalState = SCRIPT0003.State
        GF.LS.lHomePhone = SCRIPT0001.PhoneNumber
        GF.LS.lmailAreaC = SCRIPT0001.AreaCode
        GF.LS.lmailPhone3 = SCRIPT0001.Prefix
        GF.LS.lmailPhone4 = SCRIPT0001.Extension
        GF.LS.lmonth4 = SCRIPT0004.Month
        GF.LS.lday4 = SCRIPT0004.Day
        GF.LS.lyear4 = SCRIPT0004.Year
        GF.LS.lAge4 = SCRIPT0004.Age
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            SCRIPT0001.PhoneRequired = False
            SCRIPT0001.Prompt = "Home Phone: "
            SCRIPT0004.MonthPrompt = "Date of Birth: "

            GF.LS.lOverCardLimit = GF.LS.lAppName.ToString.Trim.Length
            SCRIPT0002.MiddleInitialReq = False
            SCRIPT0003.MiddleInitialReq = False

            If CInt(GF.LS.lOverCardLimit) > 25 Or GF.LS.lAppName.ToString.Trim.Length > 25 Then
                OBJDIV0001.Visible = True
                OBJDIV0002.Visible = True
            Else
                OBJDIV0001.Visible = False
                OBJDIV0002.Visible = False
            End If

            If GF.LS.lmailFname.ToString.Trim.Equals(String.Empty) Or GF.LS.lmailLname.ToString.Trim.Equals(String.Empty) Or GF.LS.lman49c.ToString.Trim.Equals("N") Then
                OBJDIV0001.Visible = True
            Else
                OBJDIV0001.Visible = False
            End If

            Select Case GF.LS.lMan46b.ToString.Trim
                Case "N"
                    OBJDIV0003.Visible = True
                    SCRIPT0002.Address1Req = True
                    SCRIPT0002.CityReq = True
                    SCRIPT0002.StateReq = True
                    SCRIPT0002.ZipReq = True
                Case Else
                    If GF.LS.lmailAdd1.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lmailCity.ToString.Trim.Equals(String.Empty) OrElse _
                     GF.LS.lmailState.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lmailZip.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lmailZip.ToString.Trim.Length <> 5 OrElse Not IsNumeric(GF.LS.lmailZip.ToString.Trim) OrElse GF.LS.lmailAdd1.ToString.Trim.Length > 25 OrElse GF.LS.lmailAdd2.ToString.Trim.Length > 25 OrElse GF.LS.lmailCity.ToString.Trim.Length > 25 OrElse _
                     GF.LS.lmailState.ToString.Trim.Length > 2 Then
                        OBJDIV0003.Visible = True
                        SCRIPT0002.Address1Req = True
                        SCRIPT0002.CityReq = True
                        SCRIPT0002.StateReq = True
                        SCRIPT0002.ZipReq = True
                    Else
                        OBJDIV0003.Visible = False
                        SCRIPT0002.Address1Req = False
                        SCRIPT0002.CityReq = False
                        SCRIPT0002.StateReq = False
                        SCRIPT0002.ZipReq = False
                    End If
            End Select

            If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
                OBJDIV0004.Visible = True
                SCRIPT0003.Address1Req = True
                SCRIPT0003.CityReq = True
                SCRIPT0003.StateReq = True
                SCRIPT0003.ZipReq = True
            Else
                OBJDIV0004.Visible = False
                SCRIPT0003.Address1Req = False
                SCRIPT0003.CityReq = False
                SCRIPT0003.StateReq = False
                SCRIPT0003.ZipReq = False
            End If

            Select Case GF.LS.lManualOccupation.ToString.Trim
                Case "B"  'Retired
                    OBJDIV0005.Visible = False
                    OBJDIV0006.Visible = False
                    OBJDIV0007.Visible = False
                    OBJDIV0008.Visible = False
                    OBJDIV0009.Visible = False
                    OBJDIV0010.Visible = False
                    OBJDIV0011.Visible = False
                    OBJDIV0012.Visible = False
                    OBJDIV0013.Visible = False
                Case "C"   'Self-employed
                    OBJDIV0005.Visible = True
                    OBJDIV0006.Visible = False
                    OBJDIV0007.Visible = False
                    OBJDIV0008.Visible = False
                    OBJDIV0009.Visible = False
                    OBJDIV0010.Visible = False
                    OBJDIV0011.Visible = False
                    OBJDIV0012.Visible = False
                    OBJDIV0013.Visible = False
                Case "D" 'student
                    OBJDIV0005.Visible = False
                    OBJDIV0006.Visible = True
                    OBJDIV0007.Visible = False
                    OBJDIV0008.Visible = False
                    OBJDIV0009.Visible = False
                    OBJDIV0010.Visible = False
                    OBJDIV0011.Visible = False
                    OBJDIV0012.Visible = False
                    OBJDIV0013.Visible = False
                Case "E" 'unemployed
                    OBJDIV0005.Visible = False
                    OBJDIV0006.Visible = False
                    OBJDIV0007.Visible = True
                    OBJDIV0008.Visible = False
                    OBJDIV0009.Visible = False
                    OBJDIV0010.Visible = False
                    OBJDIV0011.Visible = False
                    OBJDIV0012.Visible = False
                    OBJDIV0013.Visible = False
                Case "F" 'employed
                    OBJDIV0005.Visible = False
                    OBJDIV0006.Visible = False
                    OBJDIV0007.Visible = False
                    OBJDIV0008.Visible = True
                    Select Case GF.LS.lEmployed.ToString.Trim
                        Case "A" 'EDUCATION
                            OBJDIV0009.Visible = True
                            OBJDIV0010.Visible = False
                            OBJDIV0011.Visible = False
                            OBJDIV0012.Visible = False
                            OBJDIV0013.Visible = False
                        Case "B" 'PERFERED PROFESSIONAL
                            OBJDIV0009.Visible = False
                            OBJDIV0010.Visible = True
                            OBJDIV0011.Visible = False
                            OBJDIV0012.Visible = False
                            OBJDIV0013.Visible = False
                        Case "C" 'RN-REGISTER  NURSE
                            OBJDIV0009.Visible = False
                            OBJDIV0010.Visible = False
                            OBJDIV0011.Visible = False
                            OBJDIV0012.Visible = False
                            OBJDIV0013.Visible = False
                        Case "D" 'PROFESSIONAL
                            OBJDIV0009.Visible = False
                            OBJDIV0010.Visible = False
                            OBJDIV0011.Visible = True
                            OBJDIV0012.Visible = False
                            OBJDIV0013.Visible = False
                        Case "E" 'SKILLED LABOR
                            OBJDIV0009.Visible = False
                            OBJDIV0010.Visible = False
                            OBJDIV0011.Visible = False
                            OBJDIV0012.Visible = True
                            OBJDIV0013.Visible = False
                        Case "F" 'UNSKILLED LABOR
                            OBJDIV0009.Visible = False
                            OBJDIV0010.Visible = False
                            OBJDIV0011.Visible = False
                            OBJDIV0012.Visible = False
                            OBJDIV0013.Visible = False
                        Case "G" 'MILITARY
                            OBJDIV0009.Visible = False
                            OBJDIV0010.Visible = False
                            OBJDIV0011.Visible = False
                            OBJDIV0012.Visible = False
                            OBJDIV0013.Visible = True
                        Case Else
                    End Select
                Case Else
            End Select

            If GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
                GF.LS.lmonth4 = String.Empty
                GF.LS.lday4 = String.Empty
                GF.LS.lyear4 = String.Empty
                GF.LS.lDate3 = "00000000"
                GF.LS.lAge4 = 0
                SCRIPT0004.Required = False
            Else
                SCRIPT0004.Required = True
            End If

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()
            GF.LS.lmailFname = GF.LS.lmailFname.ToString.Trim.ToUpper
            GF.LS.lmailMname = GF.LS.lmailMname.ToString.Trim.ToUpper
            GF.LS.lmailLname = GF.LS.lmailLname.ToString.Trim.ToUpper

            GF.LS.lAppName = GF.LS.lAppName.ToString.Trim.ToUpper
            GF.LS.lmailAdd1 = GF.LS.lmailAdd1.ToString.Trim.ToUpper
            GF.LS.lmailCity = GF.LS.lmailCity.ToString.Trim.ToUpper
            GF.LS.lmailState = GF.LS.lmailState.ToString.Trim.ToUpper
            GF.LS.lAppName = GF.LS.lAppName.ToString.Trim.ToUpper

            GF.LS.lPhysicialAddress1 = GF.LS.lPhysicialAddress1.ToString.Trim.ToUpper
            GF.LS.lPhysicialAddress2 = GF.LS.lPhysicialAddress2.ToString.Trim.ToUpper
            GF.LS.lPhysicialCity = GF.LS.lPhysicialCity.ToString.Trim.ToUpper
            GF.LS.lPhysicialState = GF.LS.lPhysicialState.ToString.Trim.ToUpper

            If source.Equals("B") Then
                If GF.LS.lman49c.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Name Correct - Yes or No"
                    SetFocus("OBJRAD0002001")
                ElseIf GF.LS.lmailFname.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "First Name is a Required Field"
                    SetFocus("OBJTXT0017")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailFname.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "First Name invalid. No special characters."
                    SetFocus("OBJTXT0017")
                ElseIf GF.LS.lmailLname.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Last Name is a Required Field"
                    SetFocus("OBJTXT0019")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailLname.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Last Name invalid. No special characters."
                    SetFocus("OBJTXT0019")
                ElseIf GF.LS.lAppName.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please enter name up to 25 characters."
                    SetFocus("OBJTXT0015")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lAppName.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Application Name invalid. No special characters."
                    SetFocus("OBJTXT0015")
                ElseIf GF.LS.lAppName.ToString.Trim.Length > 25 Then
                    EditError = 1
                    ErrorMsg = "Please shorten name to be 25 characters."
                    SetFocus("OBJTXT0015")
                ElseIf CInt(GF.LS.lOverCardLimit) > 25 Then
                    OBJDIV0001.Visible = True
                    EditError = 1
                    ErrorMsg = "Please shorten name to be 25 characters."
                    SetFocus("OBJTXT0015")
                ElseIf GF.LS.lMan46b.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Address Correct - Yes or No"
                    SetFocus("OBJRAD0001001")
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailAdd1.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "Address1 invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address1
                ElseIf GF.LS.lmailAdd1.ToString.Trim.Length > 40 Then
                    EditError = 1
                    ErrorMsg = "Please shorten Address1 to be 40 characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address1
                ElseIf (Not GF.LS.lmailAdd2.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lmailAdd2.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Address2 invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address2
                ElseIf GF.LS.lmailAdd2.ToString.Trim.Length > 40 Then
                    EditError = 1
                    ErrorMsg = "Please shorten Address2 to be 40 characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address2
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailCity.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "City invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.City
                ElseIf GF.LS.lmailCity.ToString.Trim.Length > 25 Then
                    EditError = 1
                    ErrorMsg = "Please shorten City to be 25 characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.City
                ElseIf Not GF.gfCheckFieldValidity(GF.LS.lmailState.ToString.Trim, "([a-zA-Z0-9])") Then
                    EditError = 1
                    ErrorMsg = "State invalid. No special characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.State
                ElseIf GF.LS.lmailState.ToString.Trim.Length > 2 Then
                    EditError = 1
                    ErrorMsg = "Please shorten State to be 2 characters."
                    SCRIPT0002.FocusField = UserControlLib.NACSZNGS.FieldToFocus.State
                ElseIf CInt(GF.LS.lYear2) = 0 Then
                    EditError = 1
                    ErrorMsg = "Enter the Years at current address"
                    SetFocus("OBJSEL0001")
                ElseIf GF.LS.lPOBoxUsed.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "PO BOX Used is a required field"
                    SetFocus("OBJSEL0002")
                ElseIf (Not GF.LS.lPhysicalAddress1.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lPhysicalAddress1.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Physical Address 1 invalid. No special characters."
                    SCRIPT0003.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address1
                ElseIf (Not GF.LS.lPhysicalAddress2.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lPhysicalAddress2.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Physical Address 2 invalid. No special characters."
                    SCRIPT0003.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address2
                ElseIf (Not GF.LS.lPhysicalCity.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lPhysicalCity.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Physical City invalid. No special characters."
                    SCRIPT0003.FocusField = UserControlLib.NACSZNGS.FieldToFocus.City
                ElseIf (Not GF.LS.lPhysicalState.ToString.Trim.Equals(String.Empty) And Not GF.gfCheckFieldValidity(GF.LS.lPhysicalState.ToString.Trim, "([a-zA-Z0-9])")) Then
                    EditError = 1
                    ErrorMsg = "Physical State invalid. No special characters."
                    SCRIPT0003.FocusField = UserControlLib.NACSZNGS.FieldToFocus.State
                ElseIf GF.LS.lSELECT44.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please select Housing Information"
                    SetFocus("OBJSEL0003")
                ElseIf Not IsNumeric(GF.LS.lman33a.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please round upto nearest dollar. No commas or periods"
                    SetFocus("OBJTXT0014")
                ElseIf CInt(GF.LS.lAge4) < 18 And GF.LS.lRefusedBirth.ToString.Trim.Equals("N") Then
                    EditError = 1
                    ErrorMsg = "Customer must be 18 years of age to apply. Please check date."
                    set_currPath(ScriptPaths.LOG)
                Else
                    '20100603  cgossman  storing complete DOB
                    'call setData  ("LocalStore", "lDate3", getDatatrim ("LocalStore", "lmonth4") & getDatatrim ("LocalStore", "lday4") & getDatatrim ("LocalStore", "lyear4"))
                    Dim bdate As DateTime
                    If IsDate(GF.LS.lmonth4.ToString.Trim & "/" & GF.LS.lday4.ToString.Trim & "/" & GF.LS.lyear4.ToString.Trim) Then
                        bdate = GF.LS.lmonth4.ToString.Trim & "/" & GF.LS.lday4.ToString.Trim & "/" & GF.LS.lyear4.ToString.Trim
                        GF.LS.lDate3 = Format(bdate, "MMddyyyy")
                    Else
                        GF.LS.lDate3 = String.Empty
                    End If

                    ' GF.LS.lNum21 = "64"
                    Select Case GF.LS.lManualOccupation.ToString.Trim
                        Case "C"
                            If CInt(GF.LS.lNum21) < 60 Or CInt(GF.LS.lNum21) > 69 Then
                                OBJDIV0003.Visible = True
                                '60,61,62,63,65,66,67 for Self-employed
                                EditError = 1
                                ErrorMsg = "Please select Occupation Code"
                                SetFocus("OBJSEL0005")
                            End If
                        Case "D"
                            If CInt(GF.LS.lNum21) < 20 Or CInt(GF.LS.lNum21) > 29 Then
                                OBJDIV0004.Visible = True
                                '20,21,22,23,24,25,26,27 for student
                                EditError = 1
                                ErrorMsg = "Please select Occupation Code"
                                SetFocus("OBJSEL0006")
                            End If
                        Case "E"
                            If CInt(GF.LS.lNum21) <> 91 And CInt(GF.LS.lNum21) <> 99 Then
                                OBJDIV0005.Visible = True
                                '91,99 for unemployed
                                EditError = 1
                                ErrorMsg = "Please select Occupation Code"
                                SetFocus("OBJSEL0007")
                            End If
                        Case "F"
                            Select Case GF.LS.lEmployed.ToString.Trim
                                Case "A"
                                    If CInt(GF.LS.lNum21) < 30 Or CInt(GF.LS.lNum21) > 39 Then
                                        OBJDIV0007.Visible = True
                                        '30,31,39 for EDUCATION
                                        EditError = 1
                                        ErrorMsg = "Please select Occupation Code"
                                        SetFocus("OBJSEL0009")
                                    End If
                                Case "B"
                                    If CInt(GF.LS.lNum21) < 40 Or CInt(GF.LS.lNum21) > 49 Then
                                        OBJDIV0008.Visible = True
                                        '40,41,42,43,44,45,46,49 for PERFERED PROFESSIONAL
                                        EditError = 1
                                        ErrorMsg = "Please select Occupation Code"
                                        SetFocus("OBJSEL0010")
                                    End If
                                Case "D"
                                    If CInt(GF.LS.lNum21) < 50 Or CInt(GF.LS.lNum21) > 59 Then
                                        '51,52,53,54,55,56,59 for PROFESSIONAL
                                        OBJDIV0009.Visible = True
                                        EditError = 1
                                        ErrorMsg = "Please select Occupation Code"
                                        SetFocus("OBJSEL0011")
                                    End If
                                Case "E"
                                    If CInt(GF.LS.lNum21) < 70 Or CInt(GF.LS.lNum21) > 79 Then
                                        '70,72,73,74,79 for SKILLED LABOR
                                        OBJDIV0010.Visible = True
                                        EditError = 1
                                        ErrorMsg = "Please select Occupation Code"
                                        SetFocus("OBJSEL0012")
                                    End If
                                Case "G"
                                    If CInt(GF.LS.lNum21) <> 92 AndAlso CInt(GF.LS.lNum21) <> 93 AndAlso CInt(GF.LS.lNum21) <> 40 AndAlso CInt(GF.LS.lNum21) <> 42 AndAlso CInt(GF.LS.lNum21) <> 45 AndAlso CInt(GF.LS.lNum21) <> 50 Then
                                        OBJDIV0011.Visible = True
                                        '92,93,40,42,45,50 for MILITARY
                                        EditError = 1
                                        ErrorMsg = "Please select Occupation Code"
                                        SetFocus("OBJSEL0013")
                                    End If
                                Case Else
                                    OBJDIV0006.Visible = True
                                    EditError = 1
                                    ErrorMsg = "Please select How Employed"
                                    SetFocus("OBJSEL0008")
                            End Select
                        Case Else
                            EditError = 1
                            ErrorMsg = "Please select Occuption"
                            SetFocus("OBJSEL0004")

                    End Select
                End If
            End If
            If EditError = 0 Then
                GF.LS.lROBPayment = CInt(GF.LS.lman33a)
                'concate physical address
                If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
                    If GF.LS.lPhysicalAddress2.ToString.Trim.Equals(String.Empty) Then
                        GF.LS.lPhysicalAddr = GF.LS.lPhysicalAddress1.ToString.Trim & " " & GF.LS.lPhysicalCity.ToString.Trim & " " & GF.LS.lPhysicalState.ToString.Trim & " " & GF.LS.lPhysicalZip.ToString.Trim
                    Else
                        GF.LS.lPhysicalAddr = GF.LS.lPhysicalAddress1.ToString.Trim & " " & GF.LS.lPhysicalAddress2.ToString.Trim & " " & GF.LS.lPhysicalCity.ToString.Trim & " " & GF.LS.lPhysicalState.ToString.Trim & " " & GF.LS.lPhysicalZip.ToString.Trim

                    End If
                End If

                'job code
                Select Case GF.LS.lManualOccupation.ToString.Trim
                    Case "B"  'Retired
                        GF.LS.lNum21 = "10"
                    Case "F" 'employed
                        Select Case GF.LS.lEmployed.ToString.Trim
                            Case "C" 'RN-REGISTER  NURSE
                                GF.LS.lNum21 = "50"
                            Case "F" 'UNSKILLED LABOR
                                GF.LS.lNum21 = "80"
                            Case Else
                        End Select
                    Case Else
                End Select

                'moves lManualOccupation to lSELECT54 to log in secured file
                'for Kent to branch off of type of app
                GF.LS.lSELECT54 = GF.LS.lManualOccupation
            End If
            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

            If Not SCRIPT0002.IsValid Then
                DisplayError(SCRIPT0002.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0003.IsValid Then
                DisplayError(SCRIPT0003.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0004.IsValid Then
                DisplayError(SCRIPT0004.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False

            If CInt(GF.LS.lAge4) >= 18 Or GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
                Select Case GF.LS.lManualOccupation.ToString.Trim
                    Case "B" 'retired
                        nextPanel = Panels.MANUAL.manual0034
                    Case "C"  'Self-Employed
                        nextPanel = Panels.MANUAL.manual0035
                    Case "D"  'STUDENT
                        nextPanel = Panels.MANUAL.manual0047
                    Case "E"  'UNEMPLOYED
                        nextPanel = Panels.MANUAL.manual0037
                    Case "F"  'EMPLOYED
                        nextPanel = Panels.MANUAL.manual0038
                    Case Else
                        endOfPath = True
                End Select
            Else
                endOfPath = True
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

    Private Sub OBJCHK0001_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJCHK0001.CheckedChanged
        PanelEditAutoMapping()
       
        
        If GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
            GF.LS.lmonth4 = String.Empty
            GF.LS.lday4 = String.Empty
            GF.LS.lyear4 = String.Empty
            GF.LS.lDate3 = "00000000"
            GF.LS.lAge4 = 0
            SCRIPT0004.Required = False
        Else
            SCRIPT0004.Required = True
        End If

    End Sub
    
    Private Sub OBJSEL0002_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0002.SelectedIndexChanged
        PanelEditAutoMapping()
        If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
            OBJDIV0004.Visible = True
            SCRIPT0003.Address1Req = True
            SCRIPT0003.CityReq = True
            SCRIPT0003.StateReq = True
            SCRIPT0003.ZipReq = True
        Else
            OBJDIV0004.Visible = False
            SCRIPT0003.Address1Req = False
            SCRIPT0003.CityReq = False
            SCRIPT0003.StateReq = False
            SCRIPT0003.ZipReq = False
        End If
        
    End Sub
   
     
    Private Sub OBJSEL0004_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0004.SelectedIndexChanged, OBJSEL0008.SelectedIndexChanged
        PanelEditAutoMapping()

        '
        Select Case GF.LS.lManualOccupation.ToString.Trim
            Case "B"  'Retired
                OBJDIV0005.Visible = False
                OBJDIV0006.Visible = False
                OBJDIV0007.Visible = False
                OBJDIV0008.Visible = False
                OBJDIV0009.Visible = False
                OBJDIV0010.Visible = False
                OBJDIV0011.Visible = False
                OBJDIV0012.Visible = False
                OBJDIV0013.Visible = False
            Case "C"   'Self-employed
                OBJDIV0005.Visible = True
                OBJDIV0006.Visible = False
                OBJDIV0007.Visible = False
                OBJDIV0008.Visible = False
                OBJDIV0009.Visible = False
                OBJDIV0010.Visible = False
                OBJDIV0011.Visible = False
                OBJDIV0012.Visible = False
                OBJDIV0013.Visible = False
            Case "D" 'student
                OBJDIV0005.Visible = False
                OBJDIV0006.Visible = True
                OBJDIV0007.Visible = False
                OBJDIV0008.Visible = False
                OBJDIV0009.Visible = False
                OBJDIV0010.Visible = False
                OBJDIV0011.Visible = False
                OBJDIV0012.Visible = False
                OBJDIV0013.Visible = False
            Case "E" 'unemployed
                OBJDIV0005.Visible = False
                OBJDIV0006.Visible = False
                OBJDIV0007.Visible = True
                OBJDIV0008.Visible = False
                OBJDIV0009.Visible = False
                OBJDIV0010.Visible = False
                OBJDIV0011.Visible = False
                OBJDIV0012.Visible = False
                OBJDIV0013.Visible = False
            Case "F" 'employed
                OBJDIV0005.Visible = False
                OBJDIV0006.Visible = False
                OBJDIV0007.Visible = False
                OBJDIV0008.Visible = True
                Select Case GF.LS.lEmployed.ToString.Trim
                    Case "A" 'EDUCATION
                        OBJDIV0009.Visible = True
                        OBJDIV0010.Visible = False
                        OBJDIV0011.Visible = False
                        OBJDIV0012.Visible = False
                        OBJDIV0013.Visible = False
                    Case "B" 'PERFERED PROFESSIONAL
                        OBJDIV0009.Visible = False
                        OBJDIV0010.Visible = True
                        OBJDIV0011.Visible = False
                        OBJDIV0012.Visible = False
                        OBJDIV0013.Visible = False
                    Case "C" 'RN-REGISTER  NURSE
                        OBJDIV0009.Visible = False
                        OBJDIV0010.Visible = False
                        OBJDIV0011.Visible = False
                        OBJDIV0012.Visible = False
                        OBJDIV0013.Visible = False
                    Case "D" 'PROFESSIONAL
                        OBJDIV0009.Visible = False
                        OBJDIV0010.Visible = False
                        OBJDIV0011.Visible = True
                        OBJDIV0012.Visible = False
                        OBJDIV0013.Visible = False
                    Case "E" 'SKILLED LABOR
                        OBJDIV0009.Visible = False
                        OBJDIV0010.Visible = False
                        OBJDIV0011.Visible = False
                        OBJDIV0012.Visible = True
                        OBJDIV0013.Visible = False
                    Case "F" 'UNSKILLED LABOR
                        OBJDIV0009.Visible = False
                        OBJDIV0010.Visible = False
                        OBJDIV0011.Visible = False
                        OBJDIV0012.Visible = False
                        OBJDIV0013.Visible = False
                    Case "G" 'MILITARY
                        OBJDIV0009.Visible = False
                        OBJDIV0010.Visible = False
                        OBJDIV0011.Visible = False
                        OBJDIV0012.Visible = False
                        OBJDIV0013.Visible = True
                    Case Else
                End Select
            Case Else
        End Select

    End Sub
  
   
   
    Private Sub OBJRAD0002_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJRAD0002.SelectedIndexChanged
        PanelEditAutoMapping()
        

        Select Case GF.LS.lman49c.ToString.Trim
            Case "Y"
                If GF.LS.lmailFname.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lmailLname.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lAppName.ToString.Trim.Equals(String.Empty) OrElse CInt(GF.LS.lOverCardLimit) > 25 Then
                    OBJDIV0001.Visible = True
                Else
                    OBJDIV0001.Visible = False
                End If
            Case "N"
                OBJDIV0001.Visible = True
            Case Else
        End Select
       

    End Sub
    Private Sub OBJRAD0001_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJRAD0001.SelectedIndexChanged
        PanelEditAutoMapping()
       
        
        Select Case GF.LS.lMan46b.ToString.Trim
            Case "N"
                OBJDIV0003.Visible = True
                SCRIPT0002.Address1Req = True
                SCRIPT0002.CityReq = True
                SCRIPT0002.StateReq = True
                SCRIPT0002.ZipReq = True
            Case Else
                If GF.LS.lmailAdd1.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lmailCity.ToString.Trim.Equals(String.Empty) OrElse _
                 GF.LS.lmailState.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lmailZip.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lmailZip.ToString.Trim.Length <> 5 OrElse Not IsNumeric(GF.LS.lmailZip.ToString.Trim) OrElse GF.LS.lmailAdd1.ToString.Trim.Length > 25 OrElse GF.LS.lmailAdd2.ToString.Trim.Length > 25 OrElse GF.LS.lmailCity.ToString.Trim.Length > 25 OrElse _
                 GF.LS.lmailState.ToString.Trim.Length > 2 Then
                    OBJDIV0003.Visible = True
                    SCRIPT0002.Address1Req = True
                    SCRIPT0002.CityReq = True
                    SCRIPT0002.StateReq = True
                    SCRIPT0002.ZipReq = True
                Else
                    OBJDIV0003.Visible = False
                    SCRIPT0002.Address1Req = False
                    SCRIPT0002.CityReq = False
                    SCRIPT0002.StateReq = False
                    SCRIPT0002.ZipReq = False
                End If
        End Select
        

    End Sub








    Private Sub OBJTXT0017_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJTXT0017.TextChanged
        PanelEditAutoMapping()
        GF.LS.lmailFname = GF.LS.lmailFname.ToString.Trim.ToUpper
        GF.LS.lmailMname = GF.LS.lmailMname.ToString.Trim.ToUpper
        GF.LS.lmailLname = GF.LS.lmailLname.ToString.Trim.ToUpper

        If GF.LS.lmailMname.ToString.Trim.Equals(String.Empty) Then
            GF.LS.lAppName = (GF.LS.lmailFname.ToString.Trim & " " & GF.LS.lmailLname.ToString.Trim)
        Else
            GF.LS.lAppName = (GF.LS.lmailFname.ToString.Trim & " " & GF.LS.lmailMname.ToString.Trim & " " & GF.LS.lmailLname.ToString.Trim)
        End If


    End Sub

    Private Sub OBJTXT0015_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJTXT0015.TextChanged
        PanelEditAutoMapping()
        GF.LS.lOverCardLimit = GF.LS.lAppName.ToString.Trim.Length

        If CInt(GF.LS.lOverCardLimit) > 25 Then
            OBJDIV0002.Visible = True
        Else
            OBJDIV0002.Visible = False
        End If
    End Sub
End Class
