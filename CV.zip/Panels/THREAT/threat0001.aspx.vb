﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class threat0001
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        If GF.LS.lTVoice1 = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lTVoice1 = "N" Then OBJCHK0001.Checked = False
        If GF.LS.lTVoice2 = "Y" Then OBJCHK0002.Checked = True
        If GF.LS.lTVoice2 = "N" Then OBJCHK0002.Checked = False
        If GF.LS.lTVoice3 = "Y" Then OBJCHK0003.Checked = True
        If GF.LS.lTVoice3 = "N" Then OBJCHK0003.Checked = False
        If GF.LS.lTVoice4 = "Y" Then OBJCHK0004.Checked = True
        If GF.LS.lTVoice4 = "N" Then OBJCHK0004.Checked = False
        If GF.LS.lTVoice5 = "Y" Then OBJCHK0005.Checked = True
        If GF.LS.lTVoice5 = "N" Then OBJCHK0005.Checked = False
        If GF.LS.lTVoice6 = "Y" Then OBJCHK0006.Checked = True
        If GF.LS.lTVoice6 = "N" Then OBJCHK0006.Checked = False
        If GF.LS.lTVoice7 = "Y" Then OBJCHK0007.Checked = True
        If GF.LS.lTVoice7 = "N" Then OBJCHK0007.Checked = False
        If GF.LS.lTVoice8 = "Y" Then OBJCHK0008.Checked = True
        If GF.LS.lTVoice8 = "N" Then OBJCHK0008.Checked = False
        If GF.LS.lTVoice9 = "Y" Then OBJCHK0009.Checked = True
        If GF.LS.lTVoice9 = "N" Then OBJCHK0009.Checked = False
        If GF.LS.lTVoice10 = "Y" Then OBJCHK0010.Checked = True
        If GF.LS.lTVoice10 = "N" Then OBJCHK0010.Checked = False
        If GF.LS.lTVoice11 = "Y" Then OBJCHK0011.Checked = True
        If GF.LS.lTVoice11 = "N" Then OBJCHK0011.Checked = False
        If GF.LS.lTVoice12 = "Y" Then OBJCHK0012.Checked = True
        If GF.LS.lTVoice12 = "N" Then OBJCHK0012.Checked = False
        If GF.LS.lTVoice13 = "Y" Then OBJCHK0013.Checked = True
        If GF.LS.lTVoice13 = "N" Then OBJCHK0013.Checked = False
        If GF.LS.lTVoice14 = "Y" Then OBJCHK0014.Checked = True
        If GF.LS.lTVoice14 = "N" Then OBJCHK0014.Checked = False
        If GF.LS.lTVoice15 = "Y" Then OBJCHK0015.Checked = True
        If GF.LS.lTVoice15 = "N" Then OBJCHK0015.Checked = False
        If GF.LS.lTVoice16 = "Y" Then OBJCHK0016.Checked = True
        If GF.LS.lTVoice16 = "N" Then OBJCHK0016.Checked = False
        If GF.LS.lTVoice17 = "Y" Then OBJCHK0017.Checked = True
        If GF.LS.lTVoice17 = "N" Then OBJCHK0017.Checked = False
        If GF.LS.lTVoice18 = "Y" Then OBJCHK0018.Checked = True
        If GF.LS.lTVoice18 = "N" Then OBJCHK0018.Checked = False
        If GF.LS.lTVoice19 = "Y" Then OBJCHK0019.Checked = True
        If GF.LS.lTVoice19 = "N" Then OBJCHK0019.Checked = False
        If GF.LS.lTVoice20 = "Y" Then OBJCHK0020.Checked = True
        If GF.LS.lTVoice20 = "N" Then OBJCHK0020.Checked = False
        If GF.LS.lTVoice21 = "Y" Then OBJCHK0021.Checked = True
        If GF.LS.lTVoice21 = "N" Then OBJCHK0021.Checked = False
        If GF.LS.lTVoice22 = "Y" Then OBJCHK0022.Checked = True
        If GF.LS.lTVoice22 = "N" Then OBJCHK0022.Checked = False
        If GF.LS.lTVoice23 = "Y" Then OBJCHK0023.Checked = True
        If GF.LS.lTVoice23 = "N" Then OBJCHK0023.Checked = False
        If GF.LS.lTVoice24 = "Y" Then OBJCHK0024.Checked = True
        If GF.LS.lTVoice24 = "N" Then OBJCHK0024.Checked = False
        If GF.LS.lTNoise1 = "Y" Then OBJCHK0025.Checked = True
        If GF.LS.lTNoise1 = "N" Then OBJCHK0025.Checked = False
        If GF.LS.lTNoise2 = "Y" Then OBJCHK0026.Checked = True
        If GF.LS.lTNoise2 = "N" Then OBJCHK0026.Checked = False
        If GF.LS.lTNoise3 = "Y" Then OBJCHK0027.Checked = True
        If GF.LS.lTNoise3 = "N" Then OBJCHK0027.Checked = False
        If GF.LS.lTNoise4 = "Y" Then OBJCHK0028.Checked = True
        If GF.LS.lTNoise4 = "N" Then OBJCHK0028.Checked = False
        If GF.LS.lTNoise5 = "Y" Then OBJCHK0029.Checked = True
        If GF.LS.lTNoise5 = "N" Then OBJCHK0029.Checked = False
        If GF.LS.lTNoise6 = "Y" Then OBJCHK0030.Checked = True
        If GF.LS.lTNoise6 = "N" Then OBJCHK0030.Checked = False
        If GF.LS.lTNoise7 = "Y" Then OBJCHK0031.Checked = True
        If GF.LS.lTNoise7 = "N" Then OBJCHK0031.Checked = False
        If GF.LS.lTNoise8 = "Y" Then OBJCHK0032.Checked = True
        If GF.LS.lTNoise8 = "N" Then OBJCHK0032.Checked = False
        If GF.LS.lTNoise9 = "Y" Then OBJCHK0033.Checked = True
        If GF.LS.lTNoise9 = "N" Then OBJCHK0033.Checked = False
        If GF.LS.lTNoise10 = "Y" Then OBJCHK0034.Checked = True
        If GF.LS.lTNoise10 = "N" Then OBJCHK0034.Checked = False
        OBJSEL0001.SelectedValue = GF.LS.lTSex
        OBJSEL0002.SelectedValue = GF.LS.lTAge
        OBJSEL0003.SelectedValue = GF.LS.lTLanguage
        OBJTAR0001.Text = GF.LS.lTThreat
        OBJTXT0003.Text = GF.LS.lTCallingFrom
        OBJTXT0004.Text = GF.LS.lTRace
        SCRIPT0001.ZipCode = GF.LS.lTZip
        SCRIPT0001.Address1 = GF.LS.lTAdd1
        SCRIPT0001.Address2 = GF.LS.lTAdd2
        SCRIPT0001.City = GF.LS.lTCity
        SCRIPT0001.State = GF.LS.lTState
        SCRIPT0001.FirstName = GF.LS.lTFirstName
        SCRIPT0001.LastName = GF.LS.lTLastName
        SCRIPT0001.PhoneAreaCode = GF.LS.lTPhoneArea
        SCRIPT0001.PhonePrefix = GF.LS.lTPhone3
        SCRIPT0001.PhoneExtension = GF.LS.lTPhone4
        TextBox1.Text = GF.NGS.Bomb_Number
        TextBox10.Text = GF.NGS.Kidnapping_What_Do_You_Want
        TextBox11.Text = GF.NGS.Kidnapping_How_Where_When_Delivered
        TextBox12.Text = GF.NGS.Threat_Person_Received
        TextBox13.Text = GF.NGS.Threat_DATE_TIME
        TextBox2.Text = GF.NGS.Bomb_When_Explode
        TextBox3.Text = GF.NGS.Bomb_Located
        TextBox4.Text = GF.NGS.Bomb_Type
        TextBox5.Text = GF.NGS.Bomb_Prank
        TextBox6.Text = GF.NGS.Kidnapping_Who_Is_This
        TextBox7.Text = GF.NGS.Kidnapping_Prank
        TextBox8.Text = GF.NGS.Kidnapping_Victim
        TextBox9.Text = GF.NGS.Kidnapping_Victim_What_Wearing
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        If OBJCHK0001.Checked Then GF.LS.lTVoice1 = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lTVoice1 = "N"
        If OBJCHK0002.Checked Then GF.LS.lTVoice2 = "Y"
        If Not OBJCHK0002.Checked Then GF.LS.lTVoice2 = "N"
        If OBJCHK0003.Checked Then GF.LS.lTVoice3 = "Y"
        If Not OBJCHK0003.Checked Then GF.LS.lTVoice3 = "N"
        If OBJCHK0004.Checked Then GF.LS.lTVoice4 = "Y"
        If Not OBJCHK0004.Checked Then GF.LS.lTVoice4 = "N"
        If OBJCHK0005.Checked Then GF.LS.lTVoice5 = "Y"
        If Not OBJCHK0005.Checked Then GF.LS.lTVoice5 = "N"
        If OBJCHK0006.Checked Then GF.LS.lTVoice6 = "Y"
        If Not OBJCHK0006.Checked Then GF.LS.lTVoice6 = "N"
        If OBJCHK0007.Checked Then GF.LS.lTVoice7 = "Y"
        If Not OBJCHK0007.Checked Then GF.LS.lTVoice7 = "N"
        If OBJCHK0008.Checked Then GF.LS.lTVoice8 = "Y"
        If Not OBJCHK0008.Checked Then GF.LS.lTVoice8 = "N"
        If OBJCHK0009.Checked Then GF.LS.lTVoice9 = "Y"
        If Not OBJCHK0009.Checked Then GF.LS.lTVoice9 = "N"
        If OBJCHK0010.Checked Then GF.LS.lTVoice10 = "Y"
        If Not OBJCHK0010.Checked Then GF.LS.lTVoice10 = "N"
        If OBJCHK0011.Checked Then GF.LS.lTVoice11 = "Y"
        If Not OBJCHK0011.Checked Then GF.LS.lTVoice11 = "N"
        If OBJCHK0012.Checked Then GF.LS.lTVoice12 = "Y"
        If Not OBJCHK0012.Checked Then GF.LS.lTVoice12 = "N"
        If OBJCHK0013.Checked Then GF.LS.lTVoice13 = "Y"
        If Not OBJCHK0013.Checked Then GF.LS.lTVoice13 = "N"
        If OBJCHK0014.Checked Then GF.LS.lTVoice14 = "Y"
        If Not OBJCHK0014.Checked Then GF.LS.lTVoice14 = "N"
        If OBJCHK0015.Checked Then GF.LS.lTVoice15 = "Y"
        If Not OBJCHK0015.Checked Then GF.LS.lTVoice15 = "N"
        If OBJCHK0016.Checked Then GF.LS.lTVoice16 = "Y"
        If Not OBJCHK0016.Checked Then GF.LS.lTVoice16 = "N"
        If OBJCHK0017.Checked Then GF.LS.lTVoice17 = "Y"
        If Not OBJCHK0017.Checked Then GF.LS.lTVoice17 = "N"
        If OBJCHK0018.Checked Then GF.LS.lTVoice18 = "Y"
        If Not OBJCHK0018.Checked Then GF.LS.lTVoice18 = "N"
        If OBJCHK0019.Checked Then GF.LS.lTVoice19 = "Y"
        If Not OBJCHK0019.Checked Then GF.LS.lTVoice19 = "N"
        If OBJCHK0020.Checked Then GF.LS.lTVoice20 = "Y"
        If Not OBJCHK0020.Checked Then GF.LS.lTVoice20 = "N"
        If OBJCHK0021.Checked Then GF.LS.lTVoice21 = "Y"
        If Not OBJCHK0021.Checked Then GF.LS.lTVoice21 = "N"
        If OBJCHK0022.Checked Then GF.LS.lTVoice22 = "Y"
        If Not OBJCHK0022.Checked Then GF.LS.lTVoice22 = "N"
        If OBJCHK0023.Checked Then GF.LS.lTVoice23 = "Y"
        If Not OBJCHK0023.Checked Then GF.LS.lTVoice23 = "N"
        If OBJCHK0024.Checked Then GF.LS.lTVoice24 = "Y"
        If Not OBJCHK0024.Checked Then GF.LS.lTVoice24 = "N"
        If OBJCHK0025.Checked Then GF.LS.lTNoise1 = "Y"
        If Not OBJCHK0025.Checked Then GF.LS.lTNoise1 = "N"
        If OBJCHK0026.Checked Then GF.LS.lTNoise2 = "Y"
        If Not OBJCHK0026.Checked Then GF.LS.lTNoise2 = "N"
        If OBJCHK0027.Checked Then GF.LS.lTNoise3 = "Y"
        If Not OBJCHK0027.Checked Then GF.LS.lTNoise3 = "N"
        If OBJCHK0028.Checked Then GF.LS.lTNoise4 = "Y"
        If Not OBJCHK0028.Checked Then GF.LS.lTNoise4 = "N"
        If OBJCHK0029.Checked Then GF.LS.lTNoise5 = "Y"
        If Not OBJCHK0029.Checked Then GF.LS.lTNoise5 = "N"
        If OBJCHK0030.Checked Then GF.LS.lTNoise6 = "Y"
        If Not OBJCHK0030.Checked Then GF.LS.lTNoise6 = "N"
        If OBJCHK0031.Checked Then GF.LS.lTNoise7 = "Y"
        If Not OBJCHK0031.Checked Then GF.LS.lTNoise7 = "N"
        If OBJCHK0032.Checked Then GF.LS.lTNoise8 = "Y"
        If Not OBJCHK0032.Checked Then GF.LS.lTNoise8 = "N"
        If OBJCHK0033.Checked Then GF.LS.lTNoise9 = "Y"
        If Not OBJCHK0033.Checked Then GF.LS.lTNoise9 = "N"
        If OBJCHK0034.Checked Then GF.LS.lTNoise10 = "Y"
        If Not OBJCHK0034.Checked Then GF.LS.lTNoise10 = "N"
        GF.LS.lTSex = OBJSEL0001.SelectedValue
        GF.LS.lTAge = OBJSEL0002.SelectedValue
        GF.LS.lTLanguage = OBJSEL0003.SelectedValue
        GF.LS.lTThreat = OBJTAR0001.Text
        GF.LS.lTCallingFrom = OBJTXT0003.Text
        GF.LS.lTRace = OBJTXT0004.Text
        GF.LS.lTZip = SCRIPT0001.ZipCode
        GF.LS.lTAdd1 = SCRIPT0001.Address1
        GF.LS.lTAdd2 = SCRIPT0001.Address2
        GF.LS.lTCity = SCRIPT0001.City
        GF.LS.lTState = SCRIPT0001.State
        GF.LS.lTFirstName = SCRIPT0001.FirstName
        GF.LS.lTLastName = SCRIPT0001.LastName
        GF.LS.lTPhoneArea = SCRIPT0001.PhoneAreaCode
        GF.LS.lTPhone3 = SCRIPT0001.PhonePrefix
        GF.LS.lTPhone4 = SCRIPT0001.PhoneExtension
        GF.NGS.Bomb_Number = TextBox1.Text
        GF.NGS.Kidnapping_What_Do_You_Want = TextBox10.Text
        GF.NGS.Kidnapping_How_Where_When_Delivered = TextBox11.Text
        GF.NGS.Threat_Person_Received = TextBox12.Text
        GF.NGS.Threat_DATE_TIME = TextBox13.Text
        GF.NGS.Bomb_When_Explode = TextBox2.Text
        GF.NGS.Bomb_Located = TextBox3.Text
        GF.NGS.Bomb_Type = TextBox4.Text
        GF.NGS.Bomb_Prank = TextBox5.Text
        GF.NGS.Kidnapping_Who_Is_This = TextBox6.Text
        GF.NGS.Kidnapping_Prank = TextBox7.Text
        GF.NGS.Kidnapping_Victim = TextBox8.Text
        GF.NGS.Kidnapping_Victim_What_Wearing = TextBox9.Text
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            GF.LS.lTThreat = String.Empty
            Dim mydate As DateTime
            'Dim time As DateTime

            mydate = Format(Date.Now, "MM/dd/yyyy hh:mm:ss")
            GF.NGS.Threat_DATE_TIME = mydate

            SCRIPT0001.ZipReq = False
            SCRIPT0001.FirstNameReq = False
            SCRIPT0001.LastNameReq = False
            SCRIPT0001.Address1Req = False
            SCRIPT0001.Address2Req = False
            SCRIPT0001.CityReq = False
            SCRIPT0001.StateReq = False
            SCRIPT0001.PhoneRequired = False
            SCRIPT0001.MiddleInitialReq = False

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty
            PanelEditAutoMapping()

            'TODO: 20100520 lapeters - These are not stopping the user.
            If source.Equals("B") Then
                If GF.LS.lTRace.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please type the possible race."
                    SetFocus("OBJTXT0004")
                ElseIf GF.LS.lTThreat.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please type the threat you received."
                    SetFocus("OBJTAR0001")
                ElseIf CInt(GF.LS.lThreatForm).Equals("1") Then
                    ' SETS XLF FLAG TO "Y"
                    GF.NGS.LOGXTDAT = "Y"
                    GF.LS.lXLFmain = "Y"
                    EditError = 1
                    set_currPath(GF.UPC.Script.PreviousPathID)
                ElseIf GF.LS.lThreatForm.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please submit form"
                    SetFocus("OBJBTN0001")
                Else
                    ' Email groups are set and check for production vs test environment is done in gfSendEMailThreat.
                    GF.gfSendEmailThreat()
                    GF.NGS.CountersThreat_Email = 1
                End If
            End If

            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            ''Panel Branching code
            endofpath = True


        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub


#End Region



    Private Sub OBJBTN0001_Click(sender As System.Object, e As System.EventArgs) Handles OBJBTN0001.Click
        Try
            'Code added by converter to duplicate button mapping in BW6
            GF.LS.lThreatForm = "1"
            'parse lTThreat into local stores.
            PanelEditAutoMapping()
            For x = 0 To 950 Step 50
                Dim str As String = ""
                If x = 0 Then
                    If GF.LS.lTThreat.Length <= x + 50 Then
                        str = GF.LS.lTThreat.Substring(x, GF.LS.lTThreat.Length)
                    Else
                        str = GF.LS.lTThreat.Substring(x, 50)
                    End If
                End If

                If x > 0 And x < 950 Then
                    If GF.LS.lTThreat.Length > x And GF.LS.lTThreat.Length <= x + 50 Then

                        str = GF.LS.lTThreat.Substring(x, GF.LS.lTThreat.Length - x)
                    Else
                        If GF.LS.lTThreat.Length > x + 50 Then
                            str = GF.LS.lTThreat.Substring(x, 50)
                        End If
                    End If
                End If
                If x = 950 Then
                    If GF.LS.lTThreat.Length > 950 And GF.LS.lTThreat.Length <= 1000 Then
                        str = GF.LS.lTThreat.Substring(950, GF.LS.lTThreat.Length - 950)
                    End If
                End If

                Select Case x
                    Case 0
                        GF.LS.lTThreat1 = str
                    Case 50
                        GF.LS.lTThreat2 = str
                    Case 100
                        GF.LS.lTThreat3 = str
                    Case 150
                        GF.LS.lTThreat4 = str
                    Case 200
                        GF.LS.lTThreat5 = str
                    Case 250
                        GF.LS.lTThreat6 = str
                    Case 300
                        GF.LS.lTThreat7 = str
                    Case 350
                        GF.LS.lTThreat8 = str
                    Case 400
                        GF.LS.lTThreat9 = str
                    Case 450
                        GF.LS.lTThreat10 = str
                    Case 500
                        GF.LS.lTThreat11 = str
                    Case 550
                        GF.LS.lTThreat12 = str
                    Case 600
                        GF.LS.lTThreat13 = str
                    Case 650
                        GF.LS.lTThreat14 = str
                    Case 700
                        GF.LS.lTThreat15 = str
                    Case 750
                        GF.LS.lTThreat16 = str
                    Case 800
                        GF.LS.lTThreat17 = str
                    Case 850
                        GF.LS.lTThreat18 = str
                    Case 900
                        GF.LS.lTThreat19 = str
                    Case 950
                        GF.LS.lTThreat20 = str
                End Select
                str = String.Empty
            Next x
            'If GF.LS.lTThreat.Length <= 50 Then
            '    GF.LS.lTThreat1 = GF.LS.lTThreat.Substring(0, GF.LS.lTThreat.Length)
            'Else
            '    GF.LS.lTThreat1 = GF.LS.lTThreat.Substring(0, 50)
            'End If
            'If GF.LS.lTThreat.Length > 50 And GF.LS.lTThreat.Length <= 100 Then

            '    GF.LS.lTThreat2 = GF.LS.lTThreat.Substring(50, GF.LS.lTThreat.Length - 50)
            'Else
            '    If GF.LS.lTThreat.Length > 100 Then
            '        GF.LS.lTThreat2 = GF.LS.lTThreat.Substring(50, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 100 And GF.LS.lTThreat.Length <= 150 Then

            '    GF.LS.lTThreat3 = GF.LS.lTThreat.Substring(100, GF.LS.lTThreat.Length - 100)
            'Else
            '    If GF.LS.lTThreat.Length > 150 Then
            '        GF.LS.lTThreat3 = GF.LS.lTThreat.Substring(100, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 150 And GF.LS.lTThreat.Length <= 200 Then

            '    GF.LS.lTThreat4 = GF.LS.lTThreat.Substring(150, GF.LS.lTThreat.Length - 150)
            'Else
            '    If GF.LS.lTThreat.Length > 200 Then
            '        GF.LS.lTThreat4 = GF.LS.lTThreat.Substring(150, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 200 And GF.LS.lTThreat.Length <= 250 Then

            '    GF.LS.lTThreat5 = GF.LS.lTThreat.Substring(200, GF.LS.lTThreat.Length - 200)
            'Else
            '    If GF.LS.lTThreat.Length > 250 Then
            '        GF.LS.lTThreat5 = GF.LS.lTThreat.Substring(200, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 250 And GF.LS.lTThreat.Length <= 300 Then

            '    GF.LS.lTThreat6 = GF.LS.lTThreat.Substring(250, GF.LS.lTThreat.Length - 250)
            'Else
            '    If GF.LS.lTThreat.Length > 300 Then
            '        GF.LS.lTThreat6 = GF.LS.lTThreat.Substring(250, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 300 And GF.LS.lTThreat.Length <= 350 Then

            '    GF.LS.lTThreat7 = GF.LS.lTThreat.Substring(300, GF.LS.lTThreat.Length - 300)
            'Else
            '    If GF.LS.lTThreat.Length > 350 Then
            '        GF.LS.lTThreat7 = GF.LS.lTThreat.Substring(300, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 350 And GF.LS.lTThreat.Length <= 400 Then

            '    GF.LS.lTThreat8 = GF.LS.lTThreat.Substring(350, GF.LS.lTThreat.Length - 350)
            'Else
            '    If GF.LS.lTThreat.Length > 400 Then
            '        GF.LS.lTThreat8 = GF.LS.lTThreat.Substring(350, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 400 And GF.LS.lTThreat.Length <= 450 Then

            '    GF.LS.lTThreat9 = GF.LS.lTThreat.Substring(400, GF.LS.lTThreat.Length - 400)
            'Else
            '    If GF.LS.lTThreat.Length > 450 Then
            '        GF.LS.lTThreat9 = GF.LS.lTThreat.Substring(400, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 450 And GF.LS.lTThreat.Length <= 500 Then

            '    GF.LS.lTThreat10 = GF.LS.lTThreat.Substring(450, GF.LS.lTThreat.Length - 450)
            'Else
            '    If GF.LS.lTThreat.Length > 500 Then
            '        GF.LS.lTThreat10 = GF.LS.lTThreat.Substring(450, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 500 And GF.LS.lTThreat.Length <= 550 Then

            '    GF.LS.lTThreat11 = GF.LS.lTThreat.Substring(500, GF.LS.lTThreat.Length - 500)
            'Else
            '    If GF.LS.lTThreat.Length > 550 Then
            '        GF.LS.lTThreat11 = GF.LS.lTThreat.Substring(500, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 550 And GF.LS.lTThreat.Length <= 600 Then

            '    GF.LS.lTThreat12 = GF.LS.lTThreat.Substring(550, GF.LS.lTThreat.Length - 550)
            'Else
            '    If GF.LS.lTThreat.Length > 600 Then
            '        GF.LS.lTThreat12 = GF.LS.lTThreat.Substring(550, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 600 And GF.LS.lTThreat.Length <= 650 Then

            '    GF.LS.lTThreat13 = GF.LS.lTThreat.Substring(600, GF.LS.lTThreat.Length - 600)
            'Else
            '    If GF.LS.lTThreat.Length > 650 Then
            '        GF.LS.lTThreat13 = GF.LS.lTThreat.Substring(600, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 650 And GF.LS.lTThreat.Length <= 700 Then

            '    GF.LS.lTThreat14 = GF.LS.lTThreat.Substring(650, GF.LS.lTThreat.Length - 650)
            'Else
            '    If GF.LS.lTThreat.Length > 700 Then
            '        GF.LS.lTThreat14 = GF.LS.lTThreat.Substring(650, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 700 And GF.LS.lTThreat.Length <= 750 Then

            '    GF.LS.lTThreat15 = GF.LS.lTThreat.Substring(700, GF.LS.lTThreat.Length - 700)
            'Else
            '    If GF.LS.lTThreat.Length > 750 Then
            '        GF.LS.lTThreat15 = GF.LS.lTThreat.Substring(700, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 750 And GF.LS.lTThreat.Length <= 800 Then

            '    GF.LS.lTThreat16 = GF.LS.lTThreat.Substring(750, GF.LS.lTThreat.Length - 750)
            'Else
            '    If GF.LS.lTThreat.Length > 800 Then
            '        GF.LS.lTThreat16 = GF.LS.lTThreat.Substring(750, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 800 And GF.LS.lTThreat.Length <= 850 Then

            '    GF.LS.lTThreat17 = GF.LS.lTThreat.Substring(800, GF.LS.lTThreat.Length - 800)
            'Else
            '    If GF.LS.lTThreat.Length > 850 Then
            '        GF.LS.lTThreat17 = GF.LS.lTThreat.Substring(800, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 850 And GF.LS.lTThreat.Length <= 900 Then

            '    GF.LS.lTThreat18 = GF.LS.lTThreat.Substring(850, GF.LS.lTThreat.Length - 850)
            'Else
            '    If GF.LS.lTThreat.Length > 900 Then
            '        GF.LS.lTThreat18 = GF.LS.lTThreat.Substring(850, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 900 And GF.LS.lTThreat.Length <= 950 Then

            '    GF.LS.lTThreat19 = GF.LS.lTThreat.Substring(900, GF.LS.lTThreat.Length - 900)
            'Else
            '    If GF.LS.lTThreat.Length > 950 Then
            '        GF.LS.lTThreat19 = GF.LS.lTThreat.Substring(900, 50)
            '    End If
            'End If
            'If GF.LS.lTThreat.Length > 950 And GF.LS.lTThreat.Length <= 1000 Then

            '    GF.LS.lTThreat20 = GF.LS.lTThreat.Substring(950, GF.LS.lTThreat.Length - 950)

            'End If

            ''GF.LS.lTThreat1 = GF.LS.lTThreat.Substring(0, 50)
            ''GF.LS.lTThreat2 = GF.LS.lTThreat.Substring(50, 50)
            ''GF.LS.lTThreat3 = GF.LS.lTThreat.Substring(100, 50)
            ''GF.LS.lTThreat4 = GF.LS.lTThreat.Substring(150, 50)
            ''GF.LS.lTThreat5 = GF.LS.lTThreat.Substring(200, 50)
            ''GF.LS.lTThreat6 = GF.LS.lTThreat.Substring(250, 50)
            ''GF.LS.lTThreat7 = GF.LS.lTThreat.Substring(300, 50)
            ''GF.LS.lTThreat8 = GF.LS.lTThreat.Substring(350, 50)
            ''GF.LS.lTThreat9 = GF.LS.lTThreat.Substring(400, 50)
            ''GF.LS.lTThreat10 = GF.LS.lTThreat.Substring(450, 50)
            ''GF.LS.lTThreat11 = GF.LS.lTThreat.Substring(500, 50)
            ''GF.LS.lTThreat12 = GF.LS.lTThreat.Substring(550, 50)
            ''GF.LS.lTThreat13 = GF.LS.lTThreat.Substring(600, 50)
            ''GF.LS.lTThreat14 = GF.LS.lTThreat.Substring(650, 50)
            ''GF.LS.lTThreat15 = GF.LS.lTThreat.Substring(700, 50)
            ''GF.LS.lTThreat16 = GF.LS.lTThreat.Substring(750, 50)
            ''GF.LS.lTThreat17 = GF.LS.lTThreat.Substring(800, 50)
            ''GF.LS.lTThreat18 = GF.LS.lTThreat.Substring(850, 50)
            ''GF.LS.lTThreat19 = GF.LS.lTThreat.Substring(900, 50)
            ''GF.LS.lTThreat20 = GF.LS.lTThreat.Substring(950, 50)

            PageDown()

        Catch ex As Exception
            HandleExceptions(ex)
        End Try

    End Sub






End Class
