﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class cfresend0002
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0001.Text = GF.UPC.AgentInfo.FullName
        OBJLBL0002.Text = GF.LS.lclose
        OBJTXT0001.Text = GF.LS.lResNo2
        setfocus("OBJTXT0001")
        SCRIPT0002.ZipCode = GF.LS.lmailZip
        SCRIPT0002.Address1 = GF.LS.lmailAdd1
        SCRIPT0002.Address2 = GF.LS.lmailAdd2
        SCRIPT0002.City = GF.LS.lmailCity
        SCRIPT0002.State = GF.LS.lmailState
        SCRIPT0002.FirstName = GF.LS.lmailFname
        SCRIPT0002.LastName = GF.LS.lmailLname
        SCRIPT0002.MiddleInitial = GF.LS.lmailMname
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.UPC.AgentInfo.FullName = OBJLBL0001.Text
        GF.LS.lclose = OBJLBL0002.Text
        GF.LS.lResNo2 = OBJTXT0001.Text
        GF.LS.lmailZip = SCRIPT0002.ZipCode
        GF.LS.lmailAdd1 = SCRIPT0002.Address1
        GF.LS.lmailAdd2 = SCRIPT0002.Address2
        GF.LS.lmailCity = SCRIPT0002.City
        GF.LS.lmailState = SCRIPT0002.State
        GF.LS.lmailFname = SCRIPT0002.FirstName
        GF.LS.lmailLname = SCRIPT0002.LastName
        GF.LS.lmailMname = SCRIPT0002.MiddleInitial
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            SCRIPT0002.ZipReq = True
            SCRIPT0002.StateReq = True
            SCRIPT0002.LastNameReq = True
            SCRIPT0002.MiddleInitialReq = False
            SCRIPT0002.FirstNameReq = True
            SCRIPT0002.CityReq = True
            SCRIPT0002.Address1Req = True

            SCRIPT0001.SelectedDate = Date.Now

            windowOnLoadAutoMapping()


        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source.Equals("B") Then
                If GF.LS.lResNo2.ToString.Trim.Length <> 10 Then
                    EditError = 1
                    ErrorMsg = "Please enter all 10 digits of the reference number"
                    SetFocus("OBJTXT0001")
                ElseIf Not IsNumeric(GF.LS.lResNo2.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please enter numbers only"
                    SetFocus("OBJTXT0001")
                Else
                    GF.NGS.SECXTDAT = "Y"

                    Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                        Case "MBNACNFM", "MBNACNFS", "MBNACFSS"
                            GF.NGS.SELECT26 = "G"
                            GF.NGS.Init_Disp = "I000"
                            GF.NGS.Second_Disp = "IA00"
                            GF.NGS.Third_Disp = String.Empty
                        Case Else
                            GF.NGS.SELECT25 = "G"
                            GF.NGS.Init_Disp = "C000"
                            GF.NGS.Second_Disp = "C800"
                            GF.NGS.Third_Disp = "C8A3"
                    End Select
                    set_currPath(ScriptPaths.LOG)
                End If
            End If

            'end If
            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0002.IsValid Then
                DisplayError(SCRIPT0002.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endofpath = True

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub


#End Region









End Class
