﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class cc0020
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJRAD0002.SelectedValue = GF.NGS.SELECT3
        OBJTAR0001.Text = GF.LS.lCCOtherNotes
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.NGS.SELECT3 = OBJRAD0002.SelectedValue
        GF.LS.lCCOtherNotes = OBJTAR0001.Text
        GF.NGS.lCCOtherNotes = OBJTAR0001.Text
        GF.NGS.BusinessData34 = OBJTAR0001.Text

        If Not OBJRAD0002.SelectedItem Is Nothing Then
            GF.NGS.Dispo1 = OBJRAD0002.SelectedItem.Text
            GF.NGS.BusinessData33 = OBJRAD0002.SelectedItem.Text
        End If

        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            OBJTID0001.Text = GF.LS.lclose.ToString.Trim

            GF.NGS.Third_Disp = String.Empty
            GF.NGS.Fourth_Disp = String.Empty
            GF.NGS.Fifth_Disp = String.Empty
            GF.NGS.SELECT3 = String.Empty

            OBJTAR0001.Text = OBJTAR0001.Text & GF.LS.lCCOtherNotes
            OBJTAR0001.Visible = False
            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            Dim msglen1 As Integer = GF.LS.lCCOtherNotes.ToString.Trim.Length

            'moves comment to saller fields to help with output
            If GF.LS.lCCOtherNotes.Length <= 50 Then
                GF.LS.lOtherNotes1 = GF.LS.lCCOtherNotes.Substring(0, GF.LS.lCCOtherNotes.Length)
            Else
                GF.LS.lOtherNotes1 = GF.LS.lCCOtherNotes.Substring(0, 50)
            End If
            If GF.LS.lCCOtherNotes.Length > 50 And GF.LS.lCCOtherNotes.Length <= 100 Then

                GF.LS.lOtherNotes2 = GF.LS.lCCOtherNotes.Substring(50, GF.LS.lCCOtherNotes.Length - 50)

            End If
            'GF.LS.lOtherNotes1 = GF.LS.lCCOtherNotes.Substring(0, 50)
            'GF.LS.lOtherNotes2 = GF.LS.lCCOtherNotes.Substring(50, 50)

            'SETS XLF FLAG TO A Y
            If GF.NGS.SELECT3.ToString.Trim.Equals("D") Then
                GF.NGS.LOGXTDAT = "Y"
                GF.LS.lXLFmain = "Y"
            End If

            If source.Equals("B") Then
                If GF.NGS.SELECT3.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please make a selection"
                ElseIf (GF.NGS.SELECT3.ToString.Trim.Equals("D") And GF.LS.lCCOtherNotes.ToString.Trim.Equals(String.Empty)) Then
                    EditError = 1
                    ErrorMsg = "Please enter notes."
                    SetFocus("OBJTAR0001")
                ElseIf msglen1 > 101 Then
                    EditError = 1
                    ErrorMsg = "You entered " & msglen1 & " characters. Limit Notes to 100 characters"
                    SetFocus("OBJTAR0001")
                Else
                    EditError = 1
                    set_currPath(ScriptPaths.LOG)
                End If
            End If

            GF.NGS.M_PROB_CALL_I = "I"
            'TODO. 20100515. cshepler. Update option group to use the THIRD_DISP instead of SELECT3
            Select Case GF.NGS.Init_Disp
                Case "A000"
                    Select Case GF.NGS.SELECT3.ToString.Trim
                        'Case "A" 'RATES TOO HIGH
                        'call setData  ("DataStore", "THIRD_DISP", "A2A0" )
                        Case "B" 'PROMO PERIOD TOO SHORT
                            GF.NGS.Third_Disp = "A2A1"
                        Case "C" 'DOES NOT WANT CREDIT CHECK
                            GF.NGS.Third_Disp = "A2A2"
                        Case "D" 'OTHER
                            GF.NGS.Third_Disp = "A2A3"
                            'Case "E" 'CREDIT IS CLOSED
                            'call setData  ("DataStore", "THIRD_DISP", "A2A4" )
                        Case "F" 'STS DOWN - NO RATE INFO
                            GF.NGS.Third_Disp = "A2A5"
                        Case "G" 'BALANCE TRANSFER FEE TOO HIGH
                            GF.NGS.Third_Disp = "A2A6"
                        Case "H" 'CONTRACT RATE (APR)
                            GF.NGS.Third_Disp = "A2A7"
                        Case "I" 'ANNUAL FEE/ FOREIGN TRANSACTION FEE
                            GF.NGS.Third_Disp = "A2A8"
                        Case "J" 'DOESN'T WANT ANOTHER CREDIT CARD
                            GF.NGS.Third_Disp = "A2A9"
                        Case "K" 'DON'T ALLOW BAC TO BAC TRANSFER
                            GF.NGS.Third_Disp = "A2AA"
                        Case "L" 'DOESN'T HAVE TIME TO APPLY
                            GF.NGS.Third_Disp = "A2AB"
                        Case "M" 'OUT OF MARKET AREA/ UNDER 18 / LANGUAGE NOT SUPPORTED
                            GF.NGS.Third_Disp = "A2AC"
                        Case "N" 'WANTS OFFER MAILED TO THEM
                            GF.NGS.Third_Disp = "A2AD"
                        Case "O" 'OH NOT ZERO -- CREDIT LINE NOT HIGH ENOUGH
                            GF.NGS.Third_Disp = "A2AE"
                        Case "P" 'OH NOT ZERO -- CREDIT LINE NOT HIGH ENOUGH
                            GF.NGS.Third_Disp = "A2AF"
                    End Select
            End Select


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            'XP64620 2/12/2014 wzhang Added additional Disposition options under the No Sale.

            Select Case GF.NGS.SELECT3.ToString.Trim
                Case "J"
                    endOfPath = False
                    nextPanel = Panels.CC.cc0025
                Case Else
                    endOfPath = True
            End Select


        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

Private Sub OBJRAD0002_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles OBJRAD0002.SelectedIndexChanged
        PanelEditAutoMapping()
        If GF.NGS.SELECT3.ToString.Trim.Equals("D") Then
            OBJTAR0001.Visible = True
        Else
            OBJTAR0001.Visible = False
        End If

End Sub








End Class
