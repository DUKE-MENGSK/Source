﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class cc0240
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0001.Text = GF.LS.lIVLweb4
        OBJLBL0002.Text = GF.LS.lIVLweb5
        OBJLBL0003.Text = GF.LS.lIVLweb6
        OBJLBL0004.Text = GF.LS.lIVLweb7
        OBJLBL0005.Text = GF.LS.lIVLweb8
        OBJLBL0006.Text = GF.LS.lIVLweb9
        OBJLBL0007.Text = GF.LS.lIVLweb10
        OBJLBL0008.Text = GF.LS.lIVLweb11
        OBJLBL0009.Text = GF.LS.lIVLweb12
        OBJLBL0010.Text = GF.LS.lIVLweb13
        OBJLBL0011.Text = GF.LS.lIVLweb14
        OBJLBL0012.Text = GF.LS.lIVLweb15
        OBJLBL0013.Text = GF.LS.lIVLweb16
        OBJLBL0014.Text = GF.LS.lIVLweb19
        OBJLBL0015.Text = GF.LS.lIVLweb20
        OBJLBL0016.Text = GF.LS.lIVLweb18
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lIVLweb4 = OBJLBL0001.Text
        GF.LS.lIVLweb5 = OBJLBL0002.Text
        GF.LS.lIVLweb6 = OBJLBL0003.Text
        GF.LS.lIVLweb7 = OBJLBL0004.Text
        GF.LS.lIVLweb8 = OBJLBL0005.Text
        GF.LS.lIVLweb9 = OBJLBL0006.Text
        GF.LS.lIVLweb10 = OBJLBL0007.Text
        GF.LS.lIVLweb11 = OBJLBL0008.Text
        GF.LS.lIVLweb12 = OBJLBL0009.Text
        GF.LS.lIVLweb13 = OBJLBL0010.Text
        GF.LS.lIVLweb14 = OBJLBL0011.Text
        GF.LS.lIVLweb15 = OBJLBL0012.Text
        GF.LS.lIVLweb16 = OBJLBL0013.Text
        GF.LS.lIVLweb19 = OBJLBL0014.Text
        GF.LS.lIVLweb20 = OBJLBL0015.Text
        GF.LS.lIVLweb18 = OBJLBL0016.Text
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            GF.NGS.SELECT1 = String.Empty
            GF.NGS.SELECT97 = String.Empty

            If GF.LS.lIVLweb1.ToString.Trim.Equals("0") Then
                Select Case GF.LS.lIVLweb17.ToString.Trim
                    Case "150 day touch base"
                        OBJTID0001.Text = "The attempt to contact you was to thank you for doing business with us. We believe service starts with great communication."
                    Case "90 day touch base"
                        OBJTID0001.Text = "The attempt to contact you was to thank you for doing business with us. We believe service starts with great communication."
                    Case "Account upgrade"
                        OBJTID0001.Text = "The attempt to contact you was because we have upgraded your account. Providing products that will benefit our customers the most allow us to provide world class service."
                    Case "New account welcome call"
                        OBJTID0001.Text = "The attempt to contact you was to thank you for doing business with us. We believe service starts with great communication."
                    Case Else
                        OBJTID0001.Text = "The attempt to contact you was to thank you for doing business with us. We believe service starts with great communication."
                End Select
                OBJDIV0001.Visible = False
                OBJDIV0002.Visible = True
            Else
                OBJTID0001.Text = String.Empty
                OBJDIV0001.Visible = True
                OBJDIV0002.Visible = False
            End If

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            panelEditAutoMapping()

            '"lIVLweb1", /ReplyCode").text )
            '"lIVLweb2", /ReplyMessage").text )
            '"lIVLweb3", HomePhone").text )
            '"lIVLweb4", lt/Title").text )
            '"lIVLweb5", /FirstName").text )
            '"lIVLweb6", /MiddleName").text )
            '"lIVLweb7", lt/LastName").text )
            '"lIVLweb8", /SecondLastName").text )
            '"lIVLweb9", /Suffix").text )
            '"lIVLweb10", /Address1").text )
            '"lIVLweb11",Address2").text )
            '"lIVLweb12", Address3").text )
            '"lIVLweb13", /City").text )
            '"lIVLweb14",t/State").text )
            '"lIVLweb15", /Zip").text )
            '"lIVLweb16",/Last4Account").text )
            '"lIVLweb17",/ProgramCode").text )
            '"lIVLweb18",/GroupTransparent").text )
            '"lIVLweb19",/GroupName").text )
            '"lIVLweb20", /CardType").text )

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endofpath = False
            nextPanel = Panels.CC.cc0019
            'nextPanel = Panels.Other.languagerequest

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub


#End Region


End Class
