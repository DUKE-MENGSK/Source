﻿Imports System.Web.Mail

Public Class cfmanual0016
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0001.Text = GF.LS.lmailFname
        OBJLBL0002.Text = GF.LS.lmailLname
        OBJLBL0003.Text = GF.LS.lDispTotalHHI
        OBJTXT0020.Text = GF.LS.lcfman7a
        OBJTXT0021.Text = GF.LS.lcfman9a
        OBJTXT0022.Text = GF.LS.lcfman3a
        OBJTXT0023.Text = GF.LS.lcfman3c
        OBJSEL0010.SelectedValue = GF.LS.lSELECT45
        OBJSEL0001.SelectedValue = GF.LS.lYear2
        OBJSEL0009.SelectedValue = GF.LS.lSELECT44
        SCRIPT0001.PhoneNumber = GF.LS.lHomePhone
        SCRIPT0001.AreaCode = GF.LS.lmailAreaC
        SCRIPT0001.Prefix = GF.LS.lmailPhone3
        SCRIPT0001.Extension = GF.LS.lmailPhone4
        SCRIPT0002.PhoneNumber = GF.LS.lCellPhone
        SCRIPT0002.AreaCode = GF.LS.lCellArea
        SCRIPT0002.Prefix = GF.LS.lCell3
        SCRIPT0002.Extension = GF.LS.lCell4
        SCRIPT0003.ZipCode = GF.LS.lPhysicalZip
        SCRIPT0003.Address1 = GF.LS.lPhysicalAddress1
        SCRIPT0003.Address2 = GF.LS.lPhysicalAddress2
        SCRIPT0003.City = GF.LS.lPhysicalCity
        SCRIPT0003.State = GF.LS.lPhysicalState
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lmailFname = OBJLBL0001.Text
        GF.LS.lmailLname = OBJLBL0002.Text
        GF.LS.lDispTotalHHI = OBJLBL0003.Text
        GF.LS.lcfman7a = OBJTXT0020.Text
        GF.LS.lcfman9a = OBJTXT0021.Text
        GF.LS.lcfman3a = OBJTXT0022.Text
        GF.LS.lcfman3c = OBJTXT0023.Text
        GF.LS.lSELECT45 = OBJSEL0010.SelectedValue
        GF.LS.lYear2 = OBJSEL0001.SelectedValue
        GF.LS.lSELECT44 = OBJSEL0009.SelectedValue
        GF.LS.lHomePhone = SCRIPT0001.PhoneNumber
        GF.LS.lmailAreaC = SCRIPT0001.AreaCode
        GF.LS.lmailPhone3 = SCRIPT0001.Prefix
        GF.LS.lmailPhone4 = SCRIPT0001.Extension
        GF.LS.lCellPhone = SCRIPT0002.PhoneNumber
        GF.LS.lCellArea = SCRIPT0002.AreaCode
        GF.LS.lCell3 = SCRIPT0002.Prefix
        GF.LS.lCell4 = SCRIPT0002.Extension
        GF.LS.lPhysicalZip = SCRIPT0003.ZipCode
        GF.LS.lPhysicalAddress1 = SCRIPT0003.Address1
        GF.LS.lPhysicalAddress2 = SCRIPT0003.Address2
        GF.LS.lPhysicalCity = SCRIPT0003.City
        GF.LS.lPhysicalState = SCRIPT0003.State
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            'TextID
            OBJTID0001.Text = String.Empty
            'Script
            SCRIPT0003.Visible = False

            SCRIPT0001.PhoneRequired = True
            SCRIPT0001.Prompt = "Primary Phone Number: "
            SCRIPT0002.PhoneRequired = False
            SCRIPT0002.Prompt = "Cell Phone Number: "

            If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
                OBJTID0001.Text = "Physical Address when PO Box is used: "
                SCRIPT0003.Visible = True
                SCRIPT0003.MiddleInitialReq = False
            End If

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source.Equals("B") Then
                If Not IsNumeric(GF.LS.lcfman7a.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please enter Salary as currency only"
                    SetFocus("OBJTXT0020")
                ElseIf GF.LS.lSELECT45.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Select Frequency"
                    SetFocus("OBJSEL0010")
                ElseIf Not IsNumeric(GF.LS.lcfman9a.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please enter currency only. Cannot be blank."
                    SetFocus("OBJTXT0021")
                    Exit Sub
                ElseIf CInt(GF.LS.lYear2).Equals(0) Then
                    EditError = 1
                    ErrorMsg = "Enter the Years at current address"
                    SetFocus("OBJSEL0001")
                ElseIf GF.LS.lSELECT44.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please select Housing Information"
                    SetFocus("OBJSEL0003")
                ElseIf Not IsNumeric(GF.LS.lcfman3a.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Enter in Monthly Payment Amount in Currency Only"
                    SetFocus("OBJTXT0014")
                ElseIf Not IsNumeric(GF.LS.lcfman3c.ToString.Trim) Then
                    EditError = 1
                    ErrorMsg = "Please round up to nearest dollar. No commas or periods. Cannot be blank."
                    SetFocus("OBJTXT0023")
                ElseIf (Not GF.LS.lHomePhone.ToString.Trim.Equals(String.Empty) And GF.gfCheckFieldValidity(GF.LS.lHomePhone.ToString.Trim, "([0-9])\1{9,}")) Then
                    EditError = 1
                    ErrorMsg = "Invalid Primary Phone"
                    SCRIPT0001.Focus_AreaCode()
                ElseIf (Not GF.LS.lCellPhone.ToString.Trim.Equals(String.Empty) And GF.gfCheckFieldValidity(GF.LS.lCellPhone.ToString.Trim, "([0-9])\1{9,}")) Then
                    EditError = 1
                    ErrorMsg = "Invalid Cell Phone"
                    SCRIPT0002.Focus_AreaCode()
                Else
                    GF.LS.lFairMarketValue = CInt(GF.LS.lcfman3c)
                    GF.LS.lCheckAmt5 = CInt(GF.LS.lcfman9a)
                    GF.LS.lCheckAmt1 = CInt(GF.LS.lcfman7a)
                    GF.LS.lAmt4 = CInt(GF.LS.lcfman3a)
                End If
            End If

            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0002.IsValid Then
                DisplayError(SCRIPT0002.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0003.IsValid Then
                DisplayError(SCRIPT0003.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
                OBJTID0001.Text = "Physical Address when PO Box is used: "
                SCRIPT0003.Visible = True
            End If

            GF.LS.lTotalincome = CInt(GF.LS.lcfman7a) + CInt(GF.LS.lCheckAmt5)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            
            PanelEditAutoMapping()

            If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
                OBJTID0001.Text = "Physical Address when PO Box is used: "
                SCRIPT0003.Visible = True
            End If

            GF.LS.lTotalincome = CInt(GF.LS.lcfman7a) + CInt(GF.LS.lCheckAmt5)
            endOfPath = False
            nextPanel = Panels.CFMANUAL.cfmanual0017

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub


#End Region

    'Private Sub OBJSEL0010_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJSEL0010.SelectedIndexChanged
    '    PanelEditAutoMapping()

    '    If GF.LS.lPOBoxUsed.ToString.Trim.Equals("Y") Then
    '        OBJTID0001.Text = "Physical Address when PO Box is used: "
    '        SCRIPT0003.Visible = True
    '    End If

    '    GF.LS.lTotalincome = GF.ConvertToInteger(GF.LS.lcfman7a) + GF.ConvertToInteger(GF.LS.lCheckAmt5)

    'End Sub
    Private Sub OBJBTN0001_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OBJBTN0001.Click
        Try
            PanelEditAutoMapping()
            GF.LS.lDispTotalHHI = CInt(GF.LS.lcfman7a) + CInt(GF.LS.lcfman9a)
            WindowOnLoadAutoMapping()
        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub





End Class
