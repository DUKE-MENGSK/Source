﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class cfmanual0015
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJSEL0011.SelectedValue = GF.LS.lPOBoxUsed
        OBJSEL0010.SelectedValue = GF.LS.lManualOccupation
        If GF.LS.lSSNRefused = "Y" Then OBJCHK0002.Checked = True
        If GF.LS.lSSNRefused = "N" Then OBJCHK0002.Checked = False
        If GF.LS.lRefusedBirth = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lRefusedBirth = "N" Then OBJCHK0001.Checked = False
        SCRIPT0003.ZipCode = GF.LS.lmailZip
        SCRIPT0003.Address1 = GF.LS.lmailAdd1
        SCRIPT0003.Address2 = GF.LS.lmailAdd2
        SCRIPT0003.City = GF.LS.lmailCity
        SCRIPT0003.State = GF.LS.lmailState
        SCRIPT0003.FirstName = GF.LS.lmailFname
        SCRIPT0003.LastName = GF.LS.lmailLname
        SCRIPT0003.MiddleInitial = GF.LS.lmailMname
        'SCRIPT0001.SSN1 = GF.LS.lCustSSN1
        'SCRIPT0001.SSN2 = GF.LS.lCustSSN2
        'SCRIPT0001.SSN3 = GF.LS.lCustSSN3
        TextBox1.Text = GF.LS.lCustSSN1
        TextBox2.Text = GF.LS.lCustSSN2
        TextBox3.Text = GF.LS.lCustSSN3
        SCRIPT0002.Month = GF.LS.lmonth4
        SCRIPT0002.Day = GF.LS.lday4
        SCRIPT0002.Year = GF.LS.lyear4
        If GF.LS.lAge4 isnot String.Empty then 
            SCRIPT0002.Age = CInt(GF.LS.lAge4)
        End If
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lPOBoxUsed = OBJSEL0011.SelectedValue
        GF.LS.lManualOccupation = OBJSEL0010.SelectedValue
        If OBJCHK0002.Checked Then GF.LS.lSSNRefused = "Y"
        If Not OBJCHK0002.Checked Then GF.LS.lSSNRefused = "N"
        If OBJCHK0001.Checked Then GF.LS.lRefusedBirth = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lRefusedBirth = "N"
        GF.LS.lmailZip = SCRIPT0003.ZipCode
        GF.LS.lmailAdd1 = SCRIPT0003.Address1
        GF.LS.lmailAdd2 = SCRIPT0003.Address2
        GF.LS.lmailCity = SCRIPT0003.City
        GF.LS.lmailState = SCRIPT0003.State
        GF.LS.lmailFname = SCRIPT0003.FirstName
        GF.LS.lmailLname = SCRIPT0003.LastName
        GF.LS.lmailMname = SCRIPT0003.MiddleInitial
        'GF.LS.lCustSSN1 = SCRIPT0001.SSN1
        'GF.LS.lCustSSN2 = SCRIPT0001.SSN2
        'GF.LS.lCustSSN3 = SCRIPT0001.SSN3
        GF.LS.lCustSSN1 = TextBox1.Text
        GF.LS.lCustSSN2 = TextBox2.Text
        GF.LS.lCustSSN3 = TextBox3.Text
        GF.LS.lmonth4 = SCRIPT0002.Month
        GF.LS.lday4 = SCRIPT0002.Day
        GF.LS.lyear4 = SCRIPT0002.Year
        GF.LS.lAge4 = SCRIPT0002.Age

        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            SCRIPT0002.MonthPrompt = "Date of Birth: "
            SCRIPT0003.MiddleInitialReq = False

            windowOnLoadAutoMapping()


        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            panelEditAutoMapping()
            GF.LS.lSSNum = GF.LS.lCustSSN1.ToString.Trim & GF.LS.lCustSSN2.ToString.Trim & GF.LS.lCustSSN3.ToString.Trim
           
            If source.Equals("B") Then
                If Not (TextBox1.Text.Equals(String.Empty) AndAlso TextBox2.Text.Equals(String.Empty) AndAlso TextBox3.Text.Equals(String.Empty)) Then
                    If Not IsNumeric(TextBox1.Text) OrElse Not IsNumeric(TextBox2.Text) OrElse Not IsNumeric(TextBox3.Text) Then
                        EditError = 1
                        ErrorMsg = "Please Enter numeric values only in ssn"

                    End If
                End If
                'PO Box question
                If GF.LS.lPOBoxUsed.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "PO BOX Used is a required field"
                    SetFocus("OBJSEL0011")
                ElseIf (CInt(GF.LS.lCustSSN1).Equals(0) And GF.LS.lSSNRefused.ToString.Trim.Equals("N")) Then
                    EditError = 1
                    ErrorMsg = "Enter in SSN or Check Refused"
                    SetFocus("OBJCHK0002")
                ElseIf (CInt(GF.LS.lAge4) < 18 And GF.LS.lRefusedBirth.ToString.Trim.Equals("N")) Then
                    EditError = 1
                    ErrorMsg = "Customer must be 18 years of age to apply. Please check date."
                    SCRIPT0002.Focus()
                    'occupation check
                ElseIf GF.LS.lManualOccupation.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Please Select Job Code"
                    SetFocus("OBJSEL0004")
                ElseIf (GF.LS.lSSNRefused.ToString.Trim.Equals("N") And GF.gfCheckFieldValidity(GF.LS.lSSNum.ToString.Trim, "([0-9])\1{8,}")) Then
                    EditError = 1
                    ErrorMsg = "Invalid SSN"
                    SCRIPT0001.Focus()
                Else
                    'SSN DOB refused
                    If GF.LS.lSSNRefused.ToString.Trim.Equals("Y") Then
                        SCRIPT0001.Required = False
                        GF.LS.lOtherNotes1 = "Refused to give DOB/SSN"
                        GF.NGS.Init_Disp = "G000"
                        GF.NGS.Second_Disp = "G200"
                        GF.NGS.Third_Disp = "G2A3"
                        EditError = 1
                        set_currPath(ScriptPaths.LOG)
                    ElseIf GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
                        SCRIPT0002.Required = False
                        GF.LS.lDate3 = "00000000"
                        GF.LS.lOtherNotes1 = "Refused to give DOB/SSN"
                        GF.NGS.Init_Disp = "G000"
                        GF.NGS.Second_Disp = "G200"
                        GF.NGS.Third_Disp = "G2A3"
                        EditError = 1
                        set_currPath(ScriptPaths.LOG)
                    Else
                        SCRIPT0001.Required = True

                        SCRIPT0002.Required = True
                        '20100610  lapeters  storing full DOB
                        'call setData  ("LocalStore", "lDate3", getDatatrim ("LocalStore", "lmonth4") & getDatatrim ("LocalStore", "lday4") & getDatatrim ("LocalStore", "lyear4"))
                        Dim bdate As DateTime
                        If IsDate(GF.LS.lmonth4.ToString.Trim & "/" & GF.LS.lday4.ToString.Trim & "/" & GF.LS.lyear4.ToString.Trim) Then
                            bdate = GF.LS.lmonth4.ToString.Trim & "/" & GF.LS.lday4.ToString.Trim & "/" & GF.LS.lyear4.ToString.Trim
                            GF.LS.lDate3 = Format(bdate, "MMddyyyy")
                        Else
                            GF.LS.lDate3 = String.Empty
                        End If
                    End If
                End If
            End If

            'If Not SCRIPT0001.isValid Then
            '    DisplayError(SCRIPT0001.ErrorMessages())
            '    EditError = 1
            '    Exit Sub
            'End If

            If Not SCRIPT0002.isValid Then
                DisplayError(SCRIPT0002.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

            If Not SCRIPT0003.isValid Then
                DisplayError(SCRIPT0003.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False

            If GF.LS.lSSNRefused.ToString.Trim.Equals("Y") Or GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
                endOfPath = True
            Else
                nextPanel = Panels.CFMANUAL.cfmanual0016
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

Private Sub OBJCHK0002_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0002.CheckedChanged
        

        If GF.LS.lSSNRefused.ToString.Trim.Equals("Y") Then
            GF.LS.lSSN1a = String.Empty
            GF.LS.lSSN2a = String.Empty
            GF.LS.lSSN3a = String.Empty
            GF.LS.lSSNum = 0
        End If

End Sub
Private Sub OBJCHK0001_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0001.CheckedChanged
        If GF.LS.lRefusedBirth.ToString.Trim.Equals("Y") Then
            GF.LS.lmonth4 = String.Empty
            GF.LS.lday4 = String.Empty
            GF.LS.lyear4 = String.Empty
            GF.LS.lDate3 = "00000000"
            GF.LS.lAge4 = 0
        End If


End Sub



End Class
