﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class cfmanual0019
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJLBL0002.Text = GF.LS.lmailFname
        OBJLBL0003.Text = GF.LS.lmailLname
        OBJTXT0016.Text = GF.LS.lCoAppFname
        OBJTXT0017.Text = GF.LS.lCoAppMI
        OBJTXT0018.Text = GF.LS.lCoAppLname
        OBJRAD0001.SelectedValue = GF.LS.lSameAddress
        If GF.LS.lCoAppSSNrefused = "Y" Then OBJCHK0002.Checked = True
        If GF.LS.lCoAppSSNrefused = "N" Then OBJCHK0002.Checked = False
        If GF.LS.lCoAppDOBrefused = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lCoAppDOBrefused = "N" Then OBJCHK0001.Checked = False
        'SCRIPT0001.SSN1 = GF.LS.lCoAppSSN1a
        'SCRIPT0001.SSN2 = GF.LS.lCoAppSSN2a
        'SCRIPT0001.SSN3 = GF.LS.lCoAppSSN3a
        TextBox1.Text = GF.LS.lCoAppSSN1a
        TextBox2.Text = GF.LS.lCoAppSSN2a
        TextBox3.Text = GF.LS.lCoAppSSN3a

        SCRIPT0002.Month = GF.LS.lCoAppmm
        SCRIPT0002.Day = GF.LS.lCoAppdd
        SCRIPT0002.Year = GF.LS.lCoAppyyyy
        SCRIPT0002.Age = GF.LS.lAge4
        SCRIPT0003.ZipCode = GF.LS.lCoAppZip
        SCRIPT0003.Address1 = GF.LS.lCoAppAdd1
        SCRIPT0003.Address2 = GF.LS.lCoAppAdd2
        SCRIPT0003.City = GF.LS.lCoAppCity
        SCRIPT0003.State = GF.LS.lCoAppState
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lmailFname = OBJLBL0002.Text
        GF.LS.lmailLname = OBJLBL0003.Text
        GF.LS.lCoAppFname = OBJTXT0016.Text
        GF.LS.lCoAppMI = OBJTXT0017.Text
        GF.LS.lCoAppLname = OBJTXT0018.Text
        GF.LS.lSameAddress = OBJRAD0001.SelectedValue
        If OBJCHK0002.Checked Then GF.LS.lCoAppSSNrefused = "Y"
        If Not OBJCHK0002.Checked Then GF.LS.lCoAppSSNrefused = "N"
        If OBJCHK0001.Checked Then GF.LS.lCoAppDOBrefused = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lCoAppDOBrefused = "N"
        'GF.LS.lCoAppSSN1a = SCRIPT0001.SSN1
        'GF.LS.lCoAppSSN2a = SCRIPT0001.SSN2
        'GF.LS.lCoAppSSN3a = SCRIPT0001.SSN3
        GF.LS.lCoAppSSN1a = TextBox1.Text
        GF.LS.lCoAppSSN2a = TextBox2.Text
        GF.LS.lCoAppSSN3a = TextBox3.Text
        GF.LS.lCoAppmm = SCRIPT0002.Month
        GF.LS.lCoAppdd = SCRIPT0002.Day
        GF.LS.lCoAppyyyy = SCRIPT0002.Year
        GF.LS.lAge4 = SCRIPT0002.Age
        GF.LS.lCoAppZip = SCRIPT0003.ZipCode
        GF.LS.lCoAppAdd1 = SCRIPT0003.Address1
        GF.LS.lCoAppAdd2 = SCRIPT0003.Address2
        GF.LS.lCoAppCity = SCRIPT0003.City
        GF.LS.lCoAppState = SCRIPT0003.State
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            'Address: Hide until lSameAddress (Is Address Different From Primary?) is checked (Yes).
            'Make not required unless it needs to be displayed.  Then make required.
            SCRIPT0003.Address1Req = False
            SCRIPT0003.CityReq = False
            SCRIPT0003.StateReq = False
            SCRIPT0003.ZipReq = False

            'Hide Address unless Is Address Different From Primary?(lSameAddress) = Y
            SCRIPT0003.VISIBLE = False

            SCRIPT0002.MonthPrompt = "Date of Birth: "

            windowOnLoadAutoMapping()


        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()
            If Not (TextBox1.Text.Equals(String.Empty) AndAlso TextBox2.Text.Equals(String.Empty) AndAlso TextBox3.Text.Equals(String.Empty)) Then
                If Not IsNumeric(TextBox1.Text) OrElse Not IsNumeric(TextBox2.Text) OrElse Not IsNumeric(TextBox3.Text) Then
                    EditError = 1
                    ErrorMsg = "Please Enter numeric values only in ssn"

                End If
            End If
            GF.LS.lCoAppSSN = GF.LS.lCoAppSSN1a.ToString.Trim & GF.LS.lCoAppSSN2a.ToString.Trim & GF.LS.lCoAppSSN3a.ToString.Trim
            
            If source = "B" Then
                'If SSN or DOB refused log call
                If (GF.LS.lCoAppSSNrefused.ToString.Trim.Equals("Y") Or GF.LS.lCoAppDOBrefused.ToString.Trim.Equals("Y")) Then
                    'make SSN not required
                    SCRIPT0001.Required = False
                    'make DOB not required
                    SCRIPT0002.Required = False
                    GF.LS.lOtherNotes1 = "Refused to give DOB/SSN"
                    GF.NGS.Init_Disp = "G000"
                    GF.NGS.Second_Disp = "G200"
                    GF.NGS.Third_Disp = "G2A3"
                    GF.NGS.Fourth_Disp = String.Empty
                    GF.NGS.Fifth_Disp = String.Empty
                    GF.NGS.Sixth_Disp = String.Empty
                    GF.NGS.Seventh_Disp = String.Empty
                    GF.NGS.Eighth_Disp = String.Empty
                    GF.NGS.NINTH_DISP = String.Empty
                    EditError = 1
                    set_currPath(ScriptPaths.LOG)
                    ErrorMsg = "SSN and DOB are required."
                    'Name check
                ElseIf GF.LS.lCoAppFname.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Enter Co-Applicants First Name"
                    SetFocus("OBJTXT0016")
                ElseIf GF.LS.lCoAppLname.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Enter Co-Applicants Last Name"
                    SetFocus("OBJTXT0018")
                    ''SSN check
                ElseIf (GF.LS.lCoAppSSNrefused.ToString.Trim.Equals("N") And GF.gfCheckFieldValidity(GF.LS.lCoAppSSN.ToString.Trim, "([0-9])\1{8,}")) Then
                    EditError = 1
                    ErrorMsg = "Invalid SSN."
                    SCRIPT0001.Focus()
                ElseIf (GF.LS.lRefusedBirth.ToString.Trim.Equals("N") And CInt(GF.LS.lAge4) < 18) Then
                    EditError = 1
                    ErrorMsg = "Co-Applicant must be 18 years of age. Please check date."
                    SCRIPT0002.Focus()
                    'Is Address Different From Primary? N = Same
                ElseIf GF.LS.lSameAddress.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Is Address Different From Primary?"
                    SetFocus("OBJRAD0001")
                    'If the iSameAddress = Y means address is different from the primary applicant.  Enter CoApp's address.
                ElseIf GF.LS.lSameAddress.Equals("Y") Then
                    'display address fields
                    SCRIPT0003.Visible = True
                    'make fields required
                    SCRIPT0003.Address1Req = True
                    SCRIPT0003.CityReq = True
                    SCRIPT0003.StateReq = True
                    SCRIPT0003.ZipReq = True
                ElseIf GF.LS.lSameAddress.Equals("N") Then
                    'If the CoApp address is not different, then populate the CoApp fields with the applicants address.
                    GF.LS.lCoAppZip = GF.LS.lmailZip
                    GF.LS.lCoAppAdd1 = GF.LS.lmailAdd1
                    GF.LS.lCoAppAdd2 = GF.LS.lmailAdd2
                    GF.LS.lCoAppCity = GF.LS.lmailCity
                    GF.LS.lCoAppState = GF.LS.lmailState
                End If

                '20100610  lapeters  storing full DOB
                '20100615  lapeters  replaced lmonth4, lday4, lyear4, lDate3 with CoApp fields.
                'call setData  ("LocalStore", "lCoAppDOB", getDatatrim ("LocalStore", "lCoAppmm") & getDatatrim ("LocalStore", "lCoAppdd") & getDatatrim ("LocalStore", "lCoAppyyyy"))

                Dim bdate As DateTime
                If IsDate(GF.LS.lCoAppmm.ToString.Trim & "/" & GF.LS.lCoAppdd.ToString.Trim & "/" & GF.LS.lCoAppyyyy.ToString.Trim) Then
                    bdate = GF.LS.lCoAppmm.ToString.Trim & "/" & GF.LS.lCoAppdd.ToString.Trim & "/" & GF.LS.lCoAppyyyy.ToString.Trim
                    GF.LS.lCoAppDOB = Format(bdate, "MMddyyyy")
                Else
                    'make DOB not required
                    SCRIPT0002.Required = False
                    GF.LS.lCoAppDOB = String.Empty
                End If

            End If

            'If Not SCRIPT0001.IsValid Then
            '    DisplayError(SCRIPT0001.ErrorMessages())
            '    EditError = 1
            '    Exit Sub
            'End If
            If Not SCRIPT0002.IsValid Then
                DisplayError(SCRIPT0002.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0003.IsValid Then
                DisplayError(SCRIPT0003.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            If GF.LS.lCoAppSSNrefused.ToString.Trim.Equals("Y") Or GF.LS.lCoAppDOBrefused.ToString.Trim.Equals("Y") Then
                'log the call.
                endOfPath = True
            Else
                'continue
                nextPanel = Panels.CFMANUAL.cfmanual0020
                endOfPath = False
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

Private Sub OBJCHK0002_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0002.CheckedChanged
        PanelEditAutoMapping()

        'SSN
        'If no SSN entered check box Refused.  Y = refused
        If GF.LS.lCoAppSSNrefused.ToString.Trim.Equals("Y") Then
            SCRIPT0001.Required = False
            GF.LS.lCoAppSSN1a = String.Empty
            GF.LS.lCoAppSSN2a = String.Empty
            GF.LS.lCoAppSSN3a = String.Empty
            GF.LS.lCoAppSSNum = 0
        Else
            SCRIPT0001.Required = True
        End If


End Sub
Private Sub OBJCHK0001_CheckedChanged(sender As Object, e As System.EventArgs) Handles OBJCHK0001.CheckedChanged
        PanelEditAutoMapping()


        'DOB
        ''            'If birth date Reused, check box:.  Y = refused
        'If GF.LS.lCoAppDOBrefused.ToString.Trim.Equals("Y") Then
        '    SCRIPT0002.Required = False
        '    SCRIPT0002.SetMonthReq(False)
        '    GF.LS.lCoAppmm = String.Empty
        '    GF.LS.lCoAppdd = String.Empty
        '    GF.LS.lCoAppyyyy = String.Empty
        '    GF.LS.lCoAppDOB = 0
        'Else
        '    SCRIPT0002.Required = True
        '    SCRIPT0002.SetMonthReq(True)
        'End If



        'DOB
        'If birth date Reused, check box:.  Y = refused
        If GF.LS.lCoAppDOBrefused.ToString.Trim.Equals("Y") Then
            SCRIPT0002.Required = False
            'SCRIPT0002.SetMonthReq(False)
            GF.LS.lCoAppmm = String.Empty
            GF.LS.lCoAppdd = String.Empty
            GF.LS.lCoAppyyyy = String.Empty
            GF.LS.lCoAppDOB = 0
        Else
            SCRIPT0002.Required = True
            'SCRIPT0002.SetMonthReq(True)
        End If

    End Sub
Private Sub OBJRAD0001_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles OBJRAD0001.SelectedIndexChanged
        PanelEditAutoMapping()

        'If "Is Address Different From Primary" (lSameAddress) = Y then the coapplicant's address is required.
        If GF.LS.lSameAddress.ToString.Trim.Equals("Y") Then
            SCRIPT0003.Visible = True
            SCRIPT0003.Address1Req = True
            SCRIPT0003.CityReq = True
            SCRIPT0003.StateReq = True
            SCRIPT0003.ZipReq = True
            SCRIPT0003.MiddleInitialReq = False
            'If the address is the same as the primary applicant...
            ' the primary's address is copied to the CoApp's address...
            ' in the panelEdit code.
        Else
            SCRIPT0003.Visible = False
            SCRIPT0003.Address1Req = False
            SCRIPT0003.CityReq = False
            SCRIPT0003.StateReq = False
            SCRIPT0003.ZipReq = False

        End If

End Sub








   
End Class
