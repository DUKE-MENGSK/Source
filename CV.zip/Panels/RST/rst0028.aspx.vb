﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDataSets
Imports WestSharedFunctions

Public Class rst0028
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()	
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()	
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            'KVYAS 10252011 ADDED FOR XP# 35689
            GF.LogSystemMessageDB("Logging", "In LogCall function of LOGGING = M_PROB_CALL_I " & GF.NGS.M_PROB_CALL_I.ToString(), CBool(GF.UPC.Script.DEBUGON))

            If Not GF.NGS.SELECT10.ToString.Trim.Equals(String.Empty) Then

                'testdata
                'call setData ("LocalStore", "lDNC1AREAC", 402)
                'call setData  ("LocalStore", "lDNC2AREAC", 402)
                'call setData ("LocalStore", "lDNC1PHONE3", 333)
                'call setData  ("DataStore", "PHONE_3_2", 333)
                'call setData ("LocalStore", "lDNC1PHONE4", 5555)
                'call setData  ("DataStore", "PHONE_4_2", 5555)
                'call setData  ("DataStore", "M_FIRST_NAME","Barb")
                'call setData  ("DataStore", "FIRSTNAME2","Barb")
                'call setData  ("DataStore", "M_LAST_NAME","Eischeid")
                'call setData  ("DataStore", "LASTNAME2","Eischeid")
                'call setData  ("DataStore", "SELECT32","A")
                'call setData  ("DataStore", "SELECT35","A")
                'call setData  ("DataStore", "M_ADDRESS1","14515")
                'call setData  ("DataStore", "ADDRESSONE2","14515")
                'call setData  ("DataStore", "M_ADDRESS2",String.Empty)
                'call setData  ("DataStore", "ADDRESSTWO2",String.Empty)
                'call setData  ("DataStore", "M_CITY","Omaha")
                'call setData  ("DataStore", "CITY_2","Omaha")
                'call setData  ("DataStore", "M_STATE","NE")
                'call setData  ("DataStore", "STATE_2","NE")
                'call setData  ("DataStore", "M_ZIP","90210")
                'call setData  ("DataStore", "ZIP_2","90210")

                If GF.LS.lDNC1AREAC.ToString.Trim = GF.LS.lDNC2AREAC.ToString.Trim AndAlso GF.LS.lDNC1PHONE3.ToString.Trim = GF.NGS.PHONE_3_2.ToString.Trim AndAlso GF.LS.lDNC1PHONE4.ToString.Trim = GF.NGS.PHONE_4_2.ToString.Trim AndAlso GF.NGS.M_FIRST_NAME.ToString.Trim = GF.NGS.FirstName2.ToString.Trim AndAlso GF.NGS.M_LAST_NAME.ToString.Trim = GF.NGS.LastName2.ToString.Trim AndAlso GF.NGS.SELECT32.ToString.Trim = GF.NGS.SELECT35.ToString.Trim AndAlso GF.NGS.M_ADDRESS1.ToString.Trim = GF.NGS.ADDRESSONE2.ToString.Trim AndAlso GF.NGS.M_ADDRESS2.ToString.Trim = GF.NGS.ADDRESSTWO2.ToString.Trim AndAlso GF.NGS.M_CITY.ToString.Trim = GF.NGS.CITY_2.ToString.Trim AndAlso GF.NGS.M_STATE.ToString.Trim = GF.NGS.STATE_2.ToString.Trim AndAlso GF.NGS.M_ZIP.ToString.Trim = GF.NGS.ZIP_2.ToString.Trim Then
                    'clear record 2 to 15
                    GF.NGS.PH_2 = String.Empty
                    GF.NGS.PH_3 = String.Empty
                    GF.NGS.PH_4 = String.Empty
                    GF.NGS.PH_5 = String.Empty
                    GF.NGS.PH_6 = String.Empty
                    GF.NGS.PH_7 = String.Empty
                    GF.NGS.PH_8 = String.Empty
                    GF.NGS.PH_9 = String.Empty
                    GF.NGS.PH_10 = String.Empty
                    GF.NGS.PH_11 = String.Empty
                    GF.NGS.PH_12 = String.Empty
                    GF.NGS.PH_13 = String.Empty
                    GF.NGS.PH_14 = String.Empty
                    GF.NGS.PH_15 = String.Empty
                    GF.NGS.ZIP_2 = String.Empty
                    GF.NGS.FirstName2 = String.Empty
                    GF.NGS.SELECT35 = String.Empty
                    GF.NGS.LastName2 = String.Empty
                    GF.NGS.ADDRESSONE2 = String.Empty
                    GF.NGS.ADDRESSTWO2 = String.Empty
                    GF.NGS.CITY_2 = String.Empty
                    GF.NGS.STATE_2 = String.Empty
                    GF.LS.lDNC2AREAC = 0
                    GF.NGS.PHONE_3_2 = 0
                    GF.NGS.PHONE_4_2 = 0
                    GF.LS.lDNC2 = String.Empty
                    GF.LS.lSELECT137 = String.Empty
                    GF.LS.lSELECT138 = String.Empty
                    GF.LS.lDNC2NOADD = String.Empty
                    GF.LS.lDNC3ZIP = String.Empty
                    GF.LS.lDNC3FNAME = String.Empty
                    GF.LS.lDNC3MI = String.Empty
                    GF.LS.lDNC3LNAME = String.Empty
                    GF.LS.lDNC3ADD1 = String.Empty
                    GF.LS.lDNC3ADD2 = String.Empty
                    GF.LS.lDNC3CITY = String.Empty
                    GF.LS.lDNC3STATE = String.Empty
                    GF.LS.lDNC3AREAC = 0
                    GF.LS.lDNC3PHONE3 = 0
                    GF.LS.lDNC3PHONE4 = 0
                    GF.LS.lDNC3 = String.Empty
                    GF.LS.lSELECT139 = String.Empty
                    GF.LS.lSELECT140 = String.Empty
                    GF.LS.lDNC3NOADD = String.Empty
                    GF.LS.lDNC4ZIP = String.Empty
                    GF.LS.lDNC4FNAME = String.Empty
                    GF.LS.lDNC4MI = String.Empty
                    GF.LS.lDNC4LNAME = String.Empty
                    GF.LS.lDNC4ADD1 = String.Empty
                    GF.LS.lDNC4ADD2 = String.Empty
                    GF.LS.lDNC4CITY = String.Empty
                    GF.LS.lDNC4STATE = String.Empty
                    GF.LS.lDNC4AREAC = 0
                    GF.LS.lDNC4PHONE3 = 0
                    GF.LS.lDNC4PHONE4 = 0
                    GF.LS.lDNC4 = String.Empty
                    GF.LS.lSELECT141 = String.Empty
                    GF.LS.lSELECT142 = String.Empty
                    GF.LS.lDNC4NOADD = String.Empty
                    GF.LS.lDNC5ZIP = String.Empty
                    GF.LS.lDNC5FNAME = String.Empty
                    GF.LS.lDNC5MI = String.Empty
                    GF.LS.lDNC5LNAME = String.Empty
                    GF.LS.lDNC5ADD1 = String.Empty
                    GF.LS.lDNC5ADD2 = String.Empty
                    GF.LS.lDNC5CITY = String.Empty
                    GF.LS.lDNC5STATE = String.Empty
                    GF.LS.lDNC5AREAC = 0
                    GF.LS.lDNC5PHONE3 = 0
                    GF.LS.lDNC5PHONE4 = 0
                    GF.LS.lDNC5 = String.Empty
                    GF.LS.lSELECT143 = String.Empty
                    GF.LS.lSELECT144 = String.Empty
                    GF.LS.lDNC5NOADD = String.Empty
                    GF.LS.lDNC6ZIP = String.Empty
                    GF.LS.lDNC6FNAME = String.Empty
                    GF.LS.lDNC6MI = String.Empty
                    GF.LS.lDNC6LNAME = String.Empty
                    GF.LS.lDNC6ADD1 = String.Empty
                    GF.LS.lDNC6ADD2 = String.Empty
                    GF.LS.lDNC6CITY = String.Empty
                    GF.LS.lDNC6STATE = String.Empty
                    GF.LS.lDNC6AREAC = 0
                    GF.LS.lDNC6PHONE3 = 0
                    GF.LS.lDNC6PHONE4 = 0
                    GF.LS.lDNC6 = String.Empty
                    GF.LS.lSELECT145 = String.Empty
                    GF.LS.lSELECT146 = String.Empty
                    GF.LS.lDNC6NOADD = String.Empty
                    GF.LS.lDNC7ZIP = String.Empty
                    GF.LS.lDNC7FNAME = String.Empty
                    GF.LS.lDNC7MI = String.Empty
                    GF.LS.lDNC7LNAME = String.Empty
                    GF.LS.lDNC7ADD1 = String.Empty
                    GF.LS.lDNC7ADD2 = String.Empty
                    GF.LS.lDNC7CITY = String.Empty
                    GF.LS.lDNC7STATE = String.Empty
                    GF.LS.lDNC7AREAC = 0
                    GF.LS.lDNC7PHONE3 = 0
                    GF.LS.lDNC7PHONE4 = 0
                    GF.LS.lDNC7 = String.Empty
                    GF.LS.lSELECT147 = String.Empty
                    GF.LS.lSELECT148 = String.Empty
                    GF.LS.lDNC7NOADD = String.Empty
                    GF.LS.lDNC8ZIP = String.Empty
                    GF.LS.lDNC8FNAME = String.Empty
                    GF.LS.lDNC8MI = String.Empty
                    GF.LS.lDNC8LNAME = String.Empty
                    GF.LS.lDNC8ADD1 = String.Empty
                    GF.LS.lDNC8ADD2 = String.Empty
                    GF.LS.lDNC8CITY = String.Empty
                    GF.LS.lDNC8STATE = String.Empty
                    GF.LS.lDNC8AREAC = 0
                    GF.LS.lDNC8PHONE3 = 0
                    GF.LS.lDNC8PHONE4 = 0
                    GF.LS.lDNC8 = String.Empty
                    GF.LS.lSELECT149 = String.Empty
                    GF.LS.lSELECT150 = String.Empty
                    GF.LS.lDNC8NOADD = String.Empty
                    GF.LS.lDNC9ZIP = String.Empty
                    GF.LS.lDNC9FNAME = String.Empty
                    GF.LS.lDNC9MI = String.Empty
                    GF.LS.lDNC9LNAME = String.Empty
                    GF.LS.lDNC9ADD1 = String.Empty
                    GF.LS.lDNC9ADD2 = String.Empty
                    GF.LS.lDNC9CITY = String.Empty
                    GF.LS.lDNC9STATE = String.Empty
                    GF.LS.lDNC9AREAC = 0
                    GF.LS.lDNC9PHONE3 = 0
                    GF.LS.lDNC9PHONE4 = 0
                    GF.LS.lDNC9 = String.Empty
                    GF.LS.lSELECT151 = String.Empty
                    GF.LS.lSELECT152 = String.Empty
                    GF.LS.lDNC9NOADD = String.Empty
                    GF.LS.lDNC10ZIP = String.Empty
                    GF.LS.lDNC10FNAME = String.Empty
                    GF.LS.lDNC10MI = String.Empty
                    GF.LS.lDNC10LNAME = String.Empty
                    GF.LS.lDNC10ADD1 = String.Empty
                    GF.LS.lDNC10ADD2 = String.Empty
                    GF.LS.lDNC10CITY = String.Empty
                    GF.LS.lDNC10STATE = String.Empty
                    GF.LS.lDNC10AREAC = 0
                    GF.LS.lDNC10PHONE3 = 0
                    GF.LS.lDNC10PHONE4 = 0
                    GF.LS.lDNC10 = String.Empty
                    GF.LS.lSELECT153 = String.Empty
                    GF.LS.lSELECT154 = String.Empty
                    GF.LS.lDNC10NOADD = String.Empty
                    GF.LS.lDNC11ZIP = String.Empty
                    GF.LS.lDNC11FNAME = String.Empty
                    GF.LS.lDNC11MI = String.Empty
                    GF.LS.lDNC11LNAME = String.Empty
                    GF.LS.lDNC11ADD1 = String.Empty
                    GF.LS.lDNC11ADD2 = String.Empty
                    GF.LS.lDNC11CITY = String.Empty
                    GF.LS.lDNC11STATE = String.Empty
                    GF.LS.lDNC11AREAC = 0
                    GF.LS.lDNC11PHONE3 = 0
                    GF.LS.lDNC11PHONE4 = 0
                    GF.LS.lDNC11 = String.Empty
                    GF.LS.lSELECT155 = String.Empty
                    GF.LS.lSELECT156 = String.Empty
                    GF.LS.lDNC11NOADD = String.Empty
                    GF.LS.lDNC12ZIP = String.Empty
                    GF.LS.lDNC12FNAME = String.Empty
                    GF.LS.lDNC12MI = String.Empty
                    GF.LS.lDNC12LNAME = String.Empty
                    GF.LS.lDNC12ADD1 = String.Empty
                    GF.LS.lDNC12ADD2 = String.Empty
                    GF.LS.lDNC12CITY = String.Empty
                    GF.LS.lDNC12STATE = String.Empty
                    GF.LS.lDNC12AREAC = 0
                    GF.LS.lDNC12PHONE3 = 0
                    GF.LS.lDNC12PHONE4 = 0
                    GF.LS.lDNC12 = String.Empty
                    GF.LS.lSELECT157 = String.Empty
                    GF.LS.lSELECT158 = String.Empty
                    GF.LS.lDNC12NOADD = String.Empty
                    GF.LS.lDNC13ZIP = String.Empty
                    GF.LS.lDNC13FNAME = String.Empty
                    GF.LS.lDNC13MI = String.Empty
                    GF.LS.lDNC13LNAME = String.Empty
                    GF.LS.lDNC13ADD1 = String.Empty
                    GF.LS.lDNC13ADD2 = String.Empty
                    GF.LS.lDNC13CITY = String.Empty
                    GF.LS.lDNC13STATE = String.Empty
                    GF.LS.lDNC13AREAC = 0
                    GF.LS.lDNC13PHONE3 = 0
                    GF.LS.lDNC13PHONE4 = 0
                    GF.LS.lDNC13 = String.Empty
                    GF.LS.lSELECT159 = String.Empty
                    GF.LS.lSELECT160 = String.Empty
                    GF.LS.lDNC13NOADD = String.Empty
                    GF.LS.lDNC14ZIP = String.Empty
                    GF.LS.lDNC14FNAME = String.Empty
                    GF.LS.lDNC14MI = String.Empty
                    GF.LS.lDNC14LNAME = String.Empty
                    GF.LS.lDNC14ADD1 = String.Empty
                    GF.LS.lDNC14ADD2 = String.Empty
                    GF.LS.lDNC14CITY = String.Empty
                    GF.LS.lDNC14STATE = String.Empty
                    GF.LS.lDNC14AREAC = 0
                    GF.LS.lDNC14PHONE3 = 0
                    GF.LS.lDNC14PHONE4 = 0
                    GF.LS.lDNC14 = String.Empty
                    GF.LS.lSELECT161 = String.Empty
                    GF.LS.lSELECT162 = String.Empty
                    GF.LS.lDNC14NOADD = String.Empty
                    GF.LS.lDNC15ZIP = String.Empty
                    GF.LS.lDNC15FNAME = String.Empty
                    GF.LS.lDNC15MI = String.Empty
                    GF.LS.lDNC15LNAME = String.Empty
                    GF.LS.lDNC15ADD1 = String.Empty
                    GF.LS.lDNC15ADD2 = String.Empty
                    GF.LS.lDNC15CITY = String.Empty
                    GF.LS.lDNC15STATE = String.Empty
                    GF.LS.lDNC15AREAC = 0
                    GF.LS.lDNC15PHONE3 = 0
                    GF.LS.lDNC15PHONE4 = 0
                    GF.LS.lDNC15 = String.Empty
                    GF.LS.lSELECT163 = String.Empty
                    GF.LS.lSELECT164 = String.Empty
                    GF.LS.lDNC15NOADD = String.Empty
                    'set values to 1 output
                    GF.NGS.SELECT4 = "1"
                End If
            End If

            'call pageDown (  )

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source.Equals("B") Then
                Select Case GF.NGS.SELECT111.ToString.Trim
                    Case "A", "Y"
                        If GF.LS.lIVLName.ToString.Trim.Equals(String.Empty) OrElse GF.NGS.PHONE_NUM.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lIVLnotes1.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lIVLDNC.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lIVLletter.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lIVLSatisfied.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lIVLnotes1.ToString.Trim.Length > 501 OrElse GF.LS.lIVLnotes4.ToString.Trim.Length > 251 OrElse GF.LS.lIVLApp.ToString.Trim.Equals(String.Empty) OrElse (GF.LS.lIVLSatisfied.ToString.Trim.Equals("N") AndAlso GF.LS.lIVLnotes4.ToString.Trim.Equals(String.Empty)) OrElse (GF.LS.lIVLletter.ToString.Trim.Equals("Y") AndAlso GF.LS.lIVLaddress1.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lIVLcity.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lIVLstate.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lIVlzip.ToString.Trim.Equals(String.Empty)) Then
                            set_currPath(ScriptPaths.IVL)
                        End If
                End Select
                Select Case GF.NGS.SELECT112.ToString.Trim
                    Case "A", "Y"
                        If GF.LS.lEBRFirstName.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lEBRLastName.ToString.Trim.Equals(String.Empty) OrElse Not IsNumeric(GF.NGS.CODE11_1.ToString.Trim) OrElse GF.LS.lEBRTone.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lEBRComment.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lEBRNotes.ToString.Trim.Length > 201 OrElse Not GF.NGS.SELECT112.ToString.Trim.Equals("Y") OrElse GF.NGS.PHONE_NUM.ToString.Trim.Equals(String.Empty) OrElse GF.LS.lEBRApp.ToString.Trim.Equals(String.Empty) Then
                            set_currPath(ScriptPaths.EBR)
                        End If
                End Select
                Select Case GF.NGS.Init_Disp.ToString.Trim
                    Case "A000", "B000", "C000", "D000"
                        If GF.NGS.Second_Disp.ToString.Trim.Equals(String.Empty) Then
                            EditError = 1
                            ErrorMsg = "Call path has not been completed"
                            set_currPath(ScriptPaths.MBNA)
                        End If
                    Case "G000", "H000", "I000", "J000", "T000"
                        If GF.NGS.Second_Disp.ToString.Trim.Equals(String.Empty) Then
                            EditError = 1
                            ErrorMsg = "Call path has not been completed"
                            set_currPath(ScriptPaths.CONSUMER)
                        End If
                    Case String.Empty
                        EditError = 1
                        ErrorMsg = "Call path has not been completed"
                        Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                            Case "MBNACNFM", "MBNACNFS", "MBNACFSS"
                                set_currPath(ScriptPaths.CONSUMER)
                            Case Else
                                set_currPath(ScriptPaths.MBNA)
                        End Select
                End Select
                '20110131 cgossman - If statement should be on Third Disp
                Select Case GF.NGS.Second_Disp.ToString.Trim
                    Case "A200"
                        If GF.NGS.Third_Disp.ToString.Trim <> String.Empty Then
                        Else
                            EditError = 1
                            ErrorMsg = "Call path has not been completed"
                            set_currPath(ScriptPaths.MBNA)
                        End If
                    Case "G100"
                        If GF.NGS.Third_Disp.ToString.Trim <> String.Empty Then
                        Else
                            EditError = 1
                            ErrorMsg = "Call path has not been completed"
                            set_currPath(ScriptPaths.CONSUMER)
                        End If
                End Select

                'must have notes if other selected on no-sale
                Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                    Case "MBNACNFM", "MBNACNFS", "MBNACFSS"
                        If GF.NGS.SELECT20.ToString.Trim.Equals("K") AndAlso GF.LS.lCFNotes.ToString.Trim.Equals(String.Empty) Then
                            EditError = 1
                            ErrorMsg = "Call path has not been completed"
                            set_currPath(ScriptPaths.CONSUMER)
                        End If
                    Case Else
                        If GF.NGS.SELECT3.ToString.Trim.Equals("D") AndAlso GF.LS.lCCOtherNotes.ToString.Trim.Equals(String.Empty) Then
                            EditError = 1
                            ErrorMsg = "Call path has not been completed"
                            set_currPath(ScriptPaths.MBNA)
                        End If
                End Select
            End If


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endofpath = True

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub


#End Region









End Class
