﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class contact0011
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJTXT0001.Text = GF.LS.lDNCbn
        OBJRAD0002.SelectedValue = GF.LS.lRefuseAllB
        If GF.LS.lRefuseAll = "Y" Then OBJCHK0005.Checked = True
        If GF.LS.lRefuseAll = "N" Then OBJCHK0005.Checked = False
        If GF.LS.lConfirmLetter = "Y" Then OBJCHK0006.Checked = True
        If GF.LS.lConfirmLetter = "N" Then OBJCHK0006.Checked = False
        If GF.LS.lPolicyLetter = "Y" Then OBJCHK0007.Checked = True
        If GF.LS.lPolicyLetter = "N" Then OBJCHK0007.Checked = False
        SCRIPT0001.ZipCode = GF.LS.lmailZip
        SCRIPT0001.Address1 = GF.LS.lmailAdd1
        SCRIPT0001.Address2 = GF.LS.lmailAdd2
        SCRIPT0001.City = GF.LS.lmailCity
        SCRIPT0001.State = GF.LS.lmailState
        SCRIPT0002.AreaCode = GF.LS.lmailAreaC
        SCRIPT0002.Prefix = GF.LS.lmailPhone3
        SCRIPT0002.Extension = GF.LS.lmailPhone4
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lDNCbn = OBJTXT0001.Text
        GF.LS.lRefuseAllB = OBJRAD0002.SelectedValue
        If OBJCHK0005.Checked Then GF.LS.lRefuseAll = "Y"
        If Not OBJCHK0005.Checked Then GF.LS.lRefuseAll = "N"
        If OBJCHK0006.Checked Then GF.LS.lConfirmLetter = "Y"
        If Not OBJCHK0006.Checked Then GF.LS.lConfirmLetter = "N"
        If OBJCHK0007.Checked Then GF.LS.lPolicyLetter = "Y"
        If Not OBJCHK0007.Checked Then GF.LS.lPolicyLetter = "N"
        GF.LS.lmailZip = SCRIPT0001.ZipCode
        GF.LS.lmailAdd1 = SCRIPT0001.Address1
        GF.LS.lmailAdd2 = SCRIPT0001.Address2
        GF.LS.lmailCity = SCRIPT0001.City
        GF.LS.lmailState = SCRIPT0001.State
        GF.LS.lmailAreaC = SCRIPT0002.AreaCode
        GF.LS.lmailPhone3 = SCRIPT0002.Prefix
        GF.LS.lmailPhone4 = SCRIPT0002.Extension
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            OBJTID0001.Text = String.Empty
            OBJTID0002.Text = String.Empty
            OBJRAD0002.Visible = False

            GF.LS.lRefuseAll = String.Empty
            GF.LS.lRefuseAllB = String.Empty
            GF.LS.lConfirmLetter = String.Empty
            GF.LS.lPolicyLetter = String.Empty

            SCRIPT0001.ZipReq = True
            SCRIPT0002.PhoneRequired = True
            SCRIPT0001.StateReq = True
            SCRIPT0001.CityReq = True
            SCRIPT0001.Address1Req = True
            SCRIPT0001.Address2Req = False

            SCRIPT0002.Prompt = "Business Phone: "
            SCRIPT0001.MiddleInitialReq = False

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

            If source.Equals("B") Then
                If GF.LS.lDNCbn.ToString.Trim.Equals(String.Empty) And Not GF.LS.lRefuseAllB.ToString.Trim.Equals("N") Then
                    EditError = 1
                    ErrorMsg = "Business name is required."
                    SetFocus("OBJTXT0001")
                ElseIf (GF.gfCheckFieldValidity(GF.LS.lDNCbn.ToString.Trim, "\d") Or GF.gfCheckFieldValidity(GF.LS.lDNCbn.ToString.Trim, "([a-zA-Z])\1{3,}")) Then
                    EditError = 1
                    ErrorMsg = "Business name is invalid."
                    SetFocus("OBJTXT0001")
                ElseIf GF.gfCheckFieldValidity(GF.LS.lmailAdd1.ToString.Trim, "([a-zA-Z0-9])\1{3,}") Then
                    EditError = 1
                    ErrorMsg = "Address Line 1 is invalid."
                    SCRIPT0001.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address1
                ElseIf GF.gfCheckFieldValidity(GF.LS.lmailAreaC.ToString.Trim & GF.LS.lmailPhone3.ToString.Trim & GF.LS.lmailPhone4.ToString.Trim, "([0-9])\1{9,}") Then
                    EditError = 1
                    ErrorMsg = "Phone number is invalid. Ask the customer for their phone number."
                    SCRIPT0002.Focus_AreaCode()
                ElseIf (GF.LS.lRefuseAll.ToString.Trim.Equals("Y") And GF.LS.lRefuseAllB.ToString.Trim.Equals(String.Empty)) Then
                    EditError = 1
                    ErrorMsg = "Please make a selection."
                    SetFocus("OBJRAD0002001")
                ElseIf (GF.LS.lRefuseAll.ToString.Trim.Equals("Y") And GF.LS.lRefuseAllB.ToString.Trim.Equals("Y")) Then
                    EditError = 1
                    ErrorMsg = "Please Uncheck Refused Phone/Address and Enter Phone/Address."
                    SetFocus("OBJCHK0001")
                Else
                    'refused address/phone on both
                    If GF.LS.lRefuseAll.Equals("Y") And GF.LS.lRefuseAllB.Equals("N") Then
                        SCRIPT0001.ZipReq = False
                        SCRIPT0002.PhoneRequired = False
                        SCRIPT0001.StateReq = False
                        SCRIPT0001.CityReq = False
                        SCRIPT0001.Address1Req = False
                        SCRIPT0001.Address2Req = False
                        GF.LS.lConfirmLetter = String.Empty
                        GF.LS.lPolicyLetter = String.Empty
                        GF.NGS.Init_Disp = String.Empty
                        GF.NGS.Second_Disp = String.Empty
                        GF.NGS.Third_Disp = String.Empty
                        GF.NGS.Fourth_Disp = String.Empty
                        GF.NGS.Fifth_Disp = String.Empty
                        GF.NGS.Sixth_Disp = String.Empty
                        GF.NGS.Seventh_Disp = String.Empty
                        GF.NGS.Eighth_Disp = String.Empty
                        GF.NGS.NINTH_DISP = String.Empty
                        GF.NGS.SELECT108 = String.Empty
                        GF.NGS.SELECT10 = String.Empty
                        GF.LS.lDNCbn = String.Empty
                        GF.LS.lmailAdd1 = String.Empty
                        GF.LS.lmailAdd2 = String.Empty
                        GF.LS.lmailCity = String.Empty
                        GF.LS.lmailState = String.Empty
                        GF.LS.lmailZip = String.Empty
                        GF.LS.lmailAreaC = "0"
                        GF.LS.lmailPhone3 = "0"
                        GF.LS.lmailPhone4 = "0"
                        GF.LS.lTotalDoNotContact = "0"
                        GF.NGS.SELECT23 = String.Empty
                        GF.NGS.SELECT24 = String.Empty
                        GF.NGS.SELECT4 = String.Empty
                        GF.LS.lDNC1AREAC = 0
                        GF.LS.lDNC1PHONE3 = 0
                        GF.LS.lDNC1PHONE4 = 0
                        GF.NGS.M_FIRST_NAME = String.Empty
                        GF.NGS.M_LAST_NAME = String.Empty
                        GF.NGS.SELECT32 = String.Empty
                        GF.NGS.M_ADDRESS1 = String.Empty
                        GF.NGS.M_ADDRESS2 = String.Empty
                        GF.NGS.M_CITY = String.Empty
                        GF.NGS.M_STATE = String.Empty
                        GF.NGS.M_ZIP = String.Empty
                        GF.LS.lDNC1 = String.Empty
                    Else
                        GF.NGS.Init_Disp = "I000"
                        GF.NGS.Second_Disp = "I800"
                        GF.NGS.Third_Disp = "I8A2"
                        GF.NGS.Fourth_Disp = String.Empty
                        GF.NGS.Fifth_Disp = String.Empty
                        GF.NGS.Sixth_Disp = String.Empty
                        GF.NGS.Seventh_Disp = String.Empty
                        GF.NGS.Eighth_Disp = String.Empty
                        GF.NGS.NINTH_DISP = String.Empty
                    End If
                End If
            End If

            GF.LS.lLOGXTDAT2 = "Y"
            GF.NGS.LOGXTDAT = "Y"
            GF.LS.lXLFdnc = "Y"

            If Not SCRIPT0001.IsValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If
            If Not SCRIPT0002.IsValid Then
                DisplayError(SCRIPT0002.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            'Panel Branching code
            endOfPath = False
            If GF.LS.lRefuseAllB.Equals("N") Then
                nextPanel = Panels.CONTACT.contact0015
            Else
                nextPanel = Panels.CONTACT.contact0014
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region

    Private Sub OBJCHK0005_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJCHK0005.CheckedChanged
        PanelEditAutoMapping()

        If GF.LS.lRefuseAll.ToString.Trim.Equals("Y") Then
            OBJTID0001.Text = "A phone number and address are required to process your request.  May I please have your phone number and address?"
            OBJRAD0002.Visible = False
        End If
        PanelEditAutoMapping()

    End Sub
   
    Private Sub OBJRAD0002_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJRAD0002.SelectedIndexChanged
        PanelEditAutoMapping()
        If GF.LS.lRefuseAllB.ToString.Trim.Equals("N") Then
            OBJTID0002.Text = "I'm sorry but I will be unable to process your do not contact request without a telephone number and address."
            SCRIPT0001.ZipReq = False
            SCRIPT0002.PhoneRequired = False
            SCRIPT0001.StateReq = False
            SCRIPT0001.CityReq = False
            SCRIPT0001.Address1Req = False
            SCRIPT0001.Address2Req = False
        Else
            OBJTID0002.Text = String.Empty
        End If

        PanelEditAutoMapping()

    End Sub








End Class
