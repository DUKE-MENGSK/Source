﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class contact0007
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJRAD0001.SelectedValue = GF.LS.lRefuseAllB
        OBJRAD0002.SelectedValue = GF.NGS.SELECT12
        If GF.LS.lRefuseAll = "Y" Then OBJCHK0001.Checked = True
        If GF.LS.lRefuseAll = "N" Then OBJCHK0001.Checked = False
        If GF.LS.lConfirmLetter = "Y" Then OBJCHK0002.Checked = True
        If GF.LS.lConfirmLetter = "N" Then OBJCHK0002.Checked = False
        If GF.LS.lPolicyLetter = "Y" Then OBJCHK0003.Checked = True
        If GF.LS.lPolicyLetter = "N" Then OBJCHK0003.Checked = False
        SCRIPT0001.ZipCode = GF.LS.lmailZip
        SCRIPT0001.Address1 = GF.LS.lmailAdd1
        SCRIPT0001.Address2 = GF.LS.lmailAdd2
        SCRIPT0001.City = GF.LS.lmailCity
        SCRIPT0001.State = GF.LS.lmailState
        SCRIPT0001.FirstName = GF.LS.lmailFname
        SCRIPT0001.LastName = GF.LS.lmailLname
        SCRIPT0001.MiddleInitial = GF.LS.lmailMname
        SCRIPT0001.PhoneAreaCode = GF.LS.lmailAreaC
        SCRIPT0001.PhonePrefix = GF.LS.lmailPhone3
        SCRIPT0001.PhoneExtension = GF.LS.lmailPhone4
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lRefuseAllB = OBJRAD0001.SelectedValue
        GF.NGS.SELECT12 = OBJRAD0002.SelectedValue
        If OBJCHK0001.Checked Then GF.LS.lRefuseAll = "Y"
        If Not OBJCHK0001.Checked Then GF.LS.lRefuseAll = "N"
        If OBJCHK0002.Checked Then GF.LS.lConfirmLetter = "Y"
        If Not OBJCHK0002.Checked Then GF.LS.lConfirmLetter = "N"
        If OBJCHK0003.Checked Then GF.LS.lPolicyLetter = "Y"
        If Not OBJCHK0003.Checked Then GF.LS.lPolicyLetter = "N"
        GF.LS.lmailZip = SCRIPT0001.ZipCode
        GF.LS.lmailAdd1 = SCRIPT0001.Address1
        GF.LS.lmailAdd2 = SCRIPT0001.Address2
        GF.LS.lmailCity = SCRIPT0001.City
        GF.LS.lmailState = SCRIPT0001.State
        GF.LS.lmailFname = SCRIPT0001.FirstName
        GF.LS.lmailLname = SCRIPT0001.LastName
        GF.LS.lmailMname = SCRIPT0001.MiddleInitial
        GF.LS.lmailAreaC = SCRIPT0001.PhoneAreaCode
        GF.LS.lmailPhone3 = SCRIPT0001.PhonePrefix
        GF.LS.lmailPhone4 = SCRIPT0001.PhoneExtension
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            GF.NGS.SELECT12 = String.Empty
            GF.LS.lRefuseAll = String.Empty
            GF.LS.lRefuseAllB = String.Empty
            GF.LS.lConfirmLetter = String.Empty
            GF.LS.lPolicyLetter = String.Empty
            GF.LS.lDNCbn = String.Empty
            If (GF.LS.lTotalDoNotContact IsNot String.Empty) Then
                If CInt(GF.LS.lTotalDoNotContact).Equals(4) Then
                    OBJRAD0002.Items(1).Enabled = False
                End If
            End If
            'If CInt(GF.LS.lTotalDoNotContact).Equals(4) Then
            '    OBJRAD0002.Controls(1).Visible = True
            'End If

            GF.LS.lm1 = GF.LS.lmailFname.ToString.Trim
            GF.LS.lm2 = GF.LS.lmailLname.ToString.Trim
            GF.LS.lm3 = GF.LS.lmailMname.ToString.Trim
            GF.LS.lm4 = GF.LS.lmailAdd1.ToString.Trim
            GF.LS.lm5 = GF.LS.lmailAdd2.ToString.Trim
            GF.LS.lm6 = GF.LS.lmailCity.ToString.Trim
            GF.LS.lm7 = GF.LS.lmailState.ToString.Trim
            GF.LS.lm8 = GF.LS.lmailZip.ToString.Trim
            GF.LS.lm9 = GF.LS.lmailAreaC.ToString.Trim
            GF.LS.lm10 = GF.LS.lmailPhone3.ToString.Trim
            GF.LS.lm11 = GF.LS.lmailPhone4.ToString.Trim

            SCRIPT0001.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Zip

            windowOnLoadAutoMapping()
            SCRIPT0001.MiddleInitialReq = False

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            panelEditAutoMapping()

            If source.Equals("B") Then
                If (GF.gfCheckFieldValidity(GF.LS.lmailFname.ToString.Trim, "\d") Or gf.gfCheckFieldValidity(GF.LS.lmailFname.ToString.Trim, "([a-zA-Z])\1{3,}")) Then
                    EditError = 1
                    ErrorMsg = "First name is invalid."
                    SCRIPT0001.FocusField = UserControlLib.NACSZNGS.FieldToFocus.FirstName
                ElseIf (GF.gfCheckFieldValidity(GF.LS.lmailFname.ToString.Trim, "\d") Or gf.gfCheckFieldValidity(GF.LS.lmailFname.ToString.Trim, "([a-zA-Z])\1{3,}")) Then
                    EditError = 1
                    ErrorMsg = "Last name is invalid."
                    SCRIPT0001.FocusField = UserControlLib.NACSZNGS.FieldToFocus.LastName
                ElseIf GF.gfCheckFieldValidity(GF.LS.lmailAdd1.ToString.Trim, "([a-zA-Z0-9])\1{3,}") Then
                    EditError = 1
                    ErrorMsg = "Address Line 1 is invalid."
                    SCRIPT0001.FocusField = UserControlLib.NACSZNGS.FieldToFocus.Address1
                ElseIf GF.gfCheckFieldValidity(GF.LS.lmailAreaC.ToString.Trim & GF.LS.lmailPhone3.ToString.Trim & GF.LS.lmailPhone4.ToString.Trim, "([0-9])\1{9,}") Then
                    EditError = 1
                    ErrorMsg = "Phone number is invalid."
                    SCRIPT0001.Focus_AreaCode()
                ElseIf GF.NGS.SELECT12.ToString.Trim.Equals(String.Empty) Then
                    EditError = 1
                    ErrorMsg = "Select an option to continue"
                    SetFocus("OBJRAD0003001")
                ElseIf (GF.LS.lmailFname.ToString.Trim.Equals(GF.LS.lm1.ToString.Trim) AndAlso GF.LS.lmailLname.ToString.Trim.Equals(GF.LS.lm2.ToString.Trim) AndAlso GF.LS.lmailMname.ToString.Trim.Equals(GF.LS.lm3.ToString.Trim) AndAlso GF.LS.lmailAdd1.ToString.Trim.Equals(GF.LS.lm4.ToString.Trim) AndAlso GF.LS.lmailAdd2.ToString.Trim.Equals(GF.LS.lm5.ToString.Trim) AndAlso GF.LS.lmailCity.ToString.Trim.Equals(GF.LS.lm6.ToString.Trim) AndAlso GF.LS.lmailState.ToString.Trim.Equals(GF.LS.lm7.ToString.Trim) AndAlso GF.LS.lmailZip.ToString.Trim.Equals(GF.LS.lm8.ToString.Trim) AndAlso GF.LS.lmailAreaC.ToString.Trim.Equals(GF.LS.lm9.ToString.Trim) AndAlso GF.LS.lmailPhone3.ToString.Trim.Equals(GF.LS.lmailPhone4) And GF.LS.lmailPhone4.ToString.Trim.Equals(GF.LS.lRefusePhone) And Not GF.LS.lRefusePhone.ToString.Trim.Equals("Y") And Not GF.LS.lRefusePhoneB.Equals("N")) Then
                    EditError = 1
                    ErrorMsg = "Address or Phone Number must be changed."
                    SetFocus("SCRIPT0001")
                Else
                    GF.NGS.Init_Disp = "I000"
                    GF.NGS.Second_Disp = "I800"
                    GF.NGS.Third_Disp = "I8A2"
                    GF.NGS.Fourth_Disp = String.Empty
                    GF.NGS.Fifth_Disp = String.Empty
                    GF.NGS.Sixth_Disp = String.Empty
                    GF.NGS.Seventh_Disp = String.Empty
                    GF.NGS.Eighth_Disp = String.Empty
                    GF.NGS.NINTH_DISP = String.Empty

                    If GF.LS.lRefuseAll.ToString.Trim.Equals("Y") Then
                        Select Case GF.LS.lRefuseAllB.ToString.Trim

                            Case String.Empty
                                EditError = 1
                                ErrorMsg = "Please make a selection."
                                SetFocus("OPTION0001")

                            Case "Y"
                                EditError = 1
                                ErrorMsg = "Please Uncheck Refused Phone/Address and Enter Phone/Address."
                                GF.NGS.SELECT108 = "M"

                            Case "N"
                                'refused address/phone on both
                                SCRIPT0001.ZipReq = False
                                SCRIPT0001.PhoneRequired = False
                                SCRIPT0001.StateReq = False
                                SCRIPT0001.MiddleInitialReq = False
                                SCRIPT0001.LastNameReq = False
                                SCRIPT0001.FirstNameReq = False
                                SCRIPT0001.CityReq = False
                                SCRIPT0001.Address1Req = False
                                SCRIPT0001.Address2Req = False
                                GF.LS.lConfirmLetter = String.Empty
                                GF.LS.lPolicyLetter = String.Empty
                                GF.NGS.Init_Disp = String.Empty
                                GF.NGS.Second_Disp = String.Empty
                                GF.NGS.Third_Disp = String.Empty
                                GF.NGS.Fourth_Disp = String.Empty
                                GF.NGS.Fifth_Disp = String.Empty
                                GF.NGS.Sixth_Disp = String.Empty
                                GF.NGS.Seventh_Disp = String.Empty
                                GF.NGS.Eighth_Disp = String.Empty
                                GF.NGS.NINTH_DISP = String.Empty
                                GF.NGS.SELECT108 = String.Empty
                                GF.NGS.SELECT10 = String.Empty
                                GF.LS.lmailFname = String.Empty
                                GF.LS.lmailMname = String.Empty
                                GF.LS.lmailLname = String.Empty
                                GF.LS.lmailAdd1 = String.Empty
                                GF.LS.lmailAdd2 = String.Empty
                                GF.LS.lmailCity = String.Empty
                                GF.LS.lmailState = String.Empty
                                GF.LS.lmailZip = String.Empty
                                GF.LS.lmailAreaC = "0"
                                GF.LS.lmailPhone3 = "0"
                                GF.LS.lmailPhone4 = "0"
                        End Select
                    End If
                End If
            End If '%[OBJSCP0001]%
            If Not SCRIPT0001.isValid Then
                DisplayError(SCRIPT0001.ErrorMessages())
                EditError = 1
                Exit Sub
            End If

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            'Panel Branching code
            endofpath = False
            If GF.LS.lRefuseAllB.ToString.Trim.Equals("N") Then
                nextpanel = Panels.CONTACT.CONTACT0002
            Else
                nextpanel = Panels.CONTACT.CONTACT0012
            End If

        Catch ex As EXCEPTION
            Throw
        End Try
    End Sub


#End Region

    Private Sub OBJCHK0001_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJCHK0001.CheckedChanged
        PanelEditAutoMapping()
        'TODO. 20100521. cshepler. make these Textids like the other panelsif getDataTrim ("LocalStore", "lRefuseAll").Equals("Y") then

        If GF.LS.lRefuseAll.ToString.Trim.Equals("Y") Then
            OBJDIV0001.Visible = True
            'Else
            '    OBJDIV0001.Visible = False
        End If

    End Sub


    Private Sub OBJRAD0001_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OBJRAD0001.SelectedIndexChanged
        PanelEditAutoMapping()
        'TODO. 20100521. cshepler. make these Textids like the other panelsif getDataTrim ("LocalStore", "lRefuseAll").Equals("Y") then

        If GF.LS.lRefuseAllB.ToString.Trim.Equals("N") Then
            OBJDIV0002.Visible = True
            SCRIPT0001.ZipReq = False
            SCRIPT0001.PhoneRequired = False
            SCRIPT0001.StateReq = False
            SCRIPT0001.MiddleInitialReq = False
            SCRIPT0001.LastNameReq = False
            SCRIPT0001.FirstNameReq = False
            SCRIPT0001.CityReq = False
            SCRIPT0001.Address1Req = False
            SCRIPT0001.Address2Req = False
        Else
            OBJDIV0002.Visible = False
        End If

    End Sub

End Class
