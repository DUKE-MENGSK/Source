﻿Imports System.Xml
Imports System.Data
Public Class startup
    Inherits STDPanel
    Protected WithEvents lblText As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            'Put user code to initialize the page here
            'Script initialization code goes here.
            ' Here we will only do this if it is not a postback, since we get stuck in a big
            ' inifinate loop if it is

            If Len(Trim(GF.UPC.System.GUID)) = 0 Then
                'In Startup, No GUID, so initializing the callscript and startcalltime...

                InitCallScript()

                'moved this to gfscript load - systxb ' UA
                'SetData("Script", "STARTCALLTIME", Now())
            Else
                GF.LogSystemMessage("Script", "In Startup; We have a GUID so not initializing callscript variables...")
            End If

        Catch ex As Exception
            Throw

            'Response.Write(ex.ToString)
        End Try
    End Sub


    Private Sub InitCallScript()
        'Until we get the tandem user object, we need to build our own system table for
        'prototyping purposes. NOTE: Not all of the fields from the table schema are
        'included, just the ones we need for testing.
        Try

            'initialize all the tables at startup
            'for each column as DataColumn in myGlobalFunction.sessionDataSet.tables("DataStore").columns
            'response.write(column.toString)
            'next

            'set variables for SL
            If GF.SL Is Nothing Then GF.SL = New SLSharedLib.BaseSLVariables
            MyBase.InitVarProperties(GF.SL.ScriptSLWebserviceValues.GetType(), GF.SL.ScriptSLWebserviceValues)
            MyBase.InitVarProperties(GF.SL.ScriptSLEmailValues.GetType(), GF.SL.ScriptSLEmailValues)


            If GF.NGS Is Nothing Then GF.NGS = New DataStoreVariables()
            MyBase.InitVarProperties(GF.NGS.GetType(), GF.NGS)
            MyBase.InitVarProperties(GF.UPC.Script.GetType(), GF.UPC.Script)
            MyBase.InitVarProperties(GF.UPC.System.GetType(), GF.UPC.System)
            MyBase.InitVarProperties(GF.UPC.AgentInfo.GetType(), GF.UPC.AgentInfo)
            MyBase.InitVarProperties(GF.UPC.Configuration.GetType(), GF.UPC.Configuration)
            MyBase.InitVarProperties(GF.UPC.StationConfiguration.GetType(), GF.UPC.StationConfiguration)
            MyBase.InitVarProperties(GF.UPC.CallData.GetType(), GF.UPC.CallData)
            If GF.LS Is Nothing Then GF.LS = New LocalStoreVariables()
            MyBase.InitVarProperties(GF.LS.GetType(), GF.LS)

            Call resetHistoryTables()
            Call initDataStore()
            Call initLocalStore()
            Call initScriptVariables()
            Call initSystemVariables()
            Call initAgentInfo()

            Dim qsNewCall As String
            'Dim strPageLoad As String
            Dim userIdentifier As String

            userIdentifier = Request.QueryString("UserIdentifier")

            If Not userIdentifier Is Nothing And userIdentifier <> "" Then
                'Get user object dataset
                GF.UPC.System.GUID = userIdentifier
                Response.Write(userIdentifier)
                Dim myProxy As New TandemUserProxy
                Try
                    GF.sessionDataset.Merge(myProxy.GetUserData(userIdentifier))
                    GF.SetupBaseGlobalSessionVariables(GF.sessionDataset)
                    'GSC 11/18/2003 Added so that PROJECT_ID is populated from StationCOndfig Table
                    GF.UPC.System.PROJECT_ID = GF.UPC.StationConfiguration.ProjectId
                Catch ex As Exception
                    Response.Write("Exception in userdata.merge")
                    Response.Write(ex.ToString())
                End Try
                GF.UPC.Script.IN_ADE = True
            End If

            '10/28/03 - Inna - added if statement to save/clear NewCall queryString
            qsNewCall = Request.QueryString("NewCall")
            If qsNewCall Is Nothing Then
                GF.UPC.Script.IsNewCall = False
                GF.UPC.Script.MessageIdentifier = ""
            Else
                GF.UPC.Script.IsNewCall = True
                GF.UPC.Script.MessageIdentifier = Request.QueryString("MessageIdentifier")
            End If

            'Call setup_inputLayout()
            'Call setup_outputLayout()

            'Call this function last.
            GF.gfScriptLoad()

            'Stach 11/08 Check for verification mode and if so update Nav frame to Verification Action.
            If GF.UPC.Script.SCRIPTCALLMODE = "VERIFICATION" Then
                'Refresh the Nav Frame for Verification mode
                Call updateNavTree("4")
            ElseIf GF.UPC.Script.SCRIPTCALLMODE = "CALLBACK" Then
                'Refresh the Nav Frame for callback mode
                Call updateNavTree("5")
            End If

            If GF.UPC.Script.CALLMODE = CALLMODE_BROWSE Then
                lblText.Visible = True
            Else
                lblText.Visible = False
            End If

            'find out the first panel to display
            'strPageLoad = GF.UPC.Script.ScriptFirstPanel
            'If Len(Trim(strPageLoad)) <> 0 Then
            '    Response.Redirect(strPageLoad & "?Class=Panel&Action=OnLoad")
            'End If

            'Update the script paths to inital value
            updateNavTree()

        Catch ex As Exception
            Throw

            'Response.Write(ex.ToString)
            'Response.Write(e.StackTrace)
        End Try

    End Sub

    Private Sub initAgentInfo()

        Try

            GF.UPC.AgentInfo.firstname = "AgentFirstName"
            GF.UPC.AgentInfo.lastname = "AgentLastName"
            GF.UPC.AgentInfo.fullname = "AgentFullName"
            GF.UPC.AgentInfo.uid = "AgentUID"
            GF.UPC.AgentInfo.term_id = "AgentTerm_Id"
            GF.UPC.AgentInfo.train_ind = "AgentTrain_Ind"

        Catch ex As Exception
            Throw

            'Response.Write(ex.ToString)
        End Try
    End Sub

    Private Sub initScriptVariables()

        Try
            GF.UPC.Script.IN_ADE = False
            GF.UPC.Script.IN_BROWSER = True
            GF.UPC.Script.CALLCOMPLETE = "N"
            GF.UPC.Script.CALLMODE = 0
            GF.UPC.Script.DISCONNECTED = "Y"
            GF.UPC.Script.FIXEDMESSAGE = False
            GF.UPC.Script.FIXEDMESSAGETEXT = ""
            GF.UPC.Script.PANELLOADEND = "0"
            GF.UPC.Script.PANELLOADSTART = "0"
            GF.UPC.Script.PANELNAME = "startup"
            GF.UPC.Script.READYFORSCRIPTING = "N"
            GF.UPC.Script.WAITEDIOPENDING = False
            GF.UPC.Script.vruRecording = False
            GF.UPC.Script.VRU_RECORD = " "
            GF.UPC.Script.KICKBACK_IND = " "
            GF.UPC.Script.SCHED_DATE = DateTime.MinValue
            GF.UPC.Script.SCHED_TIME = 0
            GF.UPC.Script.SCHED_CONTACT_FIRST = " "
            GF.UPC.Script.SCHED_CONTACT_LAST = " "
            GF.UPC.Script.CALL_RESULT = " "
            GF.UPC.Script.NOSALE_REASON = " "
            GF.UPC.Script.SCRIPT_LANGUAGE = "Eng"
            GF.UPC.Script.tot_cntrs = 0
            GF.UPC.Script.tot_products = 0
            GF.UPC.Script.PRODUCTS_STREAM = " "
            GF.UPC.Script.output_variable_area = " "
            GF.UPC.Script.input_variable_area = " "
            GF.UPC.Script.tot_Input_length = 0
            GF.UPC.Script.tot_Output_length = 0
            GF.UPC.Script.returnFunction = " "
            GF.UPC.Script.NOTES = " "
            GF.UPC.Script.NEWNOTES = " "
            GF.UPC.Script.OLD_AREA = "0"
            GF.UPC.Script.OLD_PHONE = "0"
            GF.UPC.Script.NEW_AREA = "0"
            GF.UPC.Script.NEW_PHONE = "0"
            GF.UPC.Script.gEditError = "False"
            GF.UPC.Script.SP_NAME1 = " "
            GF.UPC.Script.SP_NAME2 = " "
            GF.UPC.Script.CORRECTED_PHONE = " "
            GF.UPC.Script.SRC_NAME = " "
            GF.UPC.Script.TMF = " "
            'systxb - changed for ua --> makebusy should not be on initially, set in global/shared functions.
            GF.UPC.Script.MAKEBUSYON = "N"
            GF.UPC.Script.FIRST_ENTRY = "Y"
            GF.UPC.Script.REMOTE_DISCONNECT = "N"
            GF.UPC.Script.ReleaseDateTime = DateTime.MinValue
            GF.UPC.Script.CURRPOS = "0"
            GF.UPC.Script.CallsTaken = "0"
            GF.UPC.Script.ALC = "0:00:00"
            GF.UPC.Script.CallTotalTime = "0"
            GF.UPC.Script.AppPath = Request.PhysicalApplicationPath
            GF.UPC.Script.PanelRenderFlag = False
            GF.UPC.Script.MessageIdentifier = ""
            GF.UPC.Script.IsNewCall = False
            GF.UPC.Script.isCallLogged = "N"
            GF.UPC.Script.isDisconnected = "N"

        Catch ex As Exception
            Throw

            'Response.Write(ex.ToString)
        End Try
    End Sub

    Public Sub initSystemVariables()

        Try
            GF.UPC.System.INBOUND_STATUS = "Indicated Inbound Status for CMODE panel"
            GF.UPC.System.INBOUND = "N"
            GF.UPC.System.ISIE5 = "Y"
            GF.UPC.System.SCRIPT_DROP_TIME = "4444"
            GF.UPC.System.PROJECT_ID = "SOME-PROJECT"
            GF.UPC.System.PROJECT_CALL_MODE = "Single Call Mode"
            GF.UPC.System.CAMPAIGN_ID = "SOME-CAMPAIGN"
            GF.UPC.System.SCRIPT_ID = "A000001"
            GF.UPC.System.VERSION = "1"
            GF.UPC.System.DED_CALLBACK_IND = "N"
            GF.UPC.System.TEAM_NAME = "TEAM 1"
            GF.UPC.System.PROJECT_TYPE = 0
            GF.UPC.System.BRANCH = "BRANCH 1"
            GF.UPC.System.TANDEM_SITE = "TND203332"
            GF.UPC.System.STATN_ID = "STND123334"
            GF.UPC.System.PRSNL_ID = "243232423"
            GF.UPC.System.FIRST_NAME = "John"
            GF.UPC.System.LAST_NAME = "Doe"
            GF.UPC.System.FACILITY_ID = "FAC111"
            GF.UPC.System.CALLBACKENVIRONMENT = False
            GF.UPC.System.CALLINGENVIRONMENT = False
            GF.UPC.System.VERIFICATIONENVIRONMENT = False
            GF.UPC.System.MULTIPROJ = False

            'getDataTable("System").acceptChanges()
            GF.UPC.System.DIRECNAME = "???"
            GF.UPC.System.XMLLOC = "C://"
            'GF.UPC.System.XMLLOC = xmlloc
            'GF.UPC.System.DIRECNAME = direcname
            'GF.UPC.System.DEBUGDIR = debugdir
            'GF.UPC.System.IsIE5 = False
            'GF.UPC.Script.ActualScriptName = ActualScriptName
            'GF.UPC.Script.ActualScriptVersion = ActualScriptVersion
            'GF.UPC.Script.ActualScriptReleaseString = ActualScriptReleaseStr
            'Call setProduct_ThirdParty()

        Catch ex As Exception
            Throw

            'Response.Write(ex.ToString)

        End Try
    End Sub

    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        endOfPath = True
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class









