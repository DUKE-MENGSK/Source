﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class transfer0007
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        SetFocus("OBJTXT0001")
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            If GF.LS.lCreditProtection.ToString.Trim.Equals("Y") Then
                OBJTID0006.Text = "Transfer Procedure: Enter Site Key-00408" & vbCrLf & "Enter 10 digit reference number (must include 0)" & vbCrLf & "Press 1 to confirm reference number then press *" & vbCrLf & "Release the customer into the VRU" & vbCrLf & "Customer will hear a 3 second period of silence before the VRU disclosures begin"
            Else
                OBJTID0006.Text = String.Empty
            End If

            OBJTID0001.Text = String.Empty
            OBJTID0002.Text = String.Empty
            OBJTID0003.Text = String.Empty
            OBJTID0004.Text = String.Empty
            OBJTID0005.Text = String.Empty

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False
            nextPanel = Panels.TRANSFER.transfer0003

        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region



    Private Sub OBJBTN0001_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum1.Click
        Try
            'Dial pad #1
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("1")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 1")
                GF.SendDTMFTone("1")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0002_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum2.Click
        Try
            'Dial pad #1
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("2")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 2")
                GF.SendDTMFTone("2")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0003_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum3.Click
        Try
            'Dial pad #3
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("3")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 3")
                GF.SendDTMFTone("3")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0004_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum4.Click
        Try
            'Dial pad #4
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("4")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 4")
                GF.SendDTMFTone("4")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0005_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum5.Click
        Try
            'Dial pad #5
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("5")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 5")
                GF.SendDTMFTone("5")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0006_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum6.Click
        Try
            'Dial pad #6
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("6")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 6")
                GF.SendDTMFTone("6")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0007_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum7.Click
        Try
            'Dial pad #7
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("7")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 7")
                GF.SendDTMFTone("7")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0008_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum8.Click
        Try
            'Dial pad #8
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("8")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 8")
                GF.SendDTMFTone("8")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0009_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum9.Click
        Try
            'Dial pad #9
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("9")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 9")
                GF.SendDTMFTone("9")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0010_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNumSplat.Click
        Try
            'Dial pad *
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("*")
            Else
                GF.LogSystemMessage("Dial Panel", "Button *")
                GF.SendDTMFTone("*")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0011_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum0.Click
        Try
            'Dial pad #0
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("0")
            Else
                GF.LogSystemMessage("Dial Panel", "Button 0")
                GF.SendDTMFTone("0")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0012_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNumPound.Click
        Try
            'Dial pad #
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone("#")
            Else
                GF.LogSystemMessage("Dial Panel", "Button #")
                GF.SendDTMFTone("#")
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub HandlePhoneButtons(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNum0.Click, btnNum1.Click, btnNum2.Click, btnNum3.Click, btnNum4.Click, btnNum5.Click, btnNum6.Click, btnNum7.Click, btnNum8.Click, btnNum9.Click, btnNumPound.Click, btnNumSplat.Click
        Try
            Dim b As Button = CType(sender, Button)
            If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                GF.SendDTMFTone(b.Text.Trim) '  send the text of the button
            Else
                GF.LogSystemMessage("Dial Panel", "Button #")
                GF.SendDTMFTone(b.Text.Trim) '  send the text of the button
            End If


        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub
    Private Sub OBJBTN0013_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OBJBTN0013.Click
        Try
            'Code added by converter to duplicate button mapping in BW6
            GF.LS.lDialExtension = "1"
            PanelEditAutoMapping()
            Dim ext As String = String.Empty

            If Trim(OBJTXT0001.Text).Equals(String.Empty) Then
                DisplayError("Please Fill in the Dial Pad Alternative Field")
                Exit Sub
            Else
                ext = OBJTXT0001.Text.Trim & "#"
                GF.LogSystemMessage("Dial Panel", "DTMF Tones sent: " & ext)

                If GF.UPC.System.ScriptEnv.ToString.Trim.Equals("PRD") OrElse GF.UPC.StationConfiguration.ComputerIdentifier.Substring(0, 7).Equals("wcmglab") Then
                    GF.SendDTMFTone(ext)
                Else
                    GF.LogSystemMessage("Dial Panel", "Dial Button; Sent: " & ext)
                    GF.SendDTMFTone(ext)
                End If

                If OBJTID0001.Text.Equals(String.Empty) Then
                    OBJTID0001.Text = "First Dial: " & OBJTXT0001.Text
                ElseIf OBJTID0002.Text.Equals(String.Empty) Then
                    OBJTID0002.Text = "Second Dial: " & OBJTXT0001.Text
                ElseIf OBJTID0003.Text.Equals(String.Empty) Then
                    OBJTID0003.Text = "Third Dial: " & OBJTXT0001.Text
                ElseIf OBJTID0004.Text.Equals(String.Empty) Then
                    OBJTID0004.Text = "Fourth Dial: " & OBJTXT0001.Text
                ElseIf OBJTID0005.Text.Equals(String.Empty) Then
                    OBJTID0005.Text = "Fifth Dial: " & OBJTXT0001.Text
                End If
                OBJTXT0001.Text = String.Empty

            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub







End Class
