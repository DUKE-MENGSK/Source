﻿Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports WestSharedFunctions

Public Class transferbegin
    Inherits STDPanel
    Implements IPanels

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "READ ONLY/SYSTEM GENERATED!!! - Required Panel Mapping Methods"
    ''' <summary>
    ''' Load controls values with their mapped variables/bound lists
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub WindowOnLoadAutoMapping() Implements IPanels.WindowOnLoadAutoMapping
        OBJSEL0001.SelectedValue = GF.LS.lTransferNumber
        SetFocus("OBJSEL0001")
        'Call custom WindowOnLoadAutoMapping function to allow programmer to perform any custom mapping
        CustomWindowOnLoadAutoMapping()
    End Sub

    ''' <summary>
    ''' Map control values to their assigned variables
    ''' </summary>
    ''' <remarks>IMPORTANT!!!! � This method is auto generated on panel save.  Any manual changes will be lost.</remarks>
    Public Sub PanelEditAutoMapping() Implements IPanels.PanelEditAutoMapping
        GF.LS.lTransferNumber = OBJSEL0001.SelectedValue
        'Call custom PanelEditAutoMapping function to allow programmer to perform any manual mapping
        CustomPanelEditAutoMapping()
    End Sub

#End Region

#Region "Required Custom Panel Mapping Methods"
    ''' <summary>
    ''' Perform any custom mapping of controls
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated WindowOnLoadAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to WindowOnLoadAutoMapping.
    '''  </remarks>
    Public Sub CustomWindowOnLoadAutoMapping() Implements IPanels.CustomWindowOnLoadAutoMapping

    End Sub

    ''' <summary>
    ''' Perform any custom mapping of controls values
    ''' </summary>
    ''' <remarks>
    ''' This method is called as part of the auto generated PanelEditAutoMapping to allow the
    ''' programmer to apply any custom mapping that is needed as part of a call to PanelEditAutoMapping
    ''' </remarks>
    Public Sub CustomPanelEditAutoMapping() Implements IPanels.CustomPanelEditAutoMapping

    End Sub

#End Region

#Region "Required Panel Event Handlers"

    ''' <summary>
    ''' Event handler fires when a panel initially loads
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Page_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            'Transfer Type
            '1 = Sale: Referred Transferred
            '2 = Status of Application: Transfer
            '3 = Referral
            '4 = Credit Protection
            'KVYAS 10252011 ADDED FOR XP# 35689
            GF.LogSystemMessageDB("TransferBegin", "Panel On Load of TransferBegin = M_PROB_CALL_I = " & GF.NGS.M_PROB_CALL_I.ToString(), CBool(GF.UPC.Script.DEBUGON))

            GF.LS.lTransferNumber = "X"

            Select Case GF.NGS.M_PRODUCT_ID.ToString.Trim
                Case "MBNACNFM", "MBNACNFS", "MBNACFSS" 'Consumer Finance
                    SetConsumer()
                Case "MBNAMAKC", "MBNASANC", "MBNASANS" 'Credit Cards
                    SetCredit()
                Case Else
                    If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                        OBJTID0001.Text = "Porfavor espere mientras lo transfiero a un especialista que le pueda assistir. " & GF.LS.lclose.ToString.Trim
                    Else
                        OBJTID0001.Text = "Please hold while I transfer you to a Specialist who will assist you further. " & GF.LS.lclose.ToString.Trim
                    End If
                    Dim bSelectOption As ListItem = New ListItem("Other", "0")
                    OBJSEL0001.Items.Add(bSelectOption)
            End Select

            WindowOnLoadAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you attempt to leave a panel.  
    ''' </summary>
    ''' <remarks>
    ''' Often used to perform validations/set values before branching takes place.
    ''' The "source" property dictates the users branching action
    '''      P = Branching to the previous panel
    '''      J = Jumping/navigating to another script path
    '''      B = Branching to the next panel
    ''' EditError - Set value based on your validation to reach desired result
    '''      0 = Deault value, continue to panel branch, no validation issues were encountered
    '''      1 = Set EditError to 1 to prevent branching forward/next.  Will still allow changing paths or going to the previous panel
    '''      2 = Set EditError to 2 to prevent all branching (next/previous/change paths)
    ''' ErrorMsg - Set in conjunction with EditError.  When EditError is > 0 the text assigned to ErrorMsg will automatically be displayed to the agent.
    ''' </remarks>
    Public Sub Page_panelEdit() Handles MyBase.panelEdit
        Try
            EditError = 0
            ErrorMsg = String.Empty

            PanelEditAutoMapping()


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Event handler fires when you are leaving a panel.
    ''' </summary>
    ''' <remarks>
    ''' Dictate where to go next using nextpanel and set_currpath.
    ''' nextPanel
    '''       If you have not reached the end of your path set the nextPanel property to the next panel in your path, nextPanel = Panels.NextPanelGroup.NextPanel.
    '''       E.G. nextPanel = Panels.Order.PhoneCapture
    '''       endOfPath - Indicate if you have reached the end of the current script path.
    '''            True means there are no more panels on the current path
    '''            False means there are more panels in the current path
    ''' set_currPath
    '''       Call this function if you wish to change script paths, set_currPath(ScriptPaths.NextScriptPath)
    '''       E.G.   set_currPath(ScriptPaths.Order)     
    '''       endOfPath - When changing Script Paths always set endofPath = False
    ''' </remarks>
    Private Sub Page_panelBranch() Handles MyBase.panelBranch
        Try
            endOfPath = False
            nextPanel = Panels.TRANSFER.transfer0002


        Catch ex As Exception
            Throw
        End Try
    End Sub


#End Region





    Private Sub SetConsumer()
        Try
            Select Case GF.LS.lTransferType.ToString.Trim
                Case "1" '1 = Sale: Referred Transferred
                    If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                        OBJTID0001.Text = "Senor/Senora____, su aplicacion ha sido referida a uno de nuestros analistas de credito. En caso de que un analista de credito no este disponible inmediatamente en espanol, ellos podran proveerle un traductor en caso de que sea necesario. Por favor espere mientras lo transfiero para la decision. " & GF.LS.lclose.ToString.Trim
                    Else
                        OBJTID0001.Text = "Mr./Ms. _______, your application has been referred to one of our credit analysts. Please hold while I transfer you for a credit decision. " & GF.LS.lclose.ToString.Trim
                    End If
                    OBJTID0002.Text = "When only a color is provided in STS, dial the number from below. When a phone number is provided in STS, select Other in the drop down to continue. Enter the phone number to dial  as seen in STS on the next screen."
                    Dim aSelectOption As ListItem = New ListItem("GREEN", "8886245317")
                    Dim bSelectOption As ListItem = New ListItem("BLUE", "8887846262")
                    Dim cSelectOption As ListItem = New ListItem("YELLOW", "8886244610")
                    Dim dSelectOption As ListItem = New ListItem("ELITE GREEN", "8885006268")
                    Dim eSelectOption As ListItem = New ListItem("SPANISH ANALYST", "8889628557")
                    Dim fSelectOption As ListItem = New ListItem("BFS", "8886244761")
                    Dim hSelectOption As ListItem = New ListItem("ITA MULTI CARD PCS", "8778110633")
                    Dim iSelectOption As ListItem = New ListItem("SRU CALLBACK TFN", "8553151431")
                    Dim gSelectOption As ListItem = New ListItem("Other", "0")
                    OBJSEL0001.Items.Add(aSelectOption)
                    OBJSEL0001.Items.Add(bSelectOption)
                    OBJSEL0001.Items.Add(cSelectOption)
                    OBJSEL0001.Items.Add(dSelectOption)
                    OBJSEL0001.Items.Add(eSelectOption)
                    OBJSEL0001.Items.Add(fSelectOption)
                    OBJSEL0001.Items.Add(hSelectOption)
                    OBJSEL0001.Items.Add(iSelectOption)
                    OBJSEL0001.Items.Add(gSelectOption)
                Case "2" '2 = Status of Application: Transfer
                    'Status of Application Transferred
                    If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                        OBJTID0001.Text = "Por favor mantengase en la linea mientras lo (a) transfiero con un analista de credito quien podra asistirle. " & GF.LS.lclose.ToString.Trim
                    Else
                        OBJTID0001.Text = "Please hold while I transfer you to a Credit Analyst who can further assist you. " & GF.LS.lclose.ToString.Trim
                    End If
                    OBJTID0002.Text = String.Empty
                    Dim aSelectOption As ListItem = New ListItem("STATUS OF APPLICATION TRANSFER", "8882576262")
                    OBJSEL0001.Items.Add(aSelectOption)
                Case "3" '3 = Referral
                    If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                        OBJTID0001.Text = "Porfavor espere mientras lo transfiero a un especialista que le pueda assistir. " & GF.LS.lclose.ToString.Trim
                    Else
                        OBJTID0001.Text = "Please hold while I transfer you to a Specialist who will assist you further. " & GF.LS.lclose.ToString.Trim
                    End If
                    OBJTID0002.Text = String.Empty
                    Select Case GF.NGS.Second_Disp.ToString.Trim
                        Case "J400" 'Spanish Speaking Representative
                            Dim aSelectOption As ListItem = New ListItem("SPANISH", "8886239280")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "J500" 'Other
                            Dim aSelectOption As ListItem = New ListItem("OTHER", "0")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "J600" 'Customer Service
                            Dim aSelectOption As ListItem = New ListItem("CONSUMER FINANCE CUSTOMER SERVICE", "8008928349")
                            Dim bSelectOption As ListItem = New ListItem("CREDIT CARD CUSTOMER SERVICE", "8003626299")
                            OBJSEL0001.Items.Add(aSelectOption)
                            OBJSEL0001.Items.Add(bSelectOption)
                        Case "J700"
                            Dim aSelectOption As ListItem = New ListItem("RETURNING CALL", "8882576262")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "J800" ''Spanish Customer Service
                            Dim aSelectOption As ListItem = New ListItem("SPANISH CUSTOMER SERVICE", "8008928349")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "J900" 'Complete CC Application
                            Dim aSelectOption As ListItem = New ListItem("COMPLETE CC APPLICATION", "8668676339")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "SC00"
                            Dim aSelectOption As ListItem = New ListItem("SUPERVISOR CALL", "8668907388")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case Else
                            'dim aSelectOption as ListItem = new ListItem("BALANCE TRANSFER","8888006375")
                            'dim bSelectOption as ListItem = new ListItem("TACS", getDatatrim ("LocalStore", "lRefNumber") )
                            'dim cSelectOption as ListItem = new ListItem("CREDIT","8008086220")
                            'dim dSelectOption as ListItem = new ListItem("FRAUD APPLICATIONS","8882316262")
                            'OBJSEL0001.Items.Add(aSelectOption)
                            'OBJSEL0001.Items.Add(bSelectOption)
                            'OBJSEL0001.Items.Add(cSelectOption)
                            'OBJSEL0001.Items.Add(dSelectOption)

                            'Referral:
                            '"	Business Customer Service:  800-673-1044
                            '"	Customer Marketing	888-800-6375
                            '"	Spanish Call: 	800-682-6262
                            '"	Question about an Existing Account:    800-362-6299 or 800-421-2110 varies by phone number, needs to mirror how ADE is currently set up
                            '"	Close Account (Retention):  800-362-6299
                            '"	Consumer Finance:   800-892-8349
                            '"	Apply for Different Product:   800-432-1000
                            '"	Balance Transfers:   888-800-6375
                            '"	Spanish Customer Service (TACS):   800-778-6262
                            '"	NEA Member Benefits:   800-637-4636
                            '"	Product Change Unit - 800-362-6299
                            '"	Other:  Needs to allow the agent to enter number since this is not an exhaustive list
                    End Select
                Case Else 'Default
                    Dim aSelectOption As ListItem = New ListItem("DEFAULT", "0")
                    OBJSEL0001.Items.Add(aSelectOption)
                    OBJTID0002.Text = String.Empty
            End Select
        Catch ex As Exception
            Throw
        End Try
    End Sub
    Private Sub SetCredit()
        Try
            Dim gold As String = GF.NGS.SELECT113.ToString.Trim

            Select Case GF.LS.lTransferType.ToString.Trim
                Case "1" '1 = Sale: Referred Transferred
                    If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                        OBJTID0001.Text = "Lo (a) voy a transferir ahora. " & GF.LS.lclose.ToString.Trim
                    Else
                        OBJTID0001.Text = "I will transfer you now. " & GF.LS.lclose.ToString.Trim
                    End If
                    OBJTID0002.Text = String.Empty
                    Select Case GF.LS.l800NumberDialed.ToString.Trim
                        Case "8003765559", "8004195552", "8004898666", "8004627227"
                            'Default Verbiage Above
                            Dim aSelectOption As ListItem = New ListItem("OTHER", "0")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "8668676331"
                            'Default Verbiage Above
                            'Plus These Instructions
                            OBJTID0002.Text = String.Empty
                            '"Please transfer to the account number line by pressing *8 (you will hear dial tone) and 03#.
                            'Tell the Telesales representative. Hi, this is . I have personal identification number _____.  Allow the Credit Analyst to access and confirm account.  Please release.
                            ''Speed dial 03
                            Dim aSelectOption As ListItem = New ListItem("OTHER", "0")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "8008336262", "8008449155"
                            'Default Verbiage Above
                            'Case "CC11"
                            ''CC0027 General Transfer Connect Procedures get 01# STS
                            Dim aSelectOption As ListItem = New ListItem("OTHER", "0")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case Else
                            If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                                OBJTID0001.Text = "Porfavor espere mientras lo transfiero a un analista de credito quien tomara una decision inmediata para usted. El analista de credito le va a pedir su numero de seguro social para accesar su solicitud.   Si nuestro analista de credito no esta disponible para tomar su llamada porfavor deje un mensaje y nosotros le llamaremos lo mas pronto possible. El departamento de credito esta disponible de lunes a viernes desde las 8:00 a.m. hasta las 5:00 p.m. y el numero es " & GF.LS.lRefNumber.ToString.Trim & ". "
                                'OBJTID0001.innerHTML = "I am now going to transfer you to a Credit Analyst who will make an immediate decision on your application, please have your Social Security Number ready.  If our credit analysts are unavailable to take your call please leave a message and we will call you back as soon as possible.  You can also reach our credit analyst Monday thru Friday 8am-5pm eastern at " getDatatrim ("LocalStore", "lRefNumber") & ". "
                                Dim aSelectOption As ListItem = New ListItem("REFERRAL", GF.LS.lRefNumber.ToString.Trim)
                                OBJSEL0001.Items.Add(aSelectOption)
                            ElseIf gold.Equals("Y") Then
                                OBJTID0001.Text = "Mr./Ms. _______, your application has been referred to one of our credit analysts. Please hold while I transfer you."
                                OBJTID0002.Text = "When only a color is provided in STS, dial the number from below. When a phone number is provided in STS, select Other in the drop down to continue. Enter the phone number to dial  as seen in STS on the next screen."
                                Dim aSelectOption As ListItem = New ListItem("GREEN", "8886245317")
                                Dim bSelectOption As ListItem = New ListItem("BLUE", "8887846262")
                                Dim cSelectOption As ListItem = New ListItem("YELLOW", "8886244610")
                                Dim dSelectOption As ListItem = New ListItem("ELITE GREEN", "8885006268")
                                Dim eSelectOption As ListItem = New ListItem("SPANISH ANALYST", "8889628557")
                                Dim fSelectOption As ListItem = New ListItem("BFS", "8886244761")
                                Dim hSelectOption As ListItem = New ListItem("ITA MULTI CARD PCS", "8778110633")
                                Dim iSelectOption As ListItem = New ListItem("SRU CALLBACK TFN", "8553151431")
                                Dim gSelectOption As ListItem = New ListItem("Other", "0")
                                OBJSEL0001.Items.Add(aSelectOption)
                                OBJSEL0001.Items.Add(bSelectOption)
                                OBJSEL0001.Items.Add(cSelectOption)
                                OBJSEL0001.Items.Add(dSelectOption)
                                OBJSEL0001.Items.Add(eSelectOption)
                                OBJSEL0001.Items.Add(fSelectOption)
                                OBJSEL0001.Items.Add(hSelectOption)
                                OBJSEL0001.Items.Add(iSelectOption)
                                OBJSEL0001.Items.Add(gSelectOption)
                            Else
                                OBJTID0001.Text = "I am now going to transfer you to a Credit Analyst who will make an immediate decision on your application, please have your Social Security Number ready. "
                                Dim aSelectOption As ListItem = New ListItem("OTHER", "0")
                                OBJSEL0001.Items.Add(aSelectOption)
                            End If
                    End Select

                Case "2" '2 = Status of Application: Transfer
                    If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                        OBJTID0001.Text = "Porfavor espere mientras lo transfiero a un especialista que le pueda assistir. " & GF.LS.lclose.ToString.Trim
                    Else
                        OBJTID0001.Text = "Please hold while I transfer you to a Specialist who will assist you further. " & GF.LS.lclose.ToString.Trim
                    End If
                    OBJTID0002.Text = String.Empty
                    If gold.Equals("Y") Then 'Gold
                        Select Case GF.NGS.SELECT107.ToString.Trim
                            Case "A"
                                Dim aSelectOption As ListItem = New ListItem("BALANCE TRANSFER", "8008928349")
                                OBJSEL0001.Items.Add(aSelectOption)
                            Case "B"
                                Dim aSelectOption As ListItem = New ListItem("TACS", "8008928349")
                                OBJSEL0001.Items.Add(aSelectOption)
                            Case "C"
                                Dim aSelectOption As ListItem = New ListItem("CREDIT", "8882576262")
                                OBJSEL0001.Items.Add(aSelectOption)
                            Case "E"
                                Dim aSelectOption As ListItem = New ListItem("ITA MULTI CARD PCS", "8778110633")
                                OBJSEL0001.Items.Add(aSelectOption)
                            Case "F"
                                Dim aSelectOption As ListItem = New ListItem("SRU CALLBACK TFN", "8553151431")
                                OBJSEL0001.Items.Add(aSelectOption)
                            Case "D"
                                If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                                    OBJTID0001.Text = "Lo (a) voy a conectar con un especialista quien podra asistirlo (a). " & GF.LS.lclose.ToString.Trim & " y por favor mantengase en la linea mientras lo (a) conecto."
                                Else
                                    OBJTID0001.Text = "I am going to connect you with a specialist that will be able to assist you further. " & GF.LS.lclose.ToString.Trim & " Please hold while I connect you. "
                                End If
                                Dim aSelectOption As ListItem = New ListItem("FRAUD", "8008928349")
                                OBJSEL0001.Items.Add(aSelectOption)
                            Case Else
                        End Select
                    Else
                        Select Case GF.NGS.SELECT107.ToString.Trim
                            Case "A"
                                Dim aSelectOption As ListItem = New ListItem("ENGLISH BALANCE TRANSFER", "8888006375")
                                OBJSEL0001.Items.Add(aSelectOption)
                                Dim bSelectOption As ListItem = New ListItem("SPANISH BALANCE TRANSFER", "8006113072")
                                OBJSEL0001.Items.Add(bSelectOption)
                            Case "B"
                                Dim aSelectOption As ListItem = New ListItem("MBNA TACS", "8004212110")
                                Dim bSelectOption As ListItem = New ListItem("BANKCARD SERVICES TACS", "8003626299")
                                Dim cSelectOption As ListItem = New ListItem("SPANISH TACS", "8007786262")
                                Dim dSelectOption As ListItem = New ListItem("MBNA AMERICAN EXPRESS TACS", "8009006651")
                                Dim eSelectOption As ListItem = New ListItem("BANKCARD AMERICAN EXPRESS TACS", "8886853489")
                                Dim fSelectOption As ListItem = New ListItem("LL BEAN MBNA TACS", "8002972326")
                                Dim gSelectOption As ListItem = New ListItem("CHARLES SCHWAB TACS", "8667249224")
                                Dim hSelectOption As ListItem = New ListItem("QUANTUM TACS", "8008963698")
                                Dim iSelectOption As ListItem = New ListItem("BUSINESS CARD TACS", "8888593261")
                                Dim jSelectOption As ListItem = New ListItem("CONSUMER FINANCE TACS", "8008928349")
                                Dim kSelectOption As ListItem = New ListItem("SPANISH CONSUMER FINANCE TACS", "8887861116")
                                Dim lSelectOption As ListItem = New ListItem("ITA MULTI CARD PCS", "8778110633")
                                Dim mSelectOption As ListItem = New ListItem("SRU CALLBACK TFN", "8553151431")
                                OBJSEL0001.Items.Add(aSelectOption)
                                OBJSEL0001.Items.Add(bSelectOption)
                                OBJSEL0001.Items.Add(cSelectOption)
                                OBJSEL0001.Items.Add(dSelectOption)
                                OBJSEL0001.Items.Add(eSelectOption)
                                OBJSEL0001.Items.Add(fSelectOption)
                                OBJSEL0001.Items.Add(gSelectOption)
                                OBJSEL0001.Items.Add(hSelectOption)
                                OBJSEL0001.Items.Add(iSelectOption)
                                OBJSEL0001.Items.Add(jSelectOption)
                                OBJSEL0001.Items.Add(kSelectOption)
                                OBJSEL0001.Items.Add(lSelectOption)
                                OBJSEL0001.Items.Add(mSelectOption)
                            Case "C"
                                Dim aSelectOption As ListItem = New ListItem("ENGLISH CREDIT", "8666803853")
                                OBJSEL0001.Items.Add(aSelectOption)
                                Dim bSelectOption As ListItem = New ListItem("SPANISH CREDIT", "8665309825")
                                OBJSEL0001.Items.Add(bSelectOption)
                            Case "D"
                                If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                                    OBJTID0001.Text = "Lo (a) voy a conectar con un especialista quien podra asistirlo (a). " & GF.LS.lclose.ToString.Trim & " y por favor mantengase en la linea mientras lo (a) conecto."
                                Else
                                    OBJTID0001.Text = "I am going to connect you with a specialist that will be able to assist you further. " & GF.LS.lclose.ToString.Trim & " Please hold while I connect you. "
                                End If

                                Dim aSelectOption As ListItem = New ListItem("FRAUD", "8882316262")
                                OBJSEL0001.Items.Add(aSelectOption)
                        End Select
                    End If

                Case "3" '3 = Referral
                    OBJTID0002.Text = String.Empty
                    If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                        OBJTID0001.Text = "Lo (a) voy a transferir ahora. " & GF.LS.lclose.ToString.Trim
                    Else
                        OBJTID0001.Text = "I will transfer you now. " & GF.LS.lclose.ToString.Trim
                    End If

                    Select Case GF.NGS.Second_Disp.ToString.Trim
                        Case "D400"
                            Dim aSelectOption As ListItem = New ListItem("CONSUMER FINANCE APPLICATION", "8006262760")
                            OBJSEL0001.Items.Add(aSelectOption)
                            Dim bSelectOption As ListItem = New ListItem("CONSUMER FINANCE CUSTOMER SERVICE", "8008928349")
                            OBJSEL0001.Items.Add(bSelectOption)
                        Case "D600"
                            Dim aSelectOption As ListItem = New ListItem("BUSINESS CUSTOMER SERVICE", "8888593261")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "D700"
                            Dim aSelectOption As ListItem = New ListItem("APPLY FOR DIFFERENT PRODUCT", "8003450397")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "DM00"
                            If gold.Equals("Y") Then 'Gold
                                Dim aSelectOption As ListItem = New ListItem("CUSTOMER MARKETING", "8888928349")
                                OBJSEL0001.Items.Add(aSelectOption)
                            Else
                                Dim aSelectOption As ListItem = New ListItem("CUSTOMER MARKETING", "8888006375")
                                OBJSEL0001.Items.Add(aSelectOption)
                            End If
                        Case "D900"
                            If gold.Equals("Y") Then 'Gold
                                Dim aSelectOption As ListItem = New ListItem("BALANCE TRANSFER", "8888928349")
                                OBJSEL0001.Items.Add(aSelectOption)
                            Else
                                Dim aSelectOption As ListItem = New ListItem("BALANCE TRANSFER", "8888006375")
                                OBJSEL0001.Items.Add(aSelectOption)
                            End If
                        Case "DA00"
                            Dim aSelectOption As ListItem = New ListItem("SPANISH CALL", "8006826262")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "DB00"
                            If gold.Equals("Y") Then 'Gold
                                Dim aSelectOption As ListItem = New ListItem("SPANISH CUSTOMER SERVICE", "8008928349")
                                OBJSEL0001.Items.Add(aSelectOption)
                            Else
                                Dim aSelectOption As ListItem = New ListItem("SPANISH CUSTOMER SERVICE", "8007786262")
                                OBJSEL0001.Items.Add(aSelectOption)
                            End If
                        Case "DH00"
                            Dim aSelectOption As ListItem = New ListItem("QUESTIONS ABOUT ACCOUNT", GF.LS.lRefNumber.ToString.Trim)
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "DI00"
                            Dim aSelectOption As ListItem = New ListItem("NEA MEMBER BENEFITS", "8006374636")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "DF00"
                            Dim aSelectOption As ListItem = New ListItem("OTHER", "0")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Case "SC00"
                            Dim aSelectOption As ListItem = New ListItem("SUPERVISOR CALL", "8668907388")
                            OBJSEL0001.Items.Add(aSelectOption)
                    End Select
                Case "4" '4 = Credit Protection
                    'CREDIT PROTECTION PLUS
                    OBJTID0002.Text = String.Empty
                    If GF.LS.lCreditProtection.ToString.Trim.Equals("Y") Then
                        If GF.LS.lSpanishFlag.ToString.Trim.Equals("Y") Then
                            OBJTID0001.Text = "Para completar su inscripcion en el plan opcional Credit Protection Plus, voy a transferir su llamada a un sistema automatizado. Despues de la inscripcion, se le enviarainformacion mas detallada sobre el programa. Simplemente, presione 'l' en su telefono para confirmar su inscripcion en este programa. Espere uninstante mientras transfiero su llamada al sistema automatizado."
                            Dim aSelectOption As ListItem = New ListItem("CREDIT PROTECTION", "8662005960")
                            OBJSEL0001.Items.Add(aSelectOption)
                        Else
                            OBJTID0001.Text = "To complete your enrollment in the optional Credit Protection Plus program, I am going to transfer you into an automated system to hear a few additional details. After being enrolled, the information about the program will then be sent to you. After you hear the details just press #1 on your phone to confirm and you will be all set. hold on one moment, please."
                            Dim aSelectOption As ListItem = New ListItem("CREDIT PROTECTION", "8662005855")
                            OBJSEL0001.Items.Add(aSelectOption)
                        End If
                    End If
                Case Else
                    Dim aSelectOption As ListItem = New ListItem("DEFAULT", "0")
                    OBJSEL0001.Items.Add(aSelectOption)
            End Select
        Catch ex As Exception
            Throw
        End Try
    End Sub





End Class
