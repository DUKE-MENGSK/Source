﻿Public Class DebugWindow
    Inherits STDPanel


    Protected selectedTable As String
    Protected myTextBox1 As TextBox
    Protected myTextBox2 As TextBox

    Protected _standardTypes As List(Of String) = New List(Of String)({"NGS", "LS"})
    Protected _selectableTypes As List(Of String) = New List(Of String)
    Protected _currentClassInstance As Dictionary(Of String, String) = New Dictionary(Of String, String)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then
            LoadLegacyTableNames()
            LoadBwDotNetClasses()
            DisplaySelectedBwDotNetClass()
        End If

        HandleDataBindLegacyTable()

    End Sub

    ''' <summary>
    ''' load the bw.net class drop down
    ''' </summary>
    Public Sub LoadBwDotNetClasses()

        _selectableTypes.Clear()
        _selectableTypes.AddRange(_standardTypes)

        ' get the UPC types to display
        Dim pi() As Reflection.PropertyInfo = GF.UPC.GetType().GetProperties(Reflection.BindingFlags.Public Or Reflection.BindingFlags.Instance)

        For Each i As Reflection.PropertyInfo In pi
            _selectableTypes.Add(String.Format("UPC.{0}", i.Name))
        Next

        _selectableTypes.Sort()

        ddlUpc.DataSource = _selectableTypes
        ddlUpc.DataBind()

    End Sub

    ''' <summary>
    ''' grab name/values for the selected class and bind the grid
    ''' </summary>
    Public Sub DisplaySelectedBwDotNetClass()

        Dim className As String = ddlUpc.SelectedValue
        Dim classObject As Object = GetBwDotNetClassObject(className)

        _currentClassInstance.Clear()

        If classObject IsNot Nothing Then
            Dim pi() As Reflection.PropertyInfo = classObject.GetType().GetProperties(Reflection.BindingFlags.Public Or Reflection.BindingFlags.Instance)
            For Each x As Reflection.PropertyInfo In pi
                If x.Name.Equals("GenericVariableDic", StringComparison.InvariantCultureIgnoreCase) Then
                    'Handle Generic lists			
                    Dim GenericVariableDic As Dictionary(Of String, String) = New Dictionary(Of String, String)(StringComparer.InvariantCultureIgnoreCase)                   
                    GenericVariableDic = x.GetValue(classObject, Nothing)
                    For Each var As KeyValuePair(Of String, String) In GenericVariableDic
                        _currentClassInstance.Add(var.Key, var.Value)
                    Next
                Else
                    _currentClassInstance.Add(x.Name, x.GetValue(classObject, Nothing))
                End If
            Next
        End If

        dgUpc.DataSource = _currentClassInstance
        dgUpc.DataBind()

    End Sub

    ''' <summary>
    ''' get the object to work with based on the given class name
    ''' </summary>
    Private Function GetBwDotNetClassObject(className As String) As Object

        Dim classObject As Object = Nothing

        Select Case className.ToLower()
            Case "ngs"
                classObject = GF.NGS
            Case "ls"
                classObject = GF.LS
            Case Else
                If className.StartsWith("UPC.", StringComparison.InvariantCultureIgnoreCase) Then
                    className = className.Substring(4)
                    Dim pi() As Reflection.PropertyInfo = GF.UPC.GetType().GetProperties(Reflection.BindingFlags.Public Or Reflection.BindingFlags.Instance)
                    For Each i As Reflection.PropertyInfo In pi
                        If i.Name.Equals(className) Then
                            classObject = i.GetValue(GF.UPC, Nothing)
                        End If
                    Next
                End If
        End Select

        Return classObject

    End Function

    ''' <summary>
    ''' rebind the data when the selection changes
    ''' </summary>
    Private Sub ddlUpc_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlUpc.SelectedIndexChanged
        DisplaySelectedBwDotNetClass()
    End Sub

    ''' <summary>
    ''' add an id to the link button so we can focus it after an update
    ''' </summary>
    Private Sub dgUpc_ItemCreated(sender As Object, e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dgUpc.ItemCreated
        If Not (e.Item.ItemType = ListItemType.Footer Or e.Item.ItemType = ListItemType.Header) Then
            Dim btn As LinkButton = e.Item.Cells(0).Controls(0)
            btn.Attributes.Add("id", String.Format("lnkBtn_{0}", e.Item.ItemIndex))
        End If
    End Sub

#Region "BW.Net Field Updates"

    Public Sub dgUpc_Edit(sender As Object, e As DataGridCommandEventArgs)

        ' Set the EditItemIndex property to the index of the item clicked 
        ' in the DataGrid control to enable editing for that item. Be sure
        ' to rebind the DateGrid to the data source to refresh the control.
        dgUpc.EditItemIndex = e.Item.ItemIndex
        DisplaySelectedBwDotNetClass()

        lblUpc.Text = ""

        Try
            Dim txtId As String = CType(dgUpc.Items(e.Item.ItemIndex).Cells(2).Controls(0), TextBox).ClientID
            Dim strBuilder As StringBuilder = New StringBuilder(256)
            strBuilder.Append("<script language='javascript'>")
            strBuilder.AppendFormat("setTimeout(""document.getElementById('{0}').focus();document.getElementById('{0}').select()"", 100)", txtId)
            strBuilder.Append("</script>")
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Startup", strBuilder.ToString())
        Catch ex As Exception
            ' go on, just trying to keep focus
        End Try

    End Sub

    Public Sub dgUpc_Cancel(sender As Object, e As DataGridCommandEventArgs)

        lblUpc.Text = ""

        ' Set the EditItemIndex property to -1 to exit editing mode.
        ' Be sure to rebind the DateGrid to the data source to refresh
        ' the control.
        dgUpc.EditItemIndex = -1
        DisplaySelectedBwDotNetClass()

    End Sub

    Public Sub dgupc_Update(sender As Object, e As DataGridCommandEventArgs)

        Try
            lblUpc.Text = ""
            Dim propName As String = e.Item.Cells(1).Text
            Dim propValue As String = CType(e.Item.Cells(2).Controls(0), TextBox).Text
            Dim className As String = ddlUpc.SelectedValue
            Dim classObject As Object = GetBwDotNetClassObject(className)

            If classObject IsNot Nothing Then
                Dim pi() As Reflection.PropertyInfo = classObject.GetType().GetProperties(Reflection.BindingFlags.Public Or Reflection.BindingFlags.Instance)
                For Each x As Reflection.PropertyInfo In pi
                    If x.Name.Equals(propName) Then
                        If x.CanWrite Then
                            x.SetValue(classObject, Convert.ChangeType(propValue, x.PropertyType), Nothing)
                        Else
                            Throw New Exception(String.Format("Property [{0}] is readonly.", x.Name))
                        End If
                        Exit For
                    End If
                Next
            End If

            Try
                Dim strBuilder As StringBuilder = New StringBuilder(256)
                strBuilder.Append("<script language='javascript'>")
                strBuilder.AppendFormat("setTimeout(""document.getElementById('lnkBtn_{0}').focus()"", 100)", e.Item.ItemIndex)
                strBuilder.Append("</script>")
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "Startup", strBuilder.ToString())
            Catch ex As Exception
                ' go on, just trying to keep focus
                'test
                Response.Write(ex.ToString())
            End Try

            dgUpc.EditItemIndex = -1
            DisplaySelectedBwDotNetClass()


        Catch ex As Exception
            lblUpc.Text = ex.Message()
        End Try

    End Sub

#End Region



#Region "Legacy Dataset Code"

    Public Sub HandleDataBindLegacyTable()


        selectedTable = myList.SelectedValue
        DataGridTable.DataSource = GF.sessionDataset
        DataGridTable.DataMember = selectedTable
        DataGridTable.DataBind()

    End Sub

    Private Sub LoadLegacyTableNames()

        myList.Items.Clear()
        Dim i As Integer

        For i = 0 To GF.sessionDataset.Tables.Count - 1
            myList.Items.Add(GF.sessionDataset.Tables(i).TableName)

        Next

    End Sub

    Public Sub edit(ByVal s As Object, ByVal e As DataGridCommandEventArgs)
        DataGridTable.Visible = False
        tblUpdate.Visible = True
        btnUpdate.Visible = True
        btnCancel.Visible = True
        myList.Enabled = True

        myTextBox1 = tblUpdate.FindControl("txtName")
        myTextBox1.Text = e.Item.Cells(1).Text
        myTextBox2 = tblUpdate.FindControl("txtValue")
        myTextBox2.Text = e.Item.Cells(2).Text

    End Sub


    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click

        DataGridTable.Visible = True
        tblUpdate.Visible = False
        btnUpdate.Visible = False
        btnCancel.Visible = False
        myList.Enabled = True
        myTextBox1 = tblUpdate.FindControl("txtName")
        myTextBox2 = tblUpdate.FindControl("txtValue")

        GF.SetUPCData(selectedTable, myTextBox1.Text, myTextBox2.Text)

        Call HandleDataBindLegacyTable()

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        DataGridTable.Visible = True
        tblUpdate.Visible = False
        btnUpdate.Visible = False
        btnCancel.Visible = False
        myList.Enabled = True
    End Sub


#End Region

End Class
