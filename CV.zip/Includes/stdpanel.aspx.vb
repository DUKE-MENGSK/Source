﻿Imports System.Web.Mail
Imports System.Threading

Public Class STDPanel
    Inherits BaseSTDPanel

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()

        'If Not GF.LS Is Nothing Then
        '    If Not GF.LS.lStatusFlag = "2" Then
        '        GF.gfStartMRAThread()
        '    End If
        'End If
    End Sub

#End Region

    'Private mraService As MRAService.MRAServiceClient 'boa mra webservice

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        DoStuff("Page_load IsPostBack = False")

    End Sub

    Private Sub DoStuff(ByVal message As String)
        Try
            Dim owner = Me
            GF.LS.lsTimeSleep = 3000
            Select Case owner.AppRelativeVirtualPath.ToLower()
                Case "~/panels/other/prelogging.aspx",
                    "~/panels/other/logging.aspx",
                    "~/panels/other/logcomplete.aspx",
                    "~/panels/other/transfer0002.aspx",
                    "~/panels/other/screenpop.aspx"
                    Exit Select

                Case Else
                    StartTimer(message)
            End Select

        Catch ex As Exception
            DisplayError(ex.Message)
        End Try
    End Sub

    Private Sub Page_panelEdit() Handles Me.panelEdit
        Try
            StartTimer("from Page_PanelEdit")
        Catch ex As Exception
            HandleExceptions(ex, False)
        End Try
    End Sub

    Private Sub Page_panelBranch() Handles Me.panelBranch
        Try
            StartTimer("from panelBranch")
        Catch ex As Exception
            HandleExceptions(ex, False)
        End Try
    End Sub

    Public Sub stdPanelPage_panelOnLoad() Handles MyBase.panelOnLoad
        Try
            'todo: check for all the necessary flags.  Any panels we need to skip(like logging?)
            StartTimer("from stdPanelPage_panelOnLoad")
        Catch ex As Exception
            HandleExceptions(ex, False)
        End Try

    End Sub


    Private Sub Page_panelSubmit() Handles Me.panelSubmit
        Try
            'If mraService Is Nothing Then
            '    mraService = New MRAService.MRAServiceClient()
            'End If

            If Request.QueryString("conferencenum") IsNot Nothing Then
                GF.LS.ltransferdial = "Y"
                GF.DialThirdParty(Request.QueryString("conferencenum"), "CONFERENCE") 'todo: not sure what else should be done here.  add in your current dial code.

                Thread.Sleep(2000) ' wait for 2 seconds"
                '[INC1822775] Move to DialThirdPartyAnswered
                'GF.gfConference()
                'GF.LS.lStatusFlag = "2"


                'mraService.AllowConsent(GF.LS.MBK, "") 'Update the Data per MBK after Initiating Conference Call

                'If Not String.IsNullOrWhiteSpace(GF.LS.MBK) Then
                '    GF.LogSystemMessage("MRA Conference", String.Format("MBK = {0}, 800Number = {1}", GF.LS.MBK, GF.NGS.BusinessData32))
                'End If
                'End [INC1822775]
                Exit Sub 'todo:  any reason we should stop the timer?
            End If

            StartTimer("from StdPanel, Page_panelSubmit")

        Catch ex As Exception
            HandleExceptions(ex, False)
            GF.LogSystemMessage("stdPanel Page_panelSubmit", ex.Message())
            'GF.LogException(ex)
        End Try
    End Sub

    Sub StartTimer(ByVal pCallingFrom As String)
        'GF.LogSystemMessage("IN StartTimer", "tempBaseInterval = " & tempBaseInterval & "adjustedInterval = " & adjustedInterval & "TinerStarted = " & GF.LS.lPhoneStateRulesTimerStarted & "Called From = " & pCallingFrom)
        'GF.LogSystemMessage("IN StartTimer", "Called From = " & pCallingFrom)

        'todo:  check if in a call, only call if is in a call....I don't know the flag for that callmode =1?
        'If GF.UPC.Script.CALLMODE = CALLMODE_ACTIVE and ME.UPC.Script.DISCONNECTED.ToUpper() <> "Y" Then  //todo:not sure if this is the in a call check or not
        'Exit Sub
        'End If

        If String.IsNullOrEmpty(GF.SL.ScriptSLWebserviceValues.CommonGenericDataLookup) Then

            Exit Sub
        End If

        If GF.LS.l3rdPartyOrCallerDisconConference = "Y" Then
            'If GF.UPC.Script.CALLMODE = CALLMODE_ACTIVE And GF.UPC.Script.DISCONNECTED.ToUpper() <> "Y" Then

            Dim urlpath As String = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + ResolveUrl("~/")

            If myClientCode.Contains("function doPost()") Then
                Exit Sub
            End If

            Dim sb As New System.Text.StringBuilder("")
            sb.Append("var request;").Append(vbCrLf)
            sb.Append(String.Format("setTimeout(""doPost()"", {0});", 3000)).Append(vbCrLf)
            sb.Append("function doPost(){").Append(vbCrLf)
            sb.Append("try {" & vbCrLf)
            sb.Append("     request = new XMLHttpRequest();").Append(vbCrLf)
            sb.Append("     request.onreadystatechange=stateChanged;").Append(vbCrLf)
            sb.Append("     request.open('POST', '" + urlpath + "Panels/Other/MRAWebserviceCall.aspx', true);").Append(vbCrLf) ' //todo: url change
            sb.Append("     request.send("""");").Append(vbCrLf)
            sb.Append("} catch (e) {" & vbCrLf)
            'sb.Append("    alert('do error' + e.name + ': ' + e.message);" & vbCrLf)
            sb.Append("     writeError('starttimer doPost:' + e.name + ':' + e.message);" & vbCrLf)
            sb.Append("}" & vbCrLf)
            sb.Append("};").Append(vbCrLf)
            sb.Append("").Append(vbCrLf)


            sb.Append("function stateChanged(){").Append(vbCrLf)
            sb.Append("try {" & vbCrLf)
            sb.Append(" if (request.readyState == 4) {").Append(vbCrLf)
            'sb.Append("     alert('state:' + request.readyState + ' ' + request.status + ' ' + request.responseText);" & vbCrLf)
            sb.Append(" if (request.status == 200) {").Append(vbCrLf)
            sb.Append("    var result = request.responseText;").Append(vbCrLf)
            'sb.Append("     alert('result:' + result);" & vbCrLf)
            sb.Append("     if (result.length == 10) {").Append(vbCrLf)
            sb.Append("        if (result == ""9999999999"") {").Append(vbCrLf)
            sb.Append("           writeError('starttimer statechanged: 9999999999');" & vbCrLf)
            sb.Append("        } else {").Append(vbCrLf)
            sb.Append("         parent.BranchingFR.ButtonClick('doConference&conferencenum='+result); ").Append(vbCrLf)
            sb.Append("        }").Append(vbCrLf)
            'sb.Append("     } else {").Append(vbCrLf)
            'sb.Append("         alert(""We returned: "" );").Append(vbCrLf) 'todo: change this to some clean way to report error
            sb.Append("     }").Append(vbCrLf)
            sb.Append("     } else {").Append(vbCrLf)
            sb.Append("       writeError('starttimer statechanged:' + request.status);" & vbCrLf)
            sb.Append(" }").Append(vbCrLf)
            'sb.Append("     alert('before' );" & vbCrLf)
            sb.Append("     setTimeout(""doPost()"",3000);").Append(vbCrLf)
            sb.Append(" }").Append(vbCrLf)
            sb.Append("} catch (e) {" & vbCrLf)
            'sb.Append("    alert('state error' + e.name + ': ' + e.message);" & vbCrLf)
            sb.Append("     writeError('starttimer statechanged:' + e.name + ':' + e.message);" & vbCrLf)
            sb.Append("}" & vbCrLf)
            sb.Append("};").Append(vbCrLf)
            sb.Append("").Append(vbCrLf)



            sb.Append("function writeError(msg){").Append(vbCrLf)
            sb.Append(" if(parent.parent.parent.ErrorDisplayFR.document.readyState =='complete')").Append(Environment.NewLine)
            sb.Append(" {").Append(Environment.NewLine)
            sb.Append("     parent.parent.parent.ErrorDisplayFR.DisplayBWError('error in starttimer' + msg); ").Append(Environment.NewLine)
            sb.Append("     parent.parent.parent.MainFrame.rows = '10%,29,85%,*';").Append(Environment.NewLine)
            sb.Append(" }").Append(Environment.NewLine)
            sb.Append("};").Append(vbCrLf)
            sb.Append("").Append(vbCrLf)




            myClientCode &= sb.ToString()


        End If


    End Sub




End Class
