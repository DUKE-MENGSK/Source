﻿Imports System.Xml
Imports CustomDataSets

Public Class Nav
    Inherits System.Web.UI.Page


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            'save info to Navigation Data Table ... 
            Dim ds As FrameworkDataSet = Session("gSessionDataSet")

            If ds.Tables("NavigationData").Rows.Count = 0 Then
                Dim drCallerData As DataRow
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "LOG"
                drCallerData("pathDesc") = "Call Logging"
                drCallerData("isLogging") = "True"
                drCallerData("scriptAvailable") = "ALWAYS"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/RST0028"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "MBNA"
                drCallerData("pathDesc") = "BAC Credit Card"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "ALWAYS"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/CC0001"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "CONTACT"
                drCallerData("pathDesc") = "Do Not Contact"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "ALWAYS"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/CONTACT0001"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "ESCALFORM"
                drCallerData("pathDesc") = "Escalation Form"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "ALWAYS"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/ESCALFRM0002"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "THREAT"
                drCallerData("pathDesc") = "Threatening Call"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "ALWAYS"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/THREAT0001"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "MSG"
                drCallerData("pathDesc") = "Message Board"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "BROWSE"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/MBOARD"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "ORD"
                drCallerData("pathDesc") = "Orders"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "False"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/SCREENPOP"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "TRANSFER"
                drCallerData("pathDesc") = "Call Transfer"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/TRANSFER0001"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "FATAL"
                drCallerData("pathDesc") = "Fatal Error path branched to automatically"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "False"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/FATALSKILLS"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "OVC"
                drCallerData("pathDesc") = "Overlapping Call"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/OVC0001"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "ANSWER"
                drCallerData("pathDesc") = "AnswerCall"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "False"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/ANSWERCALL"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "STRIKE"
                drCallerData("pathDesc") = "bypass logging and set ready after strike"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "False"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/PRELOGGING"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "MANUAL"
                drCallerData("pathDesc") = "Manual Credit Card Applications"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "False"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/MANUAL0002"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "CFMANUAL"
                drCallerData("pathDesc") = "Manual Consumer Finance Applications"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/CFMANUAL0001"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "START"
                drCallerData("pathDesc") = "Greeting"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/SCREENPOP"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "MRA"
                drCallerData("pathDesc") = "MRA Conference"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "False"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/MRA0001"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "CHNGREQ"
                drCallerData("pathDesc") = "CHNGREQ"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/[None]"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "CONSUMER"
                drCallerData("pathDesc") = "CONSUMER"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/[None]"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "EBR"
                drCallerData("pathDesc") = "EBR"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/[None]"
                ds.Tables("NavigationData").Rows.Add(drCallerData)
                drCallerData = ds.Tables("NavigationData").NewRow()
                drCallerData("pathName") = "IVL"
                drCallerData("pathDesc") = "IVL"
                drCallerData("isLogging") = "False"
                drCallerData("scriptAvailable") = "NEVER"
                drCallerData("restartPath") = "True"
                drCallerData("collapsedOnStartup") = "True"
                drCallerData("level") = "1"
                drCallerData("firstPanel") = "../Panels/[None]"
                ds.Tables("NavigationData").Rows.Add(drCallerData)

            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub
End Class
