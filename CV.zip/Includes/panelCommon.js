function handleSubmit() { document.getElementById("Form1").submit(); }
   
function handleForward() {fullpath=location.pathname;
	result=fullpath.split("/");
	document.getElementById("Form1").action = result[result.length - 1] + "?PageAction=Next";
	document.getElementById("Form1").submit();
}

function handleEditNext() {fullpath=location.pathname;
	result=fullpath.split("/");
	document.getElementById("Form1").action = result[result.length - 1] + "?PageAction=PreviewNext";
	document.getElementById("Form1").submit();
} 

function handleEditPrevious() {fullpath=location.pathname;
	result=fullpath.split("/");
	document.getElementById("Form1").action = result[result.length - 1] + "?PageAction=PreviewPrevious";
	document.getElementById("Form1").submit();
} 

//-------------------------------------------
// --begin converted vbscript functions
//-------------------------------------------

function saveScrollPosition() {
		var myBody, i;
		if (document.getElementsByTagName("BODY") && (document.getElementsByTagName("BODY").length>0))
		{
			myBody = document.getElementsByTagName("BODY")[0];
			document.getElementById("txtScrollPos").innerText = myBody.scrollTop;
		}
}


document.onkeydown = checkPageDownUp;

function checkPageDownUp(e){

//-- PageDown Key -------

   if(window.event.keyCode == 34){
		if(parent.document.title != "CallScriptFrame"){
			handleEditNext;
			//alert ("Cannot go to NEXT in preview mode .. sorry!!" );
		}else{
			parent.BranchingFR.ButtonClick("Next");
		}
	}

//-- PageUp Key -------

   if(window.event.keyCode == 33){
		if(parent.document.title != "CallScriptFrame"){
			handleEditPrevious;
			alert ("Cannot go to PREVIOUS in preview mode .. sorry!!" );
		}else{
			parent.BranchingFR.ButtonClick("Previous");
		}
	}

//----------------------

} //document.onkeydown


//-------------------------//
// begin message pull code //
//-------------------------//
var messageTimer;
if (document.addEventListener) {   // Mozilla, Opera, Webkit are all happy with this
    document.addEventListener("DOMContentLoaded", function () {
        document.removeEventListener("DOMContentLoaded", arguments.callee, false);
        checkForMessage();
        messageTimer = self.setInterval(checkForMessage, 1000);
    }, false);
    window.addEventListener("beforeUnload", function () {
        self.clearInterval(messageTimer);
    }, false);
} else if (document.attachEvent) {   // IE is different...
document.attachEvent("onreadystatechange", function () {
    if (document.readyState === "complete") {
        document.detachEvent("onreadystatechange", arguments.callee);
        checkForMessage();
        messageTimer = self.setInterval(checkForMessage, 1000);
    }
});
    window.attachEvent("onbeforeunload", function () {
        self.clearInterval(messageTimer);
    });
}

function checkForMessage() {
    var message;
    if (top.CheckForQueuedMessage) {
        message = top.CheckForQueuedMessage();
        if ((message != undefined) && (message.length > 0)) {
            //alert("Posting " + message);
            fullpath = location.pathname;
            result = fullpath.split("/");
            document.getElementById("Form1").action = result[result.length - 1] + "?" + message;
            document.getElementById("Form1").submit();
        }
    }
}
//-------------------------//
// end message pull code   //
//-------------------------//