﻿'------------- THIS IS THE .NET 4.0 Framework Copy of basestdpanel.aspx.vb for the SL Division ---------

Imports System.Web.Mail
Imports West.CorpSysDev.ADE.FrameworkServices
Imports CustomDatasets
Imports System.Reflection

Public Class BaseSTDPanel
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()

    End Sub

#End Region
    'Protected WithEvents myGlobalFunction As GlobalFunctions
    Protected WithEvents GF As GlobalFunctions
    Protected WithEvents ScriptPaths As ScriptPath

    Dim qsClass As String
    Dim qsAction As String
    Dim qsMessageID As String
    Dim qsUID As String
    Dim qsErrMsg As String

    Public nextPanel As String = ""
    Public endOfPath As Boolean = False
    Public source As String = ""
    Public EditError As Integer = 0
    Public ErrorMsg As String = ""
    Public myClientCode As String

    Protected Event panelOnLoad()
    Protected Event panelEdit()
    Protected Event panelBranch()
    Protected Event panelSubmit()
    Protected Event panelAgentNotReady()
    Protected Event panelAgentSignOff()
    Protected Event panelAgentDisconnect()
    Protected Event panelThirdPartyEvent(ByVal pEvent As String)
    Protected Event panelAgentSignOnFailed(ByVal pErrorCode As String, ByVal pErrorMessage As String)
    Protected Event panelAgentMakeReadyFailed(ByVal pErrorCode As String, ByVal pErrorMessage As String)
    Protected Event panelAgentSignOn()
    Protected Event panelAgentAnswered()
    Protected Event panelAgentFailedToAnswer(ByVal pErrorCode As String)

    'Call mode constants
    Public Const CALLMODE_BROWSE = 0
    Public Const CALLMODE_ACTIVE = 1
    Public Const CALLMODE_WAITING = 2
    Public Const CALLMODE_LOGGING_CALL = 3
    Public Const CALLMODE_GLOBAL_EDIT_ERROR = 4

    Public startCallTime As DateTime

#Region "Page Level functions"

    ''' <summary>
    ''' Loads the page.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ' get script paths
            ScriptPaths = New ScriptPath()

            'Leftover session table initialization
            Dim myData As FrameworkDataset
            myData = Session("gSessionDataSet")
            'myGlobalFunction.sessionDataset = myData
            GF.sessionDataset = myData

            'DATASTORES
            Dim myDataStores As DataStoreVariables
            myDataStores = CType(Session("DataStores"), DataStoreVariables)
            GF.NGS = myDataStores

            'LOCALSTORES
            Dim myLocalStores As LocalStoreVariables
            myLocalStores = CType(Session("LocalStores"), LocalStoreVariables)
            GF.LS = myLocalStores

            'UPC SYSTEM SESSION VARIABLES 
            Dim myUPCSessionVariables As WestSharedFunctions.BaseGlobalSessionVariables
            myUPCSessionVariables = CType(Session("UPCVariables"), WestSharedFunctions.BaseGlobalSessionVariables)
            GF.UPC = myUPCSessionVariables

            'Lists
            Dim myLists As BWLists
            myLists = CType(Session("Lists"), BWLists)
            GF.Lists = myLists

            'SL Variables
            Dim mySLSessionVariables As SLSharedLib.BaseSLVariables
            mySLSessionVariables = CType(Session("SLVariables"), SLSharedLib.BaseSLVariables)
            GF.SL = mySLSessionVariables

            'kp 9/05 - added to hinder multiple next clicks
            SubmitButtonDisabler(Page)

            'override alert box begin
            Dim scriptString As New System.Text.StringBuilder
            scriptString.Append(Environment.NewLine)
            scriptString.Append("if (parent.parent.parent.MainFrame){").Append(Environment.NewLine)
            scriptString.Append("parent.parent.parent.MainFrame.rows = '0,29,95%,*';").Append(Environment.NewLine)
            scriptString.Append("    }")
            scriptString.Append(Environment.NewLine)

            myClientCode = myClientCode & scriptString.ToString()
            'override alert box end

            'Event Handling Code goes here
            qsClass = Request.QueryString("Class")
            qsAction = Request.QueryString("Action")
            qsMessageID = Request.QueryString("MessageIdentifier")
            qsUID = Request.QueryString("UserIdentifier")
            qsErrMsg = Request.QueryString("ErrorMsg")

            'GSC Check for NewCall Flag, if it is there let's add the
            ' values to make this page think it is a new call
            If Not Request.QueryString("NewCall") Is Nothing Then
                qsClass = "PHONE"
                qsAction = "NewCall"
                qsUID = GF.UPC.System.GUID
            End If

            Dim strCurrentPanel As String = findPanelName(Request.FilePath())

            If Page.IsPostBack Then
                'UMS Message intended for current script
                'If this is true, then the script knows it needs to process UMS
                qsClass = Request.QueryString("PageAction")

                'kp 8/6- I added this to allow the phone control to POST its phone events instead of reloading the page
                If IsNothing(qsClass) Then
                    qsClass = Request.QueryString("Class")
                End If

                'log a debug message when debug on
                If GF.UPC.Script.BaseDebugOn Then
                    GF.LogSystemMessage("Script", "In PAGE_LOAD Postback; class: " & qsClass & ", action: " & qsAction & ", messageID: " & qsMessageID & ", errorMsg: " & qsErrMsg & ", currentPanel: " & strCurrentPanel)
                End If

                Select Case LCase(qsClass)
                    Case "next"
                        If GF.UPC.Script.IN_BROWSER Then
                            Call PageDown()
                        End If

                    Case "previous"
                        Call PageUp()

                    Case "pathchange"
                        If Request("PathChangePath") = "UPCBASEDLOGGING" Then
                            'systxb - see sprintwam v5 for code to add to this global function...
                            GF.gfAutoLogFromUPC()
                        ElseIf GF.gfAbleToChangePaths(Request("PathChangePath")) Then
                            If GF.UPC.Script.BaseDebugOn Then
                                Call GF.LogSystemMessage("Script", "In pathChange, abletochangepaths = true; Setting current path to: " & Request("PathChangePath"))
                            End If
                            Call set_currPath(Request("PathChangePath"))
                        End If

                    Case "lastpath"
                        If GF.gfAbleToChangePaths(GF.UPC.Script.PreviousPathID) Then
                            Call HandleLastPathEvent()
                        Else
                            'display an error saying we cannot go to the given path
                            DisplayError(String.Format("You cannot return to the {0} script path", GF.UPC.Script.PreviousPathID))
                        End If

                    Case "phone"
                        HandlePhoneMessages(qsAction, qsMessageID)

                    Case "ums"
                        HandleUMS(qsAction)

                    Case "panel"
                        Call handlePanelEvents(qsAction)

                        '-- panel Preview cases ---
                    Case "previewnext"
                        Call handlePreviewNext()

                    Case "previewprevious"
                        source = "P"
                        GF.UPC.Script.LastAction = "panelEdit"
                        RaiseEvent panelEdit()
                        If Len(ErrorMsg) <> 0 Then
                            DisplayError(ErrorMsg)
                        End If

                    Case "setscriptvariable"
                        GF.LogSystemMessage("Script", Request.QueryString("VariableName") & ":" & Request.QueryString("VariableValue"))
                        GF.SetPropValueByName(GF.UPC.Script, Request.QueryString("VariableName"), Request.QueryString("VariableValue"))

                    Case Else
                        GF.UPC.Script.PanelRenderFlag = False
                        GF.UPC.Script.LastAction = "panelSubmit"
                        RaiseEvent panelSubmit()
                        If GF.UPC.Script.IN_BROWSER Then
                            DisplayError("")
                        End If
                End Select
            Else
                'log a debug message when debug on
                If GF.UPC.Script.BaseDebugOn Then
                    Call GF.LogSystemMessage("Script", "In PAGE_LOAD (not postback); class: " & qsClass & ", action: " & qsAction & ", messageID: " & qsMessageID & ", errorMsg: " & qsErrMsg & ", currentPanel: " & strCurrentPanel)
                End If

                'UMS Message intended for different script
                Select Case LCase(qsClass)
                    Case "panel"
                        Call handlePanelEvents(qsAction)

                    Case "phone"
                        'RaiseEvent panelOnLoad()
                        HandlePhoneMessages(qsAction, qsMessageID)

                    Case "ums"
                        'RaiseEvent panelOnLoad()
                        HandleUMS(qsAction)

                    Case Else
                        'Response.Write("Class in QueryString not defined")
                End Select
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub

    ''' <summary>
    ''' We need to save the data store classes back to the session in order to retain any changes made during the page lifecycle
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Page_Unload(sender As Object, e As System.EventArgs) Handles Me.Unload
        ' we need to save the data store classes back to the session in order to retain any changes made during the page lifecycle
        Session("DataStores") = GF.NGS
        Session("UPCVariables") = GF.UPC
        Session("LocalStores") = GF.LS
    End Sub

    ''' <summary>
    ''' Handle any unhandled errors at the page level.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Dim ex As Exception = Server.GetLastError
            Session("Error") = ex
            Server.ClearError()
            set_nextPanel(Panels.Other.ErrorEvents)
            PageDown()
        Catch ex As Exception
            HandleExceptions(ex)
        End Try
    End Sub

#End Region


#Region "Alerting functions"

    ''' <summary>
    ''' Throws a window alert up to the page the script is on
    ''' </summary>
    ''' <param name="strMessage">Message to show</param>
    ''' <remarks></remarks>
    Public Sub MsgBox(ByVal strMessage As String) Handles GF.eMsgBox
        Try

            Dim sb As New System.Text.StringBuilder("")

            'Clean up any characters that will mess up a script/client side message.
            strMessage = strMessage.Replace("""", "")
            strMessage = strMessage.Replace("'", "")

            'WDI is handling error display locally as they want the error windows to clear on their own every postback
            'Need an ADE release for that and don't have time.
            strMessage = strMessage.Replace(vbCrLf, "<br />")
            strMessage = strMessage.Replace("\n", " <br /> ")
            sb.Append("if(parent.parent.parent.ErrorDisplayFR.document.readyState =='complete')").Append(Environment.NewLine)
            sb.Append("{").Append(Environment.NewLine)
            sb.Append("parent.parent.parent.ErrorDisplayFR.DisplayBWError('" & strMessage & "'); ").Append(Environment.NewLine)
            sb.Append("parent.parent.parent.MainFrame.rows = '10%,29,85%,*';").Append(Environment.NewLine)
            sb.Append("}").Append(Environment.NewLine)

            myClientCode = myClientCode & sb.ToString()

            'Threading.Thread.Sleep(5000)

        Catch ex As Exception
            Throw
        End Try

    End Sub

    ''' <summary>
    ''' Displays or clears up error/warning label 
    ''' </summary>
    ''' <param name="strMessage"></param>
    ''' <remarks>BackColor - Black; ForeColor - Yellow</remarks>
    Public Sub DisplayError(ByVal strMessage As String)
        Try

            'TODO - update to change colors in window alert - this one pen color yellow, background black
            If strMessage.Trim = "" Then Exit Sub

            strMessage = Replace(strMessage, "'", """")

            'Stach 4/12, now use the alert override vs the branch panel to display
            'error as branch buttons now scale to take up the whole frame.
            MsgBox(strMessage)


            'Threading.Thread.Sleep(5000)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Displays severe error 
    ''' </summary>
    ''' <param name="strMessage"></param>
    ''' <remarks>BackColor - Red; ForeColor - White</remarks>
    Public Sub DisplaySevereError(ByVal strMessage As String)
        Try
            'TODO - update to change colors in window alert - this one pen color white, background red
            If strMessage.Trim = "" Then Exit Sub

            strMessage = Replace(strMessage, "'", """")

            'Stach 4/12, now use the alert override vs the branch panel to display
            'error as branch buttons now scale to take up the whole frame.
	    'Stach - 4/13, Appending BWERRORALERT to string so ADE will know how to display message in red/error vs yellow/warning.
            MsgBox("BWERRORALERT:" & strMessage)


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Displays status in the error/warning label 
    ''' </summary>
    ''' <param name="strMessage"></param>
    ''' <remarks>BackColor - Black; ForeColor - White</remarks>
    Public Sub DisplayStatus(ByVal strMessage As String)
        Try

            'TODO - update to change colors in window alert - this one pen color white, background black
            If strMessage.Trim = "" Then Exit Sub

            strMessage = Replace(strMessage, "'", """")

            'Stach 4/12, now use the alert override vs the branch panel to display
            'error as branch buttons now scale to take up the whole frame.
            MsgBox(strMessage)

        Catch ex As Exception
            Throw
        End Try
    End Sub

#End Region

#Region "Binding functions"
    ''' <summary>
    ''' Load and bind passed list to the passed control
    ''' </summary>
    ''' <param name="crt">WebControl that allows binding/has a datasource</param>
    ''' <param name="listName">Name of BW list to be loaded</param>
    ''' <param name="textColumnName">The column in the list that should be bound as the Text for list type controls</param>
    ''' <param name="valueColumnName">The column in the list that should be bound as the Value for list type controls</param>
    ''' <remarks></remarks>
    Public Sub BindList(ByRef crt As WebControl, ByVal listName As String, Optional ByVal textColumnName As String = Nothing, Optional ByVal valueColumnName As String = Nothing)
        Try
            Dim tempDS As New DataSet
            'Read in xml file
            tempDS.ReadXml(String.Format("{0}\Lists\{1}.xml", Request.PhysicalApplicationPath, listName))
            'Bind data
            DirectCast(crt, System.Web.UI.WebControls.BaseDataBoundControl).DataSource = tempDS
            'Set Text/Value Columns if present.
            If TypeOf crt Is ListControl Then
                If Not IsNothing(textColumnName) Then DirectCast(crt, System.Web.UI.WebControls.ListControl).DataTextField = textColumnName
                If Not IsNothing(valueColumnName) Then DirectCast(crt, System.Web.UI.WebControls.ListControl).DataValueField = valueColumnName
            End If
            DirectCast(crt, System.Web.UI.WebControls.BaseDataBoundControl).DataBind()
            Exit Sub
        Catch ex As Exception
            'Catch for debugging purposes only
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Bind a list box
    ''' </summary>
    ''' <param name="listBoxName"></param>
    ''' <param name="myListBox"></param>
    ''' <param name="valueColumn"></param>
    ''' <param name="textColumn"></param>
    ''' <remarks></remarks>
    Public Sub BindListBox(ByVal listBoxName As String, ByVal myListBox As System.Web.UI.HtmlControls.HtmlSelect, ByVal valueColumn As Integer, ByVal textColumn As Integer)
        Try
            Dim listBoxPath As String

            listBoxPath = Request.PhysicalApplicationPath & "\Includes\"

            If myListBox.Items.Count = 0 Then
                Dim ListTable = New DataSet

                ListTable.ReadXml(listBoxPath & "\" & listBoxName & ".xml")

                myListBox.DataSource = ListTable
                myListBox.DataValueField = "Column" & valueColumn
                myListBox.DataTextField = "Column" & textColumn
                myListBox.DataBind()
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Loads the listbox with values from the keyedlist table in session
    ''' </summary>
    ''' <param name="keyedListName"></param>
    ''' <param name="myListBox"></param>
    ''' <remarks></remarks>
    Public Sub BindListBoxToSessionKeyedList(ByVal keyedListName As String, ByVal myListBox As System.Web.UI.HtmlControls.HtmlSelect)
        Try
            Dim myDataTable As DataTable = Session("gSessionDataSet").Tables("KeyedList" & keyedListName)

            If myDataTable Is Nothing Then
                'ERROR -> keyedlist not in session...
                DisplayError("ERROR:  The keyed list " & keyedListName & " does not exist in session!")
                Exit Sub
            End If

            myListBox.DataSource = myDataTable
            myListBox.DataValueField = "ValueColumn"
            myListBox.DataTextField = "TextColumn"
            myListBox.DataBind()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Loads the listbox with values from the keyedlist table in session
    ''' </summary>
    ''' <param name="keyedListName"></param>
    ''' <param name="myListBox"></param>
    ''' <remarks></remarks>
    Public Sub BindListBoxToSessionKeyedList(ByVal keyedListName As String, ByVal myListBox As System.Web.UI.WebControls.ListControl)
        Try
            Dim myDataTable As DataTable = Session("gSessionDataSet").Tables("KeyedList" & keyedListName)

            If myDataTable Is Nothing Then
                'ERROR -> keyedlist not in session...
                DisplayError("ERROR:  The keyed list " & keyedListName & " does not exist in session!")
                Exit Sub
            End If

            myListBox.DataSource = myDataTable
            myListBox.DataValueField = "ValueColumn"
            myListBox.DataTextField = "TextColumn"
            myListBox.DataBind()

        Catch ex As Exception
            Throw
        End Try
    End Sub

#End Region

#Region "Client side functions"

    '''<summary>
    ''' Writes out javascript code to update
    '''   1) LastPath button
    '''   2) Current panel name on the bottom panel branching frame
    ''' </summary>
    ''' <param name="strCurrentPathID">Current path</param>
    ''' <remarks></remarks>
    Public Sub updateClientSide(ByVal strCurrentPathID As String)
        Try
            'log a debug message when debug on
            If GF.UPC.Script.BaseDebugOn Then
                Call GF.LogSystemMessage("Script", "In UpdateClientSide; currentpathID: " & strCurrentPathID)
            End If

            Dim strCurrentPanel As String = RemovePanelGroupFromPanelName(findPanelName(Request.FilePath()))
            Dim strLastPath As String = GF.UPC.Script.LastPath
            Dim ds As DataSet = Session("gSessionDataSet")
            Dim nodeLevel As Integer = 1
            Dim sb As New System.Text.StringBuilder("")

            strCurrentPanel = strCurrentPanel.Replace(".aspx", "")

            'kp 2/06 added to be able to change the client side after a phone function
            myClientCode = myClientCode & GF.UPC.Script.clientcode
            GF.UPC.Script.clientcode = ""

            Call DisplayError("")

            '-- Update AgentInfo Frame
            Call updateAgentInfoFrame()

            '-- Update Navigation Frame
            Call updateNavTree()

            '-- Update Branching Frame (LastPath button and CurrentPanel name label)
            sb.Append("UpdatePanelNavPanelName();" & vbCrLf)
            sb.Append("function UpdatePanelNavPanelName() {" & vbCrLf)
            sb.Append("if((parent.BranchingFR.document.readyState =='complete') && (parent.BranchingFR.document.getElementById('cmdLastPath')))" & vbCrLf & "{" & vbCrLf)
            sb.Append("parent.parent.parent.AgentInfoFR.document.getElementById('lblPanelName').innerText='" & strCurrentPanel.ToUpper() & "'; " & vbCrLf)
            sb.Append("parent.BranchingFR.document.getElementById('cmdLastPath').value='" & strLastPath & " '; " & vbCrLf)
            sb.Append("}" & vbCrLf & "else {" & vbCrLf)
            sb.Append("setTimeout(""UpdatePanelNavPanelName()"",10);" & vbCrLf)
            sb.Append("}" & vbCrLf & "}" & vbCrLf)

            If GF.UPC.Script.CollapseTree Then
                Try
                    If ScriptPaths.GetLevel(GF.UPC.Script.PathID) = 1 Then Call CollapseAllChildren()
                Catch ex As Exception
                    'Eating any exceptions we may generate pulling the level for the script path as that is what we did before.
                End Try
            End If

            myClientCode = myClientCode & sb.ToString()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Update the UPC agent info frame
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub updateAgentInfoFrame()
        Try
            Dim ds As DataSet = Session("gSessionDataSet")
            Dim sb As New System.Text.StringBuilder("")

            sb.Append("UpdateAgentInfo();" & vbCrLf)
            sb.Append("function UpdateAgentInfo() {" & vbCrLf)
            sb.Append("if(parent.parent.parent.AgentInfoFR.document.readyState =='complete')" & vbCrLf & "{" & vbCrLf)
            sb.Append("parent.parent.parent.AgentInfoFR.document.getElementById('lblAgentId').innerText='" & GF.UPC.AgentInfo.uid & "'; " & vbCrLf)
            sb.Append("parent.parent.parent.AgentInfoFR.document.getElementById('lblName').innerText='" & GF.UPC.AgentInfo.fullname & " '; " & vbCrLf)
            sb.Append("parent.parent.parent.AgentInfoFR.document.getElementById('lblProject').innerText='" & GF.UPC.System.PROJECT_ID & " '; " & vbCrLf)
            sb.Append("parent.parent.parent.AgentInfoFR.document.getElementById('lblRTN').innerText='" & GF.UPC.CallData.rtn & " '; " & vbCrLf)
            sb.Append("parent.parent.parent.AgentInfoFR.document.getElementById('lblANI').innerText='" & GF.UPC.CallData.ani & " '; " & vbCrLf)
            sb.Append("}" & vbCrLf & "else {" & vbCrLf)
            sb.Append("setTimeout(""UpdateAgentInfo()"",10);" & vbCrLf)
            sb.Append("}" & vbCrLf & "}" & vbCrLf)
            myClientCode = myClientCode & sb.ToString()

        Catch ex As Exception
            Throw
        End Try

    End Sub
#End Region

#Region "Event Handlers"

    ''' <summary>
    ''' Catches teh eInitDatastore event from West shared functions and executes the initDatastore function
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eInitDataStore() Handles GF.eInitDataStore
        initDataStore()
    End Sub

    ''' <summary>
    ''' NO LONGER NEEDED  THIS CODE HAS BEEN REPLACED!!!!!
    ''' </summary>
    ''' <param name="actionCode"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eInitNavTree(actionCode As Integer) Handles GF.eInitNavTree

    End Sub

    ''' <summary>
    '''This function catches the eCollapseAllChildrent event from the West
    '''              shared functions class and executes the CollapseAllChildren function.    
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eCollapseAllChildren() Handles GF.eCollapseAllChildren
        Try
            CollapseAllChildren()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eDisplayError event from the West
    '''               shared functions class and executes the DisplayError function.
    ''' </summary>
    ''' <param name="strMessage"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eDisplayError(ByVal strMessage As String) Handles GF.eDisplayError
        Try
            DisplayError(strMessage)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eDisplaySeverError event from the West
    '''               shared functions class and executes the DisplaySevereError function.
    ''' </summary>
    ''' <param name="strMessage"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eDisplaySevereError(ByVal strMessage As String) Handles GF.eDisplaySevereError
        Try
            DisplaySevereError(strMessage)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eDisplayStatus event from the West
    '''               shared functions class and executes the DisplayStatus function.
    ''' </summary>
    ''' <param name="strMessage"></param>
    ''' <remarks>the pen color should be blue!</remarks>
    Private Sub myGlobalFunction_eDisplayStatus(ByVal strMessage As String) Handles GF.eDisplayStatus
        Try
            DisplayStatus(strMessage)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eEnterSpecifiedPath event from the West
    '''               shared functions class and executes the EnterSpecifiedPath function.
    ''' </summary>
    ''' <param name="pPath"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eEnterSpecifiedPath(ByVal pPath As String) Handles GF.eEnterSpecifiedPath
        Try
            'TODO - add enterspecifiedpath function and call

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eInitVars event from the West
    '''               shared functions class and executes the InitVars function.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eInitVars() Handles GF.eInitVars
        Try
            InitVars()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the ePageDown event from the West
    '''               shared functions class and executes the PageDown function.
    ''' </summary>
    ''' <param name="performPanelEdits"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_ePageDown(Optional ByVal performPanelEdits As Boolean = True) Handles GF.ePageDown

        Try
            PageDown(performPanelEdits)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the ePageUp event from the West
    '''               shared functions class and executes the PageUp function.
    ''' </summary>
    ''' <param name="performPanelEdits"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_ePageUp(Optional ByVal performPanelEdits As Boolean = True) Handles GF.ePageUp
        Try
            PageUp(performPanelEdits)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eSetCurrPath event from the West
    '''              shared functions class and executes the Set_CurrPath function.
    ''' </summary>
    ''' <param name="strPathName"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eSetCurrPath(ByVal strPathName As String) Handles GF.eSetCurrPath
        Try
            set_currPath(strPathName)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eSetNextPanel event from the West
    '''               shared functions class and executes the Set_NextPanel function.
    ''' </summary>
    ''' <param name="strPanelName"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eSetNextPanel(ByVal strPanelName As String) Handles GF.eSetNextPanel
        Try
            set_nextPanel(strPanelName)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eEditBranchError event from the West
    '''               shared functions class, redirects to the panel name sent in, then displays an error
    '''               with the error message string parameter
    ''' </summary>
    ''' <param name="strPanelName"></param>
    ''' <param name="strErrorMsg"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eEditBranchError(ByVal strPanelName As String, ByVal strErrorMsg As String) Handles GF.eEditBranchError
        Try
            editBranchError(strPanelName, strErrorMsg)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eReplaceCurrentPanel event from the West
    '''               shared functions class and executes the ReplaceCurrentPanel function.
    ''' </summary>
    ''' <param name="strPanelName"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eReplaceCurrentPanel(ByVal strPanelName As String) Handles GF.eReplaceCurrentPanel
        Try
            replaceCurrentPanel(strPanelName)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eUnhighlightCurrentPath event from the West
    '''               shared functions class and executes the UnhighlightTree function.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eUnhighlightCurrentPath() Handles GF.eUnhighlightCurrentPath
        Try
            UnHighlightTree()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    '''This function catches the eHandleExceptions event from the West
    '''              shared functions class and executes the handleExceptions function.
    '''     ''' </summary>
    ''' <param name="pException"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eHandleExceptions(ByVal pException As Exception) Handles GF.eHandleExceptions
        Try
            HandleExceptions(pException)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eEditError event from the West
    '''               shared functions class and sets the EditError property in
    '''		the stdpanel.
    ''' </summary>
    ''' <param name="pValue"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eEditError(ByVal pValue As Integer) Handles GF.eEditError
        Try
            EditError = pValue

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eErrorMsg event from the West
    '''               shared functions class and sets the ErrorMsg property in
    '''		the stdpanel.
    ''' </summary>
    ''' <param name="pMessage"></param>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eErrorMsg(ByVal pMessage As String) Handles GF.eErrorMsg
        Try
            ErrorMsg = pMessage

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' This function catches the eResetTables event from the West
    '''               shared functions class and executes the eResetTables function.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub myGlobalFunction_eResetHistoryTables() Handles GF.eResetTables
        
        Try
            resetHistoryTables()

        Catch ex As Exception
            Throw
        End Try
    End Sub

#End Region

#Region "Exception Handling"
    ''' <summary>
    ''' Exception handler for all exceptions
    ''' </summary>
    ''' <param name="pException">The exception</param>
    ''' <remarks></remarks>
    Public Sub HandleExceptions(ByVal pException As Exception, Optional displayError As Boolean = True)
        Try

            'Stach - 01/30 - Appened current script path/panel to exception source
            Try
                Dim errMsg As System.Text.StringBuilder = New System.Text.StringBuilder
                errMsg.Append("BWScript Info")
                errMsg.AppendFormat(", Project={0}, Script={1}, Version={2}", GF.UPC.System.PROJECT_ID, GF.UPC.System.ScriptName, GF.UPC.System.ScriptVersion)
                If Not String.IsNullOrWhiteSpace(GF.UPC.Script.PathID) Then errMsg.AppendFormat(", Path={0}", GF.UPC.Script.PathID)
                errMsg.AppendFormat(", Panel={0}", findPanelName(Request.FilePath()))
                If Not String.IsNullOrWhiteSpace(GF.UPC.Script.LastAction) Then errMsg.AppendFormat(", LastEvent={0}", GF.UPC.Script.LastAction)
                If Not String.IsNullOrWhiteSpace(GF.UPC.System.GUID) Then errMsg.AppendFormat(", UserIdentifer: {0}", GF.UPC.System.GUID)
                If Not String.IsNullOrWhiteSpace(GF.UPC.System.USER_ID) Then errMsg.AppendFormat(", TandemID: {0}", GF.UPC.System.USER_ID)

                If IsNothing(pException.Source) Then
                    pException.Source = errMsg.ToString
                Else
                    pException.Source = pException.Source & " " & errMsg.ToString
                End If

                'brooke, 10/12 - we built a source message, let's use it shall we??   - commented out the pexception.message (it was empty during debugging)
                'Stach, 08/20/09 - Log the exception to the agents log for easier debugging
                'Call GF.LogSystemMessage("Script Exception", "An exception took place: " & pException.Message())
                'Call GF.LogSystemMessage("Script Exception", "An exception took place: " & pException.Source())
                Call GF.LogSystemMessage("Script Exception", String.Format("An exception took place: {0}.  True Exception message: {1}", pException.Source(), pException.ToString()))
            Catch
                'no current recovery if exp is generated adding the path/panel, just continue with the base exception.
            End Try

            Dim myExceptionHandler As New West.CorpSysDev.ADE.FrameworkServices.ExceptionManagerClient

            myExceptionHandler.HandleException(pException)

            If displayError Then
                'Stach - 4/13, removing Error Message as the color of the message will be intuitive, wasted space.
                'Me.DisplaySevereError("Error Message: " & myExceptionHandler.UserMessage & "  Corrective Actions: " & myExceptionHandler.UserCorrectiveActions)
                Me.DisplaySevereError(String.Format("{0} Corrective Actions: {1}", myExceptionHandler.UserMessage, myExceptionHandler.UserCorrectiveActions))
            End If

        Catch ex As Exception
            DisplaySevereError("Error Message: " & ex.Message)
        End Try

    End Sub

#End Region

#Region "Formatting functions"
    ''' <summary>
    ''' Set the focus to the given control
    ''' </summary>
    ''' <param name="focusControl">Name of control to set focus on</param>
    ''' <remarks></remarks>
    Public Overloads Sub SetFocus(ByVal focusControl As String)
        Try

            focusControl = focusControl.Trim

            If focusControl.Length <> 0 Then


                'Stach - Get sporadic client side on this, just catch and eat anything for now
                'Dim focusScript As String = "<script language='javascript'>" & "document.getElementById('" + focusControl & "').focus();</script>"

                Dim tempSB As New StringBuilder(100)
                tempSB.AppendLine("<script language='javascript'>")
                tempSB.AppendLine("try { ")
                tempSB.AppendFormat("document.getElementById('{0}').focus(); {1}", focusControl, Environment.NewLine)
                tempSB.AppendLine("} catch (e) { } ")
                tempSB.AppendLine("</script>")

                ' Add the JavaScript code to the page.
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "FocusScript", tempSB.ToString)
                tempSB = Nothing

            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Format the display field to a given format
    ''' </summary>
    ''' <param name="myControl">The control to format (htmlgenericcontrol)</param>
    ''' <param name="myFormatID">The ID of the format type:
    ''' 0 = None
    ''' 1 = "mm/dd/yy"
    ''' 2 = "mm/dd/yyyy"
    ''' 3 = "yyyy/mm/dd"
    ''' 4 = Currency($0000)
    ''' 5 = Currency($0000.00)
    ''' 6 = Currency($0.00)
    ''' 7 = Phone((nnn)nnn-nnnn) 
    ''' 8 = Social Security(nnn-nn-nnnn)
    ''' </param>
    ''' <remarks></remarks>
    Public Sub formatDisplayField(ByRef myControl As System.Web.UI.HtmlControls.HtmlGenericControl, ByVal myFormatID As Integer)
        Try

            myControl.Style("BACKGROUND-COLOR") = "white"
            myControl.Style("FONT-WEIGHT") = "bold"
            myControl.Style("BORDER-TOP-STYLE") = "none"
            myControl.Style("BORDER-BOTTOM-STYLE") = "none"
            myControl.Style("BORDER-LEFT-STYLE") = "none"
            myControl.Style("BORDER-RIGHT-STYLE") = "none"
            myControl.Style.Remove("HEIGHT")

            Dim myControlValue As String = myControl.InnerText
            Dim myUnformattedText As String
            Dim formatDisplayData As String

            Select Case myFormatID
                Case "0"
                Case "1" ' format "mm/dd/yy"
                    If myControlValue > "" Then
                        If IsDate(myControlValue) Then
                            myUnformattedText = myControlValue
                            formatDisplayData = Month(myUnformattedText) & "/" & Day(myUnformattedText) & "/" & Mid(Year(myUnformattedText), 3, 2)
                            myControl.InnerText = formatDisplayData
                        Else
                            DisplayError("FormatDisplayField: """ & myControlValue & """ cannot be converted to date(mm/dd/yy)")
                        End If
                    End If
                Case "2" ' format "mm/dd/yyyy"
                    If myControlValue > "" Then
                        If IsDate(myControlValue) Then
                            myUnformattedText = myControlValue
                            formatDisplayData = Month(myUnformattedText) & "/" & Day(myUnformattedText) & "/" & Year(myUnformattedText)
                            myControl.InnerText = formatDisplayData
                        Else
                            DisplayError("FormatDisplayField: """ & myControlValue & """ cannot be converted to date(mm/dd/yyyy)")
                        End If
                    End If
                Case "3" ' format "yyyy/mm/dd"
                    If myControlValue > "" Then
                        If IsDate(myControlValue) Then
                            myUnformattedText = myControlValue
                            formatDisplayData = Year(myUnformattedText) & "/" & Month(myUnformattedText) & "/" & Day(myUnformattedText)
                            myControl.InnerText = formatDisplayData
                        Else
                            DisplayError("FormatDisplayField: """ & myControlValue & """ cannot be converted to date(yyyy/mm/dd)")
                        End If
                    End If
                Case "4" 'Currency($0000)
                    If myControlValue > "" Then
                        If IsNumeric(myControlValue) Then
                            formatDisplayData = FormatCurrency(myControlValue, 0)
                            myControl.InnerText = formatDisplayData
                        Else
                            DisplayError("FormatDisplayField: """ & myControlValue & """ cannot be converted to Currency($0000)")
                        End If
                    End If
                Case "5" 'Currency($0000.00)
                    If myControlValue > "" Then
                        If IsNumeric(myControlValue) Then
                            formatDisplayData = FormatCurrency(myControlValue, 2)
                            myControl.InnerText = formatDisplayData
                        Else
                            DisplayError("FormatDisplayField: """ & myControlValue & """ cannot be converted to Currency($0000.00)")
                        End If
                    End If
                Case "6" 'Currency($0.00)
                    If myControlValue > "" Then
                        If IsNumeric(myControlValue) Then
                            formatDisplayData = FormatCurrency((myControlValue / 100), 2)
                            myControl.InnerText = formatDisplayData
                        Else
                            DisplayError("FormatDisplayData: """ & myControlValue & """ cannot be converted to Currency($0.00)")
                        End If
                    End If
                Case "7" 'Phone((nnn)nnn-nnnn)
                    If myControlValue > "" Then
                        If IsNumeric(myControlValue) Then
                            myUnformattedText = myControlValue
                            formatDisplayData = "(" & Mid(myUnformattedText, 1, 3) & ") " & Mid(myUnformattedText, 4, 3) & "-" & Mid(myUnformattedText, 7, 4)
                            myControl.InnerText = formatDisplayData
                        Else
                            DisplayError("FormatDisplayField: """ & myControlValue & """ cannot be converted to Phone((nnn)nnn-nnnn)")
                        End If
                    End If
                Case "8" 'Social Security(nnn-nn-nnnn)
                    If myControlValue > "" Then
                        If IsNumeric(myControlValue) Then
                            myUnformattedText = myControlValue
                            formatDisplayData = Mid(myUnformattedText, 1, 3) & "-" & Mid(myUnformattedText, 4, 2) & "-" & Mid(myUnformattedText, 6, 4)
                            myControl.InnerText = formatDisplayData
                        Else
                            DisplayError("FormatDisplayField: """ & myControlValue & """ cannot be converted to Social Security(nnn-nn-nnnn)")
                        End If
                    End If
                Case Else
            End Select

        Catch ex As Exception
            Throw
        End Try
    End Sub



    ''' <summary>
    ''' Formats a display field according to the input values
    ''' </summary>
    ''' <param name="strToFormat">The format string</param>
    ''' <param name="myFormatID">The ID of the format type:
    ''' 0 = "mm/dd/yy"
    ''' 1 = "mm/dd/yyyy"
    ''' 2 = "yyyy/mm/dd"
    ''' 3 = Currency($0000)
    ''' 4 = Currency($0000.00)
    ''' 5 = Currency($0.00)
    ''' 6 = Phone((nnn)nnn-nnnn) 
    ''' 7 = Social Security(nnn-nn-nnnn)
    ''' 8 = Lowercase (abc..)
    ''' 9 = Uppercase (ABC...)
    ''' </param>
    ''' <returns></returns>
    ''' <remarks>Stach - 07/2012, New format option that takes a string and returns it formated so we don't need to pass in controls byref.
    '''which makes the mapping functions easier to work with.</remarks>
    Public Function FormatDisplayField(ByVal strToFormat As String, ByVal myFormatID As Integer) As String


            If Not String.IsNullOrWhiteSpace(strToFormat) Then
                'We have a value to work with
                Select Case myFormatID
                    Case "0" ' format "mm/dd/yy"                        
                        If IsDate(strToFormat) Then
                            'formatDisplayData = Month(strToFormat) & "/" & Day(strToFormat) & "/" & Mid(Year(strToFormat), 3, 2)
                            strToFormat = String.Format("{0}/{1}/{2}", Month(strToFormat), Day(strToFormat), Mid(Year(strToFormat), 3, 2))
                        Else
                            DisplayError("FormatDisplayField: """ & strToFormat & """ cannot be converted to date(mm/dd/yy)")
                        End If
                    Case "1" ' format "mm/dd/yyyy"
                        If IsDate(strToFormat) Then
                            'formatDisplayData = Month(strToFormat) & "/" & Day(strToFormat) & "/" & Year(strToFormat)
                            strToFormat = String.Format("{0}/{1}/{2}", Month(strToFormat), Day(strToFormat), Year(strToFormat))
                        Else
                            DisplayError("FormatDisplayField: """ & strToFormat & """ cannot be converted to date(mm/dd/yyyy)")
                        End If
                    Case "2" ' format "yyyy/mm/dd"                    
                        If IsDate(strToFormat) Then
                            'formatDisplayData = Year(strToFormat) & "/" & Month(strToFormat) & "/" & Day(strToFormat)
                            strToFormat = String.Format("{0}/{1}/{2}", Year(strToFormat), Month(strToFormat), Day(strToFormat))
                        Else
                            DisplayError("FormatDisplayField: """ & strToFormat & """ cannot be converted to date(yyyy/mm/dd)")
                        End If
                    Case "3" 'Currency($0000)                        
                        If IsNumeric(strToFormat) Then
                            'formatDisplayData = FormatCurrency(strToFormat, 0)
                            strToFormat = FormatCurrency(strToFormat, 0)
                        Else
                            DisplayError("FormatDisplayField: """ & strToFormat & """ cannot be converted to Currency($0000)")
                        End If
                    Case "4" 'Currency($0000.00)                        
                        If IsNumeric(strToFormat) Then
                            'formatDisplayData = FormatCurrency(strToFormat, 2)
                            strToFormat = FormatCurrency(strToFormat, 2)
                        Else
                            DisplayError("FormatDisplayField: """ & strToFormat & """ cannot be converted to Currency($0000.00)")
                        End If
                    Case "5" 'Currency($0.00)                        
                        If IsNumeric(strToFormat) Then
                            'formatDisplayData = FormatCurrency((strToFormat / 100), 2)
                            strToFormat = FormatCurrency((strToFormat / 100), 2)
                        Else
                            DisplayError("FormatDisplayField: """ & strToFormat & """ cannot be converted to Currency($0.00)")
                        End If
                    Case "6" 'Phone((nnn)nnn-nnnn)                        
                        If IsNumeric(strToFormat) AndAlso strToFormat.Length > 9 Then
                            'formatDisplayData = "(" & Mid(strToFormat, 1, 3) & ") " & Mid(strToFormat, 4, 3) & "-" & Mid(strToFormat, 7, 4)
                            strToFormat = String.Format("({0}) {1}-{2}", Mid(strToFormat, 1, 3), Mid(strToFormat, 4, 3), Mid(strToFormat, 7, 4))
                        Else
                            DisplayError("FormatDisplayField: """ & strToFormat & """ cannot be converted to Phone((nnn)nnn-nnnn)")
                        End If
                    Case "7" 'Social Security(nnn-nn-nnnn)                        
                        If IsNumeric(strToFormat) AndAlso strToFormat.Length > 8 Then
                            'formatDisplayData = Mid(strToFormat, 1, 3) & "-" & Mid(strToFormat, 4, 2) & "-" & Mid(strToFormat, 6, 4)
                            strToFormat = String.Format("{0}-{1}-{2}", Mid(strToFormat, 1, 3), Mid(strToFormat, 4, 2), Mid(strToFormat, 6, 4))
                        Else
                            DisplayError("FormatDisplayField: """ & strToFormat & """ cannot be converted to Social Security(nnn-nn-nnnn)")
                        End If
                    Case "8" 'Lowercase (abc..)                        
                        strToFormat = strToFormat.ToLower
                    Case "9" 'Social Security(nnn-nn-nnnn)
                        strToFormat = strToFormat.ToUpper
                    Case Else
                End Select
            End If

            'Return String after formating
            Return strToFormat


    End Function

#End Region

#Region "Initialization Functions"
    Public Sub New()
        Try
            GF = New GlobalFunctions

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Initializes all variables (resets datastores, localstores, and 
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InitVars()
        '************************************************************************
        'Method Name:
        'Argument List:
        'Return Type: N/A.
        'Scope: Public
        'Pre-Condition: N/A.
        'Stored Procedures: N/A
        'Description:
        '************************************************************************

        Try

            'initializes all data except script...
            resetDataTables()

            If GF.UPC.Script.BaseDebugOn Then
                Call GF.LogSystemMessage("Script", "In BASESTDPANEL_INITVARS:   Initializing script path variables...")
            End If

            GF.UPC.Script.PathID = ""
            GF.UPC.Script.CurrentPath = ""
            GF.UPC.Script.CurrentPanel = ""
            GF.UPC.Script.PreviousPathID = ""
            GF.UPC.Script.LastPath = ""

            'graceful abandon to log out of phone automatically if necessary
            GF.UPC.System.GracefulAbandon = ""

            'Stach 09/2013 - Reset Session varibles used by the WDIAddressLookup Usercontrol
            'Should be reset to 0 at the start of each call. This line can be removed if the WDIAddressLookup Usercontrol is discontinued.
            If Not IsNothing(Page.Session("WDIPerformedTargusLookup")) Then Page.Session("WDIPerformedTargusLookup") = "0"


        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Reset all the required data (datastore, localstore, callback, calldata, historypath, historypanel, verification, vru)
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub resetDataTables()
        Try

            initDataStore()
            initLocalStore()

            Call GF.ResetData("Callback")
            'Stach - 02/23/15, CallData is now its own property class, can't clear it in the old way.
            'Call GF.ResetData("CallData")             
            ResetVarPropertiesToDefaultValues(GF.UPC.CallData.GetType(), GF.UPC.CallData)            

            Call GF.ResetData("HistoryPath")
            Call GF.ResetData("HistoryPanel")
            Call GF.ResetData("Verification")
            Call GF.ResetData("Vru")

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Reset the data in the historypath and historypanel tables
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub resetHistoryTables()
        Try

            Call GF.ResetData("HistoryPath")
            Call GF.ResetData("HistoryPanel")

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Initialize all the datastore properties to default values.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub initDataStore()

        ResetVarPropertiesToDefaultValues(GF.NGS.GetType(), GF.NGS)

    End Sub

    ''' <summary>
    ''' Initialize all the localstore properties to default values
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub initLocalStore()

        ResetVarPropertiesToDefaultValues(GF.LS.GetType(), GF.LS)

    End Sub

    ''' <summary>
    ''' initialize properties for startup and between calls...
    ''' </summary>
    ''' <param name="nvType">Type to initialize</param>
    ''' <param name="nvInstance">Instance to initialize</param>
    ''' <remarks>Initialize properties (such as string properties)</remarks>
    Protected Sub InitVarProperties(nvType As Type, ByRef nvInstance As Object)
        'systxb added default values for integer and boolean to allow this function used after each call
        Dim pi() As Reflection.PropertyInfo = nvType.GetProperties(Reflection.BindingFlags.Public Or Reflection.BindingFlags.Instance)

        For Each i As Reflection.PropertyInfo In pi
            If i.PropertyType.Equals(GetType(System.String)) AndAlso i.GetValue(nvInstance, Nothing) Is Nothing Then
                i.SetValue(nvInstance, String.Empty, Nothing)
            End If
        Next

    End Sub

    ''' <summary>
    ''' Resets the properties to default values.  Use after each call to initialize values...
    ''' </summary>
    ''' <param name="nvType">Type to initialize</param>
    ''' <param name="nvInstance">Instance to initialize</param>
    ''' <remarks>Initialize data to default values (string to "", integer to 0, boolean to false)</remarks>
    Protected Sub ResetVarPropertiesToDefaultValues(nvType As Type, ByRef nvInstance As Object)

        Dim pi() As Reflection.PropertyInfo = nvType.GetProperties(Reflection.BindingFlags.Public Or Reflection.BindingFlags.Instance)

        For Each i As Reflection.PropertyInfo In pi
            If i.PropertyType.Equals(GetType(System.String)) Then
                i.SetValue(nvInstance, String.Empty, Nothing)
            End If
            If i.PropertyType.Equals(GetType(Integer)) Then
                i.SetValue(nvInstance, 0, Nothing)
            End If
            If i.PropertyType.Equals(GetType(Boolean)) Then
                i.SetValue(nvInstance, False, Nothing)
            End If
        Next

    End Sub

#End Region

#Region "Navigation and Branching functions"

    ''' <summary>
    ''' Collapse all the children in the navigation frame
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CollapseAllChildren()
        Try
            'log a debug message when debug on
            If GF.UPC.Script.BaseDebugOn Then
                Call GF.LogSystemMessage("Script", "In CollapseAllChildren...")
            End If

            Dim sb As New System.Text.StringBuilder("")
            'collapse all children in the tree except the selected one.
            sb.Append("CollapseAllChildren();" & vbCrLf)
            sb.Append("function CollapseAllChildren()" & vbCrLf & "{" & vbCrLf)
            'Added check on function as sometimes on script switch the frame is complete but function is undefined leading to javascript errors.
            sb.Append("if(parent.parent.NavigateFR.document.readyState =='complete' && parent.parent.NavigateFR.CollapseAllChildren)" & vbCrLf & "{" & vbCrLf)
            sb.Append("parent.parent.NavigateFR.CollapseAllChildren();" & vbCrLf)
            sb.Append("}" & vbCrLf & "else {" & vbCrLf)
            sb.Append("setTimeout(""CollapseAllChildren()"",100);" & vbCrLf)
            sb.Append("}" & vbCrLf & "}" & vbCrLf)
            myClientCode = myClientCode & sb.ToString()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Update the navigation tree with the action
    ''' </summary>
    ''' <param name="qsAction">Action to send into the navigation tree</param>
    ''' <remarks></remarks>
    Protected Sub updateNavTree(Optional ByVal qsAction As String = Nothing)
        Try
            'TS 11/08 - Handle Verification mode, if in verification mode don't change the nav panels Action/CallMode unless specific action is sent in
            If Not GF.IsVerificationMode() Or Not IsNothing(qsAction) Then
                'log a debug message when debug on
                If GF.UPC.Script.BaseDebugOn Then
                    Call GF.LogSystemMessage("Script", "In UpdateNavTree")
                End If

                'highlight NavTree node based on PathID in the Script dictionary
                Dim sb As New System.Text.StringBuilder("")
                Dim myCallMode As String = GF.UPC.Script.CALLMODE
                Dim myNavMode As String = GF.UPC.Script.NAVMODE

                'if the callmode is different than the navmode (in nav.aspx) then refresh nav.aspx with callmode
                If myCallMode <> myNavMode Then
                    If IsNothing(qsAction) Then
                        'Not a specal case set based on callmode
                        'sb.Append("parent.parent.NavigateFR.location = ""../Includes/Nav.aspx?Action=" & myCallMode & """;")
                        'make them equal until the callmode changes
                        GF.UPC.Script.NAVMODE = myCallMode
                    Else
                        'Specal case set based on passed in action
                        sb.Append("parent.NavigateFR.location = ""../Includes/Nav.aspx?Action=" & qsAction & """;")
                        'make them equal until the callmode changes
                        GF.UPC.Script.NAVMODE = qsAction
                    End If
                End If

                sb.Append("UpdateNavAccordian();" & vbCrLf)
                sb.Append("function UpdateNavAccordian()" & vbCrLf & "{" & vbCrLf)
                sb.Append("if((parent.parent.NavigateFR.document.readyState =='complete') && (parent.parent.NavigateFR.UpdateNavAccordian))" & vbCrLf & "{" & vbCrLf)
                'Update which paths are shown
                sb.Append("parent.parent.NavigateFR.UpdateNavAccordian(" & myCallMode & ");" & vbCrLf)
                'Highlight the right path
                sb.Append("parent.parent.NavigateFR.HighlightPath(""" & GF.UPC.Script.PathID & """);" & vbCrLf)
                sb.Append("}" & vbCrLf & "else {" & vbCrLf)
                sb.Append("setTimeout(""UpdateNavAccordian()"",100);" & vbCrLf)
                sb.Append("}" & vbCrLf & "}" & vbCrLf)
                myClientCode = myClientCode & sb.ToString()
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Change the script to the URL passed in
    ''' </summary>
    ''' <param name="URL">New script url</param>
    ''' <remarks></remarks>
    Public Sub ChangeScript(ByVal URL As String)
        Try
            Dim sb As New System.Text.StringBuilder("")
            If GF.UPC.Script.IN_BROWSER Then
                sb.Append("parent.BranchingFR.changescript('" & URL & "')" & vbCrLf)
                myClientCode = myClientCode & sb.ToString()
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Unhighlight any highlighted navigation tree members
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UnHighlightTree()
        Try

            'unhighlight all NavTree
            Dim sb As New System.Text.StringBuilder("")
            sb.Append("UnHighlightTree();" & vbCrLf)
            sb.Append("function UnHighlightTree()" & vbCrLf & "{" & vbCrLf)
            sb.Append("if(parent.parent.NavigateFR.document.readyState =='complete')" & vbCrLf & "{" & vbCrLf)
            sb.Append("parent.parent.NavigateFR.UnHighlightTree();" & vbCrLf)
            sb.Append("}" & vbCrLf & "else {" & vbCrLf)
            sb.Append("setTimeout(""UnHighlightTree()"",100);" & vbCrLf)
            sb.Append("}" & vbCrLf & "}" & vbCrLf)
            myClientCode = sb.ToString()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Disable the navigation buttons of the page
    ''' </summary>
    ''' <param name="oPage">Current page to disable navigation buttons</param>
    ''' <remarks></remarks>
    Public Sub SubmitButtonDisabler(ByRef oPage As Page)

        Dim strLastPath As String

        If Not GF.UPC.Script.LastPath Is Nothing Then
            strLastPath = GF.UPC.Script.LastPath.ToUpper
        Else
            'leave it alone
        End If

        If Not oPage.ClientScript.IsClientScriptBlockRegistered("PleaseWait") Then
            oPage.ClientScript.RegisterClientScriptBlock(oPage.GetType(), "PleaseWait", "<script language=javascript >" & vbCrLf & "var PageIsProcessing = false;" & vbCrLf & "ChangeButtons();" & vbCrLf & vbCrLf & "function PleaseWait(){" & vbCrLf & "if(PageIsProcessing==true){" & vbCrLf & "   return false;" & vbCrLf & "}else{" & vbCrLf & "   if(parent.BranchingFR!=null){" & vbCrLf & "   if(parent.BranchingFR.document.getElementById('cmdNext') !=null){parent.BranchingFR.document.getElementById('cmdNext').value = 'Processing...';}" & vbCrLf & "   if(parent.BranchingFR.document.getElementById('cmdPrevious') !=null){parent.BranchingFR.document.getElementById('cmdPrevious').value = 'Processing...';}" & vbCrLf & "   if(parent.BranchingFR.document.getElementById('cmdLastPath') !=null){parent.BranchingFR.document.getElementById('cmdLastPath').value = 'Processing...';}" & vbCrLf & "}}" & vbCrLf & "PageIsProcessing = true;" & vbCrLf & "setTimeout(""ChangeButtons()"",5000);" & vbCrLf & "return true;" & vbCrLf & "}" & vbCrLf & vbCrLf & "function ChangeButtons(){" & vbCrLf & "PageIsProcessing=false;" & vbCrLf & "if(parent.BranchingFR!=null){" & vbCrLf & "if(parent.BranchingFR.document.getElementById('cmdNext') !=null){parent.BranchingFR.document.getElementById('cmdNext').value = 'Next';}" & vbCrLf & "if(parent.BranchingFR.document.getElementById('cmdPrevious') !=null){parent.BranchingFR.document.getElementById('cmdPrevious').value = 'Previous';}" & vbCrLf & "if(parent.BranchingFR.document.getElementById('cmdLastPath') !=null){parent.BranchingFR.document.getElementById('cmdLastPath').value = '" & strLastPath & "';}" & vbCrLf & "}" & vbCrLf & "}" & vbCrLf & "<" & "/" & "script>" & vbCrLf & "")
        End If

        oPage.ClientScript.RegisterOnSubmitStatement(oPage.GetType(), "PleaseWait", "if(!PleaseWait()){return false}else{return true};")
    End Sub

    ''' <summary>
    ''' Sets and redirects the script to the nextpanel in the path
    ''' </summary>
    ''' <param name="strPanelName">Name of the panel to go to</param>
    ''' <remarks></remarks>
    Public Sub set_nextPanel(ByVal strPanelName As String)
        Try

            source = "B"

            If GF.UPC.Script.IN_BROWSER Then

                If Len(strPanelName) <> 0 Then
                    'Need to generate panel path now that we have sub directories in panels.
                    'strPanelName = "../Panels/" & strPanelName & ".aspx"
                    strPanelName = GetPanelPath(strPanelName)
                    If EditError < 1 Then
                        GF.UPC.Script.CollapseTree = False

                        If doesFileExist(strPanelName) Then
                            'Response.Redirect(strPanelName & "?Class=Panel&Action=OnLoad", False)
                            If Request.ApplicationPath.EndsWith("/") Then
                                Response.Redirect(String.Format("{0}{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, strPanelName), False)
                            Else
                                Response.Redirect(String.Format("{0}/{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, strPanelName), False)
                            End If
                        Else
                            'Response.Redirect("/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", False)
                            If Request.ApplicationPath.EndsWith("/") Then
                                Response.Redirect(String.Format("{0}Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                            Else
                                Response.Redirect(String.Format("{0}/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                            End If
                        End If

                    Else
                        DisplayError(ErrorMsg)
                    End If
                Else
                    DisplayError("Specified panel name in the set_nextPanel() is blank.")
                End If
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Branch to the given panel and display an error message
    ''' </summary>
    ''' <param name="strPanelName">Name of panel to go to</param>
    ''' <param name="strErrorMsg">Message to display as error</param>
    ''' <remarks></remarks>
    Public Sub editBranchError(ByVal strPanelName As String, ByVal strErrorMsg As String)
        Try
            source = "B"
            'RaiseEvent panelEdit()

            If GF.UPC.Script.IN_BROWSER Then

                If Len(strPanelName) <> 0 Then
                    'Need to generate panel path now that we have sub directories in panels.
                    'strPanelName = "../Panels/" & strPanelName & ".aspx"
                    strPanelName = GetPanelPath(strPanelName)
                    If EditError < 1 Then
                        GF.UPC.Script.CollapseTree = False

                        GF.UPC.Script.LoggingErrorMessage = "N"  'prevent auto branching if disconnect comes in on top of redirected panel

                        If doesFileExist(strPanelName) Then
                            'Response.Redirect(strPanelName & "?Class=Panel&Action=OnLoad&ErrorMsg=" & strErrorMsg, True)
                            If Request.ApplicationPath.EndsWith("/") Then
                                Response.Redirect(String.Format("{0}{1}?Class=Panel&Action=OnLoad&ErrorMsg={2}", Request.ApplicationPath, strPanelName, strErrorMsg), False)
                            Else
                                Response.Redirect(String.Format("{0}/{1}?Class=Panel&Action=OnLoad&ErrorMsg={2}", Request.ApplicationPath, strPanelName, strErrorMsg), False)
                            End If

                        Else
                            ' Response.Redirect("/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", True)
                            If Request.ApplicationPath.EndsWith("/") Then
                                Response.Redirect(String.Format("{0}Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                            Else
                                Response.Redirect(String.Format("{0}/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                            End If
                        End If

                    Else
                        DisplayError(ErrorMsg)
                    End If
                Else
                    DisplayError("Specified panel name in the editBranchError() is blank.")
                End If

            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Branch to the next panel in the path.  If end of path detected and the path is logging path, start logging. 
    ''' </summary>
    ''' <param name="performPanelEdits"></param>
    ''' <remarks></remarks>
    Public Sub PageDown(Optional ByRef performPaneledits As Boolean = True)
        Try
            source = "B"

            Dim strCurrentPath As String = GF.UPC.Script.CurrentPath
            Dim isLoggingPath As Boolean = False

            If performPaneledits Then
                'brooke 4/18/14 - added the performpaneledits parameter functionality
                'always perform paneledits UNLESS parameter is FALSE...

                'execute customized panelEdit and panelBranch events
                GF.UPC.Script.LastAction = "panelEdit"

                RaiseEvent panelEdit()

                'Check validator controls
                panelEditValidate()

                If EditError > 0 Then
                    DisplayError(ErrorMsg)
                    Exit Sub
                End If
            Else
                'brooke 4/18/14 - added the performpaneledits parameter functionality
                GF.LogSystemMessageDB("Script", String.Format("Panel edits in PageDown bypassed by performpaneledits set to {0}", performPanelEdits.ToString), True)

            End If

            GF.UPC.Script.LastAction = "panelBranch"

            RaiseEvent panelBranch()

            If endOfPath Then
                If GF.CheckForLoggingPath() Then
                    'Starbuck 07/09 Check for logging loop.
                    If findPanelName(Request.FilePath()).ToLower() = "logging.aspx" AndAlso GF.UPC.Script.LoggingErrorMessage = "Y" Then
                        ' we are already logging, prevent loop
                        Call GF.LogSystemMessage("ScriptLogging", "Detected logging loop in PageDown")
                        Call set_nextPanel("Other/LOGCOMPLETE")
                        Exit Sub
                    End If

                    'Execute logging logic here ....
                    DisplayStatus("Logging the call ...")
                    '20101220 pbojjireddy Overlapping Calls 1222 jsr removed for install
                    Call set_nextPanel("Other/LOGINIT")
                    'Call set_nextPanel("Other/PRELOGGING")
                Else
                    If Len(ErrorMsg) = 0 Then
                        DisplayError("End of path reached... Please use navigation window.")
                    Else
                        DisplayError(ErrorMsg)
                    End If
                End If
                Exit Sub
            End If

            If Len(nextPanel) <> 0 Then
                'find out if the pathName of the nextPanel is different from the currentPanel
                Call HandleUpdatePath(strCurrentPath, nextPanel)
                GF.UPC.Script.CollapseTree = False

                nextPanel = GetPanelPath(nextPanel)
                If doesFileExist(nextPanel) Then
                    'Response.Redirect(nextPanel & "?Class=Panel&Action=OnLoad", False)
                    If Request.ApplicationPath.EndsWith("/") Then
                        Response.Redirect(String.Format("{0}{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, nextPanel), False)
                    Else
                        Response.Redirect(String.Format("{0}/{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, nextPanel), False)
                    End If
                Else
                    'Response.Redirect("/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", False)
                    If Request.ApplicationPath.EndsWith("/") Then
                        Response.Redirect(String.Format("{0}Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                    Else
                        Response.Redirect(String.Format("{0}/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                    End If
                End If
            Else
                If Len(ErrorMsg) = 0 Then
                    DisplayError("NextPanel is not set in the panelBranch() function.")
                Else
                    DisplayError(ErrorMsg)
                End If
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Branch to the previous panel in the path
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub PageUp(Optional ByRef performPanelEdits As Boolean = True)
        Try

            source = "P"

            Dim strCurrentPath As String = GF.UPC.Script.CurrentPath
            Dim strCurrentPathID As String = GF.UPC.Script.PathID
            Dim prevPage As String

            If performPanelEdits Then

                GF.UPC.Script.LastAction = "panelEdit"

                RaiseEvent panelEdit()

            Else
                'brooke 4/18/14 - added the performpaneledits parameter functionality
                GF.LogSystemMessageDB("Script", String.Format("Panel edits in PageUp bypassed by performpaneledits set to {0}", performPanelEdits.ToString), True)
            End If

            'find out previous panel
            If EditError < 2 Then
                prevPage = NavigatePrevious(strCurrentPathID)
            Else
                If Len(Trim(ErrorMsg)) <> 0 Then DisplayError(ErrorMsg)
                Exit Sub
            End If

            If Len(prevPage) <> 0 Then
                If EditError < 2 Then
                    'find out if the pathName of the prevPage is different from the currentPage
                    Call HandleUpdatePath(strCurrentPath, prevPage)
                    GF.UPC.Script.CollapseTree = False

                    prevPage = GetPanelPath(prevPage)
                    If doesFileExist(prevPage) Then
                        'Response.Redirect(prevPage & "?Class=Panel&Action=OnLoad", False)
                        If Request.ApplicationPath.EndsWith("/") Then
                            Response.Redirect(String.Format("{0}{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, prevPage), False)
                        Else
                            Response.Redirect(String.Format("{0}/{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, prevPage), False)
                        End If
                    Else
                        'Response.Redirect("/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", False)
                        If Request.ApplicationPath.EndsWith("/") Then
                            Response.Redirect(String.Format("{0}Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                        Else
                            Response.Redirect(String.Format("{0}/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                        End If
                    End If

                Else
                    DisplayError(ErrorMsg)
                End If
            Else
                DisplayError("You are already at the beginning of this path.")
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Branches to the last Path specified on the LastPath button.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub HandleLastPathEvent()
        Try

            source = "J"
            GF.UPC.Script.LastAction = "panelEdit"
            RaiseEvent panelEdit()

            If EditError < 2 Then
                Dim lastPath As String = NavigateLastPath()
                If Len(lastPath) <> 0 Then
                    GF.UPC.Script.CollapseTree = True
                    lastPath = GetPanelPath(lastPath)
                    If doesFileExist(lastPath) Then
                        'Response.Redirect(lastPath & "?Class=Panel&Action=OnLoad", False)
                        If Request.ApplicationPath.EndsWith("/") Then
                            Response.Redirect(String.Format("{0}{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, lastPath), False)
                        Else
                            Response.Redirect(String.Format("{0}/{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, lastPath), False)
                        End If
                    Else
                        'Response.Redirect("/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", False)
                        If Request.ApplicationPath.EndsWith("/") Then
                            Response.Redirect(String.Format("{0}Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                        Else
                            Response.Redirect(String.Format("{0}/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                        End If
                    End If

                Else
                    DisplayError("Request Invalid - You do not have a prior script path.")
                End If
            Else
                DisplayError(ErrorMsg)
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Find out if the next/previous panel has a different script path, if yes save it in currpath variable
    ''' </summary>
    ''' <param name="strCurrentPath">Current script path</param>
    ''' <param name="strCurrentFile">current script paht filename</param>
    ''' <remarks></remarks>
    Public Sub HandleUpdatePath(ByVal strCurrentPath As String, ByVal strCurrentFile As String)
        Try

            If InStr(strCurrentFile, "/") > 0 Then
                Dim panelSplit() As String = strCurrentFile.Split("/")
                If panelSplit.Length <> 2 Then Throw New ArgumentException(String.Format("PanelPropertyString={0} was not in the proper format.", strCurrentFile))
                strCurrentFile = panelSplit(1)
            End If
            'See if the current panel is the first panel for any other path
            Dim pathID As String = ScriptPaths.GetPathIdByFirstPanel(strCurrentFile)
            If Not String.IsNullOrWhiteSpace(pathID) Then
                'If we have a value then this panel is the first panel for a new path
                'assigning path description to CurrentPath as the code before did.
                GF.UPC.Script.CurrentPath = ScriptPaths.GetDescription(pathID)
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Save the path in history
    ''' </summary>
    ''' <param name="strCurrentPathID">Current script path name</param>
    ''' <param name="strCurrentPanel">Current panel</param>
    ''' <remarks></remarks>
    Public Sub saveHistoryPath(ByVal strCurrentPathID As String, ByRef strCurrentPanel As String)
        '************************************************************************
        Try

            Dim ds As DataSet = Session("gSessionDataSet")
            Dim intPathID, lastSeqNum As Integer
            Dim intSeqNbr As Integer = 1

            GF.UPC.Script.CurrentPanel = strCurrentPanel

            If Len(strCurrentPathID) <> 0 Then

                ' Find path in Path Table
                Dim drPathSelect() As DataRow = ds.Tables("HistoryPath").Select("Path='" & strCurrentPathID & "'")

                If drPathSelect.Length > 0 Then
                    ' Path found in Path table; Get PathID of path
                    intPathID = drPathSelect(0).Item("PathID")
                Else
                    ' Path not found in Path table; Add row to path table
                    Dim drHistPath As DataRow
                    drHistPath = ds.Tables("HistoryPath").NewRow()
                    ' Then add the new row to the collection.
                    drHistPath("Path") = strCurrentPathID
                    ds.Tables("HistoryPath").Rows.Add(drHistPath)
                    Dim drPathAddSelect() As DataRow = ds.Tables("HistoryPath").Select("Path='" & strCurrentPathID & "'")
                    intPathID = drPathAddSelect(0).Item("PathID")
                End If

                'Dim drPanelSelect() As DataRow = ds.Tables("HistoryPanel").Select("PathID=" & intPathID, "SeqNbr Desc")

                Dim drPanelSelect() As DataRow = ds.Tables("HistoryPanel").Select("PathID=" & intPathID)

                If drPanelSelect.Length > 0 Then
                    lastSeqNum = drPanelSelect.Length - 1
                    If drPanelSelect(lastSeqNum).Item("Panel") = strCurrentPanel Then
                        Exit Sub
                    End If

                    intSeqNbr = drPanelSelect(lastSeqNum).Item("SeqNbr") + 1
                Else
                    intSeqNbr = 1
                End If
            End If

            ' Then add the new row to the collection.
            Dim drHistPanel As DataRow
            drHistPanel = ds.Tables("HistoryPanel").NewRow()
            drHistPanel("PathID") = intPathID
            drHistPanel("SeqNbr") = intSeqNbr
            drHistPanel("Panel") = strCurrentPanel
            ds.Tables("HistoryPanel").Rows.Add(drHistPanel)

            GF.UPC.Script.CURRPOS = "0"

        Catch ex As Exception
            Throw
        End Try

    End Sub

    ''' <summary>
    ''' Retrieves the name of the panel the script was previously on in the given path
    ''' </summary>
    ''' <param name="strCurrentPathID">Current script path</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function NavigatePrevious(ByVal strCurrentPathID As String) As String
        Try

            Dim ds As DataSet = Session("gSessionDataSet")
            Dim intPathID, intSeqNbr, lastSeqNum As Integer
            Dim strCurrentPanel As String = findPanelName(Request.FilePath())

            ' Find pathName in HistoryPath Table
            Dim drPathSelect() As DataRow = ds.Tables("HistoryPath").Select("Path='" & strCurrentPathID & "'")
            If drPathSelect.Length() > 0 Then
                ' Path found in Path table; get PathID of path
                intPathID = drPathSelect(0).Item("PathID")
            Else
                ' Path not found in Path table; add row to path table
            End If

            ' Find panelName in HistoryPanel Table
            Dim drPanelSelect() As DataRow = ds.Tables("HistoryPanel").Select("PathID=" & intPathID & "AND Panel='" & strCurrentPanel & "'", "SeqNbr Desc")

            If drPanelSelect.Length() > 0 Then
                intSeqNbr = drPanelSelect(0).Item("SeqNbr")
                If intSeqNbr = 1 Then
                    Return ""
                Else
                    Dim drPanelDeleteSelect() As DataRow = ds.Tables("HistoryPanel").Select("PathID=" & intPathID & "AND SeqNbr>=" & intSeqNbr, "SeqNbr Desc")
                    Dim drPanelDeleteSelectRow As DataRow
                    If drPanelDeleteSelect.Length > 0 Then
                        For Each drPanelDeleteSelectRow In drPanelDeleteSelect
                            drPanelDeleteSelectRow.Delete()
                        Next
                        ds.Tables("HistoryPanel").AcceptChanges()
                    End If
                    'Dim drPanelPreviousSelect() As DataRow = ds.Tables("HistoryPanel").Select("PathID=" & intPathID, "SeqNbr Desc")
                    Dim drPanelPreviousSelect() As DataRow = ds.Tables("HistoryPanel").Select("PathID=" & intPathID)
                    If drPanelPreviousSelect.Length <> 0 Then lastSeqNum = drPanelPreviousSelect.Length - 1
                    Return CType(drPanelPreviousSelect(lastSeqNum).Item("Panel"), String)
                End If
            Else
                Return ""
            End If

        Catch ex As Exception
            Throw
        End Try

    End Function

    ''' <summary>
    ''' Retrieves the name of the last script path
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function NavigateLastPath() As String
        Try

            Dim ds As DataSet = Session("gSessionDataSet")
            Dim intPathID, lastSeqNum As Integer
            Dim curPathID As String = GF.UPC.Script.PathID
            Dim prevPathID As String = GF.UPC.Script.PreviousPathID
            Dim curPath As String = GF.UPC.Script.CurrentPath
            Dim lastPath As String = GF.UPC.Script.LastPath

            ' Find path in Path Table
            Dim drPathSelect() As DataRow = ds.Tables("HistoryPath").Select("Path='" & GF.UPC.Script.PreviousPathID & "'")

            If Len(prevPathID) <> 0 Then GF.UPC.Script.PathID = prevPathID
            If Len(lastPath) <> 0 Then GF.UPC.Script.CurrentPath = lastPath
            GF.UPC.Script.PreviousPathID = curPathID
            GF.UPC.Script.LastPath = curPath

            If drPathSelect.Length > 0 Then
                ' Path found in Path table; Get PathID of path
                intPathID = drPathSelect(0).Item("PathID")
                Dim drPanelSelect() As DataRow = ds.Tables("HistoryPanel").Select("PathID=" & intPathID)

                If drPanelSelect.Length <> 0 Then lastSeqNum = drPanelSelect.Length - 1
                Return CType(drPanelSelect(lastSeqNum).Item("Panel"), String)
            Else
                Return ""
            End If

        Catch ex As Exception
            Throw
        End Try
    End Function

    ''' <summary>
    ''' Determines if the given panel exists in the script
    ''' </summary>
    ''' <param name="strPanel">Name of the panel to look for</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function doesFileExist(ByVal strPanel As String) As Boolean
        Try

            strPanel = strPanel.Replace(".aspx", "")

            If LCase(Left(strPanel, 3)) = "../" Or LCase(Left(strPanel, 1)) = "/" Then
                strPanel = strPanel.Replace("../", "")
                'Return MyFile.Exists(Request.PhysicalApplicationPath & strPanel & ".aspx")
                Return IO.File.Exists(Request.PhysicalApplicationPath & strPanel & ".aspx")
            ElseIf strPanel.StartsWith("panels/", StringComparison.InvariantCultureIgnoreCase) Then
                Return IO.File.Exists(Request.PhysicalApplicationPath & strPanel & ".aspx")
            Else
                'Return MyFile.Exists(Request.PhysicalApplicationPath & "Panels\" & strPanel & ".aspx")
                Return IO.File.Exists(Request.PhysicalApplicationPath & "Panels\" & strPanel & ".aspx")
            End If


        Catch ex As Exception
            Throw
        End Try

    End Function

    ''' <summary>
    ''' Takes PanelGroup/PanelName and returns just the panel name
    ''' </summary>
    ''' <param name="panelName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function RemovePanelGroupFromPanelName(ByVal panelName As String) As String
        Dim splitPath() As String = panelName.Split("/")
        If splitPath.Length > 1 Then
            Return splitPath(1)
        Else
            Return panelName
        End If
    End Function

    ''' <summary>
    ''' Retrieves the stripped down panel name for a given panel path
    ''' </summary>
    ''' <param name="strPanel">Full path of the panel</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function findPanelName(ByVal strPanel As String) As String
        Try

            'brooke 10/12 if the panel is "/includes/debugwindow.aspx" then just return it, don't throw exception...
            If strPanel.ToLower.Contains("includes/debugwindow.aspx") Then
                Return strPanel
            End If

            'Stach 5/12, Now need to return PanelSubDirectory/Panel to handle panel sub directories
            'Return IO.Path.GetFileName(strPanel)
            'Dim splitPath() As String = IO.Path.GetFileName(strPanel).Split("/")
            Dim splitPath() As String = strPanel.Split("/")


            'brooke 10/12 - added the - 1 to prevent index out of bounds exceptions...
            For i As Integer = 0 To splitPath.Length - 1
                If splitPath(i).ToLower = "panels" Then
                    'Found the panels level, assume we will now have only 1 or two levels to go 
                    Select Case splitPath.Length
                        Case i + 2
                            Return splitPath(i + 1).ToLower.Replace(".aspx", "")
                        Case i + 3
                            Return String.Format("{0}/{1}", splitPath(i + 1), splitPath(i + 2)).ToLower.Replace(".aspx", "")
                    End Select
                End If
            Next
            'Handle the posibility that the panel is located in Includes folder
            If strPanel.IndexOf("/Includes/", StringComparison.InvariantCultureIgnoreCase) > -1 Then
                Return System.IO.Path.GetFileNameWithoutExtension(strPanel)
            End If

            If IsNothing(strPanel) Then
                Throw New ArgumentException("BaseSTDPanel - Unable to identify panel as passed string is nothing")
            Else
                Throw New ArgumentException("BaseSTDPanel - Unable to identify panel in string=" & strPanel)
            End If
        Catch ex As Exception
            Throw
        End Try
    End Function

    ''' <summary>
    ''' Make the path change happen
    ''' </summary>
    ''' <param name="strCurrentPath">Path to change to</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function NavigatePathChange(ByVal strCurrentPath As String) As String
        Try

            Dim ds As DataSet = Session("gSessionDataSet")
            Dim intPathID As Integer
            Dim navigateString As String
            Dim myPathId As String = strCurrentPath
            Dim myRestart As Boolean = False
            Dim lastSeqNum As Integer

            Try
                strCurrentPath = ScriptPaths.GetDescription(strCurrentPath)
            Catch ex As Exception
                EditError = 2
                ErrorMsg = "Specified path in the set_currPath(""" & strCurrentPath & """) does not exist."
                Return ""
            End Try

            'Find path in Path Table
            Dim drPathSelect() As DataRow = ds.Tables("HistoryPath").Select("Path='" & myPathId & "'")

            If drPathSelect.Length > 0 Then

                '-- start on the first panel only if "RestartPath" attribute is set to True
                If Not ScriptPaths.RestartPath(myPathId) Then
                    ' Path found in Path table; Get PathID of path
                    intPathID = drPathSelect(0).Item("PathID")
                    Dim drPanelSelect() As DataRow = ds.Tables("HistoryPanel").Select("PathID=" & intPathID)

                    'commit data to the Script dataset
                    If myPathId <> GF.UPC.Script.PathID Then
                        GF.UPC.Script.PreviousPathID = GF.UPC.Script.PathID
                        GF.UPC.Script.PathID = myPathId
                        GF.UPC.Script.LastPath = GF.UPC.Script.CurrentPath
                        GF.UPC.Script.CurrentPath = strCurrentPath
                    End If

                    If drPanelSelect.Length <> 0 Then lastSeqNum = drPanelSelect.Length - 1

                    'Now need to process the possible subdirectory
                    'Return "../Panels/" & CType(drPanelSelect(lastSeqNum).Item("Panel"), String)
                    Return GetPanelPath(CType(drPanelSelect(lastSeqNum).Item("Panel"), String))

                Else '-- myRestart = True -- start on the first panel
                    navigateString = ScriptPaths.GetFirstPanelWithExtension(myPathId)
                    If Len(navigateString) <> 0 Then
                        'commit data to the Script dataset only if the navigateString is not blank
                        If myPathId <> GF.UPC.Script.PathID Then
                            GF.UPC.Script.PreviousPathID = GF.UPC.Script.PathID
                            GF.UPC.Script.PathID = myPathId
                            GF.UPC.Script.LastPath = GF.UPC.Script.CurrentPath
                            GF.UPC.Script.CurrentPath = strCurrentPath
                        End If
                    End If
                    'Return navigateString
                    Return ScriptPaths.GetFirstPanelPath(myPathId)
                End If

            Else
                navigateString = ScriptPaths.GetFirstPanelWithExtension(myPathId)
                If Len(navigateString) <> 0 Then
                    'commit data to the Script dataset only if the navigateString is not blank
                    If myPathId <> GF.UPC.Script.PathID Then
                        GF.UPC.Script.PreviousPathID = GF.UPC.Script.PathID
                        GF.UPC.Script.PathID = myPathId
                        GF.UPC.Script.LastPath = GF.UPC.Script.CurrentPath
                        GF.UPC.Script.CurrentPath = strCurrentPath
                    End If
                End If
                'Return navigateString
                Return ScriptPaths.GetFirstPanelPath(myPathId)
            End If

        Catch ex As Exception
            Throw
        End Try
    End Function

    ''' <summary>
    ''' In preview mode, this will display a message as to what the next panel will be
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub handlePreviewNext()
        Try
            source = "B"
            GF.UPC.Script.LastAction = "panelEdit"
            RaiseEvent panelEdit()
            GF.UPC.Script.LastAction = "panelBranch"
            RaiseEvent panelBranch()
            If Len(ErrorMsg) <> 0 Then
                MsgBox(ErrorMsg)
            End If
            If endOfPath Then
                MsgBox("End of path reached... Please use navigation window.")
            Else
                If Len(nextPanel) <> 0 Then
                    MsgBox("NextPanel is : " & nextPanel)
                Else
                    MsgBox("NextPanel is : NotDone")
                End If
            End If

        Catch ex As Exception
            HandleExceptions(ex)
        End Try

    End Sub

    ''' <summary>
    ''' Sets the next panel - if panel name is blank, we get current panel and use it.
    ''' </summary>
    ''' <param name="strPanelName">Name of the panel to go to</param>
    ''' <remarks></remarks>
    Public Sub replaceCurrentPanel(ByVal strPanelName As String)
        Try

            If GF.UPC.Script.BaseDebugOn Then
                Call GF.LogSystemMessage("Script", "In replaceCurrentPanel; strPanelName: " & strPanelName)
            End If

            source = "B"
            'RaiseEvent panelEdit()

            If GF.UPC.Script.IN_BROWSER Then
                If Len(strPanelName.Trim) = 0 Then
                    strPanelName = findPanelName(Request.FilePath())
                    strPanelName = strPanelName.Replace(".aspx", "").ToUpper()
                End If

                If Len(strPanelName) <> 0 Then
                    'Need to generate panel path now that we have sub directories in panels.
                    'strPanelName = "../Panels/" & strPanelName & ".aspx"
                    strPanelName = GetPanelPath(strPanelName)

                    GF.UPC.Script.CollapseTree = False

                    If doesFileExist(strPanelName) Then
                        'Response.Redirect(strPanelName & "?Class=Panel&Action=OnLoad", False)
                        If Request.ApplicationPath.EndsWith("/") Then
                            Response.Redirect(String.Format("{0}{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, strPanelName), False)
                        Else
                            Response.Redirect(String.Format("{0}/{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, strPanelName), False)
                        End If
                    Else
                        'Response.Redirect("/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", False)
                        If Request.ApplicationPath.EndsWith("/") Then
                            Response.Redirect(String.Format("{0}Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                        Else
                            Response.Redirect(String.Format("{0}/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                        End If
                    End If
                Else
                    DisplayError("Specified panel name in the replaceCurrentPanel() is blank.")
                End If
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

#End Region

#Region "Panel Level functions"

    ''' <summary>
    ''' Handle the events of the panel based on the action sent in
    ''' </summary>
    ''' <param name="qsaction">Query string action to be performed</param>
    ''' <remarks></remarks>
    Public Sub handlePanelEvents(ByVal qsaction As String)
        Try

            GF.UPC.Script.PanelRenderFlag = False
            Dim strCurrentPathID As String = GF.UPC.Script.PathID
            Dim strCurrentPanel As String = findPanelName(Request.FilePath())

            'log a debug message when debug on
            If GF.UPC.Script.BaseDebugOn Then
                Call GF.LogSystemMessage("Script", "In HANDLEPANELEVENTS; action: " & qsaction & " currentPanel: " & strCurrentPanel)
            End If
            Select Case LCase(qsaction)
                Case "onload"
                    'save navigation info and update TreeView and LastPath button only if in ADE or in Browser

                    If GF.UPC.Script.IN_BROWSER Then
                        saveHistoryPath(strCurrentPathID, strCurrentPanel)
                        updateClientSide(strCurrentPathID)
                    End If

                    'execute customized panelOnLoad event
                    GF.UPC.Script.LastAction = "panelLoad"
                    RaiseEvent panelOnLoad()

                    If Not IsNothing(qsErrMsg) Then
                        If Len(qsErrMsg.Trim) <> 0 Then
                            'don't let them branch if we send in an error msg (editbrancherror)
                            EditError = 2
                            DisplayError(qsErrMsg)
                        End If
                    End If

                Case "calldisconnect"
                    Call GF.HandleDisconnectEvent()

                Case "callcomplete"
                    Call GF.HandleCallCompleteEvent()

                Case Else
            End Select

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Retrieves the error messages from all of the validator controls
    ''' on the page, including those in user controls (Scriptlets).
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function panelEditValidate() As Boolean
        Try

            Dim ReturnValue As Boolean = True

            Page.Validate()
            If Not Page.IsValid Then
                Dim valCurrent As System.Web.UI.WebControls.BaseValidator
                Dim ErrorMessageString As System.Text.StringBuilder = New System.Text.StringBuilder

                ' Loop thru all of the validator controls on the page, this includes
                ' validators that are on the scriptlets
                For Each valCurrent In Page.Validators
                    ' Check to see if the validator is invalid...
                    If Not valCurrent.IsValid Then
                        If ErrorMessageString.Length <> 0 Then
                            ErrorMessageString.Append("\n")
                        End If
                        ErrorMessageString.Append(valCurrent.ErrorMessage)
                    End If
                Next

                EditError = 1
                ErrorMsg = ErrorMessageString.ToString
                ReturnValue = False
            End If

            Return ReturnValue

        Catch ex As Exception
            Throw
        End Try
    End Function

    ''' <summary>
    ''' Process the panel property value and returns the relative path to the panel
    ''' </summary>
    ''' <param name="panelPropertyValue">The panel name if not in a subdirectory or the combined panel directory and name in the format PanelSubDirectory/PanelName</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetPanelPath(ByVal panelPropertyValue As String) As String
        'Strip out the .aspx as sometimes we get it sometimes we don't.
        If InStr(panelPropertyValue, "/") > 0 Then
            'Panel value has a directory generate the relative path.
            Dim panSplit() As String = panelPropertyValue.Split("/")
            If panSplit.Length <> 2 Then Throw New ArgumentException(String.Format("Panel property value={0} was not in the expected format of PanelSubDirectory/PanelName.", panelPropertyValue))
            'Return (String.Format("/Panels/{0}/{1}.aspx", panSplit(0), panSplit(1)))
            Return (String.Format("Panels/{0}/{1}.aspx", panSplit(0), panSplit(1)))
        Else
            'Assume its not in a sub directory
            'Return (String.Format("/Panels/{0}.aspx", panelPropertyValue))
            Return (String.Format("Panels/{0}.aspx", panelPropertyValue))
        End If
    End Function

    ''' <summary>
    ''' Handle all incoming phone function usm 
    ''' </summary>
    ''' <param name="qsAction">Action to perform</param>
    ''' <param name="messageId"></param>
    ''' <remarks></remarks>
    Private Sub HandlePhoneMessages(ByVal qsAction As String, ByVal messageId As String)
        Try
            'log a debug message when debug on
            If GF.UPC.Script.BaseDebugOn Then
                Call GF.LogSystemMessage("Script", "HANDLEPHONEMESSAGES; action: " & qsAction & ", messageID: " & messageId & ", GUID: " & GF.UPC.System.GUID)
            End If

            GF.UPC.Script.PanelRenderFlag = True
            Dim myDS As New DataSet("test")
            myDS = Session("gSessionDataSet")

            Dim errorCode As String

            '10/17/03 Inna - check to see if the GUID is setup; if not, exit.
            If Len(Trim(GF.UPC.System.GUID)) = 0 Then
                Exit Sub
            End If

            Select Case qsAction.ToLower()
                Case "newcall"
                    'Stach 12/09 - Clear out old data if we didn't on ready attempt for whatever reason.
                    If GF.NGS.M_PRODUCT_ID <> "" Then
                        ' Assuming gfHandleMakeReady didn't completely execute for some reason.
                        ' Make sure old data is cleared out.
                        GF.LogSystemMessage("Script", "Product ID still exists, clearing data.")

                        'initializes all data except script here...
                        resetDataTables()
                    End If

                    GF.HandleNewCallEvent(messageId)
                    GF.gfHandleNewCall()

                Case "signon"
                    RaiseEvent panelAgentSignOn()
                    GF.gfHandleSignOn()

                Case "signonfailed"
                    Dim replyCode As String
                    Dim errorMessage As String
                    Dim recoveryText As String
                    replyCode = Request.QueryString("ErrorCode")
                    recoveryText = Request.QueryString("RecoveryText")
                    errorMessage = Request.QueryString("ErrorText") & "," & recoveryText
                    RaiseEvent panelAgentSignOnFailed(replyCode, errorMessage)
                    GF.gfSignonFailed(replyCode, errorMessage)

                Case "makereadyfailed"
                    Dim replyCode As String
                    Dim errorMessage As String
                    replyCode = Request.QueryString("ErrorCode")
                    errorMessage = Request.QueryString("ErrorText")
                    GF.gfMakeReadyFailed(replyCode, errorMessage)

                Case "readyfailed"
                    Dim replyCode As String
                    Dim errorMessage As String
                    Dim recoveryText As String
                    replyCode = Request.QueryString("ErrorCode")
                    recoveryText = Request.QueryString("RecoveryText")
                    errorMessage = Request.QueryString("ErrorText") & "," & recoveryText
                    RaiseEvent panelAgentMakeReadyFailed(replyCode, errorMessage)
                    GF.gfMakeReadyFailed(replyCode, errorMessage)

                Case "signoff"
                    RaiseEvent panelAgentSignOff()
                    GF.gfHandleSignOff()

                Case "ready"
                    GF.gfHandleMakeReady()

                Case "makeready"
                    GF.gfHandleMakeReady()

                Case "notready"
                    RaiseEvent panelAgentNotReady()
                    GF.gfHandleNotReady()

                Case "notreadywithaux"
                    GF.gfHandleNotReadyWithAux(Request.QueryString("Auxcode"))

                Case "hold"
                    GF.gfHandleHold()

                Case "offhold"
                    GF.gfHandleOffHold()

                Case "reconnectheld"
                    GF.gfHandleOffHold()

                Case "agentdisconnect"
                    RaiseEvent panelAgentDisconnect()
                    GF.gfHandleDisconnect()

                Case "remotedisconnect"
                    GF.gfHandleRemoteDisconnect()

                Case "palconferenced"
                    GF.gfHandleOffHold()

                Case "disconnectpal"
                    GF.gfHandleDisconnectPal()

                Case "palanswered"
                    GF.gfHandlePalAnswered()

                Case "callerdisconnectinconsult"
                    GF.gfHandleCallerDisconnectInConsult()

                Case "createavayaextensionfailed"
                    GF.gfHandleCreateAvayaExtensionFailed()

                Case "ctcpalconferenced"
                    GF.gfHandleCTCPalConferenced()

                Case "transferattemptedinerror"
                    GF.gfHandleMistakenTransferAttempt()

                Case "thirdpartydialinhold"
                    GF.gfHandleThirdPartyDialInHold()

                Case "avayanoschedulewarning"
                    GF.gfHandleAvayaNoScheduleWarning()

                Case "outbounddialcomplete"
                    if not messageID is nothing and messageID <> "" then
                        GF.HandleNewCallEvent(messageId)
                    end if
                    GF.gfHandleOutboundDialComplete()

                Case "outbounddialdestringing"
                    GF.gfHandleOutboundDestRinging()

                Case "forcenotready"
                    GF.gfForceNotReady()

                Case "dialthirdparty"
                    'TODO - get the phonenumber and dialtype
                    GF.gfHandleDialThirdParty()
                    RaiseEvent panelThirdPartyEvent("DIALED")

                Case "conference"
                    GF.gfHandleConference()

                Case "transfer"
                    GF.gfHandleTransfer()

                Case "disconnectthirdparty"
                    GF.gfHandleDisconnectThirdParty()

                Case "agentstrike"
                    GF.gfHandleAgentStrike()

                Case "forcesignoff"
                    'Force signoff UMS message notices the script that a new call was
                    'sent to a remote agent, but they refused to answer the call (Outbound)
                    GF.gfHandleForceSignOff()

                Case "logon"
                    'Notifies the script that the user has logged on to the workstation
                    GF.gfLogOn()

                Case "loggedon"
                    'do nothing as of now

                Case "enablesignon"
                    ' Signon button has been enabled
                    GF.gfSignonEnabled()

                Case "loggedoff"
                    'graceful abandon to skip logging out of phone automatically
                    GF.UPC.System.GracefulAbandon = "Y"

                    'destroy the session when logging off, then send a message to the socketproxy
                    Session.Abandon()
                    GF.gfSendLoggedOffEvent()

                Case "makebusyon"
                    GF.UPC.Script.MAKEBUSYON = "Y"
                    If Not IsNothing(Request.QueryString("auxcode")) Then
                        GF.UPC.Script.AuxCode = Request.QueryString("auxcode")
                    End If

                Case "makebusyoff"
                    GF.UPC.Script.MAKEBUSYON = "N"

                Case "proccomplete"
                    GF.gfExternalProcedureComplete()

                Case "proccompletefailed"
                    GF.gfExternalProcedureFailed()

                Case "dialcomplete"
                    GF.gfHandleDialThirdPartyAnswered()
                    RaiseEvent panelThirdPartyEvent("ANSWERED")

                Case "dialinprogress"
                    GF.gfHandleDialInProgress()
                    RaiseEvent panelThirdPartyEvent("DIALINPROGRESS")

                Case "dialcompletefailed"
                    GF.gfHandleDialThirdPartyFailed()
                    RaiseEvent panelThirdPartyEvent("DIALTHIRDPATYFAILED")

                Case "scriptloggedoff"
                    GF.UPC.System.GracefulAbandon = "Y"
                    Session.Abandon()

                Case "agentdialcomplete"
                    '    gfAgentAnswered()
                    '    RaiseEvent panelAgentAnswered()
                    'make sure updatenavtree gets called here
                    GF.UPC.Script.NAVMODE = "999"
                    updateNavTree()

                    GF.gfAgentAnswered()
                    RaiseEvent panelAgentAnswered()

                Case "agentdialcompletefailed"
                    errorCode = Request.QueryString("ErrorCode")
                    GF.gfAgentFailedToAnswer(errorCode)
                    RaiseEvent panelAgentFailedToAnswer(errorCode)

                Case "dataentrynewcall"
                    GF.gfHandleDataEntryCallAnswered()

                Case "dataentrycallfailed"
                    errorCode = Request.QueryString("ErrorCode")
                    GF.gfHandleDataEntryCallFailed(errorCode)

                Case "outbounddialbusy"
                    GF.gfHandleOutboundDialBusy()

                Case "palorcallerdisconnect"
                    GF.gfHandle3rdPartyOrCallerDisconConference()

                Case "destinationbusy"
                    GF.gfHandleDestinationBusy()

                Case "facexecuted"
                    GF.gfHandleFACExecuted()

                Case "phoneeventssuppressed"
                    GF.gfHandlePhoneEventsSuppressed()

                Case "unmuteallinconf"
                    GF.gfHandleUnmuteAllInConf()

                Case "mutecustinconf"
                    GF.gfHandleMuteCustInConf()

                Case "mutethirdpartyinconf"
                    GF.gfHandleMuteThirdPartyInConf()

                Case "muteagentinconf"
                    GF.gfHandleMuteAgentInConf()

                Case "muteagentmic"
                    GF.gfHandleMuteAgentMic()

                Case "unmuteagentmic"
                    GF.gfHandleUnmuteAgentMic()

                Case "muteallinconf"
                    GF.gfHandleMuteAllInConf()

                Case "paldisconnectedfromconfmute"
                    GF.gfHandlePALDisconnectFromConfMute()

                Case "paldisconnectedfromconference"
                    GF.gfHandlePALDisconnectFromConference()

                Case "thirddisconnectfromconfmute"
                    GF.gfHandleThirdDisconnectFromConfMute()

                Case "thirddisconnectfromconfmuteagent"
                    GF.gfHandleThirdDisconnectFromConfMuteAgent()

                Case "thirddisconnectfromconf"
                    GF.gfHandleThirdDisconnectFromConf()

                Case "callerdisconnectedfromconfmute"
                    GF.gfHandleCallerDisconnectFromConfMute()

                Case "callerdisconnectedfromconference"
                    GF.gfHandleCallerDisconnectFromConference()

                Case "custdisconnectfromconfmute"
                    GF.gfHandleCustDisconnectFromConfMute()

                Case "custdisconnectfromconfmuteagent"
                    GF.gfHandleCustDisconnectFromConfMuteAgent()

                Case "custdisconnectfromconf"
                    GF.gfHandleCustDisconnectFromConf()

                Case "coldtransferfailed"
                    GF.gfHandleColdTransferFailed()

                Case "servicelinkstatusup"
                    GF.gfHandleServiceLinkStatusUp()

                Case "servicelinkstatusdown"
                    GF.gfHandleServiceLinkStatusDown()

                Case "scriptmessageenablemakereadybutton"
                    GF.gfHandleScriptMessageEnableMakeReadyButton()

                Case "scriptmessagedisablemakereadybutton"
                    GF.gfHandleScriptMessageDisableMakeReadyButton()

                Case "notreadystartwork"
                    'do nothing for this one

                Case "addthirdparty", "removethirdparty", "updatethirdparty", "replacethirdparties" 
                    'Do nothing for now

                Case "mutesscrecorder"
                    GF.gfHandleMuteSSCRecorder()


                Case Else
                    'log a debug message when debug on
                    Call GF.LogSystemMessage("SCRIPT", "HANDLEPHONEMESSAGES; Action NOT defined -> " & qsAction)
            End Select

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Handle all unsolicited messages coming into the panel
    ''' </summary>
    ''' <param name="qsAction">Action to perform</param>
    ''' <remarks></remarks>
    Private Sub HandleUMS(ByVal qsAction As String)
        Try
            'log a debug message when debug on
            If GF.UPC.Script.BaseDebugOn Then
                Call GF.LogSystemMessage("Script", "HANDLEUMS; action: " & qsAction)
            End If

            GF.UPC.Script.PanelRenderFlag = True

            Select Case qsAction.ToLower()

                Case "newcall"
                    'Stach 12/09 - Clear out old data if we didn't on ready attempt for whatever reason.
                    If GF.NGS.M_PRODUCT_ID <> "" Then
                        ' Assuming gfHandleMakeReady didn't completely execute for some reason.
                        ' Make sure old data is cleared out.
                        GF.LogSystemMessage("Script", "Product ID still exists, clearing data.")

                        'initializes all data except script...
                        resetDataTables()
                    End If

                    GF.gfHandleNewCall()

                Case "signon"
                    GF.gfHandleSignOn()

                Case "signoff"
                    GF.gfHandleSignOff()

                Case "ready"
                    GF.gfHandleMakeReady()
                    set_currPath(ScriptPaths.MSG)

                Case "notready"
                    GF.gfHandleNotReady()

                Case "hold"
                    GF.gfHandleHold()

                Case "offhold"
                    GF.gfHandleOffHold()

                Case "createavayaextensionfailed"
                    GF.gfHandleCreateAvayaExtensionFailed()

                Case "callerdisconnectinconsult"
                    GF.gfHandleCallerDisconnectInConsult()

                Case "ctcpalconferenced"
                    'Do nothing for now

                Case "transferattemptedinerror"
                    GF.gfHandleMistakenTransferAttempt()

                Case "thirdpartydialinhold"
                    GF.gfHandleThirdPartyDialInHold()

                Case "avayanoschedulewarning"
                    GF.gfHandleAvayaNoScheduleWarning()

                Case "outbounddialcomplete"
                    GF.gfHandleOutboundDialComplete()

                Case "agentdisconnect"
                    GF.gfHandleDisconnect()

                Case "remotedisconnect"
                    GF.gfHandleRemoteDisconnect()

                Case "dialthirdparty"
                    GF.gfHandleDialThirdParty()

                Case "conference"
                    GF.gfHandleConference()

                Case "transfer"
                    GF.gfHandleTransfer()

                Case "disconnectthirdparty"
                    GF.gfHandleDisconnectThirdParty()

                Case "forcesignoff"
                    'Force signoff UMS message notices the script that a new call was
                    'sent to a remote agent, but they refused to answer the call (Outbound)
                    GF.gfHandleForceSignOff()

                Case "logon"
                    'Notifies the script that the user has logged on to the workstation
                    GF.gfHandleLoggedOn()

                Case "scriptswitch"
                    'do anything here?  new to avoid ums undefined errors on release switching.

                Case Else

                    Call GF.LogSystemMessage("SCRIPT", "HANDLEUMS; Action NOT defined -> " & qsAction)
            End Select

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Builds and returns a query string from the url, class, action, and messageid parameters
    ''' </summary>
    ''' <param name="myURL"></param>
    ''' <param name="qsClass"></param>
    ''' <param name="myAction"></param>
    ''' <param name="myMessageID"></param>
    ''' <param name="myUID"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function BuildQueryString(ByVal myURL As String, ByVal qsClass As String, ByVal myAction As String, ByVal myMessageID As String, ByVal myUID As String) As String
        Try

            Dim myQS As String
            myQS = myURL & "?Class=" & qsClass & "&Action=" & myAction & "&MessageID=" & myMessageID & "&myUID=" & myUID
            Return myQS

        Catch ex As Exception
            Throw
        End Try
    End Function

    ''' <summary>
    ''' For debugging, this function writes out (response.write) items in the query string
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PrintQString()
        Try
            Dim newProject, newScript, scriptURL, projectURL As String
            Dim avgTalk, avgWrap, avgHold, avgOther As String

            qsAction = Request.QueryString("Action")
            newProject = Request.QueryString("NewProject")
            newScript = Request.QueryString("NewScript")
            scriptURL = Request.QueryString("ScriptURL")
            projectURL = Request.QueryString("ProjectURL")
            avgTalk = Request.QueryString("AvgTalk")
            avgWrap = Request.QueryString("AvgWrap")
            avgHold = Request.QueryString("AvgHold")
            avgOther = Request.QueryString("AvgOther")

            'Get DataSet from Queue.  DataSet will contain
            'a datatable named NewCall and table named MsgTitle

            If qsClass <> "" Then
                Response.Write("Class = " & qsClass & "<br>")
            End If
            If qsAction <> "" Then
                Response.Write("Action = " & qsAction & "<br>")
            End If
            If qsMessageID <> "" Then
                Response.Write("MessageIdentifier = " & qsMessageID & "<br>")
            End If
            If qsUID <> "" Then
                Response.Write("User Identifier = " & qsUID & "<br>")
            End If
            If newProject <> "" Then
                Response.Write("New Project = " & newProject & "<br>")
            End If
            If scriptURL <> "" Then
                Response.Write("Script URL = " & scriptURL & "<br>")
            End If
            If projectURL <> "" Then
                Response.Write("Project URL = " & projectURL & "<br>")
            End If
            If avgTalk <> "" Then
                Response.Write("AvgTalk = " & avgTalk & "<br>")
            End If
            If avgWrap <> "" Then
                Response.Write("AvgWrap = " & avgWrap & "<br>")
            End If
            If avgHold <> "" Then
                Response.Write("AvgHold = " & avgHold & "<br>")
            End If
            If avgOther <> "" Then
                Response.Write("AvgOther = " & avgOther & "<br>")
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

#End Region


#Region "Script Path functions"
    ''' <summary>
    ''' Sets the current path of Script Path
    ''' </summary>
    ''' <param name="strPathName">Script Path PathName</param>
    ''' <remarks></remarks>
    Public Sub set_currPath(ByVal strPathName As String)
        Try
            If GF.UPC.Script.BaseDebugOn Then
                Call GF.LogSystemMessage("Script", "In Set_CurrPath; strPathName: " & strPathName)
            End If

            source = "J"

            'Don't want to always call panelEdit. If set_currpath is called from panelBranch we already passed the edits. 
            'The call ends up being a dup and we often fall into loops.
            'GF.UPC.Script.LastAction = "panelEdit"
            'RaiseEvent panelEdit()
            If Not GF.UPC.Script.LastAction.Equals("panelBranch", StringComparison.InvariantCultureIgnoreCase) Then
                'If our last action was branch we already made it through an edit.
                RaiseEvent panelEdit()

            End If
            'Set our last action after running the panel edit as we were running edit twice on set_currpaths
            GF.UPC.Script.LastAction = "panelEdit"


            ' GSC First make sure we passed the edits
            If EditError > 0 Then
                DisplayError(ErrorMsg)
                Exit Sub
            End If

            If GF.UPC.Script.IN_BROWSER Then
                'find out ScriptPath to jump to
                Dim pathChange As String = NavigatePathChange(strPathName)

                If GF.UPC.Script.BaseDebugOn Then
                    Call GF.LogSystemMessage("Script", "In Set_CurrPath; pathChange: " & pathChange)
                End If

                If Len(pathChange) <> 0 Then
                    GF.UPC.Script.CollapseTree = True
                    If doesFileExist(pathChange) Then
                        'Response.Redirect(pathChange & "?Class=Panel&Action=OnLoad", False)
                        If Request.ApplicationPath.EndsWith("/") Then
                            Response.Redirect(String.Format("{0}{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, pathChange), False)
                        Else
                            Response.Redirect(String.Format("{0}/{1}?Class=Panel&Action=OnLoad", Request.ApplicationPath, pathChange), False)
                        End If
                    Else
                        'Now moving to a more direct path as not sure where we will be with new sup panels
                        'Response.Redirect("../Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", False)
                        'Response.Redirect("/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", False)
                        If Request.ApplicationPath.EndsWith("/") Then
                            Response.Redirect(String.Format("{0}Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                        Else
                            Response.Redirect(String.Format("{0}/Panels/Other/NOTDONE.aspx?Class=Panel&Action=OnLoad", Request.ApplicationPath), False)
                        End If
                    End If
                Else
                    Call updateNavTree()
                End If
            End If

        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region "Client Side Operations"
    ''' <summary>
    ''' Target Object that will be selected and copied to clipboard.
    ''' </summary>
    ''' <param name="Target">String to copy to clipboard</param>
    ''' <remarks></remarks>
    Public Sub CopyStringToClipBoard(ByVal Target As String)
        'Stach 02/14 - Handle ' in text
        'myClientCode = myClientCode & "window.clipboardData.setData( 'Text','" & Target & "');" & vbCrLf
        myClientCode = String.Format("{0}window.clipboardData.setData( 'Text','{1}');{2}", myClientCode, Target.Replace("'", String.Format("'+ {0}'{0} + '", """")), vbCrLf)
    End Sub

    ''' <summary>
    ''' Copies in client-side javascript that grabs the text from the given html tag and copies it to the clipboard.
    ''' </summary>
    ''' <param name="Target">Target asp.net control object that will be selected and copied to clipboard.</param>
    ''' <remarks>
    ''' Code assumes string is being set on the server side to the Target tag before being called.
    ''' </remarks>
    Public Sub CopyToClipBoard(ByVal Target As String)

        Dim sb As New System.Text.StringBuilder("")

        'Code to copy from a selected object
        sb.Append("if(document.all('" & Target & "') !=null){" & vbCrLf)
        sb.Append("var obj = document.all('" & Target & "')         " & vbCrLf)
        sb.Append("if (obj.type==""text"" || obj.type==""textarea""){   " & vbCrLf)
        sb.Append("    var rng = obj.createTextRange();             " & vbCrLf)
        sb.Append("} else {                                         " & vbCrLf)
        sb.Append("    var rng = document.body.createTextRange();   " & vbCrLf)
        sb.Append("    rng.moveToElementText(obj);                  " & vbCrLf)
        sb.Append(" }                                               " & vbCrLf)
        sb.Append("rng.scrollIntoView();                            " & vbCrLf)
        sb.Append("rng.select();                                    " & vbCrLf)

        sb.Append("document.execCommand('copy');} // end if target object isn't null")
        If Not ClientScript.IsClientScriptBlockRegistered("CopyToClipboard") Then
            ClientScript.RegisterStartupScript(GetType(String), "CopyToClipboard", "<script language=javascript >" & vbCrLf & sb.ToString & vbCrLf & "</script>" & vbCrLf)
        End If

    End Sub

    ''' <summary>
    ''' Target control object that will have clipboard info pasted into it.
    ''' </summary>
    ''' <param name="controlObjectName">name of the control object to have the clipboard text pasted into it.</param>
    ''' <remarks></remarks>
    Public Sub PasteToClipBoard(ByVal controlObjectName As String)
        Dim sb As New System.Text.StringBuilder("")
        sb.Append(vbCrLf)
        sb.Append("if(document.getElementById('" & controlObjectName & "') !=null){" & vbCrLf)
        sb.Append("document.getElementById('" & controlObjectName & "').select();" & vbCrLf)
        sb.Append("document.execCommand('paste');}")
        sb.Append(vbCrLf)
        myClientCode = myClientCode & sb.ToString
    End Sub

    ''' <summary>
    ''' Set window focus to a specific control
    ''' </summary>
    ''' <param name="WindowTitle"></param>
    ''' <remarks></remarks>
    Public Sub SetWindowFocus(ByVal WindowTitle As String)
        Try        
            Dim sb As New System.Text.StringBuilder("")
            Dim Q As String = """"
            sb.Append(vbCrLf)
            sb.Append("dim objWScript3").Append(vbCrLf)
            sb.Append("set objWScript3 = CreateObject(" & Q & "WScript.Shell" & Q & ")").Append(vbCrLf)
            If WindowTitle.Trim.Length > 0 Then
                sb.Append("if not (objWScript3.AppActivate(" & Q & WindowTitle & Q & ")) then").Append(vbCrLf)
                If Left(WindowTitle.Trim, 3) = "CSI" Then
                    sb.Append("objWScript3.Run(" & Q & "mshta.exe C:\toysrus\toysrusregistry.hta" & Q & ")").Append(vbCrLf)
                End If
                sb.Append("end if").Append(vbCrLf)                
            End If
            sb.Append("set objWScript3 = nothing")

            sb.Append(vbCrLf)
            myClientCode = myClientCode & sb.ToString

        Catch ex As Exception           
            Throw
        End Try
    End Sub


    ''' <summary>
    ''' Opens an external web page given the correct parameters
    ''' </summary>
    ''' <param name="URL">Target URL to open</param>
    ''' <param name="TargetName">Title of the window to open</param>
    ''' <param name="WinWidth">Width setting for the window to open (optional)</param>
    ''' <param name="WinHeight">Height setting for the window to open (optional)</param>
    ''' <remarks></remarks>
    Public Sub OpenExternalWindow(ByVal URL As String, ByVal TargetName As String, Optional ByVal WinWidth As String = "", Optional ByVal WinHeight As String = "")
        Try
            Const DBLQ As String = Chr(34) 'DoubleQuote
            Dim sb As New System.Text.StringBuilder("")
            If GF.UPC.Script.IN_BROWSER Then
                sb.Append("OpenExtWindow();" & vbCrLf)
                sb.Append("function OpenExtWindow() {" & vbCrLf)
                sb.Append("if(parent.BranchingFR.document.readyState =='complete')" & vbCrLf & "{" & vbCrLf)
                sb.Append("  parent.BranchingFR.OpenExtWindow(" & DBLQ & URL & DBLQ & ", " & DBLQ & TargetName & DBLQ & ",'" & Trim(WinWidth) & "','" & Trim(WinHeight) & "');")
                sb.Append("}" & vbCrLf & "else {" & vbCrLf)
                sb.Append("setTimeout(""OpenExtWindow()"",10);" & vbCrLf)
                sb.Append("}" & vbCrLf & "}" & vbCrLf)
                myClientCode = myClientCode & sb.ToString()
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Close an external webpage with the existing targetname (title)
    ''' </summary>
    ''' <param name="TargetName">Title of the window to close</param>
    ''' <remarks></remarks>
    Public Sub CloseExternalWindow(ByVal TargetName As String)
        Try
            Const DBLQ As String = Chr(34) 'DoubleQuote
            Dim sb As New System.Text.StringBuilder("")
            sb.Append("CloseExtWindow();" & vbCrLf)
            sb.Append("function CloseExtWindow() {" & vbCrLf)
            sb.Append("if(parent.BranchingFR.document.readyState =='complete')" & vbCrLf & "{" & vbCrLf)
            sb.Append("  parent.BranchingFR.CloseExtWindow(" & DBLQ & TargetName & DBLQ & ");")
            sb.Append("}" & vbCrLf & "else {" & vbCrLf)
            sb.Append("setTimeout(""CloseExtWindow()"",10);" & vbCrLf)
            sb.Append("}" & vbCrLf & "}" & vbCrLf)
            myClientCode = myClientCode & sb.ToString()
        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' <summary>
    ''' Write collection of name value pairs to specified registry key.
    ''' </summary>
    ''' <param name="RegItems">RegItems - HashTable containing key/values to write</param>
    ''' <remarks></remarks>
    Public Sub BWWriteClientReg(ByVal RegItems As System.Collections.Hashtable)        

        Dim sb As New System.Text.StringBuilder("")

        sb.Append("setTimeout('BWRW()', 1200);" & vbCrLf)
        sb.Append("function BWRW(){" & vbCrLf)

        sb.Append("try {" & vbCrLf)

        sb.Append("var wshShell = new ActiveXObject(""WScript.Shell"");" + vbCrLf)
        Dim objDE As System.Collections.DictionaryEntry
        For Each objDE In RegItems
            sb.Append("wshShell.RegWrite(""" + objDE.Key + """, """ + objDE.Value + """)" + vbCrLf)
        Next

        sb.Append("} catch (e) {" & vbCrLf)
        sb.Append("    alert(e.name + ': ' + e.message);" & vbCrLf)
        sb.Append("}" & vbCrLf)

        sb.Append("}" & vbCrLf)

        myClientCode = myClientCode + sb.ToString()
    End Sub

    ''' <summary>
    ''' Read the specified registry key, save the value into a textbox on and click a button on your form
    ''' </summary>
    ''' <param name="KeyToRead">Registry key to read</param>
    ''' <param name="TxtID">id of the textbox to store the results (this should be mapped to a local/data store in BW</param>
    ''' <param name="BtnID">id a button which will be clicked when the client code is finished (could branch in BW)</param>
    ''' <remarks></remarks>
    Public Sub BWReadClientReg(ByVal KeyToRead As String, ByVal TxtID As String, ByVal BtnID As String)
      
        Dim sb As New System.Text.StringBuilder("")

        sb.Append("ReadClientReg()" + vbCrLf)
        sb.Append("function ReadClientReg(){" + vbCrLf)
        sb.Append("if (document.readyState =='complete'){" + vbCrLf)
        sb.Append("var wshShell = new ActiveXObject(""WScript.Shell"");" + vbCrLf)
        If TxtID.IndexOf("LBL") > -1 Then ' its a label
            sb.Append("document.getElementById('" + TxtID + "').innerText = wshShell.RegRead('" + KeyToRead + "');" + vbCrLf)
        Else ' its a textbox
            sb.Append("document.getElementById('" + TxtID + "').value = wshShell.RegRead('" + KeyToRead + "');" + vbCrLf)
        End If
        If BtnID.Length > 0 Then
            sb.Append("setTimeout(""ButtonClick()"",10);" + vbCrLf)
        End If
        sb.Append("}else{setTimeout(""ReadClientReg()"",10);}" + vbCrLf)
        sb.Append("}" + vbCrLf)

        sb.Append("function ButtonClick(){" + vbCrLf)
        sb.Append("document.getElementById('" + BtnID + "').click();" + vbCrLf)
        sb.Append("}" + vbCrLf)

        myClientCode = myClientCode + sb.ToString()

    End Sub

    ''' <summary>
    ''' Save clipboard text into a specified textbox and click a button on your form
    ''' </summary>
    ''' <param name="TxtID">id of the textbox to store the results (this should be mapped to a local/data store in BW</param>
    ''' <param name="BtnID">id a button which will be clicked when the client code is finished (could branch in BW)</param>
    ''' <remarks></remarks>
    Public Sub BWReadFromClipBoard(ByVal TxtID As String, ByVal BtnID As String)

        Dim sb As New System.Text.StringBuilder("")

        sb.Append("ReadFromClipboard()" + vbCrLf)
        sb.Append("function ReadFromClipboard(){" + vbCrLf)
        sb.Append("if (document.readyState =='complete'){" + vbCrLf)
        sb.Append("var wshShell = new ActiveXObject(""WScript.Shell"");" + vbCrLf)
        If TxtID.IndexOf("LBL") > -1 Then ' its a label
            sb.Append("document.getElementById('" + TxtID + "').innerText = window.clipboardData.getData('Text')" + vbCrLf)
        Else ' its a textbox
            sb.Append("document.getElementById('" + TxtID + "').value = window.clipboardData.getData('Text')" + vbCrLf)
        End If
        If BtnID.Length > 0 Then
            sb.Append("setTimeout(""ButtonClick()"",10);" + vbCrLf)
        End If
        sb.Append("}else{setTimeout(""ReadFromClipboard()"",10);}" + vbCrLf)
        sb.Append("}" + vbCrLf)

        sb.Append("function ButtonClick(){" + vbCrLf)
        sb.Append("document.getElementById('" + BtnID + "').click();" + vbCrLf)
        sb.Append("}" + vbCrLf)

        myClientCode = myClientCode + sb.ToString()

    End Sub

    ''' <summary>
    ''' Write collection of name value pairs to the registry and to the clipboard
    ''' </summary>
    ''' <param name="RegItems">Name value data to be written</param>
    ''' <param name="Target">Registry key/clipboard data to write to</param>
    ''' <remarks></remarks>
    Public Sub BWWriteToRegAndCB(ByVal RegItems As System.Collections.Hashtable, ByVal Target As String)
        Dim sb As New System.Text.StringBuilder("")

        sb.Append("" & vbCrLf)

        sb.Append("window.clipboardData.setData( 'Text','" & Target & "');" & vbCrLf)
        sb.Append("var cn = 0;" & vbCrLf)
        sb.Append("var WReg = setInterval('checkCB()', 500);" & vbCrLf)
        sb.Append("function checkCB()" & vbCrLf)
        sb.Append("{" & vbCrLf)
        sb.Append("	var CBtext = window.clipboardData.getData('Text');" & vbCrLf)
        sb.Append("	if (CBtext == '" & Target & "' || cn > 4) {" & vbCrLf)
        sb.Append("		clearInterval(WReg);" & vbCrLf)

        'RegWriteCode
        sb.Append("		var wshShell = new ActiveXObject(""WScript.Shell"");" + vbCrLf)
        Dim objDE As System.Collections.DictionaryEntry
        For Each objDE In RegItems
            sb.Append("		wshShell.RegWrite(""" + objDE.Key + """, """ + objDE.Value + """)" + vbCrLf)
        Next

        sb.Append("		}" & vbCrLf)
        sb.Append("	else {" & vbCrLf)
        sb.Append("		cn = cn + 1;" & vbCrLf)
        sb.Append("}" & vbCrLf)
        sb.Append("}" & vbCrLf)

        myClientCode = myClientCode + sb.ToString()
    End Sub

#End Region


End Class
