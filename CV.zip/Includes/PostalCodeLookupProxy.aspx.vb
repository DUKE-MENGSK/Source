﻿Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Xml.Serialization

Public Class PostalCodeLookupProxy
    Inherits System.Web.UI.Page

    Protected Property Zip As String
    Protected Property ScriptEnvironment As String
    Protected Property Timeout As Integer
    Protected Property Retries As Integer
    Protected Property UrlOverride As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim timeoutString As String, retriesString As String

        Try
            ' we'll be returning json data....
            Response.ContentType = "application/json"

            Zip = Request.QueryString("zip")
            If String.IsNullOrEmpty(zip) Then
                'Response.StatusCode = 544
                Response.Write(GetJsonError("No Zipcode was supplied!"))
                Exit Sub
            End If

            'validate the incoming zipcode...
            Dim rxZip As New System.Text.RegularExpressions.Regex("(^\d{5}$)|(^([a-zA-Z]\d){3}$)")
            If (Not rxZip.Match(zip).Success) Then
                'Response.StatusCode = 544
                Response.Write(GetJsonError("Invalid Zip or Postal Code!  United States zip codes must be 5 numbers only and Canadian postal codes must be in the format of FSA (Forward Sortation Area -> alpha-numeric-alpha), LDU (Local Delivery Unit -> 3 alpha numeric chars), ie. A1A1A1)."))
                Exit Sub
            End If

            'Script Environment value
            'todo get script environment from session? or??
            ScriptEnvironment = Request.QueryString("scriptEnvironment")

            'override the timeout?
            timeoutString = Request.QueryString("timeoutOverride")
            If Integer.TryParse(timeoutString, timeout) = False Then
                Timeout = 0
            End If

            'get the number of retries for the soap retries... default to 2 retries
            retriesString = Request.QueryString("numRetries")
            If Integer.TryParse(retriesString, retries) = False Then
                Retries = 2
            End If

            urlOverride = Request.QueryString("urlOverride")
            If urlOverride Is Nothing Then
                UrlOverride = ""
            End If

            Response.Write(PerformPostalCodeLookup())

        Catch ex As Exception

            Response.Write(GetJsonError(ex.Message))

        End Try

    End Sub



    Private Function PerformPostalCodeLookup() As String
        Try

            'NGS postal code lookup instantiations...
            Dim lookup As New NGSPostalCodeLookupProxy.ngsPostalCodeLookup
            Dim input As New NGSPostalCodeLookupProxy.ngsPostalCodeWSInput
            Dim reply As New NGSPostalCodeLookupProxy.ngsPostalCodeWSOutput

            input.PostalCode = Zip

            If Timeout > 0 Then
                lookup.Timeout = Timeout
            End If

            If UrlOverride.Trim.Length > 0 Then
                lookup.Url = UrlOverride
            Else
                lookup.Url = BuildLookupURL(lookup.Url)
            End If

            Try
                reply = lookup.CallngsPostalCodeLookup(input)
            Catch ex As Exception
                If ex.Message.IndexOf("timed out", StringComparison.InvariantCultureIgnoreCase) > -1 OrElse
                    ex.Message.IndexOf("timed-out", StringComparison.InvariantCultureIgnoreCase) > -1 Then
                    'retry num retries times...
                    If Retries > 0 Then
                        Retries = Retries - 1
                        PerformPostalCodeLookup()
                    Else
                        Return GetJsonError(String.Format("All attempts to retrieve the postal code information for {0} have failed from NGSOperations.PostalCodeLookup.", Zip))
                    End If
                Else
                    Return GetJsonError(ex.ToString())
                End If
            End Try

            If reply.ReplyCode = 0 Then
                Dim s As New Script.Serialization.JavaScriptSerializer()
                Return s.Serialize(New ZipReturnDto(reply))
            Else
                Return GetJsonError(reply.ReplyMsg)
            End If


        Catch ex As Exception
            Return GetJsonError(ex.ToString())
        End Try

    End Function


    Protected Function BuildLookupURL(ByVal inUrl As String) As String

        Try

            Dim returnUrl As String

            Select Case ScriptEnvironment.Trim().ToUpper()
                Case "PRD"
                    'build the production URL for the NGS system...
                    'http://absngswebservice.com/ngsPostalCodeLookup/ngsPostalCodeLookup.asmx
                    returnUrl = ReplaceWebserverNameInURL(inUrl, "absngswebservice.com")

                Case "TST", "TRN"
                    'set to the production URL for now....
                    'http://absngswebservice.com/ngsPostalCodeLookup/ngsPostalCodeLookup.asmx
                    returnUrl = ReplaceWebserverNameInURL(inUrl, "absngswebservice.com")

                Case "DEV"
                    'build the development URL for the NGS system...
                    'http://oma11cdevsql02/ngsPostalCodeLookup/ngsPostalCodeLookup.asmx
                    returnUrl = ReplaceWebserverNameInURL(inUrl, "oma11cdevsql02")

                Case "QA"
                    'build the QA URL for the NGS system...
                    'http://oma11cqngsweb1/ngsPostalCodeLookup/ngsPostalCodeLookup.asmx
                    returnUrl = ReplaceWebserverNameInURL(inUrl, "oma11cqngsweb1")

                Case Else
                    'environment not found, build the development URL for the NGS system...
                    'http://oma11cdevsql02/ngsPostalCodeLookup/ngsPostalCodeLookup.asmx
                    returnUrl = ReplaceWebserverNameInURL(inUrl, "oma11cdevsql02")
            End Select

            Return returnUrl

        Catch ex As Exception
            'on any exceptions return the input url which is the default soap url...
            Return inUrl
        End Try
    End Function

    Private Function GetJsonError(message As String) As String
        Return String.Format("{{ ""error"":""{0}"" }}", message)
    End Function

    Protected Function ReplaceWebserverNameInURL(ByVal inputUrl As String, ByVal newHostName As String) As String

        Try
            Dim inUri As Uri = New Uri(inputUrl)
            Dim returnUrl As String

            returnUrl = inputUrl.Replace(inUri.Host, newHostName)

            Return returnUrl

        Catch ex As Exception
            Return ""
        End Try

    End Function


    Private Class ZipReturnDto

        Public Property Zip As String

        Public Property City As String

        Public Property StateCode As String

        Public Property AreaCode As String

        Public Property CanadaFlag As String


        Public Sub New()

        End Sub


        Public Sub New(ngsReply As NGSPostalCodeLookupProxy.ngsPostalCodeWSOutput)
            Me.New()
            Me.Zip = ngsReply.ngsPostalCode.PostalCode
            Me.City = ngsReply.ngsPostalCode.CityName
            Me.StateCode = ngsReply.ngsPostalCode.ProvinceAbbr
            Me.AreaCode = ngsReply.ngsPostalCode.AreaCode
            If ngsReply.ngsPostalCode.CountryName.StartsWith("can", StringComparison.InvariantCultureIgnoreCase) Then
                Me.CanadaFlag = "C"
            Else
                Me.CanadaFlag = ""
            End If
        End Sub

    End Class


End Class



' if the NGSPostalCodeLookup is regenerated, place the regenerated reference.vb contents here, changing the namespace to NGSPostalCodeLookupProxy
' also check the default URL in the constructor

'------------------------------------------------------------------------------
' <auto-generated>
'     This code was generated by a tool.
'     Runtime Version:4.0.30319.269
'
'     Changes to this file may cause incorrect behavior and will be lost if
'     the code is regenerated.
' </auto-generated>
'------------------------------------------------------------------------------


'
'This source code was auto-generated by Microsoft.VSDesigner, Version 4.0.30319.269.
'
Namespace NGSPostalCodeLookupProxy

    '''<remarks/>
    <System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30319.1"), _
     System.Diagnostics.DebuggerStepThroughAttribute(), _
     System.ComponentModel.DesignerCategoryAttribute("code"), _
     System.Web.Services.WebServiceBindingAttribute(Name:="ngsPostalCodeLookupSoap", [Namespace]:="http://www.west.com/COS/Core/ngsPostalCode/")> _
    Partial Public Class ngsPostalCodeLookup
        Inherits System.Web.Services.Protocols.SoapHttpClientProtocol

        Private CallngsPostalCodeLookupOperationCompleted As System.Threading.SendOrPostCallback

        Private useDefaultCredentialsSetExplicitly As Boolean

        '''<remarks/>
        Public Sub New()
            MyBase.New()
            Me.Url = "http://oma11cdevsql02/ngspostalcodelookup/ngspostalcodelookup.asmx"
            If (Me.IsLocalFileSystemWebService(Me.Url) = True) Then
                Me.UseDefaultCredentials = True
                Me.useDefaultCredentialsSetExplicitly = False
            Else
                Me.useDefaultCredentialsSetExplicitly = True
            End If
        End Sub

        Public Shadows Property Url() As String
            Get
                Return MyBase.Url
            End Get
            Set(value As String)
                If (((Me.IsLocalFileSystemWebService(MyBase.Url) = True) _
                            AndAlso (Me.useDefaultCredentialsSetExplicitly = False)) _
                            AndAlso (Me.IsLocalFileSystemWebService(value) = False)) Then
                    MyBase.UseDefaultCredentials = False
                End If
                MyBase.Url = value
            End Set
        End Property

        Public Shadows Property UseDefaultCredentials() As Boolean
            Get
                Return MyBase.UseDefaultCredentials
            End Get
            Set(value As Boolean)
                MyBase.UseDefaultCredentials = value
                Me.useDefaultCredentialsSetExplicitly = True
            End Set
        End Property

        '''<remarks/>
        Public Event CallngsPostalCodeLookupCompleted As CallngsPostalCodeLookupCompletedEventHandler

        '''<remarks/>
        <System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://www.west.com/COS/Core/ngsPostalCode/ngsPostalCodeLookup", RequestElementName:="ngsPostalCodeLookup", RequestNamespace:="http://www.west.com/COS/Core/ngsPostalCode/", ResponseElementName:="ngsPostalCodeLookupResponse", ResponseNamespace:="http://www.west.com/COS/Core/ngsPostalCode/", Use:=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle:=System.Web.Services.Protocols.SoapParameterStyle.Wrapped)> _
        Public Function CallngsPostalCodeLookup(ByVal ngsPostalCodeInput As ngsPostalCodeWSInput) As <System.Xml.Serialization.XmlElementAttribute("ngsPostalCodeLookupResult")> ngsPostalCodeWSOutput
            Dim results() As Object = Me.Invoke("CallngsPostalCodeLookup", New Object() {ngsPostalCodeInput})
            Return CType(results(0), ngsPostalCodeWSOutput)
        End Function

        '''<remarks/>
        Public Overloads Sub CallngsPostalCodeLookupAsync(ByVal ngsPostalCodeInput As ngsPostalCodeWSInput)
            Me.CallngsPostalCodeLookupAsync(ngsPostalCodeInput, Nothing)
        End Sub

        '''<remarks/>
        Public Overloads Sub CallngsPostalCodeLookupAsync(ByVal ngsPostalCodeInput As ngsPostalCodeWSInput, ByVal userState As Object)
            If (Me.CallngsPostalCodeLookupOperationCompleted Is Nothing) Then
                Me.CallngsPostalCodeLookupOperationCompleted = AddressOf Me.OnCallngsPostalCodeLookupOperationCompleted
            End If
            Me.InvokeAsync("CallngsPostalCodeLookup", New Object() {ngsPostalCodeInput}, Me.CallngsPostalCodeLookupOperationCompleted, userState)
        End Sub

        Private Sub OnCallngsPostalCodeLookupOperationCompleted(ByVal arg As Object)
            If (Not (Me.CallngsPostalCodeLookupCompletedEvent) Is Nothing) Then
                Dim invokeArgs As System.Web.Services.Protocols.InvokeCompletedEventArgs = CType(arg, System.Web.Services.Protocols.InvokeCompletedEventArgs)
                RaiseEvent CallngsPostalCodeLookupCompleted(Me, New CallngsPostalCodeLookupCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState))
            End If
        End Sub

        '''<remarks/>
        Public Shadows Sub CancelAsync(ByVal userState As Object)
            MyBase.CancelAsync(userState)
        End Sub

        Private Function IsLocalFileSystemWebService(ByVal url As String) As Boolean
            If ((url Is Nothing) _
                        OrElse (url Is String.Empty)) Then
                Return False
            End If
            Dim wsUri As System.Uri = New System.Uri(url)
            If ((wsUri.Port >= 1024) _
                        AndAlso (String.Compare(wsUri.Host, "localHost", System.StringComparison.OrdinalIgnoreCase) = 0)) Then
                Return True
            End If
            Return False
        End Function
    End Class

    '''<remarks/>
    <System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30319.233"), _
     System.SerializableAttribute(), _
     System.Diagnostics.DebuggerStepThroughAttribute(), _
     System.ComponentModel.DesignerCategoryAttribute("code"), _
     System.Xml.Serialization.XmlTypeAttribute([Namespace]:="http://www.west.com/COS/Core/ngsPostalCode/")> _
    Partial Public Class ngsPostalCodeWSInput

        Private postalCodeField As String

        '''<remarks/>
        Public Property PostalCode() As String
            Get
                Return Me.postalCodeField
            End Get
            Set(value As String)
                Me.postalCodeField = value
            End Set
        End Property
    End Class

    '''<remarks/>
    <System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30319.233"), _
     System.SerializableAttribute(), _
     System.Diagnostics.DebuggerStepThroughAttribute(), _
     System.ComponentModel.DesignerCategoryAttribute("code"), _
     System.Xml.Serialization.XmlTypeAttribute([Namespace]:="http://www.west.com/COS/Core/ngsPostalCode/")> _
    Partial Public Class ngsPostalCode

        Private countryNameField As String

        Private postalCodeField As String

        Private postalTypeField As String

        Private cityNameField As String

        Private cityTypeField As String

        Private countyNameField As String

        Private countyFIPSField As String

        Private provinceNameField As String

        Private provinceAbbrField As String

        Private stateFIPSField As String

        Private mSACodeField As String

        Private areaCodeField As String

        Private timeZoneField As String

        Private uTCField As Decimal

        Private dSTField As String

        Private latitudeField As Decimal

        Private longitudeField As Decimal

        '''<remarks/>
        Public Property CountryName() As String
            Get
                Return Me.countryNameField
            End Get
            Set(value As String)
                Me.countryNameField = value
            End Set
        End Property

        '''<remarks/>
        Public Property PostalCode() As String
            Get
                Return Me.postalCodeField
            End Get
            Set(value As String)
                Me.postalCodeField = value
            End Set
        End Property

        '''<remarks/>
        Public Property PostalType() As String
            Get
                Return Me.postalTypeField
            End Get
            Set(value As String)
                Me.postalTypeField = value
            End Set
        End Property

        '''<remarks/>
        Public Property CityName() As String
            Get
                Return Me.cityNameField
            End Get
            Set(value As String)
                Me.cityNameField = value
            End Set
        End Property

        '''<remarks/>
        Public Property CityType() As String
            Get
                Return Me.cityTypeField
            End Get
            Set(value As String)
                Me.cityTypeField = value
            End Set
        End Property

        '''<remarks/>
        Public Property CountyName() As String
            Get
                Return Me.countyNameField
            End Get
            Set(value As String)
                Me.countyNameField = value
            End Set
        End Property

        '''<remarks/>
        Public Property CountyFIPS() As String
            Get
                Return Me.countyFIPSField
            End Get
            Set(value As String)
                Me.countyFIPSField = value
            End Set
        End Property

        '''<remarks/>
        Public Property ProvinceName() As String
            Get
                Return Me.provinceNameField
            End Get
            Set(value As String)
                Me.provinceNameField = value
            End Set
        End Property

        '''<remarks/>
        Public Property ProvinceAbbr() As String
            Get
                Return Me.provinceAbbrField
            End Get
            Set(value As String)
                Me.provinceAbbrField = value
            End Set
        End Property

        '''<remarks/>
        Public Property StateFIPS() As String
            Get
                Return Me.stateFIPSField
            End Get
            Set(value As String)
                Me.stateFIPSField = value
            End Set
        End Property

        '''<remarks/>
        Public Property MSACode() As String
            Get
                Return Me.mSACodeField
            End Get
            Set(value As String)
                Me.mSACodeField = value
            End Set
        End Property

        '''<remarks/>
        Public Property AreaCode() As String
            Get
                Return Me.areaCodeField
            End Get
            Set(value As String)
                Me.areaCodeField = value
            End Set
        End Property

        '''<remarks/>
        Public Property TimeZone() As String
            Get
                Return Me.timeZoneField
            End Get
            Set(value As String)
                Me.timeZoneField = value
            End Set
        End Property

        '''<remarks/>
        Public Property UTC() As Decimal
            Get
                Return Me.uTCField
            End Get
            Set(value As Decimal)
                Me.uTCField = value
            End Set
        End Property

        '''<remarks/>
        Public Property DST() As String
            Get
                Return Me.dSTField
            End Get
            Set(value As String)
                Me.dSTField = value
            End Set
        End Property

        '''<remarks/>
        Public Property Latitude() As Decimal
            Get
                Return Me.latitudeField
            End Get
            Set(value As Decimal)
                Me.latitudeField = value
            End Set
        End Property

        '''<remarks/>
        Public Property Longitude() As Decimal
            Get
                Return Me.longitudeField
            End Get
            Set(value As Decimal)
                Me.longitudeField = value
            End Set
        End Property
    End Class

    '''<remarks/>
    <System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30319.233"), _
     System.SerializableAttribute(), _
     System.Diagnostics.DebuggerStepThroughAttribute(), _
     System.ComponentModel.DesignerCategoryAttribute("code"), _
     System.Xml.Serialization.XmlTypeAttribute([Namespace]:="http://www.west.com/COS/Core/ngsPostalCode/")> _
    Partial Public Class ngsPostalCodeWSOutput

        Private replyCodeField As Integer

        Private replyMsgField As String

        Private ngsPostalCodeField As ngsPostalCode

        '''<remarks/>
        Public Property ReplyCode() As Integer
            Get
                Return Me.replyCodeField
            End Get
            Set(value As Integer)
                Me.replyCodeField = value
            End Set
        End Property

        '''<remarks/>
        Public Property ReplyMsg() As String
            Get
                Return Me.replyMsgField
            End Get
            Set(value As String)
                Me.replyMsgField = value
            End Set
        End Property

        '''<remarks/>
        Public Property ngsPostalCode() As ngsPostalCode
            Get
                Return Me.ngsPostalCodeField
            End Get
            Set(value As ngsPostalCode)
                Me.ngsPostalCodeField = value
            End Set
        End Property
    End Class

    '''<remarks/>
    <System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30319.1")> _
    Public Delegate Sub CallngsPostalCodeLookupCompletedEventHandler(ByVal sender As Object, ByVal e As CallngsPostalCodeLookupCompletedEventArgs)

    '''<remarks/>
    <System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30319.1"), _
     System.Diagnostics.DebuggerStepThroughAttribute(), _
     System.ComponentModel.DesignerCategoryAttribute("code")> _
    Partial Public Class CallngsPostalCodeLookupCompletedEventArgs
        Inherits System.ComponentModel.AsyncCompletedEventArgs

        Private results() As Object

        Friend Sub New(ByVal results() As Object, ByVal exception As System.Exception, ByVal cancelled As Boolean, ByVal userState As Object)
            MyBase.New(exception, cancelled, userState)
            Me.results = results
        End Sub

        '''<remarks/>
        Public ReadOnly Property Result() As ngsPostalCodeWSOutput
            Get
                Me.RaiseExceptionIfNecessary()
                Return CType(Me.results(0), ngsPostalCodeWSOutput)
            End Get
        End Property
    End Class
End Namespace
