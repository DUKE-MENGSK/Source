﻿Public Class ScriptPathAttribute
    'To allow for ScriptPath. type intellisence make each script path a property
    Public Property PathDescription As String
    Public Property Level As String
    Public Property FirstPanel As String
    Public Property FirstPanelPrefix As String
    Public Property ScriptAvailable As String
    Public Property IsLogging As Boolean
    'Public Property SaveScrollPos As Boolean
    Public Property RestartPath As Boolean
    Public Property CollapsedOnStartup As Boolean




    Public Sub New(ByVal pathDescription As String, ByVal level As String, ByVal firstPanel As String, ByVal firstPanelPrefix As String, ByVal scriptAvailable As String, ByVal isLogging As Boolean, ByVal restartPath As Boolean, ByVal collapsedOnStartup As Boolean)
        'Assign the properties for the new script path.
        Me.PathDescription = pathDescription
        Me.Level = level
        Me.FirstPanel = firstPanel
        Me.FirstPanelPrefix = firstPanelPrefix
        Me.ScriptAvailable = scriptAvailable
        Me.IsLogging = isLogging
        'Me.SaveScrollPos = saveScrollPos
        Me.RestartPath = restartPath
        Me.CollapsedOnStartup = collapsedOnStartup
    End Sub
End Class

Public Class BaseScriptPath

    'Hold the list of scriptpaths
    Protected scriptPathList As Dictionary(Of String, ScriptPathAttribute)

    Public Sub New()
        scriptPathList = New Dictionary(Of String, ScriptPathAttribute)
    End Sub

    Public Function GetDescription(ByVal scriptPath As String) As String
        Return scriptPathList(scriptPath).PathDescription
    End Function
    Public Function IsLogging(ByVal scriptPath As String) As Boolean
        Return scriptPathList(scriptPath).IsLogging
    End Function
    Public Function GetScriptAvailable(ByVal scriptPath As String) As String
        Return scriptPathList(scriptPath).ScriptAvailable
    End Function
    Public Function GetLevel(ByVal scriptPath As String) As String
        Return scriptPathList(scriptPath).Level
    End Function
    Public Function GetFirstPanel(ByVal scriptPath As String) As String
        Return scriptPathList(scriptPath).FirstPanel
    End Function
    Public Function GetFirstPanelWithExtension(ByVal scriptPath As String) As String
        Return String.Format("{0}.aspx", scriptPathList(scriptPath).FirstPanel)
    End Function
    Public Function GetFirstPanelPath(ByVal scriptPath As String) As String
        If String.IsNullOrWhiteSpace(scriptPathList(scriptPath).FirstPanelPrefix) Then
            'Unknown prefix, assume its in panels/not a sub directory.
            Return String.Format("panels/{0}.aspx", scriptPathList(scriptPath).FirstPanel)
        Else
            Return String.Format("panels/{0}/{1}.aspx", scriptPathList(scriptPath).FirstPanelPrefix, scriptPathList(scriptPath).FirstPanel)
        End If
    End Function
    'Public Function SaveScrollPos(ByVal scriptPath As String) As Boolean
    '    Return scriptPathList(scriptPath).SaveScrollPos
    'End Function
    Public Function RestartPath(ByVal scriptPath As String) As Boolean
        Return scriptPathList(scriptPath).RestartPath
    End Function
    Public Function CollapsedOnStartup(ByVal scriptPath As String) As Boolean
        Return scriptPathList(scriptPath).CollapsedOnStartup
    End Function
    Public Function GetPathIdByFirstPanel(ByVal pFirstPanel As String) As String
        Dim pathId As String = ""
        For Each kvp As KeyValuePair(Of String, ScriptPathAttribute) In scriptPathList
            If pFirstPanel.ToLower = kvp.Value.FirstPanel.ToLower Then
                pathId = kvp.Key
                Exit For
            End If
        Next
        'Return either found pathid or ""
        Return pathId
    End Function

End Class
