﻿Public Class RequestPostalCodeInfoFromNGS
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '********************************************************************************************************
        'Page Name: RequestPostalCodeInfoFromNGS
        'Description: Instantiates an NGSOperations.PostalCodeLookup webrequest and uses it to get the city, state, canada flag, and
        '			  area code for a given zip code then returns the data in a string to the caller. 
        '             Used by the Inbound address scriptlets ACSZNGS.ascx, CSZNGS.ascx, NACSZNGS.ascx, and NACSZPNGS.ascx from the client side.
        'QueryString Parameters: zip - the zipcode to look up, scriptenvironment - the script environment for the soap call, 
        'Returns: a ~ delimited string containing city, state, area code in that order
        'History
        'Date			Developer		Description
        '--------------------------------------------------------------------------------------------------------
        '1/15/2010		systxb			Created for NGS Calls.
        '********************************************************************************************************
        Try
            'zipcode from query
            Dim myZipCode As String

            'TESTING values......
            'myZipCode = "51104"
            'myZipCode = "A1A1A1"
            'Dim myScriptEnvironment As String = "QA"
            'Dim myURLOverride As String = ""
            'Dim myURLOverride As String = "http://oma11cdevsql02/ngspostalcodelookup/ngspostalcodelookup.asmx"
            'Dim myTimeout As String = ""
            'Dim myRetries As String = "A"
            'END OF TESTING HARDCODE VALUES....

            'PRODUCTION VALUES from Query String....
            myZipCode = Request.QueryString("zip")

            '        Response.ContentType = "text/html"

            If myZipCode = Nothing Then
                Response.StatusCode = 544
                Response.Write("No Zipcode was supplied to the RequestPostalCodeInfoFromNGS.aspx Page!" & "~")
                'Response.End()
                Exit Sub
            End If

            If myZipCode.Trim.Length = 0 Then
                Response.StatusCode = 544
                Response.Write("No Zipcode was supplied to the RequestPostalCodeInfoFromNGS.aspx Page!" & "~")
                'Response.End()
                Exit Sub
            End If

            'validate the incoming zipcode...
            Dim rxZip As New System.Text.RegularExpressions.Regex("(^\d{5}$)|(^([a-zA-Z]\d){3}$)")

            If (Not rxZip.Match(myZipCode).Success) Then
                Response.StatusCode = 544
                Response.Write("Invalid Zip or Postal Code!  United States zip codes must be 5 numbers only and Canadian postal codes must be in the format of FSA (Forward Sortation Area -> alpha-numeric-alpha), LDU (Local Delivery Unit -> 3 alpha numeric chars), ie. A1A1A1)." & "~")
                'Response.End()
                Exit Sub
            End If

            'Script Environment value
            Dim myScriptEnvironment As String = Request.QueryString("scriptenvironment")

            'override the timeout?
            Dim myTimeout As String = Request.QueryString("timeoutoverride")
            Dim myTimeoutValue As Integer
            If myTimeout = Nothing Then
                myTimeoutValue = 0
            ElseIf myTimeout.Trim.Length = 0 Then
                myTimeoutValue = 0
            Else
                myTimeoutValue = CInt(myTimeout)
            End If

            'get the number of retries for the soap retries... default to 2 retries
            Dim myRetries As String = Request.QueryString("numretries")
            If myRetries Is Nothing Then
                myRetries = "2"
            ElseIf myRetries.Trim.Length = 0 Then
                myRetries = "2"
            ElseIf Not (IsNumeric(myRetries)) Then
                myRetries = "2"
            End If

            'get the URL override from querystring
            Dim myURLOverride As String = Request.QueryString("urloverride")
            If myURLOverride Is Nothing Then
                myURLOverride = ""
            End If

            Dim myReturnStr As String = PostalCodeLookup(myZipCode, myScriptEnvironment, myURLOverride, myTimeoutValue, CInt(myRetries))
            If myReturnStr.StartsWith("Error") Then
                Response.StatusCode = 500
                Response.Write(myReturnStr & "~")
            ElseIf myReturnStr.StartsWith("998~") Then
                Response.StatusCode = 998
                Response.Write(myReturnStr.Substring(4) & "~")
            Else
                Response.Write(myReturnStr & "~")
            End If

        Catch ex As Exception
            Response.StatusCode = 500
            Response.Write(ex.ToString & "~")
            Exit Sub
        End Try
    End Sub
    Protected Function PostalCodeLookup(ByVal pZipCode As String, ByVal pScriptEnvironment As String, ByVal pUrlOverride As String, ByVal pTimeoutOverride As Integer, Optional ByVal pNumRetry As Integer = 1) As String
        Try

            Dim myZipRequest As New USERCONTROLS.PostalCodeLookup
            Dim myReplyMsg As DataSet

            myZipRequest.ZipCode = pZipCode
            myZipRequest.OverrideURL = pUrlOverride
            myZipRequest.ScriptEnvironment = pScriptEnvironment
            myZipRequest.Retries = pNumRetry

            myZipRequest.TimeoutValue = pTimeoutOverride

            myReplyMsg = myZipRequest.PerformPostalCodeLookup()

            Return (ParseReply(myReplyMsg))

        Catch ex As Exception
            Return ("Error: " & ex.ToString)
        End Try
    End Function

    Public Function ParseReply(ByVal pDS As DataSet) As String
        Try

            'only need to return city, state, areacode, and canada flag to the scriptlets
            Dim dtInput As DataTable = pDS.Tables("ReplyMessage")

            If Not dtInput Is Nothing Then

                Dim mydr As DataRow

                'check reply code
                mydr = dtInput.Rows.Find("ReplyCode")

                If Not mydr Is Nothing Then
                    If (mydr("Value") = 0) Or (mydr("Value") = 998) Then
                        'reply code is 0, continue...
                        Dim mysb As New System.Text.StringBuilder(1000)
                        Dim strItems() As String = {"CityName", "ProvinceAbbr", "AreaCode", "CountryName"}

                        If mydr("Value") = 998 Then
                            'add the reply code of 998 to the front of the sb
                            mysb.Append("998~")
                        End If

                        For Each strItem As String In strItems
                            mydr = dtInput.Rows.Find(strItem)

                            If Not mydr Is Nothing Then
                                If strItem = "CountryName" Then
                                    If mydr("Value").ToString.ToLower = "can" Then
                                        mysb.Append("C")
                                    Else
                                        mysb.Append("")
                                    End If
                                Else
                                    mysb.Append(mydr("Value")).Append("~")
                                End If
                            End If
                        Next
                        Return (mysb.ToString)
                    Else
                        'reply code not 0, error...
                        Dim mydr2 = dtInput.Rows.Find("ReplyMessage")

                        If Not mydr2 Is Nothing Then
                            Return ("Error: " & mydr2("Value"))
                        Else
                            Return ("Error:  No reply message was returned from the postal code lookup.")
                        End If
                    End If
                Else
                    Return ("Error:  No reply code was returned from the postal code lookup.")
                End If
            Else
                Return ("Error:  The reply dataset did not include table called ReplyMessage.")
            End If

        Catch ex As Exception
            Return ("Error: " & ex.ToString)
        End Try
    End Function

End Class
