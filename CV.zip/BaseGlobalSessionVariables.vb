﻿Friend Class BaseGlobalSessionVariables
    Public Sub New()
    End Sub
End Class
