﻿Namespace SLSharedLib
    Friend Class BaseSLVariables
    End Class
End Namespace
